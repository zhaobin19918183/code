//
//  MyProcketModel.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MyProcketModel.h"

@implementation MyProcketModel

@end
