//
//  MyPockerDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MyPockerDetailViewController.h"
#import "DetailViewController.h"
#import "PhotoDetailTableViewCell.h"
#import "AnimationModel.h"
#import "MyPocketDetailCell.h"
@interface MyPockerDetailViewController ()
{
    BaseLabel *titleLabel;
    BaseLabel *lineLabel;
    BaseLabel *contentLabel;
    BaseImageView *imageView;
    NSMutableDictionary *dataDic;
    
    BaseTextView *contentTextView;
    BaseImageView *backImageView;
    BaseTableView *animationTableView;
    NSMutableArray *dataModelArray;
    
    CGRect cellImageFrame;
    
    NSString *shareImageStr;
}

@end
/**
 * 機能名　　　　：MyPocket
 * 機能概要　　　：MyPocketリストを選択すると表示される画面  DBに取得保持済みのMyPocket情報を取得して詳細表示  使用ボタンにより消化
 * 作成者    　 ：趙ビン　2017/08/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation MyPockerDetailViewController
-(void)viewDidDisappear:(BOOL)animated
{
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:SSBP_NOTIFICATION_ID];
}
-(void)viewWillAppear:(BOOL)animated
{

    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *contentID = [defaults objectForKey:SSBP_NOTIFICATION_ID];
    if (contentID!=nil) {
        TSsbpContent* conten = [[SSBPContentIF sharedInstance] getInnerContent:contentID];
        self.content = conten;
        [animationTableView reloadData];
    }
    
}
-(void)backBtn
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *contentID = [defaults objectForKey:SSBP_NOTIFICATION_ID];
    if (contentID== nil)
    {
         [[NSNotificationCenter defaultCenter]postNotificationName:@"pocket" object:nil];
    }
    else
    {
      [[NSNotificationCenter defaultCenter]postNotificationName:@"home" object:nil];
    }

}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.shareBut.hidden = YES;
    [self.pocketButton setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    self.bottomView.backgroundColor =[UIColor whiteColor];
    NSMutableDictionary * dict = [NSMutableDictionary dictionary];
    [dict setValue:@"MyPocket お知らせ" forKey:@"rel_url_label"];
    [dict setValue:@"color" forKey:@"rel_url_ios"];
 
    [self CreatBottomViewSubviews:dict];
    self.linkBut.backgroundColor = [UIColor colorWithRed:204/255.0 green:67/255.0 blue:0 alpha:1];
    [self.linkBut setText:@"MyPocket お知らせ" textColor:BaseButtonWhite];
    [self CreatTableview];
    [self navigationBar];
    [self detailData];
 
}

//共有ボタンクリックイベント
-(void)pocketButtonClick{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:self.content.contentImageUrl forKey:@"image"];
    [dic setValue:self.content.contentTitle forKey:@"title"];
    [NetWorkManager setShareInfoDic:dic];
}

-(void)BottomViewButtonClick:(UIButton *)button dic:(NSDictionary *)dic
{
    DetailViewController *detailView = [[DetailViewController alloc]init];
    detailView.content =self.content;
    [self.navigationController pushViewController:detailView animated:YES];
}
/**
 * 機能名　　　　：MyPocketの詳細は
 * 機能概要　　　： MyPocketリストを選択すると表示される画面  DBに取得保持済みのMyPocket情報を取得して詳細表示  使用ボタンにより消化

 * 作成者    　 ：趙ビン　2017/07/18
 ***********************************************************************
 ***********************************************************************
 */

-(void)CreatTableview
{
    //creat tableview
    animationTableView = [[BaseTableView alloc]init];
    animationTableView.frame = CGRectMake(0, 0,Screen_W , Screen_H- 64 - YSpan(75));
    animationTableView.delegate = self;
    animationTableView.dataSource = self;
    [self.view addSubview:animationTableView];
    animationTableView.separatorStyle = UITableViewCellStyleDefault;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuse = @"reuse";
    MyPocketDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[MyPocketDetailCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
     self.title = self.content.contentTitle;
    cell.celltag = 0;
    cell.imgView.userInteractionEnabled = YES;
    [cell.imgView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickImageView:)]];
    [cell setTsDeatilcontent:self.content];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return Screen_H;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
#pragma mark - delegate
-(void)getImage:(NSString *)image{
    shareImageStr = image;
}
- (void)clickImageView:(UITapGestureRecognizer *)tap
{
    AmplifyView *amplifyView = [[AmplifyView alloc] initWithFrame:self.view.bounds andGesture:tap andSuperView:self.view];
    [[UIApplication sharedApplication].keyWindow addSubview:amplifyView];
}
//表のセルの高さをリフレッシュ
-(void)refreshTableView:(float)cellHeight imageViewHeight:(CGRect)imageFrame{
 
  //  [animationTableView reloadData];
}

/**
 * 機能名　　　　：写真
 * 機能概要　　　：基礎配置
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
-(void)layoutView
{

    backImageView = [[BaseImageView alloc]init];
    backImageView.frame = customCGRect(10, 100, 355, 200);
    backImageView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:backImageView];
    contentTextView = [[BaseTextView alloc]init];
    contentTextView.frame = customCGRect(10, backImageView.bounds.size.height + 110,  [UIScreen mainScreen].bounds.size.width-20, backImageView.bounds.size.height);
    contentTextView.backgroundColor = [UIColor clearColor];
    contentTextView.textColor = [UIColor whiteColor];
    contentTextView.editable = NO;
    [self.view addSubview:contentTextView];
 
}
/**
 * 機能名　　　　：写真の詳細は
 * 機能概要　　　：データのページ。
 * 作成者    　 ：趙ビン　2017/07/18
 ***********************************************************************
 ***********************************************************************
 */

-(void)detailData
{
}

-(void)navigationBar
{
}

-(void)backViewcontroller
{
    [self.navigationController popViewControllerAnimated:YES];
}


@end
