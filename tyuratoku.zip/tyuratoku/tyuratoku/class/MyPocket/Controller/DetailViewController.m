//
//  DetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "DetailViewController.h"
#import "MyPocketDetailCell.h"
@interface DetailViewController ()
{
    BaseLabel *titleLabel;
    BaseLabel *lineLabel;
    BaseLabel *contentLabel;
    BaseImageView *imageView;
    NSMutableDictionary *dataDic;
    
    BaseTextView *contentTextView;
    BaseImageView *backImageView;
    BaseTableView *animationTableView;
    NSMutableArray * dataModelArray;
    BaseButton *aleartButton;
    
    CGRect cellImageFrame;
    
}


@end
/**
 * 機能名　　　　：MyPocket
 * 機能概要　　　：MyPocketリストを選択すると表示される画面  DBに取得保持済みのMyPocket情報を取得して詳細表示  使用ボタンにより消化
 * 作成者    　 ：趙ビン　2017/08/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation DetailViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self bottomV];
    [self CreatTableview];
    [self navigationBar];
    [self detailData];

}
-(void)bottomV
{
    //>画面を提示し、店員に操作してもらってください
    self.shareBut.hidden = YES;
    [self.pocketButton setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    NSMutableDictionary * dict = [NSMutableDictionary dictionary];
    [dict setValue:@"MyPocket お知らせ" forKey:@"rel_url_label"];
    [dict setValue:@"color" forKey:@"rel_url_ios"];
    [self CreatBottomViewSubviews:dict];
    
    BaseLabel *titlelabel =[[BaseLabel alloc]init];
    [titlelabel setText:@"画面を提示し、店員に操作してもらってください" textAlignment:BaseLabelCenter];
    [titlelabel setTextFont:12 textColor:BaseLabelGray];
    titlelabel.frame = customCGRect(40, 0, 295, 10);
    [self.bottomView addSubview:titlelabel];
    
    self.linkBut.frame = customCGRect(40, 12, 295, 45);
    [self.linkBut setText:@"MyPocket お知らせ" textColor:BaseButtonWhite];
    self.dateLabel =[[BaseLabel alloc]init];
    [self.dateLabel setTextFont:12 textColor:BaseLabelBlack];
    self.dateLabel.frame =CGRectMake(YSpan(self.linkBut.frame.origin.x), self.linkBut.frame.origin.y + self.linkBut.frame.size.height +5 *KHEIGHT, self.linkBut.frame.size.width, 10*KHEIGHT);
    [self.bottomView addSubview:self.dateLabel];
    
    self.linkBut.backgroundColor = [UIColor colorWithRed:1/255.0 green:86/255.0 blue:102/255.0 alpha:1];
    self.bottomView.backgroundColor =[UIColor whiteColor];
    if ([self.content.contentLimitType isEqualToString:@"1"]) {
        NSString *dateStrEnd = [NSString stringWithFormat:@"%@",self.content.contentEndAt];
        dateStrEnd =  [dateStrEnd substringToIndex:10];
        NSString *dateStrSatrt = [NSString stringWithFormat:@"%@",self.content.contentStartAt];
        dateStrSatrt= [dateStrSatrt substringToIndex:10];
        [self.dateLabel setText:[NSString stringWithFormat:@"有効期間 %@ %@",dateStrSatrt,dateStrEnd] textAlignment:BaseLabelCenter];
    }
    if ([self.content.contentLimitType isEqualToString:@"2"]) {
        NSString *dateStrEnd = [NSString stringWithFormat:@"%@",self.content.contentEndAt];
        dateStrEnd =  [dateStrEnd substringToIndex:16];
        [self.dateLabel setText:[NSString stringWithFormat:@"有効期間 %@",dateStrEnd] textAlignment:BaseLabelCenter];
    }
    if ([self.content.contentLimitType isEqualToString:@"3"])
    {
        [self.dateLabel setText:@"1回限り有効" textAlignment:BaseLabelCenter];
    }
  
    if (self.content.status == 1)
    {
        [self.linkBut setTitle:@"使用済み" forState:UIControlStateNormal];
        self.linkBut.backgroundColor =[UIColor grayColor];
        self.linkBut.userInteractionEnabled = NO;
    }
}
-(void)detailbutton
{
    
    BaseLabel *dateLabel = [[BaseLabel alloc]init];
    dateLabel.frame = customCGRect(80, 550, 215, 20);
    [dateLabel setText:@"有効期間" textAlignment:BaseLabelCenter];
    [dateLabel setTextFont:13 textColor:BaseLabelBlack];
    [self.view addSubview:dateLabel];
    
    BaseButton *detailButton = [[BaseButton alloc]init];
    detailButton.layer.cornerRadius = 10.0;
    [detailButton setText:@"MyPocket お知らせ" textColor:BaseButtonWhite];
    detailButton.frame = customCGRect(80, 490, 215, 50);
    detailButton.backgroundColor = [UIColor colorWithRed:1/255.0 green:86/255.0 blue:102/255.0 alpha:1];

    [self.view addSubview:detailButton];
    
}
-(void)detail
{
    DetailViewController *detailView = [[DetailViewController alloc]init];
    [self.navigationController pushViewController:detailView animated:YES];
}
/**
 * 機能名　　　　：写真の詳細は
 * 機能概要　　　：創建ui
 * 作成者    　 ：趙ビン　2017/08/18
 ***********************************************************************
 ***********************************************************************
 */
-(void)CreatTableview
{
    //creat tableview
    animationTableView = [[BaseTableView alloc]init];
    animationTableView.frame =CGRectMake(0, 0,Screen_W , Screen_H- 64 - YSpan(75));
    animationTableView.delegate = self;
    animationTableView.dataSource = self;
    [self.view addSubview:animationTableView];
    animationTableView.separatorStyle = UITableViewCellStyleDefault;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return Screen_H;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuse = @"reuse";
    MyPocketDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[MyPocketDetailCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    self.title = self.content.contentTitle;
    aleartButton = cell.detailButton;
    cell.detailButton.tag = [self.content.contentType integerValue];
    cell.celltag = 1;
    cell.dateLabel.hidden = YES;
    [cell setTsDeatilcontent:self.content];
 
    return cell;
}

-(void)BottomViewButtonClick:(UIButton *)button dic:(NSDictionary *)dic
{

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@""message:@"Pocketを使用しますか？"preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:alert animated:YES completion:nil];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDestructive handler:^(UIAlertAction*action) {
        [button setTitle:@"使用済み" forState:UIControlStateNormal];
        button.backgroundColor =[UIColor grayColor];
        
        if (![self.content.contentType isEqualToString:@"4"])
        {
            self.content.status = 1;
            [[SSBPSdkIF sharedInstance] removeContent:self.content.contentId];
                       
        }
        else
        {
            [self useDB];
        }
        if (self.navigationController.viewControllers.count <= 1) {
            [self dismissViewControllerAnimated:true completion:nil];
        } else {
            [self.navigationController popViewControllerAnimated:true];
        }
        
        
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancle" style:UIAlertActionStyleCancel handler:^(UIAlertAction*action)
                      {

                          
                      }]];
}

- (void)useDB {
    @autoreleasepool {
        BOOL chk = [[SSBPSdkIF sharedInstance] useContent:self.content.contentId];
        if (chk) {
            self.content.status =1;
            [self setStatus];
        }
    }
}
- (void)setStatus {
    if (self.content.status != 1)
    {
        [aleartButton setEnabled:true];
    } else {
        [aleartButton setEnabled:false];
    }
}

        
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (void)clickImageView:(UITapGestureRecognizer *)tap
{
    AmplifyView *amplifyView = [[AmplifyView alloc] initWithFrame:self.view.bounds andGesture:tap andSuperView:self.view];
    [[UIApplication sharedApplication].keyWindow addSubview:amplifyView];
}
//表のセルの高さをリフレッシュ
-(void)refreshTableView:(float)cellHeight imageViewHeight:(CGRect)imageFrame{
    PhotoModel *model = dataModelArray[0];
    model.cellHeight = cellHeight;
    cellImageFrame = imageFrame;
    [animationTableView reloadData];
}

/**
 * 機能名　　　　：写真
 * 機能概要　　　：基礎配置
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
-(void)layoutView
{

    backImageView = [[BaseImageView alloc]init];
    backImageView.frame = customCGRect(10, 100, 355, 200);
    backImageView.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:backImageView];
    
    contentTextView = [[BaseTextView alloc]init];
    contentTextView.frame = customCGRect(10, backImageView.bounds.size.height + 110,  [UIScreen mainScreen].bounds.size.width-20, backImageView.bounds.size.height);
    contentTextView.backgroundColor = [UIColor clearColor];
    
    contentTextView.textColor = [UIColor whiteColor];
    contentTextView.editable = NO;
    
    [self.view addSubview:contentTextView];
    
    
}
/**
 * 機能名　　　　：写真の詳細は
 * 機能概要　　　：データのページ。
 * 作成者    　 ：趙ビン　2017/07/18
 ***********************************************************************
 ***********************************************************************
 */

-(void)detailData
{
}

-(void)navigationBar
{
    
}

//共有ボタンクリックイベント
-(void)pocketButtonClick{

    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:self.content.contentImageUrl forKey:@"image"];
    [dic setValue:self.content.contentTitle forKey:@"title"];
    [NetWorkManager setShareInfoDic:dic];
}


-(void)backViewcontroller
{
    [self.navigationController popViewControllerAnimated:YES];
}


@end
