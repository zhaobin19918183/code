//
//  MyPocketViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MyPocketViewController.h"
#import "BasePocketTableViewCell.h"
#import "MyPockerDetailViewController.h"
#import "AppDelegate.h"
#define UIKitLocalizedString(key) [[NSBundle bundleWithIdentifier:@"com.apple.UIKit"] localizedStringForKey:key value:@"" table:nil]
@interface MyPocketViewController ()
{

    NSMutableArray *imageArray;
    NSMutableArray *backImageArray;
    NSString *imageString ;
    NSMutableArray *dataArray;
     NSArray* Coupons;
    NSString *isSelect;
    BaseButton *button;
}
@end
/**
 * 機能名　　　　：MyPocket
 * 機能概要　　　：MyPocketメニューを選択すると表示される画面
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation MyPocketViewController
- (void)viewWillAppear:(BOOL)animated {
    // OK/MyPocketへ移動/内容確認
    [super viewWillAppear:animated];
    [self loadDB];
  

}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadDB];
    [SSBPSdkIF sharedInstance].delegateIF = self;
    [self layoutView];
    self.view.backgroundColor =[UIColor whiteColor];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addnotice:) name:@"pocketcontent" object:nil];
    [self.tableView reloadData];
}

-(void)addnotice:(NSNotification *)sender
{
    if (sender.object !=nil)
    {
        isSelect = @"select";
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:isSelect forKey:@"select"];
        [self.tableView reloadData];
    
    }else
    {
    
     [self loadDB];
    }

}

- (void)ssbpSdkIFDidFailCheckMaster {
  [SSBPSdkIF sharedInstance].delegateIF = nil;
}

- (void)ssbpScannerDidFinishCheckMaster {
     [SSBPSdkIF sharedInstance].delegateIF = nil;
}

/**
 * 機能名　　　　：MyPocket
 * 機能概要　　　：MyPocketメニューを選択すると表示される画面
 * 作成者    　 ：趙ビン　2017/07/18
 ***********************************************************************
 ***********************************************************************
 */
-(void)layoutView
{
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView =[[BaseTableView alloc]initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H - 110*KHEIGHT)];
    self.tableView.delegate = self;
    self.tableView.dataSource=self;
    self.tableView.separatorStyle = NO;
    self.tableView.backgroundColor = [UIColor whiteColor];

    [self.view addSubview:self.tableView];
   //
    imageArray = [[NSMutableArray alloc]initWithObjects:@"pocket_red",@"pocket_blue",@"pocket_gray",@"pocket_orange", nil];
 
}

- (void)loadDB {
    @autoreleasepool {
        Coupons = [[NSArray alloc]init];
        Coupons = [[SSBPContentIF sharedInstance] getInnerContents:@"pocket"];
        [_tableView reloadData];
//        [self NOData:Coupons];
    }
 
}

#pragma mark Info View

//SSBP
- (void)ssbpSdkIFAddContent:(NSString*)contentId
{
    TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:contentId];
    if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"pocket"]) {
        [self loadDB];
     
    }
}
//ヘッダー下にサブメニューが有り、Home及び設定以外のコンテンツへ遷移可能  SSBPを利用したビーコン検知に伴って取得されたPocketコンテンツをリスト表示
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{ 
    static NSString *cellIndetifier = @"cell";
    BasePocketTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[NSString stringWithFormat:@"%ld",(long)indexPath.row]];
    
    if (cell == nil) {
        cell = [[BasePocketTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIndetifier];
    }
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *firstName = [defaults objectForKey:@"select"];
    
    if (indexPath.row == 0&&[firstName isEqualToString:@"select"])
    {
        MyPockerDetailViewController *detail =[[MyPockerDetailViewController alloc]init];
        TSsbpContent* content = [Coupons objectAtIndex:0];
        detail.content= content;
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"pocketcontent" object:nil];
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"select"];
        [self.navigationController pushViewController:detail animated:YES];
    }
    
    TSsbpContent* content = [Coupons objectAtIndex:indexPath.row];
    NSInteger inde =[content.contentType integerValue];
    imageString = [NSString stringWithFormat:@"%@",[imageArray objectAtIndex:inde-1]];
    cell.backImageVIew.image =[UIImage imageNamed:imageString];
    [cell.titleLabel setText:content.contentTitle textAlignment:BaseLabelCenter];
    cell.contentTextView.text = content.contentSubTitle;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return Coupons.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return 180*KHEIGHT;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyPockerDetailViewController *detail =[[MyPockerDetailViewController alloc]init];
    TSsbpContent* content = [Coupons objectAtIndex:indexPath.row];
    detail.content= content;
    [self.navigationController pushViewController:detail animated:YES];

}

@end
