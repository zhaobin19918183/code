//
//  MyPocketDetailCell.h
//  Beautiful
//
//  Created by newland on 2017/8/24.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseDetailCell.h"
#import "MyProcketModel.h"
@interface MyPocketDetailCell : UITableViewCell
@property(nonatomic,strong)MyProcketModel  * model;
@property(nonatomic,strong)TSsbpContent* content;
@property(nonatomic,strong)BaseLabel *titleLabel;//title
@property (nonatomic,strong)UIScrollView *scrollView;//ScrollView
@property(nonatomic,strong)BaseImageView *imgView;//image
@property(nonatomic,strong)BaseLabel *contentOneLabel;//Picture above text
@property(nonatomic,strong)BaseLabel *contentTwoLabel;//Text below picture
@property(nonatomic,strong)BaseButton *playButton;
@property(nonatomic,strong)BaseLabel *dateLabel;
@property(nonatomic,strong)BaseButton *detailButton;
@property float cellHeight;
@property(nonatomic,assign)NSInteger celltag;

-(void)setTsDeatilcontent:(TSsbpContent *)model;
@end
