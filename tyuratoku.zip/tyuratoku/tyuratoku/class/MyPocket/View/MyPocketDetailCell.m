
//
//  MyPocketDetailCell.m
//  Beautiful
//
//  Created by newland on 2017/8/24.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MyPocketDetailCell.h"

@implementation MyPocketDetailCell

-(UIImage *) imageCompressForWidth:(UIImage *)sourceImage targetWidth:(CGFloat)defineWidth{

    UIImage *newImage = nil;

    CGSize imageSize = sourceImage.size;

    CGFloat width = imageSize.width;

    CGFloat height = imageSize.height;

    CGFloat targetWidth = defineWidth;

    CGFloat targetHeight = height / (width / targetWidth);

    CGSize size = CGSizeMake(targetWidth, targetHeight);

    CGFloat scaleFactor = 0.0;

    CGFloat scaledWidth = targetWidth;

    CGFloat scaledHeight = targetHeight;

    CGPoint thumbnailPoint = CGPointMake(0.0, 0.0);

    if(CGSizeEqualToSize(imageSize, size) == NO){

        CGFloat widthFactor = targetWidth / width;

        CGFloat heightFactor = targetHeight / height;

        if(widthFactor > heightFactor){

            scaleFactor = widthFactor;

        }

        else{

            scaleFactor = heightFactor;

        }

        scaledWidth = width * scaleFactor;

        scaledHeight = height * scaleFactor;

        if(widthFactor > heightFactor){

            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;

        }else if(widthFactor < heightFactor){

            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;

        }

    }

    UIGraphicsBeginImageContext(size);

    CGRect thumbnailRect = CGRectZero;

    thumbnailRect.origin = thumbnailPoint;

    thumbnailRect.size.width = scaledWidth;

    thumbnailRect.size.height = scaledHeight;

    [sourceImage drawInRect:thumbnailRect];

    newImage = UIGraphicsGetImageFromCurrentImageContext();

    if(newImage == nil){

        NSLog(@"scale image fail");

    }

    UIGraphicsEndImageContext();

    return newImage;

}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //
        self.titleLabel = [[BaseLabel alloc]init];
        [self.titleLabel setTextFont:16 textColor:BaseLabelBlue];
        self.titleLabel.textColor = customGreen;
        self.titleLabel.numberOfLines = 2;
        [self.contentView addSubview:self.titleLabel];
        
        self.scrollView = [[ UIScrollView alloc]init];
        [self.contentView addSubview:self.scrollView];
        
        self.imgView = [[BaseImageView alloc]init];
       
        [self.contentView addSubview:self.imgView];
        
        self.contentOneLabel = [[BaseLabel alloc]init];

        [self.contentView addSubview:self.contentOneLabel];
    
        self.contentTwoLabel = [[BaseLabel alloc]init];

        [self.contentView addSubview:self.contentTwoLabel];
        
        self.detailButton =[[BaseButton alloc]init];
       
//        _detailButton.layer.cornerRadius = 10.0;
//        [_detailButton setText:@"MyPocket お知らせ" textColor:BaseButtonWhite];
//        [self.contentView addSubview:self.detailButton];
       
            self.dateLabel =[[BaseLabel alloc]init];
            [self.dateLabel setTextFont:12 textColor:BaseLabelBlack];
            [self.contentView addSubview:self.dateLabel];
        
        
    }
    return self;
}

-(void)setTsDeatilcontent:(TSsbpContent *)model
{
   
    if (self.celltag == 1) {
        _detailButton.backgroundColor = [UIColor colorWithRed:1/255.0 green:86/255.0 blue:102/255.0 alpha:1];
      
    }
    else{
        self.detailButton.backgroundColor = [UIColor colorWithRed:204/255.0 green:67/255.0 blue:0 alpha:1];
    }
    self.titleLabel.frame = customCGRect(10, 10, 365, 45);
    [self.titleLabel setText:model.contentSubTitle textAlignment:BaseLabelLeft];
    [self.titleLabel autoLabelHeightFromString];
    
    
    [self.contentOneLabel setText:model.contentBody1 textAlignment:BaseLabelLeft];
    self.contentOneLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.titleLabel.frame)+YSpan(10), XSpan(355), YSpan(80));
    [self.contentOneLabel autoLabelHeightFromString];
    self.imgView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, 0);
    [self.contentTwoLabel setText:model.contentBody2 textAlignment:BaseLabelLeft];
    [self.contentTwoLabel setTextFont:14 textColor:BaseLabelBlack];
   
   
    [self.imgView sd_setImageWithURL:[NSURL URLWithString:model.contentImageUrl] placeholderImage:[UIImage imageNamed:@"demo"] options:SDWebImageRetryFailed completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL)
    {
        
       self.imgView.image = [self imageCompressForWidth:image targetWidth:Screen_W];
        CGSize size = self.imgView.image.size;
        CGFloat H = size.height;
        
        self.imgView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, H);
        
        self.contentTwoLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.imgView.frame)+YSpan(10), XSpan(355), YSpan(100));
        [self.contentTwoLabel autoLabelHeightFromString];
        if (self.celltag !=1)
        {
            self.dateLabel.frame = CGRectMake(XSpan(40), CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10), XSpan(300), YSpan(20));
            self.detailButton.frame = CGRectMake(XSpan(80), CGRectGetMaxY(self.dateLabel.frame)+YSpan(10), XSpan(215), YSpan(50));
        }
        else
        {
            
            self.detailButton.frame = CGRectMake(XSpan(80), CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10), XSpan(215), YSpan(50));
            self.dateLabel.frame = CGRectMake(XSpan(40), CGRectGetMaxY(self.detailButton.frame)+YSpan(10), XSpan(300), YSpan(20));
            
        }

        
    }];
    
    
    if ([model.contentLimitType isEqualToString:@"1"]) {
        NSString *dateStrEnd = [NSString stringWithFormat:@"%@",model.contentEndAt];
        dateStrEnd =  [dateStrEnd substringToIndex:10];
        NSString *dateStrSatrt = [NSString stringWithFormat:@"%@",model.contentStartAt];
        dateStrSatrt= [dateStrSatrt substringToIndex:10];
         [self.dateLabel setText:[NSString stringWithFormat:@"有効期間 %@ %@",dateStrSatrt,dateStrEnd] textAlignment:BaseLabelCenter];
    }
    if ([model.contentLimitType isEqualToString:@"2"]) {
        NSString *dateStrEnd = [NSString stringWithFormat:@"%@",model.contentEndAt];
        dateStrEnd =  [dateStrEnd substringToIndex:16];
        [self.dateLabel setText:[NSString stringWithFormat:@"有効期間 %@",dateStrEnd] textAlignment:BaseLabelCenter];
    }
    if ([model.contentLimitType isEqualToString:@"3"])
    {
        [self.dateLabel setText:@"1回限り有効" textAlignment:BaseLabelCenter];
    }
    self.cellHeight  =  self.detailButton.frame.origin.y;
   
   
}


@end
