//
//  PhotoDetailTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/8/10.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhotoModel.h"

@interface PhotoDetailTableViewCell : BaseDetailCell

/**モデル*/
@property(nonatomic,strong)PhotoModel *detailCellModel;

@end
