//
//  PhotoDetailTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/8/10.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "PhotoDetailTableViewCell.h"

@implementation PhotoDetailTableViewCell

- (void)setDetailCellModel:(PhotoModel *)detailCellModel{
    _detailCellModel = detailCellModel;
    [self setSubviewFrame:(NoticeModel *)detailCellModel];
}

- (void)showVideoPlayer{
    self.imgView.hidden =YES;
    // [self prefersStatusBarHidden];
    UIView *playerView = [[UIView alloc] init];
    playerView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, YSpan(200));
    [self.contentView addSubview:playerView];
    
    self.videoPlayer = [SRVideoPlayer playerWithVideoURL:[self urlstring:_detailCellModel.movie_url] playerView:playerView playerSuperView:playerView.superview];
    //_videoPlayer.videoName = @"Here Is The Video Name";
    self.videoPlayer.playerEndAction = SRVideoPlayerEndActionStop;
    [self.videoPlayer play];
}

- (NSURL *)urlstring:(NSString *)movieUrl{
    if (movieUrl.length ==0) {
        
    }
    
    NSURL *fileURL = [NSURL URLWithString:movieUrl];
    return fileURL;
}

@end
