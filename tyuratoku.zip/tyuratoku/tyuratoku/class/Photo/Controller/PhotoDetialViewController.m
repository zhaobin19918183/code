//
//  PhotoDetialViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "PhotoDetialViewController.h"
#import "PhotoModel.h"
#import "AnimationModel.h"
#import "PhotoDetailTableViewCell.h"
@interface PhotoDetialViewController (){

    BaseTextView *contentTextView;
    BaseImageView *backImageView;
    BaseTableView *animationTableView;
    CGRect cellImageFrame;
    NSString *shareImageStr;
}

@end
/**
 * 機能名　　　　：写真の詳細は
 * 機能概要　　　：美ら得アプリのログイン画面です。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation PhotoDetialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     self.view.backgroundColor = [UIColor colorWithRed:85/255.0 green:85/255.0 blue:85/255.0 alpha:1];
    self.bottomView.hidden = YES;
    self.title = self.detailModel.title;
    //creat tableview
    animationTableView = [[BaseTableView alloc]init];
    animationTableView.frame = CGRectMake(0, 0,Screen_W , Screen_H-64);
    animationTableView.delegate = self;
    animationTableView.dataSource = self;
    animationTableView.backgroundColor =[UIColor colorWithRed:85/255.0 green:85/255.0 blue:85/255.0 alpha:1];
    [self.view addSubview:animationTableView];
    animationTableView.separatorStyle = UITableViewCellStyleDefault;
    
    //底面のボタンを作成する
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
    [dic setValue:self.detailModel.rel_url forKey:@"rel_url"];
    [dic setValue:self.detailModel.rel_url_label forKey:@"rel_url_label"];
    [self CreatBottomViewSubviews:dic];
    
    [self detailData];

}

#pragma mark - tableView
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.detailModel.cellHeight==0) {
        return tableView.frame.size.height;
    }else{
        return self.detailModel.cellHeight;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    PhotoDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[PhotoDetailTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor colorWithRed:85/255.0 green:85/255.0 blue:85/255.0 alpha:1];
    cell.detailCellModel = self.detailModel;
    cell.imgView.userInteractionEnabled = YES;
    cell.titleLabel.textColor =[UIColor whiteColor];
    cell.contentOneLabel.textColor =[UIColor whiteColor];
    cell.contentTwoLabel.textColor =[UIColor whiteColor];
 
    cell.line.backgroundColor =[UIColor whiteColor];
    
    CALayer * layer = [cell.imgScrollView layer];
    layer.borderColor = [[UIColor whiteColor] CGColor];
    layer.borderWidth = 3.0f;
    cell.imgScrollView.layer.shadowColor = [UIColor whiteColor].CGColor;
    cell.imgScrollView.layer.shadowOffset = CGSizeMake(0, 0);
    cell.imgScrollView.layer.shadowOpacity = 0.5;
    cell.imgScrollView.layer.shadowRadius = 10.0;
    cell.imageFrame = cellImageFrame;
    
    cell.delegate =self;
    [cell.imgView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickImageView:)]];
    
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
//分かち合う
- (void)shareButton{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:shareImageStr forKey:@"image"];
    [dic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
    [dic setValue:self.detailModel.title forKey:@"title"];
    [NetWorkManager setShareInfoDic:dic];
}

#pragma mark - delegate
- (void)getImage:(NSString *)image{
    shareImageStr = image;
}
//画像拡大表示
- (void)clickImageView:(UITapGestureRecognizer *)tap{
    AmplifyView *amplifyView = [[AmplifyView alloc] initWithFrame:self.view.bounds andGesture:tap andSuperView:self.view];
    [[UIApplication sharedApplication].keyWindow addSubview:amplifyView];
}

//表のセルの高さをリフレッシュ
- (void)refreshTableView:(float)cellHeight imageViewHeight:(CGRect)imageFrame{
    self.detailModel.cellHeight = cellHeight;
    cellImageFrame = imageFrame;
    [animationTableView reloadData];
}
//下のボタンをクリックしてイベントを見る
- (void)BottomViewButtonClick:(UIButton *)button dic:(NSDictionary *)dic{
    
    switch (button.tag) {
        case 0:
            NSLog(@"0");
            break;
        case 1:
            NSLog(@"1");
            break;
        case 2:
            NSLog(@"2");
            break;
        case 3:
        {
            //rel_url_iosが空の場合、オープンrel_url
            if ([self.detailModel.rel_url_ios isKindOfClass:[NSNull class]]||[self.detailModel.rel_url_ios isEqualToString:@""]) {
                
                NSURL *cleanURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@", self.detailModel.rel_url]];
                [[UIApplication sharedApplication] openURL:cleanURL];
                
            }else{
                
                NSURL *cleanURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@", [self.detailModel.rel_url_ios stringByRemovingPercentEncoding]]];
                [[UIApplication sharedApplication] openURL:cleanURL];
                NSMutableDictionary *dic = [NSMutableDictionary dictionary];
                [dic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
                 [NetWorkManager OpenUrl:[self.detailModel.rel_url_ios stringByRemovingPercentEncoding] download:self.detailModel.rel_url dic:dic];
            }
            
        }
            break;
        default:
            break;
    }
}

/**
 * 機能名　　　　：写真
 * 機能概要　　　：創建ui
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */

- (void)layoutView{
    
    backImageView = [[BaseImageView alloc]init];
    backImageView.frame = customCGRect(10, 100, 355, 200);
    backImageView.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:backImageView];
    
    contentTextView = [[BaseTextView alloc]init];
    contentTextView.frame = customCGRect(10, backImageView.bounds.size.height + 110,  [UIScreen mainScreen].bounds.size.width-20, backImageView.bounds.size.height);
    contentTextView.backgroundColor = [UIColor clearColor];
 
    contentTextView.textColor = [UIColor whiteColor];
    contentTextView.editable = NO;
    
    [self.view addSubview:contentTextView];
    
    
}
/**
 * 機能名　　　　：写真の詳細は
 * 機能概要　　　：データのページ。
 * 作成者    　 ：趙ビン　2017/07/18
 ***********************************************************************
 ***********************************************************************
 */

- (void)detailData{
     [backImageView sd_setImageWithURL:serviceImageUrl(self.detailModel.list_thumb_url) placeholderImage:[UIImage imageNamed:@"noImage"]];

     contentTextView.text =[NSString stringWithFormat:@"%@",self.detailModel.body] ;
}


- (void)backViewcontroller{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
