//
//  PhotoDetialViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"
#import "PhotoModel.h"

@interface PhotoDetialViewController : BaseDetailViewController<UITextViewDelegate,UITableViewDelegate,UITableViewDataSource,clickImageDelegate>
/**モデル*/
@property(nonatomic,strong)UIBarButtonItem *leftBarButtonItem;
@property(nonatomic,strong)NSString *titleStr;
@property(nonatomic,strong)NSIndexPath *index;
@property(nonatomic,strong)PhotoModel *detailModel;

@end
