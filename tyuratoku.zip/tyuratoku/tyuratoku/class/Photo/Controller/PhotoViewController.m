//
//  PhotoViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "PhotoViewController.h"
#import "PhotoCollectionViewCell.h"
#import "PhotoModel.h"
#import "SettingViewController.h"

static NSString *reuse = @"reuse";

@interface PhotoViewController (){
    /**リスト*/
    BaseCollectionView *photoCollectionView;
    /**リストデータ*/
    NSMutableArray <PhotoModel*>*photoArray;
    /**サーバーラストパラメータ*/
    NSString *lastTime;
    /**表示或非表示活動指示器*/
    BOOL showHUDState;
}

@end
/**
 * 機能名　　　　：写真
 * 機能概要　　　：写真リストを選択すると表示される画面  DBに取得保持済みの写真情報を取得して詳細表示。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation PhotoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initData];
    [self getRequest];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    //創建ui
    photoCollectionView = [[BaseCollectionView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, MainVc_H) collectionViewLayout:layout];
    photoCollectionView.backgroundColor = [UIColor clearColor];
    photoCollectionView.delegate = self;
    photoCollectionView.dataSource = self;
    [self.view addSubview:photoCollectionView];
    
    //register
    [photoCollectionView registerClass:[PhotoCollectionViewCell class] forCellWithReuseIdentifier:reuse];
    
    //プルダウン更新
    [photoCollectionView downRefresh];
    //プルダウン更新操作
    [photoCollectionView downRefreshData:^{
        //表示 HUD
        showHUDState = NO;
        //ラストの値を取る
        lastTime = [NetWorkManager getLastTimeForDBName:eventDBName];
        //請求データ
        [self getRequest];
    }];
 
}

- (void)initData{
    //表示HUD
    showHUDState = YES;
    
    //初期化
    photoArray = [NSMutableArray array];
    //ラストの値を取る
    lastTime = [NetWorkManager getLastTimeForDBName:photoDBName];
    
    //データベースデータを読み取る
    NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAndDate(photoDBName, lastTime) DBName:photoDBName];
    if (array.count>0) {
        for (NSMutableDictionary *dic in array) {
            [photoArray addObject:[[PhotoModel alloc] initWithDic:dic]];
        }
        //非表示 HUD
        showHUDState = NO;
    }
    
}

#pragma mark - collectionView
//創建ui
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return photoArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    PhotoCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    
    if (cell ==nil) {
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    }
    
    cell.backgroundColor = [UIColor yellowColor];
    
    [cell setImageName:[photoArray objectAtIndex:indexPath.row]];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(122*KWIDTH, 122*KWIDTH);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{

    return 2.0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 2.0;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    PhotoDetialViewController *detail =[[PhotoDetialViewController alloc]init];
    detail.detailModel = [photoArray objectAtIndex:indexPath.row];
    detail.index = indexPath;
    [self.navigationController pushViewController:detail animated:YES];
    
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(XSpan(1), XSpan(2), XSpan(1), XSpan(2));
}

#pragma mark - request
- (void)getRequest{
    [NetWorkManager POST:listUrl paraments:[NSString stringWithFormat:@"_=%@&feature_key=photo&last=%@",[NetWorkManager getTicket],lastTime] showHUD:showHUDState success:^(id responseObject)
     {
        NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
        
        //データを取り出す
        NSMutableArray *modelDataArray = [dict valueForKey:@"data"];
        
        //追加データ
        for (int i = 0; i<modelDataArray.count; i++) {
            //請求パラメータを取り出して dic
            NSMutableDictionary *dic = [modelDataArray objectAtIndex:i];
            //dic 转モデル
            PhotoModel *dbModel = [[PhotoModel alloc] initWithDic:dic];
            //データベースには、data_id値があるかどうか
            NSMutableArray *dbArray = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_selectDataId(photoDBName, dbModel.data_id) DBName:photoDBName];
            //もしarrayの量は0より大きくて
            NSMutableDictionary *dataDictionary = [NSMutableDictionary dictionary];
            dataDictionary = [NSMutableDictionary dictionaryWithDictionary:dic];
            [dataDictionary setValue:@
             "0" forKey:@"cellHeight"];
            //もしarrayの量は0より大きくて
            if (dbArray.count==0) {
                //存在しないと添加の
                [[FMDBTool sharedManager]Queue_addDataToDataBase:dataDictionary DBName:photoDBName];
            }else{
                //存在が更新さ
                [[FMDBTool sharedManager]Queue_updateDataWithDic:dataDictionary DBName:photoDBName];
            }
            if ([dbModel.delete_date integerValue]>0){
                //現在のデータを削除する
                [[FMDBTool sharedManager]Queue_deleteDBAllData:dbModel.data_id DBName:photoDBName];
            }
        }
        
        //パケットデータを取り出す
        NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAndDate(photoDBName, lastTime) DBName:photoDBName];
        [photoArray removeAllObjects];
        for (NSDictionary *dic in array) {
            [photoArray addObject:[[PhotoModel alloc] initWithDic:dic]];
        }
        
        //ラストの設定値
        [NetWorkManager setLastTimeForDBName:photoDBName];
        //更新リスト
        [photoCollectionView reloadData];
        //非表示活動指示器
        showHUDState = NO;
        //出入りリストパラメーター、表示エラーが表示されます
//        [self upRefreshData:photoArray];
    } failure:^(NSError *error) {
    }];
    
}

@end
