//
//  PhotoModel.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "PhotoModel.h"

@implementation PhotoModel

+(PhotoModel *)PhotoDic :(NSMutableDictionary *)dic
{
    PhotoModel *photo = [[PhotoModel alloc]initWithDic:dic];
    photo.body= [dic valueForKey:@"body"];
    photo.image_url =[dic valueForKey:@"image_url"];
    photo.list_thumb_url= [dic valueForKey:@"list_thumb_url"];
    photo.title= [dic valueForKey:@"title"];
    photo.start_date= [dic valueForKey:@"start_date"];
    photo.end_date= [dic valueForKey:@"end_date"];
    photo.data_id= [dic valueForKey:@"data_id"];
  //  photo.movie_thumb_url= [dic valueForKey:@"movie_thumb_url"];
    return photo;

}
@end
