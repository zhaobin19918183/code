 //
//  NetWorkManager.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NetWorkManager.h"
#import<Social/Social.h>
//afn
static AFHTTPSessionManager *manager;
static AFNetworkReachabilityManager *reachabilityManager;
//活動指示器
static DGActivityIndicatorView *activityIndicatorView;
//分かち合う
static UIActivityViewController *activityVC;
static NSMutableArray *shareArray;
//info
static NSUserDefaults *info;

/**
 * 機能名　　　　：工具類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation NetWorkManager
//初期設定データ
+(AFHTTPSessionManager *)shareManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager = [AFHTTPSessionManager manager];
            reachabilityManager = [AFNetworkReachabilityManager sharedManager];
            activityIndicatorView = [[DGActivityIndicatorView alloc]initWithType:DGActivityIndicatorAnimationTypeBallTrianglePath tintColor:RGBA(0, 175, 204, 1)];
            info = [NSUserDefaults standardUserDefaults];
            shareArray = [NSMutableArray array];
            [NetWorkManager netWorkState];
        }
    });
    return manager;
}

//インターネットを取り消してお願いする
+(void)CancelNetWorkManager{
    [manager.operationQueue cancelAllOperations];
}

#pragma mark - net
//post ネットワーク要求
+(void)POST:(NSString *)URLString paraments:(NSString *)paraments showHUD:(BOOL)HUD success:(void(^)(id responseObject))success failure:(void(^)(NSError *error))failure{
    
    //タイムアウトタイム
    manager.requestSerializer.timeoutInterval = timeOut;
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    [manager.requestSerializer setQueryStringSerializationWithBlock:^NSString *(NSURLRequest *request, id parameters, NSError *__autoreleasing *error) {
        return parameters;
    }];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:
                                                         @"application/json",
                                                         @"text/json",
                                                         @"text/javascript",
                                                         @"text/html",
                                                         @"text/plain",
                                                         nil];
    //http
    [manager  POST:URLString parameters:paraments progress:^(NSProgress * _Nonnull uploadProgress) {
        
        if (HUD) {
            [NetWorkManager showHUD];
        }
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject){
        if (success){
            success(responseObject);
            [NetWorkManager hideHUD];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error){
        if (failure){
            failure(error);
            [NetWorkManager hideHUD];
            [NetWorkManager CancelNetWorkManager];
            NSLog(@"%@:%s/nエラーが出て:%@",NSStringFromClass([[NetWorkManager getCurrentVC] class]),__func__,error);
        }
    }];
}

//傍受ネットワーク状況
+(void)netWorkState{
    [reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        if (status == AFNetworkReachabilityStatusNotReachable) {
            [[NSNotificationCenter defaultCenter]postNotificationName:@"noNet" object:nil];
            [NetWorkManager CancelNetWorkManager];
        }else{
            
        }
    }];
    [reachabilityManager startMonitoring];
}

#pragma mark - HUD
+(void)showHUD{
    dispatch_async(dispatch_get_main_queue(), ^{
        activityIndicatorView.frame = CGRectMake(0, 0, Screen_W/6, Screen_W/6);
        UIWindow *window = [[UIApplication sharedApplication].windows lastObject];
        activityIndicatorView.center = window.center;
        [window addSubview:activityIndicatorView];
        [activityIndicatorView startAnimating];
    });
}

+(void)hideHUD{
    [activityIndicatorView stopAnimating];
    [activityIndicatorView removeFromSuperview];
}

#pragma mark - other tool
+(UIViewController *)topViewController{
    @try {
        UIWindow *window = [[UIApplication sharedApplication].delegate window];
        UIViewController *rootViewController = window.rootViewController;
        
        if ([rootViewController isKindOfClass:[UITabBarController class]]) {
            UITabBarController *tabBarController = (UITabBarController *)rootViewController;
            rootViewController = tabBarController.selectedViewController;
        } else if ([rootViewController isKindOfClass:[UINavigationController class]]) {
            UINavigationController *navigationController = (UINavigationController*)rootViewController;
            rootViewController =  navigationController.visibleViewController;
        } else if (rootViewController.presentedViewController) {
            UIViewController *presentedViewController = rootViewController.presentedViewController;
            rootViewController = presentedViewController;
        }
        return rootViewController;
    } @catch (NSException *exception) {
        NSLog(@"==========%serror:%@==========",__func__,exception);
    }
}

//alert
static UIAlertController *alertVC = nil;
+(void)showAlertWithTitle:(NSString *)title message:(NSString *)message{
    @try {
        if (alertVC == nil) {
            alertVC = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *confirAction = [UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                alertVC = nil;
                [[NSNotificationCenter defaultCenter]postNotificationName:@"popViewController" object:nil];
                
            }];
            
            [alertVC addAction:confirAction];
            [[NetWorkManager topViewController] presentViewController:alertVC animated:YES completion:nil];
        }
    } @catch (NSException *exception) {
        NSLog(@"==========%serror:%@==========",__func__,exception);
    }
    
}

+(UIColor *)getHexColor:(NSString *)color{
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    // String should be 6 or 8 characters
    if ([cString length] < 6) {
        return [UIColor clearColor];
    }
    // strip "0X" or "#" if it appears
    if ([cString hasPrefix:@"0X"])
        cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor clearColor];
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    //r
    NSString *rString = [cString substringWithRange:range];
    //g
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    //b
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    return [UIColor colorWithRed:((float) r / 255.0f) green:((float) g / 255.0f) blue:((float) b / 255.0f) alpha:1.0f];
}

//zipフォルダを削除する
+(void)deleteZipFloder{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL Exists = [fileManager fileExistsAtPath:[NetWorkManager getZipPath]];
    if (Exists) {
        [fileManager removeItemAtPath:[NetWorkManager getZipPath] error:nil];
    }
}

//MenuTitle
+(NSMutableArray<NSString*> *)getDBMenuTitleArray{
    NSArray *array = [NSArray array];
    NSMutableArray *titleArray = [NSMutableArray array];
    array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_searchMenuAllTitle DBName:menuDBName];
    for (NSDictionary *dic in array) {
        [titleArray addObject:[dic valueForKey:@"menu_title"]];
    }
    return titleArray;
}

//MenuKey
+(NSMutableArray<NSString*> *)getDBMenuKeyArray{
    NSArray *array = [NSArray array];
    NSMutableArray *titleArray = [NSMutableArray array];
    array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_searchMenuShowKey DBName:menuDBName];
    for (NSDictionary *dic in array) {
        [titleArray addObject:[dic valueForKey:@"menu_feature_key"]];
    }
    return titleArray;
}

//MenuShowTitle
+(NSMutableArray<NSString*> *)getDBMenuShowTitleArray{
    NSArray <NSString*>*array = [NSArray array];
    NSMutableArray *titleArray = [NSMutableArray array];
    array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_searchMenuShowTitle DBName:menuDBName];
    for (NSDictionary *dic in array) {
        [titleArray addObject:[dic valueForKey:@"menu_title"]];
    }
    return titleArray;
}


+(NSString *)getCurrentTimeStr{
    NSTimeZone *sourceTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];//或GMT
    NSTimeZone *destinationTimeZone = [NSTimeZone localTimeZone];
    NSInteger sourceGMTOffset = [sourceTimeZone secondsFromGMTForDate:[NSDate date]];
    NSInteger destinationGMTOffset = [destinationTimeZone secondsFromGMTForDate:[NSDate date]];
    NSTimeInterval interval = destinationGMTOffset - sourceGMTOffset;
    NSTimeInterval nowInterval = [[NSDate date] timeIntervalSince1970];
    NSInteger time = interval+nowInterval;
    NSString *nowTime = [NSString stringWithFormat:@"%ld",time];
    return nowTime;
}

+(NSString *)currentDateStr:(NSString *)str{
    
    NSTimeInterval time = [str doubleValue];
    NSDate *detaildate = [NSDate dateWithTimeIntervalSince1970:time];
    //Instantiate a NSDateFormatter object
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //Set time format
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    
    NSArray *array = [[dateFormatter stringFromDate: detaildate] componentsSeparatedByString:@"-"];
    return  [NSString stringWithFormat:@"%@年%@月%@日",array[0],array[1],array[2]];
}

+(NSString *)dateTransformToTimeSp{
    UInt64 recordTime = [[NSDate date] timeIntervalSince1970];//客户端当前10位毫秒级时间戳
    NSString *timeSp = [NSString stringWithFormat:@"%llu",recordTime];//时间戳转字符串(10位毫秒级时间戳字符串)
    return timeSp;
}

+(NSMutableArray *)setArray:(NSArray *)arraySet{
    NSSet *setCell = [NSSet setWithArray:arraySet];
    NSMutableArray *setArr = [[NSMutableArray alloc]init];
    setArr = [NSMutableArray arrayWithArray:[setCell allObjects]];
    return setArr;
}

//現在制御装置を取得
+(UIViewController *)getCurrentVC{
    UIViewController *result = nil;
    
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal){
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for(UIWindow * tmpWin in windows){
            if (tmpWin.windowLevel == UIWindowLevelNormal){
                window = tmpWin;
                break;
            }
        }
    }
    
    UIView *frontView = [[window subviews] objectAtIndex:0];
    id nextResponder = [frontView nextResponder];
    
    if ([nextResponder isKindOfClass:[UIViewController class]]){
        result = nextResponder;
    }else{
        result = window.rootViewController;
    }
    
    return result;
}

//画像補充フィールドの余分な文字を取り除く
+(NSMutableArray *)getImageUrlArray:(NSString *)urlStr{
    NSMutableArray *array = [NSMutableArray array];
    urlStr = [urlStr stringByReplacingOccurrencesOfString:@"[" withString:@""];
    urlStr = [urlStr stringByReplacingOccurrencesOfString:@"]" withString:@""];
    urlStr = [urlStr stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    urlStr = [urlStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (![urlStr isEqualToString:@""]) {
        array = [NSMutableArray arrayWithArray:[urlStr componentsSeparatedByString:@","]];
    }
    
    return array;
}

//システム共有システム
+(void)setShareInfoDic:(NSMutableDictionary *)dic{
    //初期化
    shareArray = [NSMutableArray array];
    
    //分かち合うデータを追加する
    NSString *url = [dic valueForKey:@"rel_url_ios"];
    NSString *title = [dic valueForKey:@"title"];
    NSString *textToShare = [NSString stringWithFormat:@"%@#%@%@",title,CountryLanguage(@"app_name"),url];
    //分かち合う写真を添加して
    BaseImageView *imageToShare = [[BaseImageView alloc]init];
    [imageToShare sd_setImageWithURL:[NSURL URLWithString:[dic valueForKey:@"image"]]placeholderImage:[UIImage imageNamed:@"noImage"]options:SDWebImageCacheMemoryOnly completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
        if (image!=nil) {
            [shareArray addObject:imageToShare.image];
        }
        
    }];
    //分かち合う文字
    [shareArray addObject:textToShare];
    
    //共有を作成
    activityVC = [[UIActivityViewController alloc]initWithActivityItems:shareArray applicationActivities:nil];
    activityVC.excludedActivityTypes = @[UIActivityTypePrint, UIActivityTypeCopyToPasteboard,UIActivityTypeAssignToContact,UIActivityTypeSaveToCameraRoll,UIActivityTypeAddToReadingList];
    
    //傍受活動
    UIActivityViewControllerCompletionWithItemsHandler myBlock = ^(UIActivityType activityType, BOOL completed, NSArray * returnedItems, NSError * activityError){
//        NSLog(@"activityType :%@", activityType);
        if (completed){
            NSLog(@"completed");
        }else{
            NSLog(@"cancel");
        }
    };
    activityVC.completionWithItemsHandler = myBlock;
    
    //ポップアップシステム共有システム
    UIViewController *rootVc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [rootVc presentViewController:activityVC animated:TRUE completion:nil];
}

#pragma mark - getInfo
+(NSString *)getTicket{
    NSString *ticket = [info valueForKey:@"ticket"];
    NSLog(@"ticket----%@",ticket);
    if ([ticket isEqualToString:@""]||[ticket isKindOfClass:[NSNull class]]||ticket==nil) {
        [NetWorkManager POST:[NSString stringWithFormat:@"%@/api/service/ticket/get",serviceUrl] paraments:@"service_token=b04afccb19bedfc720e6462218b17cad" showHUD:NO success:^(id responseObject) {
            //成功後に戻りのデータを求めます
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
            //获取チケット
            [info setObject:dic[@"data"][@"ticket"] forKey:@"ticket"];
            
            
        } failure:^(NSError *error) {
            
        }];
    }
    ticket = [info valueForKey:@"ticket"];
    return ticket;
}

+(NSString *)getZipPath{
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *zipPath = [NSString stringWithFormat:@"%@/zip/initial_pack",documentPath];
    return zipPath;
}

+(NSDictionary *)getJsonDic{
    NSDictionary *zipPath = [info valueForKey:@"jsonDic"];
    return zipPath;
}

+(UIColor *)getBaseColor{
    NSString *color = [info valueForKey:@"base_color"];
    UIColor *hexColor = [NetWorkManager getHexColor:color];
    return hexColor;
}

+(UIColor *)getTextColor{
    NSString *color = [info valueForKey:@"text_color"];
    UIColor *hexColor = [NetWorkManager getHexColor:color];
    return hexColor;
}

+(NSString *)getZipVersion{
    NSString *zipPath = [info valueForKey:@"version"];
    return zipPath;
}

+(NSArray *)getMenuArray{
    NSArray *menuArray = [info valueForKey:@"menuArray"];
    return menuArray;
}

+(NSArray<NSString*>*)getMenuNameArray{
    NSArray *menuArray = [info valueForKey:@"menuNameArray"];
    return menuArray;
}


+(NSDictionary *)getZipHomeInfo{
    NSDictionary *homeDic = [[NetWorkManager getMenuArray] objectAtIndex:0];
    return homeDic;
}

+(NSDictionary *)getZipNoticeInfo{
    NSDictionary *noticeDic = [[NetWorkManager getMenuArray] objectAtIndex:1];
    return noticeDic;
}

+(NSDictionary *)getZipEventInfo{
    NSDictionary *eventDic = [[NetWorkManager getMenuArray] objectAtIndex:2];
    return eventDic;
}

+(NSDictionary *)getZipShopInfo{
    NSDictionary *shopDic = [[NetWorkManager getMenuArray] objectAtIndex:3];
    return shopDic;
}

+(NSDictionary *)getZipMovieInfo{
    NSDictionary *movieDic = [[NetWorkManager getMenuArray] objectAtIndex:4];
    return movieDic;
}

+(NSDictionary *)getZipPhotoInfo{
    NSDictionary *photoDic = [[NetWorkManager getMenuArray] objectAtIndex:5];
    return photoDic;
}

+(NSDictionary *)getZipMypocketInfo{
    NSDictionary *mypocketDic = [[NetWorkManager getMenuArray] objectAtIndex:6];
    return mypocketDic;
}

+(NSDictionary *)getZipSettingInfo{
    NSDictionary *settingDic = [[NetWorkManager getMenuArray] objectAtIndex:7];
    return settingDic;
}

+(NSString *)getInfoStr:(MenuInfo)key fromDic:(NSString *)type{
    NSString *value = @"";
    switch (key) {
        case MenuId:
            value = @"menu_id";
            break;
        case MenuKey:
            value = @"menu_feature_key";
            break;
        case MenuTitle:
            value = @"menu_title";
            break;
        case MenuBigColorDefault:
            value = @"menu_large_color_enable";
            break;
        case MenuBigColorChoose:
            value = @"menu_large_color_pushed";
            break;
        case MenuBigColorSelected:
            value = @"menu_large_color_selected";
            break;
        case MenuBigImageDefault:
            value = @"menu_large_icon_enable";
            break;
        case MenuBigImageChoose:
            value = @"menu_large_icon_pushed";
            break;
        case MenuBigImageSelected:
            value = @"menu_large_icon_selected";
            break;
        case MenuSmallColorDefault:
            value = @"menu_small_color_enable";
            break;
        case MenuSmallColorChoose:
            value = @"menu_small_color_pushed";
            break;
        case MenuSmallColorSelected:
            value = @"menu_small_color_selected";
            break;
        case MenuSmallImageDefault:
            value = @"menu_small_icon_enable";
            break;
        case MenuSmallImageChoose:
            value = @"menu_small_icon_pushed";
            break;
        case MenuSmallImageSelected:
            value = @"menu_small_icon_selected";
            break;
        default:
            break;
    }
    
    NSDictionary *dic = [NSDictionary dictionary];
    if ([type isEqualToString:@"notice"]) {
        dic = [NetWorkManager getZipNoticeInfo];
    }else if ([type isEqualToString:@"leisure"]){
        dic = [NetWorkManager getZipEventInfo];
    }else if ([type isEqualToString:@"photo"]){
        dic = [NetWorkManager getZipPhotoInfo];
    }else if ([type isEqualToString:@"movie"]){
        dic = [NetWorkManager getZipMovieInfo];
    }else if ([type isEqualToString:@"hp"]){
        
    }else if ([type isEqualToString:@"pocket"]){
        dic = [NetWorkManager getZipMypocketInfo];
    }else if ([type isEqualToString:@"sns"]){
        
    }else if ([type isEqualToString:@"commerce"]){
        
    }else if ([type isEqualToString:@"shop"]){
        dic = [NetWorkManager getZipShopInfo];
    }else if ([type isEqualToString:@"inquiry"]){
        
    }else if ([type isEqualToString:@"home"]){
        dic = [NetWorkManager getZipHomeInfo];
    }else{
        dic = [NetWorkManager getZipSettingInfo];
    }
    return [dic valueForKey:value];
}

+(NSArray<NSString *> *)getMenuTypeArray{
    NSArray *menuTypeArray = [info valueForKey:@"menuTypeArray"];
    return menuTypeArray;
}

+(void)setLastTimeForDBName:(NSString *)name{
    info = [NSUserDefaults standardUserDefaults];
    [info setValue:[NetWorkManager getCurrentTimeStr] forKey:[NSString stringWithFormat:@"LastTime%@",name]];
    [info synchronize];
}

+(NSString *)getLastTimeForDBName:(NSString *)name{
    NSString *lastTime = [info valueForKey:[NSString stringWithFormat:@"LastTime%@",name]];
    if (lastTime==NULL||lastTime==nil) {
        lastTime = @"0";
    }
//    NSLog(@"lasttime---%@",lastTime);
    return lastTime;
}

+(void)removeAllInFo{
    NSDictionary *dic = [info dictionaryRepresentation];
    for(id key in dic) {
        [info removeObjectForKey:key];
    }
    [info synchronize];
}

+ (void)OpenUrl:(NSString *)str download:(NSString *)downloadUrl dic:(NSDictionary *)dic{
//    if ([[dic[@"rel_url_ios"] stringByRemovingPercentEncoding] containsString:str]) {
//        if([[UIApplication sharedApplication] canOpenURL:
//            [NSURL URLWithString:str]]){
//        }else{
//            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:downloadUrl]];
//        }
//        
//    }
    
    if([[UIApplication sharedApplication] canOpenURL:
        [NSURL URLWithString:str]]){
    }else{
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:downloadUrl]];
    }
}

@end
