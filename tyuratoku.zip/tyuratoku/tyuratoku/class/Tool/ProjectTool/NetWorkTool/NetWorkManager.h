//
//  NetWorkManager.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <Foundation/Foundation.h>

/**タイムアウトタイム*/
static NSTimeInterval timeOut = 30.f;

/**地元jsonのフィールド*/
typedef enum : NSUInteger {
    MenuId,//menu_id
    MenuKey,//menu_feature_key
    MenuTitle,//menu_title
    MenuBigColorDefault,//menu_large_color_enable
    MenuBigColorChoose,//menu_large_color_pushed
    MenuBigColorSelected,//menu_large_color_selected
    MenuBigImageDefault,//menu_large_icon_enable
    MenuBigImageChoose,//menu_large_icon_pushed
    MenuBigImageSelected,//menu_large_icon_selected
    MenuSmallColorDefault,//menu_small_color_enable
    MenuSmallColorChoose,//menu_small_color_pushed
    MenuSmallColorSelected,//menu_small_color_selected
    MenuSmallImageDefault,//menu_small_icon_enable
    MenuSmallImageChoose,//menu_small_icon_pushed
    MenuSmallImageSelected//menu_small_icon_selected
} MenuInfo;

/**メニュー種類*/
typedef enum : NSUInteger {
    HomeType,
    NoticeType,
    EventType,
    ShopType,
    MovieType,
    PhotoType,
    MypocketType,
    SettingType
} MenuType;

@interface NetWorkManager : NSObject<UIDocumentInteractionControllerDelegate>

/**
 初期設定データ

 @return AFHTTPSessionManager
 */
+(AFHTTPSessionManager *)shareManager;
/**
 インターネットを取り消してお願いする
 */
+(void)CancelNetWorkManager;
/**
 ネットワーク要求

 @param URLString url
 @param paraments アップロードパラメータ
 @param HUD 表示活動指示器
 @param success 成功後のフィボナッチリトレースメント
 @param failure 失敗後のフィボナッチリトレースメント
 */
+(void)POST:(NSString *)URLString paraments:(NSString *)paraments showHUD:(BOOL)HUD success:(void(^)(id responseObject))success failure:(void(^)(NSError *error))failure;
/**傍受ネットワーク状況*/
+(void)netWorkState;

#pragma mark - HUD
/**表示活動指示器*/
+(void)showHUD;
/**隠しイベント指示器*/
+(void)hideHUD;

#pragma mark - otherTool
/**最も上層部コントローラ*/
+(UIViewController *)topViewController;
/**
 ヒントフレーム

 @param title 標題
 @param message 内容
 */
+(void)showAlertWithTitle:(NSString *)title message:(NSString *)message;
/**
 获取16進色
 
 @param color 16進色
 @return uicolor 対象
 */
+(UIColor *)getHexColor:(NSString *)color;
/**zipフォルダを削除する*/
+(void)deleteZipFloder;
/** UTC タイムスタンプ */
+(NSString *)getCurrentTimeStr;
/** 現在の期日を得る */
+(NSString *)currentDateStr:(NSString *)str;
/***/
+(NSString *)dateTransformToTimeSp;
/***/
+(NSMutableArray *)setArray:(NSArray *)arraySet;
/**現在制御装置を取得*/
+(UIViewController *)getCurrentVC;
/**画像補充フィールドの余分な文字を取り除く*/
+(NSMutableArray *)getImageUrlArray:(NSString *)urlStr;
/**システム共有システム*/
+(void)setShareInfoDic:(NSMutableDictionary *)dic;

#pragma mark - getInfo
/**获取チケット */
+(NSString *)getTicket;
/**获取zipパス*/
+(NSString *)getZipPath;
/**获取Json */
+(NSDictionary *)getJsonDic;
/** BaseColor */
+(UIColor *)getBaseColor;
/** TextColor */
+(UIColor *)getTextColor;
/** Version */
+(NSString *)getZipVersion;
/** メニューArray */
+(NSArray *)getMenuArray;
/** MenuNameArray*/
//+(NSArray<NSString*>*)getMenuNameArray;
/** HomeInfo */
+(NSDictionary *)getZipHomeInfo;
/** NoticeInfo */
+(NSDictionary *)getZipNoticeInfo;
/** leisureInfo */
+(NSDictionary *)getZipEventInfo;
/** ShopInfo */
+(NSDictionary *)getZipShopInfo;
/** MovieInfo */
+(NSDictionary *)getZipMovieInfo;
/** PhotoInfo */
+(NSDictionary *)getZipPhotoInfo;
/** MypocketInfo */
+(NSDictionary *)getZipMypocketInfo;
/** SettingInfo */
+(NSDictionary *)getZipSettingInfo;
/**MenuTitle*/
+(NSMutableArray<NSString*> *)getDBMenuTitleArray;
/**MenuKey*/
+(NSMutableArray<NSString*> *)getDBMenuKeyArray;
/**MenuShowTitle*/
+(NSMutableArray<NSString*> *)getDBMenuShowTitleArray;
/**infoをすべて削除*/
+(void)removeAllInFo;

/**
 取得対応機能のフィールドストリングス

 @param key フィールド
 @param type 機能
 @return ストリングス
 */
+(NSString *)getInfoStr:(MenuInfo)key fromDic:(NSString *)type;
/**
 設置ラスト・フィールド

 @param name データベーステーブル名
 */
+(void)setLastTimeForDBName:(NSString *)name;
/**
 字段获取ベビー

 @param name データベーステーブル名
 @return UTCタイムスタンプ
 */
+(NSString *)getLastTimeForDBName:(NSString *)name;

/**
 urlが開けられたか否かを判断するには、ダウンロードのために店に行く
 
 */
+ (void)OpenUrl:(NSString *)str download:(NSString *)downloadUrl dic:(NSDictionary *)dic;
@end
