//
//  MJDIYAutoGifFooter.h
//  Beautiful
//
//  Created by newland on 2017/7/21.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface MJDIYAutoGifFooter : MJRefreshAutoGifFooter

@end
