//
//  MJDIYGifHeader.m
//  Beautiful
//
//  Created by newland on 2017/7/21.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MJDIYGifHeader.h"

static BOOL refreshState = NO;

/**
 * 機能名　　　　：頭部更新工具類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/08/1
 ***********************************************************************
 ***********************************************************************
 */
@implementation MJDIYGifHeader{
    BaseLabel *titleLabel;//タイトル
    BaseImageView *imageView;//画像
    DGActivityIndicatorView *loadingView;//活動指示器
}

- (void)prepare{
    [super prepare];
    
    self.mj_h = 50;
    
    //タイトル
    titleLabel = [[BaseLabel alloc] init];
    [titleLabel setTextFont:BaseLabelDefaultFont textColor:BaseLabelGray];
//    titleLabel.backgroundColor = [UIColor yellowColor];
    [self addSubview:titleLabel];
    
    //活動指示器
    loadingView = [[DGActivityIndicatorView alloc]initWithType:DGActivityIndicatorAnimationTypeBallTrianglePath tintColor:RGBA(0, 175, 204, 1) size:30];
//    loadingView.backgroundColor = [UIColor magentaColor];
    [self addSubview:loadingView];
    
    //画像
    imageView = [[BaseImageView alloc]init];
    imageView.image = [UIImage imageNamed:@""];
    [self addSubview:imageView];
    
    self.stateLabel.hidden = YES;
}

#pragma mark 在这里设置子控件的位置和尺寸
- (void)placeSubviews{
    [super placeSubviews];
    
    loadingView.frame = customCGRect(self.frame.size.width/2-90, 10, 30, 30);
    
    titleLabel.frame = CGRectMake(CGRectGetMaxX(loadingView.frame), loadingView.frame.origin.y, self.frame.size.width/3, loadingView.frame.size.height);
    
    imageView.frame = loadingView.frame;
    
}

#pragma mark 傍受scrollViewのcontentOffset変え
- (void)scrollViewContentOffsetDidChange:(NSDictionary *)change{
    [super scrollViewContentOffsetDidChange:change];
    
}

#pragma mark 傍受scrollViewのcontentSize変え
- (void)scrollViewContentSizeDidChange:(NSDictionary *)change{
    [super scrollViewContentSizeDidChange:change];
    
}

#pragma mark 傍受scrollViewのドラッグの状態を変える
- (void)scrollViewPanStateDidChange:(NSDictionary *)change{
    [super scrollViewPanStateDidChange:change];
    
}

#pragma mark 傍受の更新状態
- (void)setState:(MJRefreshState)state{
    MJRefreshCheckState;

    switch (state) {
        case MJRefreshStatePulling:
            imageView.hidden = NO;
//            imageView.image = [UIImage imageNamed:@""];
            [loadingView stopAnimating];
            [titleLabel setText:@"Drop refresh" textAlignment:BaseLabelCenter];
            break;
        case MJRefreshStateIdle:
            imageView.hidden = NO;
//            imageView.image = [UIImage imageNamed:@""];
            if (refreshState==NO) {
                [titleLabel setText:@"Drop refresh" textAlignment:BaseLabelCenter];
            }else{
                [titleLabel setText:@"Loosen refresh" textAlignment:BaseLabelCenter];
            }
            refreshState = !refreshState;
            [loadingView stopAnimating];
            break;
        case MJRefreshStateRefreshing:
            imageView.hidden = YES;
            [titleLabel setText:@"Refreshing ..." textAlignment:BaseLabelCenter];
            [loadingView startAnimating];
            break;
        default:
            break;
    }
}

//牽引時
- (void)setPullingPercent:(CGFloat)pullingPercent{
    [super setPullingPercent:pullingPercent];
    
}

@end
