//
//  SHBAVPlayerView.h
//  AVPlayerViewController_Demo
//
//  Created by 沈红榜 on 15/12/22.
//  Copyright © 2015年 沈红榜. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
@interface SHBAVPlayerView : UIView
@property(nonatomic,retain)AVPlayer *player;
- (id)initWithFrame:(CGRect)frame url:(NSString *)url;

- (void)play;
- (void)stop;

@end
