//
//  ClassHeader.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#ifndef ClassHeader_h
#define ClassHeader_h

//screen
#define Screen_W [UIScreen mainScreen].bounds.size.width
#define Screen_H [UIScreen mainScreen].bounds.size.height
#define KWIDTH ([UIScreen mainScreen].bounds.size.width/375)
#define KHEIGHT ([UIScreen mainScreen].bounds.size.height/667)
#define MainVc_H Screen_H - 64 - 40
#define XSpan(X) X*KWIDTH
#define YSpan(Y) Y*KHEIGHT
#define customCGRect(X,Y,W,H) CGRectMake(X*KWIDTH, Y*KHEIGHT, W*KWIDTH, H*KHEIGHT)

//多言語
#define CountryLanguage(Language) NSLocalizedString(Language, @"")

//RGB
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define customGreen RGBA(0, 86, 102, 1)

//FMDB
#define homeDBName @"Home_DataBase"
#define pocketDBName @"Pocket_DataBase"
#define animationDBName @"Animation_DataBase"
#define photoDBName @"Photo_DataBase"
#define eventDBName @"Event_DataBase"
#define noticeDBName @"Notice_DataBase"
#define shopDBName @"Shop_DataBase"
#define menuDBName @"Menu_DataBase"

//sql
#define SQL_groupBy(tableName) [NSString stringWithFormat:@"select *from %@ group by category_id, category_name ORDER BY category_id desc",tableName]
#define SQL_selectDataId(tableName,data_id) [NSString stringWithFormat:@"select *from %@ where data_id = %@",tableName,data_id]
#define SQL_betweenAnd(tableName,timeStr,categoryId) [NSString stringWithFormat:@"select *from %@ list where %@ BETWEEN(list.start_date)AND(list.end_date) and list.category_id = %ld",tableName,timeStr,categoryId]
#define SQL_betweenAndDate(tableName,timeStr) [NSString stringWithFormat:@"select *from %@ list where %@ BETWEEN(list.start_date)AND(list.end_date)",tableName,timeStr]
#define SQL_updateMenuName(tableName,name,status,key) [NSString stringWithFormat:@"UPDATE %@ SET menu_title = '%@' , status = '%@' where menu_feature_key = '%@'",tableName,name,status,key]
#define SQL_searchMenuAllTitle [NSString stringWithFormat:@"select menu_title from Menu_DataBase"]
#define SQL_searchMenuShowTitle [NSString stringWithFormat:@"select menu_title from Menu_DataBase where status = '表示'"]
#define SQL_searchMenuShowKey [NSString stringWithFormat:@"select menu_feature_key from Menu_DataBase where status = '表示'"]

//url
//#define serviceUrl @"https://switch-smile-cms.portalsite.jp"
#define serviceUrl @"https://dev.smile-cms.com"
#define service_token @"b04afccb19bedfc720e6462218b17cad"
#define ticketGet [NSString stringWithFormat:@"%@/api/service/ticket/get",serviceUrl]
#define ticketCheck [NSString stringWithFormat:@"%@/api/service/ticket/check",serviceUrl]
#define mainPage [NSString stringWithFormat:@"%@/api/service/feature/index",serviceUrl]
#define listUrl [NSString stringWithFormat:@"%@/api/service/data/modified",serviceUrl]
#define serviceImageUrl(imageUrl) [NSURL URLWithString:[NSString stringWithFormat:@"%@",imageUrl]]

#endif /* ClassHeader_h */
