//
//  FMDBTool.m
//  fmdb
//
//  Created by newland on 2017/7/5.
//  Copyright © 2017年 newland. All rights reserved.
//


#import "FMDBTool.h"

static FMDBTool *DBTool = nil;
static NSUserDefaults *info;
/**
 * 機能名　　　　：データベース工具類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/08/1
 ***********************************************************************
 ***********************************************************************
 */
@implementation FMDBTool{
    /**データベース*/
    FMDatabase *dataBase;
    FMDatabaseQueue *queueDataBase;
    /**記憶フィールド名*/
    NSString *DBPropertyStr;
    /**データベース経路*/
//    NSString *DBPath;
}

#pragma mark - データ作成モード
+(FMDBTool *)sharedManager{
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        DBTool = [[self alloc] init];
        info = [NSUserDefaults standardUserDefaults];
    });
    return DBTool;
}

#pragma mark - creat
//単一スレッド作成データベース
-(void)createTableWith:(Class)model{
    [FMDBTool setDBName:NSStringFromClass(model)];
    dataBase = [FMDatabase databaseWithPath:DBPath];
    //データベースを開ける
    if ([dataBase open]) {
        //開いて事務を開く
        [dataBase beginTransaction];
        //ロールバックタグ
        BOOL isRollBack = NO;
        @try {
            // データベースのSQL文
            NSString *sql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (DBNum INTEGER PRIMARY KEY AUTOINCREMENT",DBName];
            sql = [self getPropertyWithClass:model sql:sql];
            //判断
            BOOL res = [dataBase executeUpdate:sql];
            if (res) {
                NSLog(@"データベースの作成に成功する");
            }
            
        } @catch (NSException *exception) {
            NSLog(@"データベースの作成に失敗する");
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        
        //データベースを閉鎖する
        [dataBase close];
    }
}
-(void)createTableWithSQL:(NSString *)sql{
    dataBase = [FMDatabase databaseWithPath:DBPath];
    //データベースを開ける
    if ([dataBase open]) {
        //開いて事務を開く
        [dataBase beginTransaction];
        //ロールバックタグ
        BOOL isRollBack = NO;
        @try {
            //判断
            BOOL res = [dataBase executeUpdate:sql];
            if (res) {
                NSLog(@"データベースの作成に成功する");
            }
            
        } @catch (NSException *exception) {
            NSLog(@"データベースの作成に失敗する");
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        
        //データベースを閉鎖する
        [dataBase close];
    }
}
-(void)createTableWith:(Class)model primaryKey:(NSString *)key attribute:(FMDBType)type DBName:(NSString *)name{
    [FMDBTool setDBName:name];
    dataBase = [FMDatabase databaseWithPath:DBPath];
    //データベースを開ける
    if ([dataBase open]) {
        //開いて事務を開く
        [dataBase beginTransaction];
        //ロールバックタグ
        BOOL isRollBack = NO;
        @try {
            NSString *attribute = [self getFMDBType:type];
            // データベースのSQL文
            NSString *sql;
            //もしキーをnilやnullまたは空白文字列にキーを自己成長のDBNum
            if([key isEqualToString:@""]||key==nil||key==NULL){
                sql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (DBNum INTEGER PRIMARY KEY AUTOINCREMENT",name];
            }else{
                sql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (%@ %@ PRIMARY KEY",name,key,attribute];
            }
            
            //最後のSQL文
            sql = [self getPropertyWithClass:model sql:sql];
            //判断
            BOOL res = [dataBase executeUpdate:sql];
            if (res) {
                NSLog(@"データベースの作成に成功する");
            }
            
        } @catch (NSException *exception) {
            NSLog(@"データベースの作成に失敗する");
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        
        //データベースを閉鎖する
        [dataBase close];
    }
}

//マルチスレッドデータベース
-(void)Queue_createTableWith:(Class)model{
    [FMDBTool setDBName:NSStringFromClass(model)];
    queueDataBase = [FMDatabaseQueue databaseQueueWithPath:DBPath];
    //事務の多スレッド
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        // データベースのSQL文
        NSString *sql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (DBNum INTEGER PRIMARY KEY AUTOINCREMENT",DBName];
        sql = [self getPropertyWithClass:model sql:sql];
        //判断
        BOOL res = [db executeUpdate:sql];
        if (res) {
            NSLog(@"データベースの作成に成功する");
        }else{
            *rollback = YES;
            NSLog(@"データベースの作成に失敗する");
            return;
        }
    }];
}
-(void)Queue_createTableWithSQL:(NSString *)sql{
    queueDataBase = [FMDatabaseQueue databaseQueueWithPath:DBPath];
    //事務の多スレッド
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        //判断
        BOOL res = [db executeUpdate:sql];
        if (res) {
            NSLog(@"データベースの作成に成功する");
        }else{
            *rollback = YES;
            NSLog(@"データベースの作成に失敗する");
            return;
        }
    }];
}
-(void)Queue_createTableWith:(Class)model  primaryKey:(NSString *)key attribute:(FMDBType)type DBName:(NSString *)name{
    [FMDBTool setDBName:name];
    queueDataBase = [FMDatabaseQueue databaseQueueWithPath:DBPath];
    //事務の多スレッド
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        NSString *attribute = [self getFMDBType:type];
        // データベースのSQL文
        NSString *sql;
        //もしキーをnilやnullまたは空白文字列にキーを自己成長のDBNum
        if([key isEqualToString:@""]||key==nil||key==NULL){
            sql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (DBNum INTEGER PRIMARY KEY AUTOINCREMENT",name];
        }else{
            sql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (%@ %@ PRIMARY KEY",name,key,attribute];
        }
        
        //最後のSQL文
        sql = [self getPropertyWithClass:model sql:sql];
        //判断
        BOOL res = [db executeUpdate:sql];
        if (res) {
            NSLog(@"データベースの作成に成功する");
        }else{
            *rollback = YES;
            NSLog(@"データベースの作成に失敗する");
            return;
        }
    }];
}



#pragma mark -  add
//追加データを追加
-(void)addDataToDataBase:(NSMutableDictionary *)data DBName:(NSString *)name{
    //開いてデータベースを開く
    [FMDBTool setDBName:name];
    dataBase = [FMDatabase databaseWithPath:DBPath];
    if ([dataBase open]) {
        //開いて事務を開く
        [dataBase beginTransaction];
        //ロールバックタグ
        BOOL isRollBack = NO;
        @try {
            //すべてのすべき値
            NSString *valuesStr = @"";
            NSString *keyStr = @"";
            //循環を取り出してすべき遍歴する
            NSMutableArray *allKeyArray = [self getAllKeys:name];
            NSMutableArray *allAttributeArray = [self getAllAttributes:name];
            for (int i = 0; i<allKeyArray.count; i++) {
                NSString *key = [allKeyArray objectAtIndex:i];
                NSString *attribute = [allAttributeArray objectAtIndex:i];
                
                BOOL isTrue = [dataBase columnExists:key inTableWithName:name];
                if (isTrue==NO) {
                    continue;
                }
                //取り出し今すべき
                NSString *value;
                if ([[data valueForKey:key] isKindOfClass:[NSNull class]]||[data valueForKey:key]==nil||[data valueForKey:key]==NULL) {
                    value = @"";
                }else{
                    value = [data valueForKey:key];
                }
                
                //最後にはカンマがなければカンマがない
                if ([key isEqualToString:[allKeyArray lastObject]]){
                    keyStr = [keyStr stringByAppendingString:[NSString stringWithFormat:@"%@",key]];
                    //数字タイプと判断する
                    if ([attribute isEqualToString:@"1"]) {
                        valuesStr = [valuesStr stringByAppendingString:[NSString stringWithFormat:@"'%@'",value]];
                    }else{
                        valuesStr = [valuesStr stringByAppendingString:[NSString stringWithFormat:@"%@",value]];
                    }
                }else{
                    keyStr = [keyStr stringByAppendingString:[NSString stringWithFormat:@"%@,",key]];
                    //数字タイプと判断する
                    if ([attribute isEqualToString:@"1"]) {
                        valuesStr = [valuesStr stringByAppendingString:[NSString stringWithFormat:@"'%@',",value]];
                    }else{
                        valuesStr = [valuesStr stringByAppendingString:[NSString stringWithFormat:@"%@,",value]];
                    }
                }
            }
            
            //問い合わせ文
            NSString *sql = [NSString stringWithFormat:@"INSERT INTO %@ (%@) VALUES ('%@')",name,keyStr,valuesStr];
            BOOL res = [dataBase executeUpdate:sql];
            if (res) {
                NSLog(@"データ挿入成功");
            }
        } @catch (NSException *exception) {
            NSLog(@"データ挿入失败");
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        //データベースを閉鎖する
        [dataBase close];
    }
}
//多スレッド添加データ
-(void)Queue_addDataToDataBase:(NSMutableDictionary *)data DBName:(NSString *)name{
    //事務の多スレッド
    [FMDBTool setDBName:name];
    queueDataBase = [FMDatabaseQueue databaseQueueWithPath:DBPath];
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        //すべてのすべき値
        NSString *valuesStr = @"";
        NSString *keyStr = @"";
        //循環を取り出してすべき遍歴する
        NSMutableArray *allKeyArray = [self getAllKeys:name];
        NSMutableArray *allAttributeArray = [self getAllAttributes:name];
        for (int i = 0; i<allKeyArray.count; i++) {
            NSString *key = [allKeyArray objectAtIndex:i];
            NSString *attribute = [allAttributeArray objectAtIndex:i];
            
            BOOL isTrue = [db columnExists:key inTableWithName:name];
            if (isTrue==NO) {
                continue;
            }
            //取り出し今すべき
            NSString *value;
            if ([[data valueForKey:key] isKindOfClass:[NSNull class]]||[data valueForKey:key]==nil||[data valueForKey:key]==NULL) {
                value = @"";
            }else{
                value = [data valueForKey:key];
            }
            
            //最後にはカンマがなければカンマがない
            if ([key isEqualToString:[allKeyArray lastObject]]){
//                NSLog(@"%@===%@",key,[allKeyArray lastObject]);
                keyStr = [keyStr stringByAppendingString:[NSString stringWithFormat:@"%@",key]];
                //数字タイプと判断する
                if ([attribute isEqualToString:@"1"]) {
                    valuesStr = [valuesStr stringByAppendingString:[NSString stringWithFormat:@"'%@'",value]];
                }else{
                    valuesStr = [valuesStr stringByAppendingString:[NSString stringWithFormat:@"%@",value]];
                }
            }else{
                keyStr = [keyStr stringByAppendingString:[NSString stringWithFormat:@"%@,",key]];
                //数字タイプと判断する
                if ([attribute isEqualToString:@"1"]) {
                    valuesStr = [valuesStr stringByAppendingString:[NSString stringWithFormat:@"'%@',",value]];
                }else{
                    valuesStr = [valuesStr stringByAppendingString:[NSString stringWithFormat:@"%@,",value]];
                }
            }
        }
        
        //問い合わせ文
        NSString *sql = [NSString stringWithFormat:@"INSERT INTO %@ (%@) VALUES (%@)",name,keyStr,valuesStr];
        BOOL res = [db executeUpdate:sql];
        if (res) {
            NSLog(@"データ挿入成功");
        }else{
            NSLog(@"データ挿入失败");
            *rollback = YES;
            return ;
        }
    }];
}

//増加フィールド
-(void)addNewKeyToDataBase:(NSString *)key attribute:(NSString *)attribute DBName:(NSString *)name{
    //データベースを開ける
    [FMDBTool setDBName:name];
    dataBase = [FMDatabase databaseWithPath:DBPath];
    if ([dataBase open]) {
        //開いて事務を開く
        [dataBase beginTransaction];
        //事務マーク
        BOOL isRollBack = NO;
        @try {
            //判断フィールドが存在するかどうかを判断する
            if (![dataBase columnExists:key inTableWithName:name]) {
                NSString *sql = [NSString stringWithFormat:@"ALTER TABLE %@ ADD COLUMN %@ %@",name,key,attribute];
                BOOL ret = [dataBase executeUpdate:sql];
                if (ret) {
                    NSLog(@"新しいフィールドが成功を増加する");
                }
            }
        } @catch (NSException *exception) {
            NSLog(@"新しいフィールドが失敗する");
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        //データベースを閉鎖する
        [dataBase close];
    }
}
//多スレッド添加フィールド
-(void)Queue_addNewKeyToDataBase:(NSString *)key attribute:(NSString *)attribute DBName:(NSString *)name{
    //事務の多スレッド
    [FMDBTool setDBName:name];
    queueDataBase = [FMDatabaseQueue databaseQueueWithPath:DBPath];
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        //判断フィールドが存在するかどうかを判断する
        if (![dataBase columnExists:key inTableWithName:name]) {
            NSString *sql = [NSString stringWithFormat:@"ALTER TABLE %@ ADD COLUMN %@ %@",name,key,attribute];
            BOOL ret = [db executeUpdate:sql];
            if (ret) {
                NSLog(@"新しいフィールドが成功を増加する");
            }else{
                NSLog(@"新しいフィールドが失敗する");
                *rollback = YES;
                return ;
            }
        }
    }];
}

#pragma mark - search
//すべてのデータを検索する
-(NSMutableArray *)searchAllData:(NSString *)name{
    //総数グループ
    NSMutableArray *dataArray = [[NSMutableArray alloc]init];
    [FMDBTool setDBName:name];
    dataBase = [FMDatabase databaseWithPath:DBPath];
    //開いてデータベースを開く
    if ([dataBase open]){
        //開いて事務を開く
        [dataBase beginTransaction];
        //事務マーク
        BOOL isRollBack = NO;
        @try {
            FMResultSet *resultSet = [dataBase executeQuery:[NSString stringWithFormat:@"select * from %@",name]];
            while ([resultSet next]) {
                NSMutableDictionary *dataDic = [[NSMutableDictionary alloc]init];
               NSMutableArray *DBPropertyArray = [info valueForKey:[NSString stringWithFormat:@"%@Property",name]];
                for (NSString *value in DBPropertyArray) {
                    [dataDic setObject:[resultSet stringForColumn:value]forKey:value];
                }
                [dataArray addObject:dataDic];
            }
            
        } @catch (NSException *exception) {
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        //データベースを閉鎖する
        [dataBase close];;
    }
    
    return dataArray;
}

//マルチスレッド検索すべてのデータを検索
-(NSMutableArray *)Queue_searchAllData:(NSString *)name{
    //総数グループ
    NSMutableArray *dataArray = [[NSMutableArray alloc]init];
    [FMDBTool setDBName:name];
    queueDataBase = [FMDatabaseQueue databaseQueueWithPath:DBPath];
    //事務の多スレッド
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        FMResultSet *resultSet = [db executeQuery:[NSString stringWithFormat:@"select * from %@",name]];
        while ([resultSet next]) {
            NSMutableDictionary *dataDic = [[NSMutableDictionary alloc]init];
            NSMutableArray *DBPropertyArray = [info valueForKey:[NSString stringWithFormat:@"%@Property",name]];
            for (NSString *value in DBPropertyArray) {
                if ([db columnExists:value inTableWithName:DBName]) {
                    [dataDic setObject:[resultSet stringForColumn:value]forKey:value];
                }
            }
            [dataArray addObject:dataDic];
        }
//        NSLog(@"すべてのデータを検索する:%@",dataArray);
    }];
    return dataArray;
}

//指定データを検索
-(NSMutableArray *)searchDataBaseReslust:(NSString *)sql DBName:(NSString *)name{
    //総数グループ
    NSMutableArray *dataArray = [[NSMutableArray alloc]init];
    //データベースを開ける
    if ([dataBase open]){
        //開いて事務を開く
        [dataBase beginTransaction];
        //事務マーク
        BOOL isRollBack = NO;
        @try {
            FMResultSet *resultSet = [dataBase executeQuery:sql];
            while ([resultSet next]) {
                NSMutableDictionary *dataDic = [[NSMutableDictionary alloc]init];
                NSMutableArray *DBPropertyArray = [info valueForKey:[NSString stringWithFormat:@"%@Property",name]];
                for (NSString *name in DBPropertyArray) {
                    [dataDic setObject:[resultSet stringForColumn:name]forKey:name];
                }
                [dataArray addObject:dataDic];
            }
            NSLog(@"すべてのデータを検索する:%@",dataArray);
        } @catch (NSException *exception) {
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        //データベースを閉鎖する
        [dataBase close];;
    }
    return dataArray;
}

//多スレッド検索指定データ
-(NSMutableArray *)Queue_searchDataBaseReslust:(NSString *)sql DBName:(NSString *)name{
    //総数グループ
    NSMutableArray *dataArray = [[NSMutableArray alloc]init];
    //事務の多スレッド
    [FMDBTool setDBName:name];
    queueDataBase = [FMDatabaseQueue databaseQueueWithPath:DBPath];
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        FMResultSet *resultSet = [db executeQuery:sql];
        
        while ([resultSet next]) {
            @try {
                NSMutableDictionary *dataDic = [[NSMutableDictionary alloc]init];
                if ([sql containsString:@"*"]) {
                    NSMutableArray *DBPropertyArray = [info valueForKey:[NSString stringWithFormat:@"%@Property",name]];
                    for (NSString *value in DBPropertyArray) {
                        if ([db columnExists:value inTableWithName:name]) {
                            [dataDic setObject:[resultSet stringForColumn:value]forKey:value];
                        }
                    }
                }else{
                    NSArray *array = [sql componentsSeparatedByString:@" "];
                    NSString *value = [array objectAtIndex:1];
//                    for (NSString *value in array) {
                        if ([db columnExists:value inTableWithName:name]) {
                            [dataDic setObject:[resultSet stringForColumn:value]forKey:value];
                        }
//                    }
                }
                [dataArray addObject:dataDic];
            } @catch (NSException *exception) {
                NSLog(@"%@:%s/nエラーが出て:%@",NSStringFromClass([[NetWorkManager getCurrentVC] class]),__func__,exception);
                *rollback = YES;
            }
        
        }
        NSLog(@"すべてのデータを検索する:%@",dataArray);
    }];
    return dataArray;
}

#pragma mark - update
//更新データ
-(void)updateDataToDataBase:(NSString *)sql{
    //データベースを開ける
    if ([dataBase open]){
        //開いて事務を開く
        [dataBase beginTransaction];
        //事務マーク
        BOOL isRollBack = NO;
        @try {
            BOOL res = [dataBase executeUpdate:sql];
            if (res) {
                NSLog(@"データ更新の成功:%@",sql);
            }
        } @catch (NSException *exception) {
            NSLog(@"データ更新失敗:%@",sql);
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        //データベースを閉鎖する
        [dataBase close];
    }
}
-(void)updateDataWithDic:(NSMutableDictionary *)dic DBName:(NSString *)name{
    //データベースを開ける
    if ([dataBase open]){
        //開いて事務を開く
        [dataBase beginTransaction];
        //事務マーク
        BOOL isRollBack = NO;
        NSString *value = @"";
        NSString *key = @"";
        NSString *sql = @"";
        @try {
            NSArray *keyArray = [dic allKeys];
            for (int i = 0; i<keyArray.count; i++) {
                if ([keyArray objectAtIndex:i]==[keyArray lastObject]) {
                    key = [keyArray objectAtIndex:i];
                    value = [dic valueForKey:[keyArray objectAtIndex:i]];
                    
                    id tempObj = [dic valueForKey:[keyArray objectAtIndex:i]];
                    if ([[tempObj class] isSubclassOfClass:[NSNumber class]]) {
                        sql = [value stringByAppendingString:[NSString stringWithFormat:@"%@ = %@,",key,value]];
                    }else{
                        sql = [value stringByAppendingString:[NSString stringWithFormat:@"%@ = '%@',",key,value]];
                    }
                }else{
                    id tempObj = [dic valueForKey:[keyArray objectAtIndex:i]];
                    if ([[tempObj class] isSubclassOfClass:[NSNumber class]]) {
                        sql = [value stringByAppendingString:[NSString stringWithFormat:@"%@ = %@",key,value]];
                    }else{
                        sql = [value stringByAppendingString:[NSString stringWithFormat:@"%@ = '%@'",key,value]];
                    }
                }
            }
            BOOL res = [dataBase executeUpdate:[NSString stringWithFormat:@"UPDATE %@ SET %@",name,sql]];
            if (res) {
                NSLog(@"データ更新の成功:%@",sql);
            }
        } @catch (NSException *exception) {
            NSLog(@"データ更新失敗:%@",sql);
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        //データベースを閉鎖する
        [dataBase close];
    }
}
//マルチスレッド更新データ
-(void)Queue_updateDataToDataBase:(NSString *)sql{
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        BOOL res = [db executeUpdate:sql];
        if (res) {
            NSLog(@"データ更新の成功:%@",sql);
        } else {
            NSLog(@"データ更新失敗:%@",sql);
            *rollback = YES;
            return ;
        }
    }];
}
-(void)Queue_updateDataWithDic:(NSMutableDictionary *)dic DBName:(NSString *)name{
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        NSString *value = @"";
        NSString *key = @"";
        NSString *sql = @"";
        NSArray *keyArray = [dic allKeys];
        for (int i = 0; i<keyArray.count; i++) {
            if ([keyArray objectAtIndex:i]==[keyArray lastObject]) {
                key = [keyArray objectAtIndex:i];
                value = [dic valueForKey:[keyArray objectAtIndex:i]];
                if (value==nil||value==NULL||[value isKindOfClass:[NSNull class]]) {
                    value = @"";
                }
                
                id tempObj = [dic valueForKey:[keyArray objectAtIndex:i]];
                if ([[tempObj class] isSubclassOfClass:[NSNumber class]]) {
                    sql = [value stringByAppendingString:[NSString stringWithFormat:@"%@ = %@,",key,value]];
                }else{
                    sql = [value stringByAppendingString:[NSString stringWithFormat:@"%@ = '%@',",key,value]];
                }
            }else{
                id tempObj = [dic valueForKey:[keyArray objectAtIndex:i]];
                if ([[tempObj class] isSubclassOfClass:[NSNumber class]]) {
                    sql = [value stringByAppendingString:[NSString stringWithFormat:@"%@ = %@",key,value]];
                }else{
                    sql = [value stringByAppendingString:[NSString stringWithFormat:@"%@ = '%@'",key,value]];
                }
            }
        }
        BOOL res = [dataBase executeUpdate:[NSString stringWithFormat:@"UPDATE %@ SET %@",name,sql]];
        if (res) {
            NSLog(@"データ更新の成功:%@",sql);
        } else {
            NSLog(@"データ更新失敗:%@",sql);
            *rollback = YES;
            return ;
        }
    }];
}

#pragma mark - delete
//すべてのデータを削除する
-(void)deleteDBAllData:(NSString *)name{
    //データベースを開ける
    if ([dataBase open]) {
        //開いて事務を開く
        [dataBase beginTransaction];
        //事務マーク
        BOOL isRollBack = NO;
        @try {
            NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@",name];
            BOOL res = [dataBase executeUpdate:sql];
            if (res) {
                NSLog(@"データ削除の成功");
            }
        } @catch (NSException *exception) {
            NSLog(@"データ削除");
            isRollBack = YES;
            //ロールバック
            [dataBase rollback];
        } @finally {
            if (!isRollBack) {
                //提出する
                [dataBase commit];
            }
        }
        //データベースを閉鎖する
        [dataBase close];
    }
}

//多线程删除所有数据
-(void)Queue_deleteDBAllData:(NSString *)name{
    //事務の多スレッド
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@",name];
        BOOL res = [db executeUpdate:sql];
        if (res) {
            NSLog(@"データ削除の成功");
        } else {
            *rollback = YES;
            NSLog(@"データ削除");
            return ;
        }
    }];
}
-(void)Queue_deleteDBAllData:(NSString *)data_id DBName:(NSString *)name{
    //事務の多スレッド
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        NSString *sql = [NSString stringWithFormat:@"DELETE FROM %@ where data_id = '%@'",name,data_id];
        BOOL res = [db executeUpdate:sql];
        if (res) {
            NSLog(@"データ削除の成功");
        } else {
            *rollback = YES;
            NSLog(@"データ削除");
            return ;
        }
    }];
}
//データベースの削除
-(void)deleteDBFile:(NSString *)name{
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    BOOL bRet = [fileMgr fileExistsAtPath:name];
    if (bRet) {
        NSError *err;
        BOOL result = [fileMgr removeItemAtPath:name error:&err];
        if (result) {
            NSLog(@"データベースの削除成功:%@",name);
        }else{
            NSLog(@"データベースの削除:%@",name);
        }
    }
}

#pragma mark - tool
//数据库名
+(void)setDBName:(NSString *)dbName{
    //テーブル名
    DBName = dbName;
    //データベース経路
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];
    DBPath = [documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.db",dbName]];
    NSLog(@"データベース経路:%@",DBPath);
}
//モデルを得るすべての属性
-(NSString *)getPropertyWithClass:(Class)model sql:(NSString *)sql{
    NSMutableArray *DBPropertyArray = [[NSMutableArray alloc]init];
    NSMutableArray *DBAttributeArray = [[NSMutableArray alloc]init];
    // 現在種類のすべての属性を得る
    unsigned int count;//レコード属性の数を記録して
    objc_property_t *properties = class_copyPropertyList(model, &count);
    
    //循環取り出し属性
    for (int i = 0; i < count; i++) {
        // objc_property_t属性タイプ
        objc_property_t property = properties[i];
        //属性の名称C言語文字列を取得
        const char *cName = property_getName(property);
        const char *cAttribute = property_getAttributes(property);
        
        // 転換をObjective C文字列
        NSString *name = [NSString stringWithCString:cName encoding:NSUTF8StringEncoding];
        if ([name isEqualToString:@"DBNum"]) {
            continue;
        }
        NSString *attribute = [NSString stringWithCString:cAttribute encoding:NSUTF8StringEncoding];
        NSArray *array = [attribute componentsSeparatedByString:@","];
        attribute = [array objectAtIndex:0];
        
        //判断はどんなタイプとして保存するタイプの配列に入り
        //T?データは表示タイプをNSLog(@"%@",attribute);查看
        if ([attribute containsString:@"NSData"]) {
            attribute = @"data";
            [DBAttributeArray addObject:@"1"];
        }else if ([attribute containsString:@"NSDate"]){
            attribute = @"date";
            [DBAttributeArray addObject:@"1"];
        }else if ([attribute containsString:@"Tq"]||[attribute containsString:@"Ti"]){
            attribute = @"integer";
            [DBAttributeArray addObject:@"0"];
        }else if ([attribute containsString:@"Tb"]||[attribute containsString:@"BOOL"]){
            attribute = @"blob";
            [DBAttributeArray addObject:@"0"];
        }else if ([attribute containsString:@"Tf"]){
            attribute = @"float";
            [DBAttributeArray addObject:@"0"];
        }else if ([attribute containsString:@"Td"]){
            attribute = @"double";
            [DBAttributeArray addObject:@"0"];
        }else{
            attribute = @"text";
            [DBAttributeArray addObject:@"1"];
        }
        
        //属性名とデータタイプを一緒につなぎ合わせ
        sql = [sql stringByAppendingString:[NSString stringWithFormat:@" ,%@ %@",name,attribute]];
        //すべての属性を取得して文字列を取る
        if (i==0) {
            DBPropertyStr = [NSMutableString stringWithString:name];
        }else{
            NSString *str = [NSString stringWithFormat:@" ,%@",name];
            DBPropertyStr = [DBPropertyStr stringByAppendingString:str];
        }
        //属性を配列に追加
        [DBPropertyArray addObject:name];
    }
    
    //データベース設定表を作成
    if (creatDBInfoType==0) {
        [self createDBInfo];
        NSMutableDictionary *FMDBInfoDic = [NSMutableDictionary dictionary];
        [FMDBInfoDic setObject:DBPropertyArray forKey:@"DBPropertyArray"];
        [FMDBInfoDic setObject:DBAttributeArray forKey:@"DBAttributeArray"];
        [FMDBInfoDic setObject:DBPath forKey:@"DBPath"];
        [self Queue_addDataToDataBase:FMDBInfoDic DBName:FMDBInfoName];
    }else if(creatDBInfoType==1){
        [info setObject:DBPropertyArray forKey:[NSString stringWithFormat:@"%@Property",DBName]];
        [info setObject:DBAttributeArray forKey:[NSString stringWithFormat:@"%@Attribute",DBName]];
        [info setObject:DBPath forKey:[NSString stringWithFormat:@"%@DBPath",DBPath]];
        [info synchronize];
    }
    
    sql = [sql stringByAppendingString:@")"];
    return sql;
}
//データ取得タイプ
-(NSString *)getFMDBType:(FMDBType)type{
    NSString *str = @"text";
    switch (type) {
        case DataType:
            str = @"data";
            break;
        case DateType:
            str = @"date";
            break;
        case BOOLType:
            str = @"bool";
            break;
        case DoubleType:
            str = @"double";
            break;
        case FloatType:
            str = @"float";
            break;
        case IntegerType:
            str = @"integer";
            break;
        default:
            break;
    }
    return str;
}
//獲得フィールド
-(NSMutableArray *)getAllKeys:(NSString *)name{
    NSMutableArray *keyArray = [NSMutableArray array];
    if (creatDBInfoType==0) {
        keyArray = [self searchAllData:FMDBInfoName];
    }else{
        keyArray = [info valueForKey:[NSString stringWithFormat:@"%@Property",name]];
    }
    return keyArray;
}
//取得タイプ
-(NSMutableArray *)getAllAttributes:(NSString *)name{
    NSMutableArray *AttributeArray = [NSMutableArray array];
    if (creatDBInfoType==0) {
        AttributeArray = [self searchAllData:FMDBInfoName];
    }else{
        AttributeArray = [info valueForKey:[NSString stringWithFormat:@"%@Attribute",name]];
    }
    return AttributeArray;
}

#pragma mark - DBInfo
//データベース設定用建表
-(void)createDBInfo{
    queueDataBase = [FMDatabaseQueue databaseQueueWithPath:DBPath];
    //事務の多スレッド
    [queueDataBase inTransaction:^(FMDatabase * _Nonnull db, BOOL * _Nonnull rollback) {
        // データベースのSQL文
        NSString *sql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (DBNum INTEGER PRIMARY KEY AUTOINCREMENT,DBPropertyArray data ,DBAttributeArray data,DBPath text,DBName text",FMDBInfoName];
        //判断
        BOOL res = [db executeUpdate:sql];
        if (res) {
            NSLog(@"データベースの作成に成功する");
        }else{
            *rollback = YES;
            NSLog(@"データベースの作成に失敗する");
            return;
        }
    }];
}

@end
