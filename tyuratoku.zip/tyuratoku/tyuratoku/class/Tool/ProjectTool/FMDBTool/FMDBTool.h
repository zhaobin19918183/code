//
//  FMDBTool.h
//  fmdb
//
//  Created by newland on 2017/7/5.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FMDB.h>
#import <objc/runtime.h>

/**データベース経路*/
static NSString *DBPath;
/**データベーステーブル名*/
static NSString *DBName;
/**記憶フィールド名*/
static NSString *DBPropertyStr;
/**
 FMDBデータベース設置表名称
 ただcreatDBInfoType＝いちに有効
 */
static NSString *FMDBInfoName = @"FMDBInfo";

/**
 0：創建FMDBデータベース設置表（表の数をお勧めして特別の長い間）
 1：創建NSUserDefaultsデータベース設置表（デフォルト）
 他：1つのデータベース作成用テーブルのみで使用します
 */
static NSInteger creatDBInfoType = 1;

/**フィールドタイプ*/
typedef enum : NSUInteger {
    BOOLType,
    StringType,
    DataType,
    DateType,
    IntegerType,
    FloatType,
    DoubleType,
} FMDBType;


/**
 FMDB道具類
 */
@interface FMDBTool : NSObject

#pragma mark - init
/**初期化*/
+(FMDBTool *)sharedManager;


#pragma mark - setDBName
/**データベース名を設定*/
+(void)setDBName:(NSString *)dbName;




#pragma mark - creat
/**
 データベース作成（先に設定表名方法）作成
 
 @param model では自動モデル伝来の属性をモデルとして対応するデータ型フィールド
 */
-(void)createTableWith:(Class)model;
/**
 データベース作成（先に設定表名方法）作成
 
 @param sql 創建表のSQL文
 */
-(void)createTableWithSQL:(NSString *)sql;
/**
 データベースを作成
 
 @param model 伝来自動モデルの属性をモデルとしてフィールドを対応データタイプ
 @param key メインキーをすればnilやnullまたは空白文字列にキーを自己成長のDBNum
 @param type データ型（もしキーを空、ここに記入）
 @param name テーブル名
 */
-(void)createTableWith:(Class)model primaryKey:(NSString *)key attribute:(FMDBType)type DBName:(NSString *)name;


#pragma mark 多スレッド形式作成表
/**
 データベース作成（先に設定表名方法）作成
 
 @param model 伝来自動モデルの属性をモデルとしてフィールドを対応データタイプ
 */
-(void)Queue_createTableWith:(Class)model;
/**
 データベース作成（先に設定表名方法）作成
 
 @param sql 表の作成SQL文
 */
-(void)Queue_createTableWithSQL:(NSString *)sql;
/**
 データベースを作成
 
 @param model 伝来自動モデルの属性をモデルとしてフィールドを対応データタイプ
 @param key メインキーをすればnilやnullまたは空白文字列にキーを自己成長のDBNum
 @param type データ型（もしキーを空、ここに記入）
 @param name テーブル名
 */
-(void)Queue_createTableWith:(Class)model  primaryKey:(NSString *)key attribute:(FMDBType)type DBName:(NSString *)name;




#pragma mark - add
/**1件のデータを追加して*/
-(void)addDataToDataBase:(NSMutableDictionary *)data DBName:(NSString *)name;
-(void)Queue_addDataToDataBase:(NSMutableDictionary *)data DBName:(NSString *)name;


#pragma mark 新しいフィールドを追加
/**
 新しいフィールドを追加
 
 @param key フィールド名
 @param attribute フィールドタイプ
 @param name テーブル名
 */
-(void)addNewKeyToDataBase:(NSString *)key attribute:(NSString *)attribute DBName:(NSString *)name;
#pragma mark 多スレッド添加新フィールド
/**
 新しいフィールドを追加
 
 @param key フィールド名
 @param attribute フィールドタイプ
 @param name テーブル名
 */
-(void)Queue_addNewKeyToDataBase:(NSString *)key attribute:(NSString *)attribute DBName:(NSString *)name;




#pragma mark - delete
/**データベースの削除*/
-(void)deleteDBFile:(NSString *)name;
/**すべてのデータを削除する*/
-(void)deleteDBAllData:(NSString *)name;
/**マルチスレッド削除データ*/
-(void)Queue_deleteDBAllData:(NSString *)name;
-(void)Queue_deleteDBAllData:(NSString *)data_id DBName:(NSString *)name;




#pragma mark - update
/**更新データ*/
-(void)updateDataToDataBase:(NSString *)sql;
-(void)updateDataWithDic:(NSMutableDictionary *)dic DBName:(NSString *)name;
/**マルチスレッド更新データ*/
-(void)Queue_updateDataToDataBase:(NSString *)sql;
-(void)Queue_updateDataWithDic:(NSMutableDictionary *)dic DBName:(NSString *)name;



#pragma mark - search
/**すべてのデータを検索する*/
-(NSMutableArray *)searchAllData:(NSString *)name;
/**マルチスレッド検索全てデータ*/
-(NSMutableArray *)Queue_searchAllData:(NSString *)name;
/**指定データを検索*/
-(NSMutableArray *)searchDataBaseReslust:(NSString *)sql DBName:(NSString *)name;
-(NSMutableArray *)Queue_searchDataBaseReslust:(NSString *)sql DBName:(NSString *)name;

@end
