//
//  AmplifyView.m
//  Beautiful
//
//  Created by newland on 2017/8/11.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AmplifyView.h"

@interface AmplifyView()<UIScrollViewDelegate>

@property (nonatomic,strong) UIImageView *lastImageView;
@property (nonatomic,assign) CGRect originalFrame;
@property (nonatomic,strong) UIScrollView *scrollView;

@end
@implementation AmplifyView

- (instancetype)initWithFrame:(CGRect)frame andGesture:(UITapGestureRecognizer *)tap andSuperView:(UIView *)superView
{
    if (self=[super initWithFrame:frame]) {
        //scrollView作为背景
        UIScrollView *bgView = [[UIScrollView alloc] init];
        bgView.frame = CGRectMake(0, 0, Screen_W, Screen_H);
       // bgView.backgroundColor = [color colorWithAlphaComponent:0.5];
        bgView.backgroundColor = [UIColor colorWithWhite:0.f alpha:0.5];
        
        UITapGestureRecognizer *tapBg = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapBgView:)];
        [bgView addGestureRecognizer:tapBg];
        
        UIImageView *picView = (UIImageView *)tap.view;
        
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.image = picView.image;

//        imageView.frame = [bgView convertRect:picView.frame fromView:self];
        imageView.frame = CGRectMake(0, 0, [bgView convertRect:picView.frame fromView:self].size.width, [bgView convertRect:picView.frame fromView:self].size.height);
//        imageView.frame = frame;
        [bgView addSubview:imageView];
        [self addSubview:bgView];
        
        self.lastImageView = imageView;
        self.originalFrame = imageView.frame;
        self.scrollView = bgView;
        
        //最大放大比例
        self.scrollView.maximumZoomScale = 5;
        self.scrollView.delegate = self;
//        NSLog(@"987654321-----%f-----%f",imageView.frame.origin.x,imageView.frame.origin.y);
        [UIView animateWithDuration:0.5 animations:^{
            CGRect frame = imageView.frame;
            frame.size.width = bgView.frame.size.width;
            frame.size.height = frame.size.width * (imageView.image.size.height / imageView.image.size.width);
            frame.origin.x = 0;
            frame.origin.y = (bgView.frame.size.height - frame.size.height) * 0.5;
            imageView.frame = frame;
//            NSLog(@"123456789-----%f-----%f",imageView.frame.origin.x,imageView.frame.origin.y);
        }];
        
    }
    return self;
}

-(void)tapBgView:(UITapGestureRecognizer *)tapBgRecognizer
{
    self.scrollView.contentOffset = CGPointZero;
    [UIView animateWithDuration:0.5 animations:^{
        self.lastImageView.frame = self.originalFrame;
        tapBgRecognizer.view.backgroundColor = [UIColor clearColor];
//        NSLog(@"123456789");
    } completion:^(BOOL finished) {
        [tapBgRecognizer.view removeFromSuperview];
        [self removeFromSuperview];
        self.scrollView = nil;
        self.lastImageView = nil;
    }];
    
}



//返回可缩放的视图

-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView

{
    CGFloat H = self.lastImageView.frame.size.height;
    CGFloat w = self.lastImageView.frame.size.width;
    self.lastImageView.frame= CGRectMake(0, 64, w, H);
    return self.lastImageView;
    
}




@end
