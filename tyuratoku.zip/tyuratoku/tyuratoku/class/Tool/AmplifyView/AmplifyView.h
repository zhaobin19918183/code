//
//  AmplifyView.h
//  Beautiful
//
//  Created by newland on 2017/8/11.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AmplifyView : UIView
- (instancetype)initWithFrame:(CGRect)frame andGesture:(UITapGestureRecognizer *)tap andSuperView:(UIView *)superView;
@end
