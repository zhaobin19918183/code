//
//  SRBrightnessView.h
//  SRVideoPlayer
//
//  Created by https://github.com/guowilling on 17/4/6.
//  Copyright © 2017年 SR. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SRBrightnessView : UIView

+ (instancetype)sharedBrightnessView;

@end
