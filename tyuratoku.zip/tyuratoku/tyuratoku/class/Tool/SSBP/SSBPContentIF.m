//
//  SSBPContentIF.m
//
//  Created by Ayumi Togashi on 2016/09/27.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define SHARED_INSTANCE(...) ({ static dispatch_once_t pred; static id sharedObject; dispatch_once(&pred, ^{ sharedObject = (__VA_ARGS__); }); sharedObject; })

#import "SSBPContentIF.h"

#import "DBSsbpContent.h"

@implementation SSBPContentIF

+ (id)sharedInstance {
    return SHARED_INSTANCE([self new]);
}

- (id)init {
    self = [super init];
    if (self) {
    }
    return self;
}

- (void)addContents:(NSArray<SSBPContent*>*)ssbpContents beaconId:(NSString*)beaconId geofenceId:(NSString*)geofenceId {
    if (ssbpContents == nil) return;
    for (SSBPContent* content in ssbpContents) {
        TSsbpContent* tSsbpContent = [self checkContent:content beaconId:beaconId geofenceId:geofenceId];
        NSLog(@"%@",tSsbpContent);
     //   [self checkAmisContents:tSsbpContent];
    }
//   [[NSNotificationCenter defaultCenter]postNotificationName:@"pocket" object:nil];
   [[NSNotificationCenter defaultCenter] postNotificationName:@"add" object:nil];
}

// Amis様連携処理(サイネージ多言語用)
- (void)checkAmisContents:(TSsbpContent*)tSsbpContent {
    if (tSsbpContent == nil) return;
    
  
      
}
- (TSsbpContent*)checkContent:(SSBPContent*)ssbpContent beaconId:(NSString*)beaconId geofenceId:(NSString*)geofenceId {
    if (ssbpContent == nil) return nil;

    DBSsbpContent* dBSsbpContent = [DBSsbpContent new];
    TSsbpContent* tSsbpContent = [dBSsbpContent findByContentID:ssbpContent.contentId];
    if (tSsbpContent == nil) {
        tSsbpContent = [TSsbpContent new];
        tSsbpContent.status = 0;
    }
    tSsbpContent.beaconId = beaconId;
    tSsbpContent.geofenceId = geofenceId;

    tSsbpContent.contentId = ssbpContent.contentId;
  //  tSsbpContent.contentName = ssbpContent.contentName;
    tSsbpContent.contentAction = ssbpContent.contentAction;
//    tSsbpContent.contentURL = @"";
//    tSsbpContent.contentMainDescription = @"";
//    tSsbpContent.contentSubDescription = @"";
//    tSsbpContent.contentMainImageURL = @"";
//    tSsbpContent.contentSubImageURL = @"";
//    tSsbpContent.stampYetImageURL = @"";
//    tSsbpContent.stampDoneImageURL = @"";
//    tSsbpContent.contentSound = @"";

    for (SSBPStore* text in ssbpContent.contentTexts)
    {
        
        if ([self checkSame:text.key val2:@"type"]) {
            tSsbpContent.contentType = text.value;
        } else if ([self checkSame:text.key val2:@"title"]) {
            tSsbpContent.contentTitle = text.value;
        } else if ([self checkSame:text.key val2:@"sub_title"]) {
            tSsbpContent.contentSubTitle = text.value;
        } else if ([self checkSame:text.key val2:@"body1"]||[self checkSame:text.key val2:@"privacy_policy"]) {
            tSsbpContent.contentBody1 = text.value;
        }
        else if ([self checkSame:text.key val2:@"body2"]||[self checkSame:text.key val2:@"terms_of_service"]) {
            tSsbpContent.contentBody2 = text.value;
        }
        else if ([self checkSame:text.key val2:@"limit_type"]) {
            tSsbpContent.contentLimitType = text.value;
        }
        else if ([self checkSame:text.key val2:@"repeatable"]) {
            tSsbpContent.contentRepeatable = text.value;
        }
     
//        NSLog(@"   text key(%@)/value(%@)", text.key, text.value);
    }
    for (SSBPStore* link in ssbpContent.contentLinks) {
    
        if ([self checkSame:link.key val2:@"image_url"]) {
            if(!([tSsbpContent.contentImageUrl rangeOfString:@"https"].location !=NSNotFound))
            {
                tSsbpContent.contentImageUrl = link.value;
//                tSsbpContent.contentImage = [NSData data];
            }
            else
            {
                tSsbpContent.contentImageUrl = link.value;
//               tSsbpContent.contentImage = (NSData *)link.value;
            }
        }
//        } else if ([self checkSame:link.key val2:@"main_image"]) {
//            tSsbpContent.contentMainImageURL = link.value;
//        } else if ([self checkSame:link.key val2:@"sub_image"]) {
//            tSsbpContent.contentSubImageURL = link.value;
//        } else if ([self checkSame:link.key val2:@"stamp_yet"]) {
//            tSsbpContent.stampYetImageURL = link.value;
//        } else if ([self checkSame:link.key val2:@"stamp_done"]) {
//            tSsbpContent.stampDoneImageURL = link.value;
//        } else if ([self checkSame:link.key val2:@"sound"]) {
//            tSsbpContent.contentSound = link.value;
//        }
        //NSLog(@"   link key(%@)/value(%@)", text.key, text.value);
    }

    tSsbpContent.contentStartAt = [self makeUTCDateTimeToString:ssbpContent.contentStartAt];
    tSsbpContent.contentEndAt = [self makeUTCDateTimeToString:ssbpContent.contentEndAt];

    // 有効期限外テスト
    {
        // 期限前テスト
        //NSDate* after_1day = [NSDate dateWithTimeIntervalSinceNow:24 * 60 * 60];
        //tSsbpContent.contentStartAt = [self makeUTCDateTimeToString:after_1day];
        // 期限切れテスト
        //NSDate* before_1day = [NSDate dateWithTimeIntervalSinceNow:-24 * 60 * 60];
        //tSsbpContent.contentEndAt = [self makeUTCDateTimeToString:before_1day];
    }

    [self addContent:tSsbpContent];

    return tSsbpContent;
}

- (void)addContent:(TSsbpContent*)content {
    if (content == nil) return;

    @autoreleasepool {
        DBSsbpContent* dBSsbpContent = [DBSsbpContent new];
        TSsbpContent* tSsbpContent = [dBSsbpContent findByContentID:content.contentId];
        if (tSsbpContent == nil) {
            [dBSsbpContent add:content];
           NSLog(@"DBContent add(%@)", content.contentImageUrl);
         [[NSNotificationCenter defaultCenter] postNotificationName:@"pocketnotice" object:content];
            if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpContentIFAddContent:)]) {
                [self.delegateIF ssbpContentIFAddContent:content.contentId];
            }
        } else {
            BOOL isChange = false;
            if (![self checkSame:tSsbpContent.contentType val2:content.contentType]) isChange = true;
            tSsbpContent.contentType = content.contentType;
            
            if (![self checkSame:tSsbpContent.contentTitle val2:content.contentTitle]) isChange = true;
            tSsbpContent.contentTitle = content.contentTitle;
            
            if (![self checkSame:tSsbpContent.contentSubTitle val2:content.contentSubTitle]) isChange = true;
            tSsbpContent.contentSubTitle = content.contentSubTitle;
            
            if (![self checkSame:tSsbpContent.contentBody1 val2:content.contentBody1]) isChange = true;
            tSsbpContent.contentBody1 = content.contentBody1;
            
            if (![self checkSame:tSsbpContent.contentImageUrl val2:content.contentImageUrl]) isChange = true;
            tSsbpContent.contentImageUrl = content.contentImageUrl;
    
//            if (![tSsbpContent.contentImage isEqualToData:content.contentImage]) {
//                if (tSsbpContent.contentImage == nil)
//                    isChange = true;
//                tSsbpContent.contentImage = content.contentImage;
//            }
//            
//            if (![self checkSame:(NSString *)tSsbpContent.contentImage val2:(NSString *)content.contentImage]) isChange = true;
//            tSsbpContent.contentImageUrl =(NSString *) content.contentImage;
            
            if (![self checkSame:tSsbpContent.contentBody2 val2:content.contentBody2]) isChange = true;
            tSsbpContent.contentBody2 = content.contentBody2;
            
            if (![self checkSame:tSsbpContent.contentLimitType val2:content.contentLimitType]) isChange = true;
            tSsbpContent.contentLimitType = content.contentLimitType;
            
            if (![self checkSame:tSsbpContent.contentRepeatable val2:content.contentLimitType]) isChange = true;
            tSsbpContent.contentRepeatable = content.contentRepeatable;
            /*====================*/
            if (![self checkSame:tSsbpContent.contentId val2:content.contentId]) isChange = true;
            tSsbpContent.contentId = content.contentId;
                       if (![self checkSame:tSsbpContent.contentAction val2:content.contentAction]) isChange = true;
            tSsbpContent.contentAction = content.contentAction;
            
            if (![self checkSame:tSsbpContent.contentStartAt val2:content.contentStartAt]) isChange = true;
            tSsbpContent.contentStartAt = content.contentStartAt;
            if (![self checkSame:tSsbpContent.contentEndAt val2:content.contentEndAt]) isChange = true;
            tSsbpContent.contentEndAt = content.contentEndAt;
            if (![self checkSame:tSsbpContent.beaconId val2:content.beaconId]) isChange = true;
            tSsbpContent.beaconId = content.beaconId;
            if (![self checkSame:tSsbpContent.geofenceId val2:content.geofenceId]) isChange = true;
            tSsbpContent.geofenceId = content.geofenceId;
            if (tSsbpContent.status != 1) { // 使用済み以外なら有効期限チェックを行う
                int status = [self checkContentStatus:tSsbpContent];
                if (status != -1) {
                    if (tSsbpContent.status != status) isChange = true;
                    tSsbpContent.status = status;
                }
            }
            if (isChange) {
              
                [dBSsbpContent update:tSsbpContent];
            }
        }
    }
}

- (NSArray<TSsbpContent*>*)getInnerContents:(NSString*)action {
    @autoreleasepool {
        NSArray<TSsbpContent*>* contentList = nil;
        DBSsbpContent* dBSsbpContent = [DBSsbpContent new];
        if (action.length == 0) {
            contentList = [dBSsbpContent getAll];
        } else {
            contentList = [dBSsbpContent getActions:action];
        }

        if (contentList != nil) {
            for (TSsbpContent* item in contentList) {
                if (item.status != 1) { // 使用済み以外なら有効期限チェックを行う
                    int status = [self checkContentStatus:item];
                    if (status != -1) {
                        item.status = status;
                        [dBSsbpContent update:item];
                    }
                }
            }
        }
        return contentList;
    }
}

- (NSArray<TSsbpContent*>*)getInnerBeaconContents:(NSString*)beaconId {
    @autoreleasepool {
        DBSsbpContent* dBSsbpContent = [DBSsbpContent new];
        NSArray<TSsbpContent*>* contentList = [dBSsbpContent getBeacons:beaconId];
        if (contentList != nil) {
            for (TSsbpContent* item in contentList) {
                if (item.status != 1) { // 使用済み以外なら有効期限チェックを行う
                    int status = [self checkContentStatus:item];
                    if (status != -1) {
                        item.status = status;
                        [dBSsbpContent update:item];
                    }
                }
            }
        }
        return contentList;
    }
}

- (NSArray<TSsbpContent*>*)getInnerGeofenceContents:(NSString*)geofenceId {
    @autoreleasepool {
        DBSsbpContent* dBSsbpContent = [DBSsbpContent new];
        NSArray<TSsbpContent*>* contentList = [dBSsbpContent getGeofences:geofenceId];
        if (contentList != nil) {
            for (TSsbpContent* item in contentList) {
                if (item.status != 1) { // 使用済み以外なら有効期限チェックを行う
                    int status = [self checkContentStatus:item];
                    if (status != -1) {
                        item.status = status;
                        [dBSsbpContent update:item];
                    }
                }
            }
        }
        return contentList;
    }
}

- (TSsbpContent*)getInnerContent:(NSString*)contentId {
    @autoreleasepool {
        DBSsbpContent* dBSsbpContent = [DBSsbpContent new];
        TSsbpContent* item = [dBSsbpContent findByContentID:contentId];
        if (item != nil) {
            if (item.status != 1) { // 使用済み以外なら有効期限チェックを行う
                int status = [self checkContentStatus:item];
                if (status != -1) {
                    item.status = status;
                    [dBSsbpContent update:item];
                }
            }
        }
        return item;
    }
}

- (int)checkContentStatus:(TSsbpContent*)item {
    @autoreleasepool {
        NSDate* NowDate = [NSDate date];
        NSDate* StartDate = [self makeUTCDateTimeFromString:item.contentStartAt];
        NSDate* EndDate = [self makeUTCDateTimeFromString:item.contentEndAt];
        if (!StartDate) return -1;
        if (!EndDate) return -1;

        @try {
            BOOL before = false;
            BOOL after = false;

            NSComparisonResult chk_start = [NowDate compare:StartDate];
            NSComparisonResult chk_end = [NowDate compare:EndDate];

            if (chk_start == NSOrderedAscending) {
                before = true;
            }
            if (chk_end == NSOrderedDescending) {
                after = true;
            }

            if (before) {
                return 2; // 期限前
            } else if (after) {
                return 3; // 期限切れ
            } else {
                return 0; // 有効期限
            }
        } @catch (NSException* exception) {
        } @finally {
        }
    }

    return -1; // なんらかの問題あり
}

- (BOOL)useContent:(NSString*)contentId {
    @autoreleasepool {
        DBSsbpContent* dBSsbpContent = [DBSsbpContent new];
        return [dBSsbpContent use:contentId];
    }
}

- (BOOL)removeContent:(NSString*)contentId {
    @autoreleasepool {
        DBSsbpContent* dBSsbpContent = [DBSsbpContent new];
        return [dBSsbpContent remove:contentId];
    }
}

- (void)clearAllContent {
    @autoreleasepool {
        DBSsbpContent* dBSsbpContent = [DBSsbpContent new];
        [dBSsbpContent dropDatabase];
    }
}

#pragma mark -
#pragma mark Etc

- (NSString*)makeUTCDateTimeToString:(NSDate*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
        [formatter setLocale:[NSLocale systemLocale]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString* strDate = [formatter stringFromDate:date];
        if (strDate) {
            return strDate;
        } else {
            return @"";
        }
    }
}

- (NSDate*)makeUTCDateTimeFromString:(NSString*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
        [formatter setLocale:[NSLocale systemLocale]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        return [formatter dateFromString:date];
    }
}

- (BOOL)checkSame:(NSString*)val1 val2:(NSString*)val2 {
    if ((val1 == nil) && (val2 == nil)) return true;
    else if (val1 == nil) return false;
    else if (val2 == nil) return false;
    else if ([val1 compare:val2] == NSOrderedSame) return true;
    else return false;
}

#pragma mark -
#pragma mark Extra


@end
