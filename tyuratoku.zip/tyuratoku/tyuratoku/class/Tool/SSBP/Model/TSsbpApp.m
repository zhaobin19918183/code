//
//  TSsbpApp.m
//
//  Created by Ayumi Togashi on 2016/09/15.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "TSsbpApp.h"

@implementation TSsbpApp

@end
