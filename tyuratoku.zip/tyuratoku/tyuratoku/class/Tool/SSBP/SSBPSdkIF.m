//
//  SSBPSdkIF.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define SHARED_INSTANCE(...) ({ static dispatch_once_t pred; static id sharedObject; dispatch_once(&pred, ^{ sharedObject = (__VA_ARGS__); }); sharedObject; })

#define SENDLOG_REALTIME 0
#define SENDLOG_INTERVAL 600

#define SEL_APP_NAME    @"SelAppName"
#define SEL_APP_KEY     @"SelAppKey"
#define SEL_SECRET_KEY  @"SelSecretKey"
#define SEL_HOST        @"SelHost"

#define SSBP_LOCALE_ID       @"LocaleID"
#define SSBP_LOCALE_DEFAULT  @"LocaleDefault"
#define SSBP_DEVICE_ID       @"DeviceID"
#define SSBP_DEVICE_TOKEN    @"DeviceToken"
#define SSBP_MQTT_UUID       @"MqttUUID"

#define SSBP_DETECT_BEACON   @"DetectBeacon"
#define SSBP_GEOFENCE_DEBUG 1

#import "SSBPSdkIF.h"

#import "SSBPCsvIF.h"

@interface SSBPSdkIF ()

@property (nonatomic, readwrite) NSString* appName;
@property (nonatomic, readwrite) NSString* appKey;
@property (nonatomic, readwrite) NSString* secretKey;
@property (nonatomic, readwrite) NSString* localeId;
@property (nonatomic, readwrite) NSString* localeDefault;
@property (nonatomic, readwrite) NSString* deviceId;
@property (nonatomic, readwrite) NSString* deviceToken;

@property (nonatomic, readwrite) NSArray<SSBPQuestion*>* attrQuestions;

@end

@implementation SSBPSdkIF {
    UIBackgroundTaskIdentifier bgTask;

    NSDictionary* oldAnswers;
}

+ (id)sharedInstance {
    return SHARED_INSTANCE([self new]);
}

- (id)init {
    self = [super init];
    if (self) {
        // 保存情報の全削除
        //NSString* appDomain = [[NSBundle mainBundle] bundleIdentifier];
        //[[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];

        [self sdkInitialize];
        //[SSBPScannerManager sharedManager].waitTime = 300;
        [SSBPScannerManager sharedManager].useGPS = true;
        [SSBPScannerManager sharedManager].useCoreBluetooth = true;
        [SSBPScannerManager sharedManager].useNode = true;
        [SSBPScannerManager sharedManager].useEdge = true;
        [SSBPScannerManager sharedManager].usePublicBeacon = true;
        [SSBPScannerManager sharedManager].useGeofence = false;
        [SSBPScannerManager sharedManager].delegateSSBPScanner = self;
        self.useBeaconLog = true;
        self.useContentLog = true;
        self.useNotification = true;

        [SSBPContentIF sharedInstance].delegateIF = self;
    }
    return self;
}

- (NSArray<TSsbpApp*>*)getAppInfos {
    SSBPCsvIF* csvIF = [SSBPCsvIF new];
    return [csvIF getAppInfos];
}

- (void)setMaster:(NSString*)appName {
    // この処理は、サンプルとして設定ファイルで複数のアプリに対応するためのものです。
    // 通常のアプリケーションの場合、設定は単独で固定となるためNSUserDefaultsでの管理は必ずしも必要はありません。
    NSArray* appInfos = [self getAppInfos];
    NSString* nowAppKey = [[NSUserDefaults standardUserDefaults] stringForKey:SSBP_APPKEY];
    NSString* nowDeviceId = [SSBPManager sharedManager].deviceId;

    BOOL isSelect = false;
    if ((appName.length > 0) && ![self checkSame:self.appName val2:appName]) {
        for (int i = 0; i < appInfos.count; i++) {
            TSsbpApp* appInfo = [appInfos objectAtIndex:i];
            if ([self checkSame:appInfo.appName val2:appName]) {
                [[NSUserDefaults standardUserDefaults] setObject:appInfo.appName forKey:SEL_APP_NAME];
                [[NSUserDefaults standardUserDefaults] setObject:appInfo.appKey forKey:SEL_APP_KEY];
                [[NSUserDefaults standardUserDefaults] setObject:appInfo.secretKey forKey:SEL_SECRET_KEY];
                [[NSUserDefaults standardUserDefaults] setObject:appInfo.host forKey:SEL_HOST];

                // SDK内で保持しているパラメータも強制的に初期化
                [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:SSBP_LOCALE_ID];
                [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:SSBP_LOCALE_DEFAULT];
                if ([self checkSame:appInfo.appKey val2:nowAppKey]) {
                    if (nowDeviceId.length == 0) {
                        [[NSUserDefaults standardUserDefaults] setObject:appInfo.deviceId forKey:SSBP_DEVICE_ID];
                    }
                } else {
                    [[NSUserDefaults standardUserDefaults] setObject:appInfo.deviceId forKey:SSBP_DEVICE_ID];
                }
                [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:SSBP_DEVICE_TOKEN];
                [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:SSBP_MQTT_UUID];
                [[NSUserDefaults standardUserDefaults] synchronize];

                // SDK内で保持している施設マスク設定もクリア
                [[SSBPScannerManager sharedManager] setScanFacilityMask:[NSMutableArray array] enaFlag:true];

                self.useBeaconLog = appInfo.useBeaconLog;
                self.useContentLog = appInfo.useContentLog;
                self.useNotification = appInfo.useNotification;
                isSelect = true;
                break;
            }
        }
    }

    if (isSelect) {
        [self clearAllContent];
    }

    [[SSBPScannerManager sharedManager] regetMaster];
    [self sdkAuthorized];
}

- (void)sdkInitialize {
    // init manager.
    self.appName = [[NSUserDefaults standardUserDefaults] stringForKey:SEL_APP_NAME];
    self.appKey = [[NSUserDefaults standardUserDefaults] stringForKey:SEL_APP_KEY];
    self.secretKey = [[NSUserDefaults standardUserDefaults] stringForKey:SEL_SECRET_KEY];
    NSString* host = [[NSUserDefaults standardUserDefaults] stringForKey:SEL_HOST];
    if ((self.appName.length == 0) || (self.appKey.length == 0) || (self.secretKey.length == 0) || (host.length == 0)) {
        return;
    }

    NSMutableArray* params = [NSMutableArray array];

    SSBPStore* param_appKey = [SSBPStore new];
    param_appKey.key = SSBP_APPKEY;
    param_appKey.value = self.appKey;
    [params addObject:param_appKey];

    SSBPStore* param_host = [SSBPStore new];
    param_host.key = SSBP_TARGET_HOST;
    param_host.value = [NSString stringWithFormat:@"https://%@", host];
    [params addObject:param_host];

    SSBPStore* param_tcp = [SSBPStore new];
    param_tcp.key = SSBP_MQTT_TARGET_TCP;
    param_tcp.value = host;
    [params addObject:param_tcp];

    [[SSBPManager sharedManager] setSessionParam:60 retryCount:0 retryInterval:250];
    [[SSBPManager sharedManager] initialize:params storeKey:self.secretKey];
}

- (void)applicationNewActive {
    // App起動時処理
    // DBやAPIの仕様が変更された場合、ゴミが残っていると問題となる可能性有り
    // 以下の処理を行うことで初期化され解消されるはず
    // ただし、ログ送信エラーによる正常な再送信待ちのデータも消えることになるため必要なら下記2行をコメントアウトすること
    [[SSBPManager sharedManager] allClearBeaconLog];
    [[SSBPManager sharedManager] allClearContentLog];
}

- (void)applicationBecomeActive {
    // Appがアクティブになった時点でバックグラウンド処理を無効化
    if (bgTask != UIBackgroundTaskInvalid) {
        [[UIApplication sharedApplication] endBackgroundTask:bgTask];
        bgTask = UIBackgroundTaskInvalid;
        NSLog(@"endBackgroundTask");
    }

    self.appName = [[NSUserDefaults standardUserDefaults] stringForKey:SEL_APP_NAME];
    NSArray* appInfos = [self getAppInfos];
    if (appInfos.count == 1) {
        TSsbpApp* appInfo = [appInfos objectAtIndex:0];
        if (self.appName.length == 0) {
            // テスト動作として複数に対応するような場合は選択有りきだが、単独設定なら展開し固定で良い
            // ただし、端末のdeviceIdを管理したい場合は注意が必要
            [self setMaster:appInfo.appName];
            return;
        } else {
            // テスト動作として単独設定でも内容を変更した場合には展開する
            // ただし、端末のdeviceIdを管理したい場合は注意が必要
            if (![self checkSame:appInfo.appName val2:self.appName]) {
                [self setMaster:appInfo.appName];
                return;
            }
        }
    }

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        if ([SSBPManager sharedManager].deviceId.length == 0) {
            [self sdkAuthorized];
        } else {
            self.appKey = [[NSUserDefaults standardUserDefaults] stringForKey:SEL_APP_KEY];
            self.secretKey = [[NSUserDefaults standardUserDefaults] stringForKey:SEL_SECRET_KEY];
            self.deviceId = [SSBPManager sharedManager].deviceId;
            self.deviceToken = [SSBPManager sharedManager].deviceToken;
            
            [self sdkSetDeviceLocale];
            if (self.useBeaconLog) {
                [self sendBeaconLog:true];
            }
        }
    });
}

- (void)applicationEnterBackground {
    [self checkBackgroundScan];
}

- (void)applicationTerminate {
    if ([SSBPManager sharedManager].deviceId.length > 0) {
        [self clearActionContent:@"navi"]; // クリアしたいコンテンツがあればここで
    }

    // Appが廃棄になった時点でバックグラウンド処理を無効化
    if (bgTask != UIBackgroundTaskInvalid) {
        [[UIApplication sharedApplication] endBackgroundTask:bgTask];
        bgTask = UIBackgroundTaskInvalid;
        NSLog(@"endBackgroundTask");
    }
}

- (void)startBackgroundTask {
    if (bgTask == UIBackgroundTaskInvalid) {
        bgTask = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
            if (bgTask != UIBackgroundTaskInvalid) {
                [[UIApplication sharedApplication] endBackgroundTask:bgTask];
                bgTask = UIBackgroundTaskInvalid;
                NSLog(@"endBackgroundTask");
            }
        }];
        double secondsToStayOpen = [UIApplication sharedApplication].backgroundTimeRemaining;
        NSLog(@"startBackgroundTask %f", secondsToStayOpen);
    }
}

- (void)sdkAuthorized {
    [self sdkInitialize];
    [[SSBPManager sharedManager] authentication:^(BOOL status, NSError* error) {
        if (status && (error.code == 0)) {
            NSLog(@"sdkAuthorized OK");
            if ([SSBPManager sharedManager].deviceId.length > 0) {
                self.deviceId = [SSBPManager sharedManager].deviceId;
                self.deviceToken = [SSBPManager sharedManager].deviceToken;

                [self sdkSetDeviceLocale];
            } else {
                [self sdkUpdateDeviceInfo:nil];
            }
        } else {
            NSLog(@"sdkAuthorized Error:%@", [error localizedDescription]);

            if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpSdkIFDidFailCheckMaster)]) {
                [self.delegateIF ssbpSdkIFDidFailCheckMaster];
            }
        }
    }];
}

- (void)sdkUpdateDeviceInfo:(NSArray<SSBPAttribute*>*)params {
    [[SSBPManager sharedManager] updateDeviceInfo:params completionHandler:^(NSString* deviceId, NSError* error) {
        if ((deviceId.length > 0) && (error.code == 0)) {
            NSLog(@"sdkUpdateDeviceInfo OK");
            self.deviceId = [SSBPManager sharedManager].deviceId;
            self.deviceToken = [SSBPManager sharedManager].deviceToken;

            if ([SSBPManager sharedManager].localeId.length == 0) {
                [self sdkSetDeviceLocale];
            }
        } else {
            NSLog(@"sdkUpdateDeviceInfo Error:%@", [error localizedDescription]);

            if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpSdkIFDidFailCheckMaster)]) {
                [self.delegateIF ssbpSdkIFDidFailCheckMaster];
            }
        }

        if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpSdkIFDidFinishUpdateDeviceInfo)]) {
            [self.delegateIF ssbpSdkIFDidFinishUpdateDeviceInfo];
        }
    }];
}

- (void)sdkSetDeviceLocale {
    [[SSBPManager sharedManager] setDeviceLocale:^(BOOL change, NSError* error) {
        if ((error == nil) || (error.code == 0)) {
            self.localeId = [SSBPManager sharedManager].localeId;
            self.localeDefault = [SSBPManager sharedManager].localeDefault;

            if (change) {
                [[SSBPScannerManager sharedManager] relocaleMaster];
                [self sdkGetCsvMaster];
            }
        } else {
            NSLog(@"sdkSetDeviceLocale Error:%@", [error localizedDescription]);

            if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpSdkIFDidFailCheckMaster)]) {
                [self.delegateIF ssbpSdkIFDidFailCheckMaster];
            }
        }
        [self sdkGetMaster];
    }];
}

- (void)sdkGetCsvMaster {
    SSBPCsvIF* csvIF = [SSBPCsvIF new];
    NSArray* appInfos = [csvIF getAppInfos];
    for (TSsbpApp* appInfo in appInfos) {
        if ([self checkSame:appInfo.appName val2:self.appName]) {
            if (appInfo.csvFacilities.length > 0) {
                NSArray* facilities = [csvIF getFacilityCSV:self.localeId defLocaleId:self.localeDefault since:@"" csvFacilities:appInfo.csvFacilities csvFloors:appInfo.csvFloors];
                NSLog(@"setFacilityList:%@", [csvIF getLastUpdate]);
                [[SSBPScannerManager sharedManager] setFacilityList:facilities updateTime:[csvIF getLastUpdate]];
            } else {
                [[SSBPScannerManager sharedManager] setFacilityList:nil updateTime:@""];
            }
            if (appInfo.csvBeacons.length > 0) {
                NSArray* beacons = [csvIF getBeaconCSV:@"" csvBeacons:appInfo.csvBeacons];
                NSLog(@"setBeaconList:%@", [csvIF getLastUpdate]);
                [[SSBPScannerManager sharedManager] setBeaconList:beacons updateTime:[csvIF getLastUpdate]];
            } else {
                [[SSBPScannerManager sharedManager] setBeaconList:nil updateTime:@""];
            }
            if (appInfo.csvNodes.length > 0) {
                NSArray* nodes = [csvIF getNodeCSV:self.localeId defLocaleId:self.localeDefault since:@"" csvNodes:appInfo.csvNodes];
                NSLog(@"setNodeList:%@", [csvIF getLastUpdate]);
                [[SSBPScannerManager sharedManager] setNodeList:nodes updateTime:[csvIF getLastUpdate]];
            } else {
                [[SSBPScannerManager sharedManager] setNodeList:nil updateTime:@""];
            }
            if (appInfo.csvEdges.length > 0) {
                NSArray* edges = [csvIF getEdgeCSV:@"" csvEdges:appInfo.csvEdges];
                NSLog(@"setEdgeList:%@", [csvIF getLastUpdate]);
                [[SSBPScannerManager sharedManager] setEdgeList:edges updateTime:[csvIF getLastUpdate]];
            } else {
                [[SSBPScannerManager sharedManager] setEdgeList:nil updateTime:@""];
            }
/*
#pragma mark debug --
            if ([self checkSame:appInfo.csvEdges val2:@"app1_connection_nodes"]) {
                NSArray* geofences = [csvIF getGeofenceCSV:self.localeId defLocaleId:self.localeDefault since:@"" csvGeofences:@"app1_geofences"];
                NSLog(@"setGeofenceList:%@", [csvIF getLastUpdate]);
                [[SSBPScannerManager sharedManager] setGeofenceList:geofences updateTime:[csvIF getLastUpdate]];
            }
#pragma mark -- debug
*/
            [[SSBPScannerManager sharedManager] setGeofenceList:nil updateTime:@""];
        }
    }
}

- (void)sdkGetMaster {
    [[SSBPScannerManager sharedManager] checkMaster];

    if (self.useNotification) {
        [self registerNotification];
    }
}

#pragma mark -
#pragma mark 属性関連

- (void)getAttributes {
    [[SSBPManager sharedManager] getAttributes:^(NSArray<SSBPQuestion*>* ssbpQuestions, NSError* error) {
        if (self.attrAnswers == nil) {
            self.attrAnswers = [NSMutableDictionary dictionary];
        } else {
            if (self.attrAnswers.count > 0) {
                [self.attrAnswers removeAllObjects];
            }
        }

        if (error.code == 0) {
            if (ssbpQuestions != nil) {
                for (SSBPQuestion* question in ssbpQuestions) {
                    for (SSBPAnswer* answer in question.answers) {
                        [self.attrAnswers setObject:@"0" forKey:answer.answerId];
                    }
                }
            }
            self.attrQuestions = ssbpQuestions;
            oldAnswers = [self.attrAnswers copy];
        } else {
            NSLog(@"error getAttributes(%@)", error);
        }

        if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpSdkIFDidFinishGetAttributes)]) {
            [self.delegateIF ssbpSdkIFDidFinishGetAttributes];
        }
    }];
}

- (void)getDeviceInfo {
    [[SSBPManager sharedManager] getDeviceInfo:^(NSArray<SSBPAttribute*>* ssbpAttributes, NSError* error) {
        if (ssbpAttributes && (self.attrQuestions != nil)) {
            for (SSBPQuestion* question in self.attrQuestions) {
                for (SSBPAttribute* attribute in ssbpAttributes) {
                    if ([self checkSame:question.attrId val2:attribute.attrId]) {
                        for (SSBPAnswer* answer in question.answers) {
                            [self.attrAnswers setObject:@"0" forKey:answer.answerId];
                            if ([attribute.answerId containsObject:answer.answerId]) {
                                [self.attrAnswers setObject:@"1" forKey:answer.answerId];
                            }
                        }
                    }
                }
            }
            oldAnswers = [self.attrAnswers copy];
        } else {
            NSLog(@"error getDeviceInfo(%@)", error);
        }

        if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpSdkIFDidFinishGetDeviceInfo)]) {
            [self.delegateIF ssbpSdkIFDidFinishGetDeviceInfo];
        }
    }];
}

- (void)updateDeviceInfo {
    BOOL isChange = false;
    if ((self.attrAnswers != nil) && (oldAnswers != nil)) {
        NSArray* keys = [self.attrAnswers allKeys];
        for (NSString* key in keys) {
            NSString* value = [self.attrAnswers objectForKey:key];
            NSString* valueOld = [oldAnswers objectForKey:key];
            if (![self checkSame:value val2:valueOld]) {
                isChange = true;
                break;
            }
        }
    }

    if (isChange && (self.attrQuestions != nil)) {
        NSMutableArray* result = [NSMutableArray array];

        //for (int i = 0; i < 1; i++) {
        for (int i = 0; i < self.attrQuestions.count; i++) {
            SSBPQuestion* question = [self.attrQuestions objectAtIndex:i];

            NSMutableArray* answerId = [NSMutableArray array];
            for (SSBPAnswer* answer in question.answers) {
                NSString* value = [self.attrAnswers objectForKey:answer.answerId];
                if ([self checkSame:value val2:@"1"]) {
                    [answerId addObject:answer.answerId];
                    if (question.multipleAllowed != 1) break;
                }
            }

            if (answerId.count > 0) {
                SSBPAttribute* attr = [SSBPAttribute new];
                attr.attrId = question.attrId;
                attr.answerId = answerId;
                [result addObject:attr];
            }
        }

        [self sdkUpdateDeviceInfo:result];
    } else {
        if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpSdkIFDidFinishUpdateDeviceInfo)]) {
            [self.delegateIF ssbpSdkIFDidFinishUpdateDeviceInfo];
        }
    }
}

#pragma mark -
#pragma mark 汎用コンテンツ

- (void)getUtilityContents {
    [[SSBPScannerManager sharedManager] getUtilityContents];
}

#pragma mark -
#pragma mark 検知制御

- (BOOL)getBackgroundScan {
    NSArray* modes = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"UIBackgroundModes"];
    if ((modes != nil) && (modes.count > 0)) {
        /*
        // GPSのBackground動作だけ厳密にチェックするなら以下の処理とする
        BOOL chkMode = false;
        if ((modes != nil) && (modes.count > 0)) {
            NSUInteger index = [modes indexOfObject:@"location"];
            if (index != NSNotFound) {
                chkMode = true;
            }
        }
        return chkMode;
        */
        return true;
    } else {
        return false;
    }
}

- (void)setDetectBeacon:(BOOL)flag {
    if (flag) {
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:SSBP_DETECT_BEACON];
    } else {
        [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:SSBP_DETECT_BEACON];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (BOOL)getDetectBeacon {
    long detectBeacon = [[NSUserDefaults standardUserDefaults] integerForKey:SSBP_DETECT_BEACON];
    return (detectBeacon > 0);
}

- (void)scanStart {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        if ([self getDetectBeacon]) {
            [[SSBPScannerManager sharedManager] scanStart];
        } else if ([SSBPScannerManager sharedManager].useGPS) {
            [[SSBPScannerManager sharedManager] startLocationService];
        }
    });
}

- (void)checkBackgroundScan {
    // ビーコンログ送信のためにバックグラウンド処理を有効化(180秒ルール適用)
    [self startBackgroundTask];

    // 非アクティブ時に保持しているビーコンログを送信
    if ([SSBPManager sharedManager].deviceId.length > 0) {
        if (self.useBeaconLog) {
            [self sendBeaconLog:false];
        }
    }

    // 設定に依存して動作に制限がかかるため、明示的に止める制御は不要
    // 明示的に制御してしまうと、常に許可としても動作再開は出来ない
    /*
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        if ([CLLocationManager authorizationStatus] != kCLAuthorizationStatusAuthorizedAlways) {
            //[[SSBPScannerManager sharedManager] scanStop];
        } else if (![self getBackgroundScan]) {
            //[[SSBPScannerManager sharedManager] stopLocationService];
        } else {
            if ([SSBPScannerManager sharedManager].useGPS) {
                if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive) {
                    [[SSBPScannerManager sharedManager] startLocationService];
                } else {
                    [[SSBPScannerManager sharedManager] startLocationService];
                    //[[SSBPScannerManager sharedManager] startSignificantLocationService];
                }
            }
        }
    });
    */
}

- (void)scanStop {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [[SSBPScannerManager sharedManager] scanStop];

        if ([SSBPScannerManager sharedManager].useGPS) {
            if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive) {
                [[SSBPScannerManager sharedManager] startLocationService];
            } else {
                [[SSBPScannerManager sharedManager] startLocationService];
                //[[SSBPScannerManager sharedManager] startSignificantLocationService];
            }
        }
    });
}

#pragma mark -
#pragma mark SSBPScannerDelegate override

- (void)ssbpScannerDidFinishCheckMaster {
    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerDidFinishCheckMaster)]) {
        [self.delegateIF ssbpScannerDidFinishCheckMaster];
    }

    [self scanStart];
}

- (void)ssbpScannerHitBeacon:(NSString*)beaconId {
    [[SSBPScannerManager sharedManager]getBeaconContents:beaconId];

    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerHitBeacon:)]) {
        [self.delegateIF ssbpScannerHitBeacon:beaconId];
    }
}

- (void)ssbpScannerHitGeofence:(NSString*)geofenceId message:(NSString*)message {
    [[SSBPScannerManager sharedManager]getGeofenceContents:geofenceId];
    TSsbpGeofence* geofence = [[SSBPScannerManager sharedManager]getInnerGeofence:geofenceId];

    if (SSBP_GEOFENCE_DEBUG >= 0) {
        if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive) {
        } else {
            if (geofence.geofenceMessage.length > 0) {
                [self sendLocalNotification:@"" message:geofence.geofenceMessage info:nil];
            }
        }
    }

    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerHitGeofence:message:)]) {
        [self.delegateIF ssbpScannerHitGeofence:geofenceId message:message];
    }
}

- (void)ssbpScannerHitBeaconContents:(NSArray<SSBPContent*>*)ssbpContents beaconId:(NSString*)beaconId {
    if (ssbpContents == nil) return;

    [[SSBPContentIF sharedInstance] addContents:ssbpContents beaconId:beaconId geofenceId:@""];

    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerHitBeaconContents:beaconId:)]) {
        [self.delegateIF ssbpScannerHitBeaconContents:ssbpContents beaconId:beaconId];
    }
}

- (void)ssbpScannerHitGeofenceContents:(NSArray<SSBPContent*>*)ssbpContents geofenceId:(NSString*)geofenceId {
    if (ssbpContents == nil) return;

    [[SSBPContentIF sharedInstance] addContents:ssbpContents beaconId:@"" geofenceId:geofenceId];

    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerHitGeofenceContents:geofenceId:)]) {
        [self.delegateIF ssbpScannerHitGeofenceContents:ssbpContents geofenceId:geofenceId];
    }
}

- (void)ssbpScannerHitUtilityContents:(NSArray<SSBPContent*>*)ssbpContents {
    if (ssbpContents == nil) return;

    [[SSBPContentIF sharedInstance] addContents:ssbpContents beaconId:@"" geofenceId:@""];

    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerHitUtilityContents:)]) {
        [self.delegateIF ssbpScannerHitUtilityContents:ssbpContents];
    }
}

- (void)ssbpScannerHitRoute:(NSArray<NSString*>*)ssbpRoute {
    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerHitRoute:)]) {
        [self.delegateIF ssbpScannerHitRoute:ssbpRoute];
    }
}

- (void)ssbpScannerDidFinishLocation {
    /*
    NSDate* now = [NSDate date];
    NSString* message = [NSString stringWithFormat:@"didUpdateLocations %@ / %@ (%.02fm) - %@", [SSBPScannerManager sharedManager].latitude, [SSBPScannerManager sharedManager].longitude, [[SSBPScannerManager sharedManager].horizontalAccuracy doubleValue], [self makeLocaleDateTimeToString:now]];
    //NSLog(@"%@", message);
    if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive) {
    } else {
        [self sendNotification:@"" message:message info:nil];
    }
    */

    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerDidFinishLocation)]) {
        [self.delegateIF ssbpScannerDidFinishLocation];
    }
}

- (void)ssbpScannerDidFailLocationWithError:(NSError*)error {
    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerDidFailLocationWithError:)]) {
        [self.delegateIF ssbpScannerDidFailLocationWithError:error];
    }
}

- (void)ssbpScannerDidFinishHeading {
    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerDidFinishHeading)]) {
        [self.delegateIF ssbpScannerDidFinishHeading];
    }
}

- (void)ssbpScannerDidMessage:(NSString*)type title:(NSString*)title message:(NSString*)message {
   // NSLog(@"%@", message);
    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerDidMessage:title:message:)]) {
        [self.delegateIF ssbpScannerDidMessage:type title:title message:message];
    }

    @autoreleasepool {
        if (SSBP_GEOFENCE_DEBUG > 0) {
            if ([self checkSame:type val2:SSBP_MESSAGE_ENTER_GEOFENCE] || [self checkSame:type val2:SSBP_MESSAGE_EXIT_GEOFENCE]) {
                TSsbpGeofence* tSsbpGeofence = [[SSBPScannerManager sharedManager] getInnerGeofence:title];
                CLLocation* g_pos = [[CLLocation alloc] initWithLatitude:[tSsbpGeofence.latitude doubleValue] longitude:[tSsbpGeofence.longitude doubleValue]];

                CLLocationManager* locationManager = [CLLocationManager new];
                CLLocation* n_pos = [locationManager location];

                CLLocationDistance distance = 0;
                CLLocationAccuracy accuracy = 0;
                if (n_pos == nil) {
                    if (([SSBPScannerManager sharedManager].latitude.length > 0) && ([SSBPScannerManager sharedManager].longitude.length > 0)) {
                        n_pos = [[CLLocation alloc] initWithLatitude:[[SSBPScannerManager sharedManager].latitude doubleValue] longitude:[[SSBPScannerManager sharedManager].longitude doubleValue]];
                    }
                }
                if (n_pos != nil) {
                    distance = [g_pos distanceFromLocation:n_pos];
                    accuracy = n_pos.horizontalAccuracy;
                }

                [self sendLocalNotification:type message:[NSString stringWithFormat:@"%@ / (距離%fm:誤差%0.2fm)", message, distance, accuracy] info:nil];
            }
            if (SSBP_GEOFENCE_DEBUG > 1) {
                if ([self checkSame:type val2:SSBP_MESSAGE_ENTERED_GEOFENCE] || [self checkSame:type val2:SSBP_MESSAGE_EXITED_GEOFENCE]) {
                    [self sendLocalNotification:type message:message info:nil];
                }
            }
        }
    }
}

- (void)ssbpScannerChangeNearest:(NSString*)beaconId {
    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerChangeNearest:)]) {
        [self.delegateIF ssbpScannerChangeNearest:beaconId];
    }
}

- (void)ssbpScannerChangeBeacon:(SSBPRegionInfo*)info {
    if ((info != nil) && (info.beaconId.length > 0)) {
        [self addBeaconLog:info.beaconId proximity:info.proximity];
    }

    if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpScannerChangeBeacon:)]) {
        [self.delegateIF ssbpScannerChangeBeacon:info];
    }
}

#pragma mark -
#pragma mark SSBPContentIFDelegate override

- (void)ssbpContentIFAddContent:(NSString*)contentId {
    [self addContentGetLog:contentId];

    TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:contentId];

    BOOL isCoupon = [content.contentAction hasPrefix:@"coupon"];
    BOOL isInfo = [content.contentAction hasPrefix:@"info"];
    BOOL isPush = [content.contentAction hasPrefix:@"push"];
    BOOL isPocket= [content.contentAction hasPrefix:@"pocket"];

    if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive) {
        if (self.delegateIF && [self.delegateIF respondsToSelector:@selector(ssbpSdkIFAddContent:)]) {
            [self.delegateIF ssbpSdkIFAddContent:contentId];
        }
    } else {
        NSDate* now = [NSDate date];
        NSMutableDictionary* info = [NSMutableDictionary dictionary];
        if (isCoupon) {
            [info setValue:@"coupon" forKey:SSBP_NOTIFICATION_TYPE];
            [info setValue:content.contentId forKey:SSBP_NOTIFICATION_ID];
            [self sendLocalNotification:@"" message:[NSString stringWithFormat:NSLocalizedString(@"captionAddCouponMessage", @""), [self escapeString:content.contentId], [self makeLocaleDateTimeToString:now]] info:info.copy];
        } else if (isInfo) {
            //[info setValue:@"info" forKey:SSBP_NOTIFICATION_TYPE];
            //[info setValue:content.contentId forKey:SSBP_NOTIFICATION_ID];
            //[self sendLocalNotification:@"" message:[NSString stringWithFormat:NSLocalizedString(@"captionAddInfoMessage", @""), [self escapeString:content.contentName], [self makeLocaleDateToString:now]] info:info.copy];
        } else if (isPush) {
            [self sendNotification:content.contentId message:content.contentId info:nil];
        }
        else if (isPocket) {
            [info setValue:@"pocket" forKey:SSBP_NOTIFICATION_TYPE];
            [info setValue:content.contentId forKey:SSBP_NOTIFICATION_ID];
            [self sendLocalNotification:content.contentTitle message:[NSString stringWithFormat:NSLocalizedString(content.contentSubTitle, @""), [self escapeString:content.contentId],[self makeLocaleDateTimeToString:now]] info:info.copy];
            [[NSNotificationCenter defaultCenter]postNotificationName:@"pocketDetail" object:content];
//            [self sendNotification:content.contentId message:content.contentId info:nil];
        }


    }
}

- (void)ssbpContentIFGetURL:(NSString*)type url:(NSString*)url {
    if ([url hasPrefix:@"https"]) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            SSBPHttpRequester* requester = [SSBPHttpRequester new];
            [requester httpRequestGet:url withParam:nil completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
                if ((error != nil) || (data == nil)) return;
            }];
        });
    }
}

#pragma mark -
#pragma mark SSBPContent

- (BOOL)useContent:(NSString*)contentId {
    @autoreleasepool {
        BOOL chk = [[SSBPContentIF sharedInstance] useContent:contentId];
        if (chk) {
            [self addContentUseLog:contentId];
        }
        return chk;
    }
}

- (BOOL)removeContent:(NSString*)contentId {
    @autoreleasepool {
        return [[SSBPContentIF sharedInstance] removeContent:contentId];
    }
}

- (void)clearAllContent {
    @autoreleasepool {
        [[SSBPContentIF sharedInstance] clearAllContent];
        [[SSBPScannerManager sharedManager] clearAllBeaconAction];
    }
}

- (void)clearActionContent:(NSString*)action {
    @autoreleasepool {
        NSArray* contents = [[SSBPContentIF sharedInstance] getInnerContents:action];
        if (contents != nil) {
            for (TSsbpContent* content in contents) {
                [self removeContent:content.contentId];
                [[SSBPScannerManager sharedManager] clearBeaconAction:content.beaconId];
            }
        }
    }
}

#pragma mark -
#pragma mark Log関係

- (void)addBeaconLog:(NSString*)beaconId proximity:(CLProximity)proximity {
    if (self.useBeaconLog) {
        TSsbpBeacon* ssbpBeacon = [[SSBPScannerManager sharedManager] getInnerBeacon:beaconId];
        if (ssbpBeacon != nil) {
            NSMutableArray* array = [NSMutableArray array];

            SSBPBeaconLog* beaconLog = [SSBPBeaconLog new];
            beaconLog.beaconId = ssbpBeacon.beaconId;
            beaconLog.proximity = proximity;
            beaconLog.accuracy = @"";
            if ([SSBPScannerManager sharedManager].useGPS) {
                beaconLog.latitude = [SSBPScannerManager sharedManager].latitude;
                beaconLog.longitude= [SSBPScannerManager sharedManager].longitude;
                beaconLog.gpsAccuracy= [SSBPScannerManager sharedManager].horizontalAccuracy;
            }
            if ([SSBPScannerManager sharedManager].useCoreBluetooth) {
                beaconLog.battery = ssbpBeacon.batteryLevel;
                beaconLog.rssi = [NSString stringWithFormat:@"%ld", (long)ssbpBeacon.rssi];
            } else {
                beaconLog.battery = -1;
                beaconLog.rssi = @"";
            }

            beaconLog.timestamp = [NSDate date];

            [array addObject:beaconLog];
            [[SSBPManager sharedManager] storeBeaconLog:array];

            if (SENDLOG_REALTIME != 0) {
                [self sendBeaconLog:false];
            }
        }
    }
}

- (void)sendBeaconLog:(BOOL)loopFlag {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(sendBeaconLog:) object:nil];
    if (!self.useBeaconLog) return;

    [[SSBPManager sharedManager] addBeaconLog:^(NSError* error) {
        // リアルタイム送信および送信フラグが立っていなければ再送信はしない
        // この処理は、送信の成否に関わらずで良いと思われる
        if (SENDLOG_REALTIME != 0) {
            if (loopFlag) {
                [self performSelector:@selector(sendBeaconLog:) withObject:[NSNumber numberWithBool:true] afterDelay:SENDLOG_INTERVAL];
            }
        }
    }];
}

- (void)addContentGetLog:(NSString*)contentId {
    if (self.useContentLog) {
        TSsbpContent* tSsbpContent = [[SSBPContentIF sharedInstance] getInnerContent:contentId];
        if (tSsbpContent != nil) {
            NSMutableArray* array = [NSMutableArray array];

            SSBPContentLog* contentLog = [SSBPContentLog new];
            contentLog.type = 1;
            contentLog.contentId = tSsbpContent.contentId;
            contentLog.beaconId = tSsbpContent.beaconId;
            if ([SSBPScannerManager sharedManager].useGPS) {
                contentLog.latitude = [SSBPScannerManager sharedManager].latitude;
                contentLog.longitude= [SSBPScannerManager sharedManager].longitude;
                contentLog.accuracy= [SSBPScannerManager sharedManager].horizontalAccuracy;
            }
            contentLog.getTimestamp = [self makeUTCDateTimeFromString:tSsbpContent.acquiredDate];

            [array addObject:contentLog];
            [[SSBPManager sharedManager] storeContentLog:array];

            [self sendContentLog];
        }
    }
}

- (void)addContentUseLog:(NSString*)contentId {
    if (self.useContentLog) {
        TSsbpContent* tSsbpContent = [[SSBPContentIF sharedInstance] getInnerContent:contentId];
        if (tSsbpContent != nil) {
            NSMutableArray* array = [NSMutableArray array];

            SSBPContentLog* contentLog = [SSBPContentLog new];
            contentLog.type = 2;
            contentLog.contentId = tSsbpContent.contentId;
            contentLog.beaconId = tSsbpContent.beaconId;
            if ([SSBPScannerManager sharedManager].useGPS) {
                contentLog.latitude = [SSBPScannerManager sharedManager].latitude;
                contentLog.longitude= [SSBPScannerManager sharedManager].longitude;
                contentLog.accuracy= [SSBPScannerManager sharedManager].horizontalAccuracy;
            }
            contentLog.getTimestamp = [self makeUTCDateTimeFromString:tSsbpContent.acquiredDate];
            contentLog.useTimestamp = [self makeUTCDateTimeFromString:tSsbpContent.usedDate];

            [array addObject:contentLog];
            [[SSBPManager sharedManager] storeContentLog:array];

            [self sendContentLog];
        }
    }
}

- (void)sendContentLog {
    [[SSBPManager sharedManager] addContentLog:^(NSError* error) {
    }];
}

#pragma mark -
#pragma mark Remote通知関連

- (void)registerRemoteNotification {
//#if __IPHONE_OS_VERSION_MAX_ALLOWED < 100000
    // iOS8からは、LocalNotificationでも確認が必要
    // 及び、APNsを使わない通知を利用する場合でユーザーの許諾を行わないと、Appleの審査でrejectされる可能性有り
    if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerUserNotificationSettings:)]) {
        UIUserNotificationSettings* settings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert|UIUserNotificationTypeBadge|UIUserNotificationTypeSound categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    }
/* iOS10以降の場合、"UserNotifications framework"を追加した上で以下の処理が必要となる
#else
     UNUserNotificationCenter *notifiCenter = [UNUserNotificationCenter currentNotificationCenter];
     [notifiCenter requestAuthorizationWithOptions:(UNAuthorizationOptionSound | UNAuthorizationOptionAlert | UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error){
     if (!error) {
     [[UIApplication sharedApplication] registerForRemoteNotifications];
     }
     }];
#endif
*/
}

- (void)registerDeviceToken:(NSData*)deviceToken {
    // APNSへ登録成功 -> SSBPへ登録処理
    [[SSBPManager sharedManager] registerDeviceToken:deviceToken];
}

#pragma mark -
#pragma mark Local通知関連

- (void)registerNotification {
//#if __IPHONE_OS_VERSION_MAX_ALLOWED < 100000
    // iOS8からは、LocalNotificationでも確認が必要
    // 及び、APNsを使わない通知を利用する場合でユーザーの許諾を行わないと、Appleの審査でrejectされる可能性有り
    if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerUserNotificationSettings:)]) {
        UIUserNotificationSettings* settings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert|UIUserNotificationTypeBadge|UIUserNotificationTypeSound categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    }
/* iOS10以降の場合、"UserNotifications framework"を追加した上で以下の処理が必要となる
#else
    UNUserNotificationCenter *notifiCenter = [UNUserNotificationCenter currentNotificationCenter];
    [notifiCenter requestAuthorizationWithOptions:(UNAuthorizationOptionSound | UNAuthorizationOptionAlert | UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error){
        if (!error) {
            [[UIApplication sharedApplication] registerForRemoteNotifications];
        }
    }];
#endif
*/
}

- (void)sendLocalNotification:(NSString*)title message:(NSString*)message info:(NSDictionary*)info {
    if (self.useNotification) {
        [self sendNotification:title message:message info:info];
    }
}

- (void)sendNotification:(NSString*)title message:(NSString*)message info:(NSDictionary*)info {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        @autoreleasepool {
//#if __IPHONE_OS_VERSION_MAX_ALLOWED < 100000
            //[self clearAllNotification];

            // 新規通知を作成する
            UILocalNotification* notification = [UILocalNotification new];

            notification.fireDate = [NSDate new];
            notification.timeZone = [NSTimeZone defaultTimeZone];
            notification.alertTitle = title;
            notification.alertBody = message;
            notification.userInfo = info;
            notification.hasAction = true;
            notification.alertAction = @"Open";

            // 新規通知を登録する
            [[UIApplication sharedApplication] scheduleLocalNotification:notification];
/*
#else
            NSDate* now = [NSDate date];
            NSInteger unixtime = [now timeIntervalSince1970];

            UNMutableNotificationContent* notificationContent = [[UNMutableNotificationContent alloc] init];
            notificationContent.title = title;
            notificationContent.body = message;
            notificationContent.userInfo = info;

            UNTimeIntervalNotificationTrigger* trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:0 repeats: false];
            UNNotificationRequest* request = [UNNotificationRequest requestWithIdentifier:[NSString stringWithFormat:@"%ld", (long)unixtime] content:objNotificationContent trigger:trigger];
            UNUserNotificationCenter* center = [UNUserNotificationCenter currentNotificationCenter];
            [center addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) { }];
#endif
*/
        }
    });
}

- (void)clearAllNotification {
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
}

- (void)clearNotification:(UILocalNotification*)notification {
    NSArray* oldNotifications = [[UIApplication sharedApplication].scheduledLocalNotifications mutableCopy];

    NSString* type = [notification.userInfo objectForKey:SSBP_NOTIFICATION_TYPE];
    NSString* notificationId = [notification.userInfo objectForKey:SSBP_NOTIFICATION_ID];

    for (UILocalNotification* oldNotification in oldNotifications) {
        NSString* oldType = [oldNotification.userInfo objectForKey:SSBP_NOTIFICATION_TYPE];
        NSString* oldId = [oldNotification.userInfo objectForKey:SSBP_NOTIFICATION_ID];

        if ([self checkSame:oldType val2:type] && [self checkSame:oldId val2:notificationId]) {
            [[UIApplication sharedApplication] cancelLocalNotification:notification];
        }
    }
}

#pragma mark -
#pragma mark Etc

- (NSString*)checkAuthDigest {
    return [[SSBPManager sharedManager] makeAuthDigest];
}

- (NSString*)makeUTCDateTimeToString:(NSDate*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
        [formatter setLocale:[NSLocale systemLocale]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString* strDate = [formatter stringFromDate:date];
        if (strDate) {
            return strDate;
        } else {
            return @"";
        }
    }
}

- (NSDate*)makeUTCDateTimeFromString:(NSString*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
        [formatter setLocale:[NSLocale systemLocale]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        return [formatter dateFromString:date];
    }
}

- (NSString*)makeLocaleDateToString:(NSDate*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone defaultTimeZone]];
        [formatter setLocale:[NSLocale currentLocale]];
        formatter.dateFormat = NSLocalizedString(@"captionDateFormat", @"");
        NSString* strDate = [formatter stringFromDate:date];
        if (strDate) {
            return strDate;
        } else {
            return @"";
        }
    }
}

- (NSString*)makeLocaleDateTimeToString:(NSDate*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone defaultTimeZone]];
        [formatter setLocale:[NSLocale currentLocale]];
        formatter.dateFormat = NSLocalizedString(@"captionDateTimeFormat", @"");
        NSString* strDate = [formatter stringFromDate:date];
        if (strDate) {
            return strDate;
        } else {
            return @"";
        }
    }
}

- (BOOL)checkSame:(NSString*)val1 val2:(NSString*)val2 {
    if ((val1 == nil) && (val2 == nil)) return true;
    else if (val1 == nil) return false;
    else if (val2 == nil) return false;
    else if ([val1 compare:val2] == NSOrderedSame) return true;
    else return false;
}

- (NSString*)escapeString:(NSString*)str {
    return [[[[str stringByReplacingOccurrencesOfString:@"\'" withString:@"\\\'"]
              stringByReplacingOccurrencesOfString:@"\\" withString:@"\\\\"]
             stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""]
            stringByReplacingOccurrencesOfString:@"%" withString:@"%%"];
}

@end
