//
//  SSBPContentIF.h
//
//  Created by Ayumi Togashi on 2016/09/27.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_App_Static_SSBPContentIF_h
#define SSBP_App_Static_SSBPContentIF_h

#import <Foundation/Foundation.h>

#import <SSBPSdk/SSBPContent.h>

#import "TSsbpContent.h"

@protocol SSBPContentIFDelegate <NSObject>

@optional

- (void)ssbpContentIFAddContent:(NSString*)contentId;
- (void)ssbpContentIFGetURL:(NSString*)type url:(NSString*)url;

@end

@interface SSBPContentIF : NSObject

@property (weak, nonatomic) id<SSBPContentIFDelegate>delegateIF;

+ (SSBPContentIF*)sharedInstance;

- (void)addContents:(NSArray<SSBPContent*>*)ssbpContents beaconId:(NSString*)beaconId geofenceId:(NSString*)geofenceId;
- (void)addContent:(TSsbpContent*)content;
- (NSArray<TSsbpContent*>*)getInnerContents:(NSString*)action;
- (NSArray<TSsbpContent*>*)getInnerBeaconContents:(NSString*)beaconId;
- (NSArray<TSsbpContent*>*)getInnerGeofenceContents:(NSString*)geofenceId;
- (TSsbpContent*)getInnerContent:(NSString*)contentId;

- (BOOL)useContent:(NSString*)contentId;
- (BOOL)removeContent:(NSString*)contentId;
- (void)clearAllContent;

@end

#endif
