//
//  SSBPNode.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Node_h
#define SSBP_AppSDK_Static_Node_h

@interface SSBPNode : NSObject

@property (copy, nonatomic) NSString* nodeId;
@property (copy, nonatomic) NSString* nodeName;
@property (assign, nonatomic) NSInteger nodeType;
@property (copy, nonatomic) NSString* facilityId;
@property (copy, nonatomic) NSString* floorId;
@property (assign, nonatomic) NSInteger relativeX;
@property (assign, nonatomic) NSInteger relativeY;
@property (copy, nonatomic) NSString* beaconId;
@property (assign, nonatomic) NSInteger goalFlag;
@property (copy, nonatomic) NSString* nodeAction;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
