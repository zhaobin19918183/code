//
//  SSBPSysParam.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_SysParam_h
#define SSBP_AppSDK_Static_SysParam_h

@interface SSBPSysParam : NSObject

@property (copy, nonatomic) NSString* sysKey;
@property (copy, nonatomic) NSString* sysValue;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
