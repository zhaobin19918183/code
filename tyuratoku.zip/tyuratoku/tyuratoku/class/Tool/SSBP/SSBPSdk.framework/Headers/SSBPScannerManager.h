//
//  SSBPScannerManager.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_ScannerManager_h
#define SSBP_AppSDK_Static_ScannerManager_h

#import <CoreLocation/CoreLocation.h>
#import <CoreBluetooth/CoreBluetooth.h>

#import "SSBPManager.h"

#import "SSBPRegionInfo.h"

#import "TSsbpFacility.h"
#import "TSsbpFloor.h"
#import "TSsbpBeacon.h"
#import "TSsbpBeaconAction.h"
#import "TSsbpNode.h"
#import "TSsbpEdge.h"
#import "TSsbpGeofence.h"

@protocol SSBPScannerDelegate <NSObject>

@optional

- (void)ssbpScannerDidFinishCheckMaster;

- (void)ssbpScannerHitUtilityContents:(NSArray<SSBPContent*>*)ssbpContents;

- (void)ssbpScannerHitBeacon:(NSString*)beaconId;
- (void)ssbpScannerHitBeaconContents:(NSArray<SSBPContent*>*)ssbpContents beaconId:(NSString*)beaconId;
- (void)ssbpScannerHitRoute:(NSArray<NSString*>*)ssbpRoute;

- (void)ssbpScannerHitGeofence:(NSString*)geofenceId message:(NSString*)message;
- (void)ssbpScannerHitGeofenceContents:(NSArray<SSBPContent*>*)ssbpContents geofenceId:(NSString*)geofenceId;

- (void)ssbpScannerDidFinishLocation;
- (void)ssbpScannerDidFailLocationWithError:(NSError*)error;

- (void)ssbpScannerDidFinishHeading;

- (void)ssbpScannerDidMessage:(NSString*)type title:(NSString*)title message:(NSString*)message;

- (void)ssbpScannerChangeNearest:(NSString*)beaconId;
- (void)ssbpScannerChangeBeacon:(SSBPRegionInfo*)info;

@end

@interface SSBPScannerManager : CLLocationManager<CLLocationManagerDelegate, CBCentralManagerDelegate, CBPeripheralDelegate>

@property (weak, nonatomic) id<SSBPScannerDelegate>delegateSSBPScanner;

@property (assign, nonatomic) BOOL useGPS;
@property (assign, nonatomic) BOOL useCoreBluetooth;
@property (assign, nonatomic) BOOL useNode;
@property (assign, nonatomic) BOOL useEdge;
@property (assign, nonatomic) BOOL usePublicBeacon;
@property (assign, nonatomic) BOOL useGeofence;

@property (assign, nonatomic) NSInteger waitTime;
@property (assign, nonatomic) NSInteger minInterval;

@property (copy, nonatomic, readonly) NSString* latitude;
@property (copy, nonatomic, readonly) NSString* longitude;
@property (copy, nonatomic, readonly) NSString* horizontalAccuracy;

@property (assign, nonatomic, readonly) CLLocationDirection magneticHeading;
@property (assign, nonatomic, readonly) CLLocationDirection trueHeading;

+ (SSBPScannerManager*)sharedManager;

- (void)regetMaster;
- (void)relocaleMaster;
- (void)checkMaster;
- (void)getRoute:(NSString*)startId goalId:(NSString*)goalId;

- (void)setFacilityList:(NSArray<SSBPFacility*>*)ssbpFacilities updateTime:(NSString*)updateTime;
- (void)setBeaconList:(NSArray<SSBPBeacon*>*)ssbpBeacons updateTime:(NSString*)updateTime;
- (void)setNodeList:(NSArray<SSBPNode*>*)ssbpNodes updateTime:(NSString*)updateTime;
- (void)setEdgeList:(NSArray<SSBPEdge*>*)ssbpEdges updateTime:(NSString*)updateTime;

- (void)setGeofenceList:(NSArray<SSBPGeofence*>*)ssbpGeofences updateTime:(NSString*)updateTime;

- (void)clearAllFloor;
- (void)addFloor:(TSsbpFloor*)floor;
- (void)clearAllBeacon;
- (void)addBeacon:(TSsbpBeacon*)beacon;
- (void)clearAllNode;
- (void)addNode:(TSsbpNode*)node;
- (void)clearAllEdge;
- (void)addEdge:(TSsbpEdge*)edge;

- (void)clearAllGeofence;
- (void)addGeofence:(TSsbpGeofence*)geofence;

- (NSArray<TSsbpFacility*>*)getInnerFacilities;
- (NSArray<TSsbpFloor*>*)getInnerFloors:(NSString*)facilityId;
- (TSsbpFloor*)getInnerFloor:(NSString*)floorId;

- (NSArray<TSsbpBeacon*>*)getInnerBeacons;
- (NSArray<TSsbpBeacon*>*)getInnerFacilityBeacons:(NSString*)facilityId;
- (NSArray<TSsbpBeacon*>*)getInnerFloorBeacons:(NSString*)floorId;
- (TSsbpBeacon*)getInnerBeacon:(NSString*)beaconId;
- (NSArray<TSsbpBeacon*>*)getNearLocationBeacons:(NSInteger)max_num;

- (NSArray<TSsbpNode*>*)getInnerNodesWithAction:(NSString*)action facilityId:(NSString*)facilityId floorId:(NSString*)floorId;
- (NSArray<TSsbpNode*>*)getInnerGoals:(NSString*)facilityId floorId:(NSString*)floorId;
- (TSsbpNode*)getInnerNode:(NSString*)nodeId;
- (TSsbpNode*)getInnerBeaconNode:(NSString*)beaconId;
- (void)getInnerRoute:(NSString*)startId goalId:(NSString*)goalId;

- (NSArray<TSsbpBeaconAction*>*)getBeaconActions;
- (TSsbpBeaconAction*)getBeaconAction:(NSString*)beaconId;
- (void)setBeaconActionStatus:(NSString*)beaconId status:(NSInteger)status;
- (void)clearAllBeaconAction;
- (void)clearBeaconAction:(NSString*)beaconId;

- (NSArray<TSsbpGeofence*>*)getInnerGeofences;
- (TSsbpGeofence*)getInnerGeofence:(NSString*)geofenceId;
- (NSArray<TSsbpGeofence*>*)getNearLocationGeofences:(NSInteger)max_num;

- (void)setScanFacilityMask:(NSArray<NSString*>*)facilityIds enaFlag:(BOOL)enaFlag;
- (NSArray<NSString*>*)getScanFacilityMask:(BOOL)enaFlag;

- (void)scanStart;
- (void)rangingStop;
- (void)scanStop;

- (NSArray<SSBPRegionInfo*>*)getRegionInfoList;

- (void)getUtilityContents;
- (void)getBeaconContents:(NSString*)beaconId;
- (void)getGeofenceContents:(NSString*)geofenceId;

- (void)startLocationService;
- (void)startSignificantLocationService;
- (void)stopLocationService;

- (void)compassStart;
- (void)compassStop;

@end

#endif
