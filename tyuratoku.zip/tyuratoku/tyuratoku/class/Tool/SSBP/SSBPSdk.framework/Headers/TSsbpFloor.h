//
//  TSsbpFloor.h
//
//  Copyright (c) 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_TFloor_h
#define SSBP_AppSDK_Static_TFloor_h

#import <Foundation/Foundation.h>

@interface TSsbpFloor : NSObject

// ID
@property (assign, nonatomic) NSInteger nId;

// Floor Info
@property (copy, nonatomic) NSString* floorId;
@property (copy, nonatomic) NSString* floorName;
@property (copy, nonatomic) NSString* mapImageURL;
@property (copy, nonatomic) NSData* mapImage;
@property (assign, nonatomic) NSInteger floorNum;
@property (assign, nonatomic) double floorDeg;

// Facility Info
@property (copy, nonatomic) NSString* facilityId;
@property (copy, nonatomic) NSString* facilityName;
@property (copy, nonatomic) NSString* uuid;

@property (copy, nonatomic) NSString* createdDate;
@property (copy, nonatomic) NSString* updatedDate;

@end

#endif
