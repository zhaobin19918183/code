//
//  SSBPCommon.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Common_h
#define SSBP_AppSDK_Static_Common_h

#define SSBP_ERRDOMAIN                  @"com.switch-smile.ssbpsdk"
#define SSBP_AUTH_APPKEY_ERROR          @"appKeyまたはその他のパラメータが設定されていません。"
#define SSBP_SERVER_ERROR               @"なんらかの原因で、サーバーに接続できませんでした。"

#define SSBP_APPKEY                     @"AppKey"
#define SSBP_SECRET_KEY                 @"SecretKey"
#define SSBP_TARGET_HOST                @"TargetHost"

#define SSBP_ENDPOINT_AUTH              @"EndpointAuth"
#define SSBP_ENDPOINT_SYSPARAMS         @"EndpointSysParams"
#define SSBP_ENDPOINT_LOCALES           @"EndpointLocales"

#define SSBP_ENDPOINT_DELTA_FACILITIES  @"EndpointDeltaFacilities"
#define SSBP_ENDPOINT_DELTA_BEACONS     @"EndpointDeltaBeacons"
#define SSBP_ENDPOINT_DELTA_NODES       @"EndpointDeltaNodes"
#define SSBP_ENDPOINT_DELTA_EDGES       @"EndpointDeltaEdges"

#define SSBP_ENDPOINT_DELTA_GEOFENCES   @"EndpointDeltaGeofences"

#define SSBP_ENDPOINT_DELTA_PUBLIC_FACILITIES  @"EndpointDeltaPublicFacilities"
#define SSBP_ENDPOINT_DELTA_PUBLIC_BEACONS     @"EndpointDeltaPublicBeacons"

#define SSBP_ENDPOINT_FACILITIES        @"EndpointFacilities"
#define SSBP_ENDPOINT_BEACONS           @"EndpointBeacons"
#define SSBP_ENDPOINT_BEACONCONTENTS    @"EndpointBeaconContents"

#define SSBP_ENDPOINT_GEOFENCECONTENTS  @"EndpointGeofenceContents"

#define SSBP_ENDPOINT_UTILITYCONTENTS   @"EndpointUtilityContents"

#define SSBP_ENDPOINT_ATTRIBUTES        @"EndpointAttributes"
#define SSBP_ENDPOINT_DEVICEINFO        @"EndpointDeviceInfo"
#define SSBP_ENDPOINT_UPDATEDEVICEINFO  @"EndpointUpdateDeviceInfo"

#define SSBP_ENDPOINT_NODES             @"EndpointNodes"
#define SSBP_ENDPOINT_EDGES             @"EndpointEdges"
#define SSBP_ENDPOINT_ROUTE             @"EndpointRoute"

#define SSBP_ENDPOINT_BEACONLOGS        @"EndpointAddBeaconLogs"
#define SSBP_ENDPOINT_CONTENTLOGS       @"EndpointAddContentLogs"

#define SSBP_MQTT_TARGET_TCP            @"MQTTTargetTcp"
#define SSBP_MQTT_TARGET_TCP_PORT       @"MQTTTargetTcpPort"

#define SSBP_MQTT_AUTH_DISABLE          @"0"
#define SSBP_MQTT_AUTH_ENABLE           @"1"
#define SSBP_MQTT_ENABLE                @"MQTTAuthEnable"
#define SSBP_MQTT_USERNAME              @"MQTTUserName"
#define SSBP_MQTT_PASSWORD              @"MQTTPassword"

#define SSBP_PUBLISHTOPIC_BEACONLOGS    @"PublishTopicBeaconLogs"
#define SSBP_SUBSCRIBETOPIC_BEACONLOGS  @"SubscribeTopicBeaconLogs"

#define SSBP_LOCALE_ID                  @"LocaleID"
#define SSBP_LOCALE_DEFAULT             @"LocaleDefault"
#define SSBP_DEVICE_ID                  @"DeviceID"
#define SSBP_DEVICE_TOKEN               @"DeviceToken"
#define SSBP_MQTT_UUID                  @"MqttUUID"

#define SSBP_STORE_BEACON_LOGS          @"ssbp_beacon_logs"
#define SSBP_STORE_CONTENT_LOGS         @"ssbp_content_logs"

#define SSBP_TIMEOUT_INTERVAL           @"TimeoutInterval"
#define SSBP_RETRY_COUNT                @"RetryCount"
#define SSBP_RETRY_INTERVAL             @"RetryInterval"

#define SSBP_PARAM_CONTENT_PATH         @":content_path"
#define SSBP_PARAM_MAP_PATH             @":map_path"
#define SSBP_PARAM_WAIT_TIME            @":content_wait_time"
#define SSBP_PARAM_FACILITY_VER         @":facility_version"
#define SSBP_PARAM_BEACON_VER           @":beacon_version"
#define SSBP_PARAM_NAVI_VER             @":navi_version"

#define SSBP_FACILITY_VER               @"ssbp_facilityVer"
#define SSBP_BEACON_VER                 @"ssbp_beaconVer"
#define SSBP_NAVI_VER                   @"ssbp_naviVer"

#define SSBP_IS_CHANGE_FACILITY         @"ssbp_isChangeFacility"
#define SSBP_IS_CHANGE_BEACON           @"ssbp_isChangeBeacon"
#define SSBP_IS_CHANGE_NAVI             @"ssbp_isChangeNavi"
#define SSBP_IS_CHANGE_NODE             @"ssbp_isChangeNode"
#define SSBP_IS_CHANGE_EDGE             @"ssbp_isChangeEdge"

#define SSBP_WAIT_TIME                  @"ssbp_waitTime"
#define SSBP_CONTENT_PATH               @"ssbp_contentPath"
#define SSBP_MAP_PATH                   @"ssbp_mapPath"

#define SSBP_FACILITY_DATE              @"ssbp_facilityDate"
#define SSBP_BEACON_DATE                @"ssbp_beaconDate"
#define SSBP_NODE_DATE                  @"ssbp_nodeDate"
#define SSBP_EDGE_DATE                  @"ssbp_edgeDate"

#define SSBP_GEOFENCE_DATE              @"ssbp_geofenceDate"

#define SSBP_PUBLIC_FACILITY_DATE       @"ssbp_publicFacilityDate"
#define SSBP_PUBLIC_BEACON_DATE         @"ssbp_publicBeaconDate"

#define SSBP_MESSAGE_ENTER_REGION       @"EnterRegion"
#define SSBP_MESSAGE_EXIT_REGION        @"ExitRegion"
#define SSBP_MESSAGE_RANGE_BEACON       @"RangeBeacon"

#define SSBP_MESSAGE_ENTER_GEOFENCE     @"EnterGeofence"
#define SSBP_MESSAGE_EXIT_GEOFENCE      @"ExitGeofence"
#define SSBP_MESSAGE_ENTERED_GEOFENCE   @"EnteredGeofence"
#define SSBP_MESSAGE_EXITED_GEOFENCE    @"ExitedGeofence"

#define SSBP_NON_INTERVAL_BEACON        @"nonInterval"

#define SSBP_FACILITY_ENA_MASK          @"ssbp_facilityEnaMask"
#define SSBP_FACILITY_DIS_MASK          @"ssbp_facilityDisMask"

#endif
