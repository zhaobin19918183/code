//
//  SSBPFloor.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Floor_h
#define SSBP_AppSDK_Static_Floor_h

@interface SSBPFloor : NSObject

@property (copy, nonatomic) NSString* floorId;
@property (copy, nonatomic) NSString* floorName;
@property (copy, nonatomic) NSString* mapURL;
@property (assign, nonatomic) NSInteger floorNum;
@property (assign, nonatomic) double floorDeg;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
