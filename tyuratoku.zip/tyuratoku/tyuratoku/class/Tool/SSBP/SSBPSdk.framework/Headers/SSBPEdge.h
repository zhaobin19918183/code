//
//  SSBPEdge.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Edge_h
#define SSBP_AppSDK_Static_Edge_h

@interface SSBPEdge : NSObject

@property (copy, nonatomic) NSString* edgeId;
@property (copy, nonatomic) NSString* nodeOut;
@property (copy, nonatomic) NSString* nodeIn;
@property (assign, nonatomic) NSInteger cost;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
