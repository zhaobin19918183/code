//
//  SSBPRoute.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Route_h
#define SSBP_AppSDK_Static_Route_h

@interface SSBPRoute : NSObject

@property (copy, nonatomic) NSString* nodeId;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
