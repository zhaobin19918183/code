//
//  SSBPContent.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Content_h
#define SSBP_AppSDK_Static_Content_h

#import "SSBPStore.h"

@interface SSBPContent : NSObject

@property (copy, nonatomic) NSString* contentId;
@property (copy, nonatomic) NSString* contentName;
@property (copy, nonatomic) NSString* contentAction;
@property (copy, nonatomic) NSArray<SSBPStore*>* contentTexts;
@property (copy, nonatomic) NSArray<SSBPStore*>* contentLinks;
@property (strong, nonatomic) NSDate* contentStartAt;
@property (strong, nonatomic) NSDate* contentEndAt;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
