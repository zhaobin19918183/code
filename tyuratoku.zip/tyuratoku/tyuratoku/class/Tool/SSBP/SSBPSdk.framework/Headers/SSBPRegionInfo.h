//
//  SSBPRegionInfo.h
//
//  Copyright (c) 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <CoreLocation/CoreLocation.h>

@interface SSBPRegionInfo : NSObject

@property (copy, nonatomic) NSString* identifier;
@property (copy, nonatomic) NSString* beaconId;
@property (assign, nonatomic) CLProximity proximity;
@property (copy, nonatomic, readonly) NSString* nearestBeaconId;
@property (strong, nonatomic) NSDate* updatedDate;

- (BOOL)checkNearestBeacon;

@end
