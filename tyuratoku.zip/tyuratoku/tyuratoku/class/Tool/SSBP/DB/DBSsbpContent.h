//
//  DBSsbpContent.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_App_Static_DBSsbpContent_h
#define SSBP_App_Static_DBSsbpContent_h

#import <Foundation/Foundation.h>

#import "FMDB.h"

#import "TSsbpContent.h"

@interface DBSsbpContent : NSObject {
    FMDatabase* db;
}

- (void)dropDatabase;

// 一覧取得
- (NSArray<TSsbpContent*>*)getAll;
- (NSArray<TSsbpContent*>*)getActions:(NSString*)action;
- (NSArray<TSsbpContent*>*)getBeacons:(NSString*)beaconId;
- (NSArray<TSsbpContent*>*)getGeofences:(NSString*)geofenceId;

- (TSsbpContent*)findByContentID:(NSString*)contentId;

- (BOOL)add:(TSsbpContent*)ssbpContent;
- (BOOL)update:(TSsbpContent*)ssbpContent;
- (BOOL)use:(NSString*)contentId;

- (BOOL)remove:(NSString*)contentId;
- (BOOL)removeAll;

@end

#endif
