//
//  TSsbpContent.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_App_Static_TSsbpContent_h
#define SSBP_App_Static_TSsbpContent_h

#import <Foundation/Foundation.h>

@interface TSsbpContent : NSObject

// ID
@property (assign, nonatomic) NSInteger nId;
@property (copy, nonatomic) NSString* contentId;
@property (copy, nonatomic) NSString* contentAction;
@property (copy, nonatomic) NSString* contentStartAt;
@property (copy, nonatomic) NSString* contentEndAt;
@property (copy, nonatomic) NSString* beaconId;
@property (copy, nonatomic) NSString* geofenceId;
@property (assign, nonatomic) NSInteger status;
@property (copy, nonatomic) NSString* acquiredDate;
@property (copy, nonatomic) NSString* usedDate;
@property (copy, nonatomic) NSString* contentType;
@property (copy, nonatomic) NSString* contentTitle;
@property (copy, nonatomic) NSString* contentSubTitle;
@property (copy, nonatomic) NSString* contentBody1;
@property (copy, nonatomic) NSString* contentImageUrl;
//@property (copy, nonatomic) NSData  * contentImage;
@property (copy, nonatomic) NSString* contentBody2;
@property (copy, nonatomic) NSString* contentLimitType;
@property (copy, nonatomic) NSString* contentRepeatable;
@property (copy, nonatomic) NSString* contentCreateddate;
@property (copy, nonatomic) NSString* contentlastupdate;




@end

#endif
