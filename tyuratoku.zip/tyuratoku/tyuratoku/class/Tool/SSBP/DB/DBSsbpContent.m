//
//  DBSsbpContent.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define DATABASE_NAME                 @"ssbp_content.db"
#define TABLE_NAME                    @"t_content"
#define COL_ID                        @"_id"
#define COL_CONTENT_ID @ "contentId"
#define COL_CONTENT_ACTION @ "contentAction"
#define COL_CONTENT_TYPE @ "contentType"
#define COL_CONTENT_TITLE @ "contentTitle"
#define COL_CONTENT_SUBTITLE @ "contentSubTitle"
#define COL_CONTENT_BODY1 @ "contentBody1"
#define COL_CONTENT_IMAGE_URL @ "contentImageUrl"
#define COL_CONTENT_IMAGE @ "contentImage"
#define COL_CONTENT_BODY2 @ "contentBody2"
#define COL_CONTENT_LIMIT_TYPE @ "contentLimitType"
#define COL_CONTENT_REPEATABLE @ "contentRepeatable"
#define COL_CONTENT_START_AT @ "startAt"
#define COL_CONTENT_END_AT @ "endAt"
#define COL_BEACON_ID @ "beaconId"
#define COL_GEOFENCE_ID @ "geofenceId"
#define COL_STATUS @ "status"
#define COL_ACQUIRED @ "acquired_date"
#define COL_USED @ "used_date"
#define COL_CREATED @ "created_date"
#define COL_UPDATED @ "last_update"


#import "DBSsbpContent.h"

@implementation DBSsbpContent

- (id)init {
    self = [super init];
    [self initializeDatabase];
    return self;
}

- (void)initializeDatabase {
    @autoreleasepool {
        
        
        
        
        NSString* SQL_CREATE1 = [NSString stringWithFormat:@"create table %@", TABLE_NAME];
        NSString* SQL_CREATE2 = [NSString stringWithFormat:@" (%@ integer primary key autoincrement not null, ", COL_ID];
        
        NSString* SQL_CREATE3 = [NSString stringWithFormat:@"%@ text not null, ", COL_CONTENT_ID];
        NSString* SQL_CREATE4 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_ACTION];
        NSString* SQL_CREATE5 = [NSString stringWithFormat:@"%@ text,", COL_CONTENT_TYPE];
        NSString* SQL_CREATE6 = [NSString stringWithFormat:@"%@ text,", COL_CONTENT_TITLE];
        NSString* SQL_CREATE7 = [NSString stringWithFormat:@"%@ text,", COL_CONTENT_SUBTITLE];
        NSString* SQL_CREATE8 = [NSString stringWithFormat:@"%@ text,", COL_CONTENT_BODY1];
        NSString* SQL_CREATE9 = [NSString stringWithFormat:@"%@ text,", COL_CONTENT_IMAGE_URL];
        NSString* SQL_CREATE10 = [NSString stringWithFormat:@"%@ text,", COL_CONTENT_IMAGE];
        NSString* SQL_CREATE11 = [NSString stringWithFormat:@"%@ text,", COL_CONTENT_BODY2];
        NSString* SQL_CREATE12 = [NSString stringWithFormat:@"%@ text,", COL_CONTENT_LIMIT_TYPE];
        NSString* SQL_CREATE13 = [NSString stringWithFormat:@"%@ text,", COL_CONTENT_REPEATABLE];
        NSString* SQL_CREATE14 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_START_AT];
        NSString* SQL_CREATE15 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_END_AT];
        
        NSString* SQL_CREATE16 = [NSString stringWithFormat:@"%@ text, ", COL_BEACON_ID];
        NSString* SQL_CREATE17 = [NSString stringWithFormat:@"%@ text, ", COL_GEOFENCE_ID];
        
        NSString* SQL_CREATE18 = [NSString stringWithFormat:@"%@ text, ", COL_STATUS];
        NSString* SQL_CREATE19 = [NSString stringWithFormat:@"%@ text, ", COL_ACQUIRED];
        
        NSString* SQL_CREATE20 = [NSString stringWithFormat:@"%@ text, ", COL_USED];
        NSString* SQL_CREATE21 = [NSString stringWithFormat:@"%@ text, ", COL_CREATED];
        NSString* SQL_CREATE22 = [NSString stringWithFormat:@"%@ text) ", COL_UPDATED];
        
        
        
        
        
        
        NSMutableString* initSQL = [NSMutableString	string];
        [initSQL appendString:SQL_CREATE1];
        [initSQL appendString:SQL_CREATE2];
        [initSQL appendString:SQL_CREATE3];
        [initSQL appendString:SQL_CREATE4];
        [initSQL appendString:SQL_CREATE5];
        [initSQL appendString:SQL_CREATE6];
        [initSQL appendString:SQL_CREATE7];
        [initSQL appendString:SQL_CREATE8];
        [initSQL appendString:SQL_CREATE9];
        [initSQL appendString:SQL_CREATE10];
        [initSQL appendString:SQL_CREATE11];
        [initSQL appendString:SQL_CREATE12];
        [initSQL appendString:SQL_CREATE13];
        [initSQL appendString:SQL_CREATE14];
        [initSQL appendString:SQL_CREATE15];
        [initSQL appendString:SQL_CREATE16];
        [initSQL appendString:SQL_CREATE17];
        [initSQL appendString:SQL_CREATE18];
        [initSQL appendString:SQL_CREATE19];
        [initSQL appendString:SQL_CREATE20];
        [initSQL appendString:SQL_CREATE21];
        [initSQL appendString:SQL_CREATE22];
        
        NSArray* paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, true);
        NSString* dir = [paths objectAtIndex:0];
        NSString* strFilePath = [dir stringByAppendingPathComponent:DATABASE_NAME];
        
        NSFileManager* fileManager = [NSFileManager defaultManager];
        if (![fileManager fileExistsAtPath:strFilePath]) {
            db = [FMDatabase databaseWithPath:strFilePath];
            [db open];
            BOOL bRet = [db executeStatements:initSQL];
            if (!bRet) {
                NSLog(@"Error: %d msg: %@", db.lastErrorCode,db.lastErrorMessage);
            }
            [db close];
        }
    else {
            db = [FMDatabase databaseWithPath:strFilePath];
        }
    }
}

- (void)dropDatabase {
    @autoreleasepool {
        NSArray* paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, true);
        NSString* dir = [paths objectAtIndex:0];
        NSString* strFilePath = [dir stringByAppendingPathComponent:DATABASE_NAME];
        
        NSFileManager* fileManager = [NSFileManager defaultManager];
        BOOL success = [fileManager fileExistsAtPath:strFilePath];
        if (success) {
            [fileManager removeItemAtPath:strFilePath error:nil];
            [self initializeDatabase];
        }
    }
}

// 一覧取得
- (NSArray<TSsbpContent*>*)getAll {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ order by %@ desc;", TABLE_NAME, COL_ID];
        
        [db open];
        FMResultSet* result = [db executeQuery:strSQL];
        NSArray<TSsbpContent*>* array = [self readResultSet:result];
        [db close];
        
        return array;
    }
}

- (NSArray<TSsbpContent*>*)getActions:(NSString*)action {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ where %@ = ? order by %@ desc;", TABLE_NAME, COL_CONTENT_ACTION, COL_ID];
        
        [db open];
        FMResultSet* result = [db executeQuery:strSQL, action];
        NSArray<TSsbpContent*>* array = [self readResultSet:result];
        [db close];
        
        return array;
    }
}

- (NSArray<TSsbpContent*>*)getBeacons:(NSString*)beaconId {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ where %@ = ? order by %@ desc;", TABLE_NAME, COL_BEACON_ID, COL_ID];
        
        [db open];
        FMResultSet* result = [db executeQuery:strSQL, [NSString stringWithFormat:@"%@", beaconId]];
        NSArray<TSsbpContent*>* array = [self readResultSet:result];
        [db close];
        
        return array;
    }
}

- (NSArray<TSsbpContent*>*)getGeofences:(NSString*)geofenceId {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ where %@ = ? order by %@ desc;", TABLE_NAME, COL_GEOFENCE_ID, COL_ID];
        
        [db open];
        FMResultSet* result = [db executeQuery:strSQL, [NSString stringWithFormat:@"%@", geofenceId]];
        NSArray<TSsbpContent*>* array = [self readResultSet:result];
        [db close];
        
        return array;
    }
}

- (TSsbpContent*)findByContentID:(NSString*)contentId {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ where %@ = ?;", TABLE_NAME, COL_CONTENT_ID];
        
        [db open];
        FMResultSet* result = [db executeQuery:strSQL, [NSString stringWithFormat:@"%@", contentId]];
        TSsbpContent* col = [self readResult:result];
        [db close];
        
        return col;
    }
}

- (BOOL)add:(TSsbpContent*)ssbpContent {
    @autoreleasepool {
   
  
        NSArray* cols = @[COL_CONTENT_ID,
                          COL_CONTENT_ACTION,
                          COL_CONTENT_TYPE,
                          COL_CONTENT_TITLE,
                          COL_CONTENT_SUBTITLE,
                          COL_CONTENT_BODY1,
                          COL_CONTENT_IMAGE_URL,
//                          COL_CONTENT_IMAGE,
                          COL_CONTENT_BODY2,
                          COL_CONTENT_LIMIT_TYPE,
                          COL_CONTENT_REPEATABLE,
                          COL_CONTENT_START_AT,
                          COL_CONTENT_END_AT,
                          COL_BEACON_ID,
                          COL_GEOFENCE_ID,
                          COL_STATUS,
                          COL_ACQUIRED,
                          COL_USED,
                          COL_CREATED,
                          COL_UPDATED
                          ];
        NSMutableArray* values = [NSMutableArray new];
        for (int i = 0; i < cols.count; i++) [values addObject:@"?"];
        
        NSString* strSQL = [NSString stringWithFormat:@"insert into %@ (%@) values(%@);", TABLE_NAME, [cols componentsJoinedByString:@", "],[values componentsJoinedByString:@", "]];
        /*
         er nId;
   
         */
        NSArray* params = [NSArray arrayWithObjects:
                           
                           [NSString stringWithFormat:@"%@", ssbpContent.contentId],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentAction],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentType],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentTitle],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentSubTitle],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentBody1],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentImageUrl],
//                           [NSString stringWithFormat:@"%@", ssbpContent.contentImage],
                      
                           [NSString stringWithFormat:@"%@", ssbpContent.contentBody2],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentLimitType],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentRepeatable],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentStartAt],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentEndAt],
                           [NSString stringWithFormat:@"%@", ssbpContent.beaconId],
                           [NSString stringWithFormat:@"%@", ssbpContent.geofenceId],
                           [NSString stringWithFormat:@"%@", ssbpContent.acquiredDate],
                           [NSString stringWithFormat:@"%@", ssbpContent.usedDate],
                            [NSNumber numberWithInteger:0],
                             [NSString stringWithFormat:@"%@", ssbpContent.contentCreateddate],
                            [NSString stringWithFormat:@"%@", ssbpContent.contentlastupdate],
                           nil];
        
        [db open];
        BOOL bRet = [db executeUpdate:strSQL withArgumentsInArray:params];
        if (!bRet) {
            NSLog(@"Error: %d msg: %@", db.lastErrorCode,db.lastErrorMessage);
            NSString* arrString = [NSString stringWithFormat:@"%@",params];
            NSString* arrEncoding = [NSString stringWithCString:[arrString cStringUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding];
            NSLog(@"%@", arrEncoding);
        }
        [db close];
        return bRet;
    }
}

- (BOOL)update:(TSsbpContent*)ssbpContent {
    @autoreleasepool {
        
        
        //TODO:新增数据
        NSArray* cols = @[COL_CONTENT_ID,
                          COL_CONTENT_ACTION,
                          COL_CONTENT_TYPE,
                          COL_CONTENT_TITLE,
                          COL_CONTENT_SUBTITLE,
                          COL_CONTENT_BODY1,
                          COL_CONTENT_IMAGE_URL,
                          COL_CONTENT_BODY2,
                          COL_CONTENT_LIMIT_TYPE,
                          COL_CONTENT_REPEATABLE,
                          COL_CONTENT_START_AT,
                          COL_CONTENT_END_AT,
                          COL_BEACON_ID,
                          COL_GEOFENCE_ID,
                          COL_STATUS,
                          COL_ACQUIRED,
                          COL_USED,
                          COL_CREATED,
                          COL_UPDATED
                          ];
        
        
        
        NSString* strSQL = [NSString stringWithFormat:@"update %@ set %@ = ? where %@ = ?;", TABLE_NAME, [cols componentsJoinedByString:@" = ?, "], COL_CONTENT_ID];
        NSArray* params = [NSArray arrayWithObjects:
                           
                           [NSString stringWithFormat:@"%@", ssbpContent.contentId],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentAction],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentType],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentTitle],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentSubTitle],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentBody1],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentImageUrl],
                           //                           [NSString stringWithFormat:@"%@", ssbpContent.contentImage],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentBody2],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentLimitType],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentRepeatable],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentStartAt],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentEndAt],
                           [NSString stringWithFormat:@"%@", ssbpContent.beaconId],
                           [NSString stringWithFormat:@"%@", ssbpContent.geofenceId],
                           [NSString stringWithFormat:@"%@", ssbpContent.acquiredDate],
                           [NSString stringWithFormat:@"%@", ssbpContent.usedDate],
                           [NSNumber numberWithInteger:ssbpContent.status],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentCreateddate],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentlastupdate],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentId],
                           nil];
        
        [db open];
        BOOL bRet = [db executeUpdate:strSQL withArgumentsInArray:params];
        if (!bRet) {
            NSLog(@"Error: %d msg: %@", db.lastErrorCode,db.lastErrorMessage);
            NSString* arrString = [NSString stringWithFormat:@"%@",params];
            NSString* arrEncoding = [NSString stringWithCString:[arrString cStringUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding];
            NSLog(@"%@", arrEncoding);
        }
        [db close];
        
        return bRet;
    }
}

- (BOOL)use:(NSString*)contentId {
    @autoreleasepool {
        NSDate* now = [NSDate date];
        NSString* strNow = [self makeUTCDateTimeToString:now];
        
        NSArray* cols = @[COL_STATUS,
                          COL_USED,
                          COL_UPDATED];
        
        NSString* strSQL = [NSString stringWithFormat:@"update %@ set %@ = ? where %@ = ?;", TABLE_NAME, [cols componentsJoinedByString:@" = ?, "], COL_CONTENT_ID];
        
        NSArray* params = [NSArray arrayWithObjects:
                           [NSNumber numberWithInteger:1],
                           [NSString stringWithFormat:@"%@", strNow],
                           [NSString stringWithFormat:@"%@", strNow],
                           [NSString stringWithFormat:@"%@", contentId],
                           nil];
        
        [db open];
        BOOL bRet = [db executeUpdate:strSQL withArgumentsInArray:params];
        if (!bRet) {
            NSLog(@"Error: %d msg: %@", db.lastErrorCode,db.lastErrorMessage);
            NSString* arrString = [NSString stringWithFormat:@"%@",params];
            NSString* arrEncoding = [NSString stringWithCString:[arrString cStringUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding];
            NSLog(@"%@", arrEncoding);
        }
        [db close];
        
        return bRet;
    }
}

- (BOOL)remove:(NSString*)contentId {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"delete from %@ where %@ = ?;", TABLE_NAME, COL_CONTENT_ID];
        
        [db open];
        BOOL ret = [db executeUpdate:strSQL, [NSString stringWithFormat:@"%@", contentId]];
        [db close];
        
        return ret;
    }
}

- (BOOL)removeAll {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"delete from %@;", TABLE_NAME];
        
        [db open];
        BOOL ret = [db executeUpdate:strSQL];
        [db close];
        
        return ret;
    }
}

- (NSArray<TSsbpContent*>*)readResultSet:(FMResultSet*)resultSet {
    NSMutableArray<TSsbpContent*>* array = [NSMutableArray new];
    if (resultSet == nil) return [array copy];
    
    int indexId = [resultSet columnIndexForName:COL_ID];
    if (indexId < 0) { return [array copy]; }
    
    int indexContentId = [resultSet columnIndexForName:COL_CONTENT_ID];
    int indexContentAction = [resultSet columnIndexForName:COL_CONTENT_ACTION];
    int indexContentStartAt = [resultSet columnIndexForName:COL_CONTENT_START_AT];
    int indexContentEndAt = [resultSet columnIndexForName:COL_CONTENT_END_AT];
    int indexBeaconId = [resultSet columnIndexForName:COL_BEACON_ID];
    int indexGeofenceId = [resultSet columnIndexForName:COL_GEOFENCE_ID];
    int indexStatus = [resultSet columnIndexForName:COL_STATUS];
    int indexAcquired = [resultSet columnIndexForName:COL_ACQUIRED];
    int indexUsed = [resultSet columnIndexForName:COL_USED];
    int indexCreated = [resultSet columnIndexForName:COL_CREATED];
    int indexUpdated = [resultSet columnIndexForName:COL_UPDATED];
    int indexcontentType = [resultSet columnIndexForName:COL_CONTENT_TYPE];
    int indexcontentTitle = [resultSet columnIndexForName:COL_CONTENT_TITLE];
    int indexcontentSubTitle = [resultSet columnIndexForName:COL_CONTENT_SUBTITLE];
    int indexcontentBody1 = [resultSet columnIndexForName:COL_CONTENT_BODY1];
    int indexcontentImageUrl = [resultSet columnIndexForName:COL_CONTENT_IMAGE_URL];
//    int indexcontentImage = [resultSet columnIndexForName:COL_CONTENT_IMAGE];
    int indexcontentBody2 = [resultSet columnIndexForName:COL_CONTENT_BODY2];
    int indexcontentLimitType = [resultSet columnIndexForName:COL_CONTENT_LIMIT_TYPE];
    int indexcontentRepeatable = [resultSet columnIndexForName:COL_CONTENT_REPEATABLE];
    
    while ([resultSet next]) {
        TSsbpContent* col = [TSsbpContent new];
        col.nId = [resultSet intForColumnIndex:indexId];
          if (indexCreated >= 0) { col.contentType = [resultSet stringForColumnIndex:indexCreated]; }
        
         if (indexUpdated >= 0) { col.contentType = [resultSet stringForColumnIndex:indexUpdated]; }
        
        if (indexcontentType >= 0) { col.contentType = [resultSet stringForColumnIndex:indexcontentType]; }
        if (indexcontentTitle >= 0) { col.contentTitle = [resultSet stringForColumnIndex:indexcontentTitle]; }
        if (indexcontentSubTitle >= 0) { col.contentSubTitle = [resultSet stringForColumnIndex:indexcontentSubTitle]; }
        if (indexcontentBody1 >= 0) { col.contentBody1 = [resultSet stringForColumnIndex:indexcontentBody1]; }
        if (indexcontentImageUrl >= 0) { col.contentImageUrl = [resultSet stringForColumnIndex:indexcontentImageUrl]; }
//        if (indexcontentImage >= 0) { col.contentImage = [resultSet dataForColumnIndex:indexcontentImage]; }
        if (indexcontentLimitType >= 0) { col.contentLimitType = [resultSet stringForColumnIndex:indexcontentLimitType]; }
        if (indexcontentBody2 >= 0) { col.contentBody2 = [resultSet stringForColumnIndex:indexcontentBody2]; }
        if (indexcontentRepeatable >= 0) { col.contentRepeatable= [resultSet stringForColumnIndex:indexcontentRepeatable]; }
        if (indexContentId >= 0) { col.contentId = [resultSet stringForColumnIndex:indexContentId]; }
        if (indexContentAction >= 0) { col.contentAction = [resultSet stringForColumnIndex:indexContentAction]; }
        if (indexContentStartAt >= 0) { col.contentStartAt = [resultSet stringForColumnIndex:indexContentStartAt]; }
        if (indexContentEndAt >= 0) { col.contentEndAt = [resultSet stringForColumnIndex:indexContentEndAt]; }
        if (indexBeaconId >= 0) { col.beaconId = [resultSet stringForColumnIndex:indexBeaconId]; }
        if (indexGeofenceId >= 0) { col.geofenceId = [resultSet stringForColumnIndex:indexGeofenceId]; }
        if (indexStatus >= 0) { col.status = [resultSet intForColumnIndex:indexStatus]; }
        if (indexAcquired >= 0) { col.acquiredDate = [resultSet stringForColumnIndex:indexAcquired]; }
        if (indexUsed >= 0) { col.usedDate = [resultSet stringForColumnIndex:indexUsed]; }
        [array addObject:col];
    }
    
    return [array copy];
}

- (TSsbpContent*)readResult:(FMResultSet*)resultSet {
    if (resultSet == nil) return nil;
    
    int indexId = [resultSet columnIndexForName:COL_ID];
    if (indexId < 0) { return nil; }
    
    int indexContentId = [resultSet columnIndexForName:COL_CONTENT_ID];
    int indexContentAction = [resultSet columnIndexForName:COL_CONTENT_ACTION];
    int indexContentStartAt = [resultSet columnIndexForName:COL_CONTENT_START_AT];
    int indexContentEndAt = [resultSet columnIndexForName:COL_CONTENT_END_AT];
    int indexBeaconId = [resultSet columnIndexForName:COL_BEACON_ID];
    int indexGeofenceId = [resultSet columnIndexForName:COL_GEOFENCE_ID];
    int indexStatus = [resultSet columnIndexForName:COL_STATUS];
    int indexAcquired = [resultSet columnIndexForName:COL_ACQUIRED];
    int indexUsed = [resultSet columnIndexForName:COL_USED];
    int indexCreated = [resultSet columnIndexForName:COL_CREATED];
    int indexUpdated = [resultSet columnIndexForName:COL_UPDATED];
    
    
    int indexcontentType = [resultSet columnIndexForName:COL_CONTENT_TYPE];
    int indexcontentTitle = [resultSet columnIndexForName:COL_CONTENT_TITLE];
    int indexcontentSubTitle = [resultSet columnIndexForName:COL_CONTENT_SUBTITLE];
    int indexcontentBody1 = [resultSet columnIndexForName:COL_CONTENT_BODY1];
    int indexcontentImageUrl = [resultSet columnIndexForName:COL_CONTENT_IMAGE_URL];
//    int indexcontentImage = [resultSet columnIndexForName:COL_CONTENT_IMAGE];
    int indexcontentBody2 = [resultSet columnIndexForName:COL_CONTENT_BODY2];
    int indexcontentLimitType = [resultSet columnIndexForName:COL_CONTENT_LIMIT_TYPE];
    int indexcontentRepeatable = [resultSet columnIndexForName:COL_CONTENT_REPEATABLE];
    
    TSsbpContent* col = [TSsbpContent new];
    while ([resultSet next]) {
        col.nId = [resultSet intForColumnIndex:indexId];
        if (indexCreated >= 0) { col.contentType = [resultSet stringForColumnIndex:indexCreated]; }
        if (indexUpdated >= 0) { col.contentType = [resultSet stringForColumnIndex:indexUpdated]; }
        if (indexcontentType >= 0) { col.contentType = [resultSet stringForColumnIndex:indexcontentType]; }
        if (indexcontentTitle >= 0) { col.contentTitle = [resultSet stringForColumnIndex:indexcontentTitle]; }
        if (indexcontentSubTitle >= 0) { col.contentSubTitle = [resultSet stringForColumnIndex:indexcontentSubTitle]; }
        if (indexcontentBody1 >= 0) { col.contentBody1 = [resultSet stringForColumnIndex:indexcontentBody1]; }
        if (indexcontentImageUrl >= 0) { col.contentImageUrl = [resultSet stringForColumnIndex:indexcontentImageUrl]; }
//        if (indexcontentImage >= 0) { col.contentImage = [resultSet dataForColumnIndex:indexcontentImage]; }
        if (indexcontentLimitType >= 0) { col.contentLimitType = [resultSet stringForColumnIndex:indexcontentLimitType]; }
        if (indexcontentBody2 >= 0) { col.contentBody2 = [resultSet stringForColumnIndex:indexcontentBody2]; }
        if (indexcontentRepeatable >= 0) { col.contentRepeatable= [resultSet stringForColumnIndex:indexcontentRepeatable]; }
        
        if (indexContentId >= 0) { col.contentId = [resultSet stringForColumnIndex:indexContentId]; }
        if (indexContentAction >= 0) { col.contentAction = [resultSet stringForColumnIndex:indexContentAction]; }
        if (indexContentStartAt >= 0) { col.contentStartAt = [resultSet stringForColumnIndex:indexContentStartAt]; }
        if (indexContentEndAt >= 0) { col.contentEndAt = [resultSet stringForColumnIndex:indexContentEndAt]; }
        if (indexBeaconId >= 0) { col.beaconId = [resultSet stringForColumnIndex:indexBeaconId]; }
        if (indexGeofenceId >= 0) { col.geofenceId = [resultSet stringForColumnIndex:indexGeofenceId]; }
        if (indexStatus >= 0) { col.status = [resultSet intForColumnIndex:indexStatus]; }
        if (indexAcquired >= 0) { col.acquiredDate = [resultSet stringForColumnIndex:indexAcquired]; }
        if (indexUsed >= 0) { col.usedDate = [resultSet stringForColumnIndex:indexUsed]; }
        return col;
    }
    
    return nil;
}

- (NSString*)makeUTCDateTimeToString:(NSDate*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
        [formatter setLocale:[NSLocale systemLocale]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        return [formatter stringFromDate:date];
    }
}

@end

