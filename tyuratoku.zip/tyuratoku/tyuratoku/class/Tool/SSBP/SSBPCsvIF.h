//
//  SSBPCsvIF.h
//
//  Created by Ayumi Togashi on 2016/09/27.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_App_Static_SSBPCsvIF_h
#define SSBP_App_Static_SSBPCsvIF_h

#import <Foundation/Foundation.h>

#import <SSBPSdk/SSBPFacility.h>
#import <SSBPSdk/SSBPBeacon.h>
#import <SSBPSdk/SSBPNode.h>
#import <SSBPSdk/SSBPEdge.h>
#import <SSBPSdk/SSBPGeofence.h>

#import "TSsbpApp.h"

@interface SSBPCsvIF : NSObject

- (NSArray<TSsbpApp*>*)getAppInfos;

- (NSArray<SSBPFacility*>*)getFacilityCSV:(NSString*)localeId defLocaleId:(NSString*)defLocaleId since:(NSString*)since csvFacilities:(NSString*)csvFacilities csvFloors:(NSString*)csvFloors;
- (NSArray<SSBPBeacon*>*)getBeaconCSV:(NSString*)since csvBeacons:(NSString*)csvBeacons;
- (NSArray<SSBPNode*>*)getNodeCSV:(NSString*)localeId defLocaleId:(NSString*)defLocaleId since:(NSString*)since csvNodes:(NSString*)csvNodes;
- (NSArray<SSBPEdge*>*)getEdgeCSV:(NSString*)since csvEdges:(NSString*)csvEdges;
- (NSArray<SSBPGeofence*>*)getGeofenceCSV:(NSString*)localeId defLocaleId:(NSString*)defLocaleId since:(NSString*)since csvGeofences:(NSString*)csvGeofences;

- (NSString*)getLastUpdate;

@end

#endif
