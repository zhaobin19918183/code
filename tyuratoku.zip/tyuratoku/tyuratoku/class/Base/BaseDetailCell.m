//
//  BaseDetailCell.m
//  Beautiful
//
//  Created by newland on 2017/8/16.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseDetailCell.h"
static CGRect reloadImageFrame;

/**
 * 機能名　　　　：お知らせ詳しい
 * 機能概要　　　：お知らせリスト詳しい
 * 作成者    　 ：郭麗影　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation BaseDetailCell{
    BOOL moreImageState;
    BOOL isFirst;
    
    
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.titleLabel = [[BaseLabel alloc]init];
        [self.titleLabel setTextFont:16 textColor:BaseLabelBlue];
        self.titleLabel.font = [UIFont boldSystemFontOfSize:XSpan(16)];
        self.titleLabel.textColor = customGreen;
        [self.contentView addSubview:self.titleLabel];
        
        self.line = [[UIView alloc]init];
        [self.contentView addSubview:self.line];
        self.line.backgroundColor = [UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1];
        
        self.scrollView = [[ UIScrollView alloc]init];
        [self.contentView addSubview:self.scrollView];
        
        self.imgView = [[BaseImageView alloc]init];
        [self.contentView addSubview:self.imgView];
        
        self.contentOneLabel = [[BaseLabel alloc]init];
        [self.contentOneLabel setTextFont:14 textColor:BaseLabelBlack];
        [self.contentView addSubview:self.contentOneLabel];
        
        self.numLabel = [[BaseLabel alloc]init];
        self.numLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.numLabel];
        
        self.contentTwoLabel = [[BaseLabel alloc]init];
        [self.contentTwoLabel setTextFont:14 textColor:BaseLabelBlack];
        [self.contentView addSubview:self.contentTwoLabel];
        
        self.playButton =[[BaseButton alloc]init];
        [self.contentView addSubview:self.playButton];
        
        isFirst = YES;
        moreImageState = NO;
    }
    return self;
}


//設置位置を設置してデータを追加
-(void)setSubviewFrame:(NoticeModel *)model{
    
    //標題データ
    [self.titleLabel setText:model.sub_title textAlignment:BaseLabelLeft];
    //もしsub_titleは空は、titleLabelの高さはゼロ
    if ([[model.sub_title stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0) {
        self.titleLabel.frame = customCGRect(10, 0, 355, 0);
    }
    else{//さもなくばtitleLabelの高さ適応
        self.titleLabel.frame = customCGRect(10, 10, 355, 10);
        [self.titleLabel autoLabelHeightFromString];
        
        self.line.frame = CGRectMake(0, CGRectGetMaxY(self.titleLabel.frame)+YSpan(5), Screen_W, XSpan(1));
    }
    
    //もしmovie_urlは空に
    if ([model.movie_url isEqualToString:@""]||[model.movie_url isKindOfClass:[NSNull class]]) {
        //ボディ・イメージを含むならば
        if ([model.body containsString:@"<IMAGE>"]) {
            NSArray * array = [model.body componentsSeparatedByString:@"<IMAGE>"];
            //IMAGE前の内容をタイトル下
            [self.contentOneLabel setText:array[0] textAlignment:BaseLabelLeft];
            self.contentOneLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.titleLabel.frame)+YSpan(10), XSpan(355), YSpan(80));
            [self.contentOneLabel autoLabelHeightFromString];
            //もしimage_urlは空
            if (([model.image_url isKindOfClass:[NSNull class]]||[model.image_url isEqualToString:@""])&&self.imageUrlArray.count==0) {
                //imgViewの高さを0
                self.imgView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, 0);
                //足を付けるイメージの後ろの内容
                [self.contentTwoLabel setText:array[1] textAlignment:BaseLabelLeft];
                self.contentTwoLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.imgView.frame), XSpan(355), YSpan(80));
                [self.contentTwoLabel autoLabelHeightFromString];
                //すべての内容の高度を得る
                model.cellHeight = CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10);
            }
            else{//image_urlない空
                if (isFirst){
                    //すべての写真のは、すべての写真の中には
                    self.arrayImage = [NSMutableArray arrayWithArray:[model.image_url componentsSeparatedByString:@","]];
                    //画像の配列が空になるとしたら
                    if ([[self.arrayImage objectAtIndex:0]isEqualToString:@""]) {
                        //外部から導入された配列
                        self.arrayImage = self.imageUrlArray;
                    }else{//画像の配列が空にならないなら
                        //画像配列に外部配列が入って
                        [self.arrayImage addObjectsFromArray:self.imageUrlArray];
                    }
                    //ページ数の表示文字を取得する
                    self.numStr = [NSString stringWithFormat:@"1/%ld",self.arrayImage.count];
                    if (self.arrayImage.count==1) {
                        moreImageState = NO;
                    }
                    else{
                    
                        moreImageState = YES;
                    }
                    //画像を表示しない前に文字を
                    [self.contentTwoLabel setText:array[1] textAlignment:BaseLabelLeft];
                    self.contentTwoLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), XSpan(355), YSpan(80));
                    [self.contentTwoLabel autoLabelHeightFromString];
                    model.cellHeight = CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10);
                    //画像を追加
                    [self.imgView sd_setImageWithURL:[NSURL URLWithString:[self.arrayImage objectAtIndex:0]] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
                        
                        if (image==nil) {
                            image = [UIImage imageNamed:@"noImage"];
                        }
                        //scrollView設置位置と大きさ
                        self.scrollView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, Screen_W*image.size.height/image.size.width);
                        for (int i = 0; i<self.arrayImage.count; i++) {
                            //初期化scrollview上のimageview
                            self.imgScrollView = [[BaseImageView alloc]init];
                            [self.scrollView addSubview:self.imgScrollView];
                            self.imgScrollView.frame = CGRectMake(Screen_W*i, 0, Screen_W, Screen_W*image.size.height/image.size.width);
                            //i = 0時足を付ける要請のscrollViewの第一個の位置図
                            if (i==0) {
                                self.imgScrollView.image = image;
                            }
                            else{
                                //その他の写真を載
                                [self.imgScrollView sd_setImageWithURL:[NSURL URLWithString:self.arrayImage[i]] placeholderImage:[UIImage imageNamed:@"noImage"]];
                            }
                            self.imgScrollView.tag = 233+i;
                            //画像に手を添えて
                            [self.imgScrollView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapClick:)]];
                            self.imgScrollView.userInteractionEnabled = YES;
                            //下の文字に付値する
                            [self.contentTwoLabel setText:array[1] textAlignment:BaseLabelLeft];
                            //moreImageStateの値は、イエスは足を付ける画像ページの表示以外は足を付ける
                            if (moreImageState) {
                                self.numLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.scrollView.frame)+YSpan(10), XSpan(355), YSpan(30));
                                [self.numLabel setText:self.numStr];
                            }else{
                                self.numLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.scrollView.frame)+YSpan(10), XSpan(355), 0);
                            }
                            //下の文字の位置を再設定する
                            self.contentTwoLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.numLabel.frame)+YSpan(10), XSpan(355), YSpan(80));
                            [self.contentTwoLabel autoLabelHeightFromString];
                            //すべての内容の高度を得る
                            model.cellHeight = CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10);
                            if (i==0) {
                                model.cellHeight = CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10);
                                [self.delegate refreshTableView:model.cellHeight imageViewHeight:self.imgView.frame];
                                reloadImageFrame = self.imgScrollView.frame;
                            }
                            isFirst = NO;
                        }
                    }];
                    
                }
                
                self.scrollView.contentSize = CGSizeMake(Screen_W*self.arrayImage.count, 0);
                self.scrollView.pagingEnabled = YES;
                self.scrollView.delegate = self;

                self.scrollView.showsHorizontalScrollIndicator = NO;
                self.scrollView.showsVerticalScrollIndicator = NO;
            }
            
        }
        else{//体の中の画像はありません
            //タイトルの下の文字はbody
            [self.contentOneLabel setText:model.body textAlignment:BaseLabelLeft];
            self.contentOneLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.titleLabel.frame)+YSpan(10), XSpan(355), YSpan(80));
            [self.contentOneLabel autoLabelHeightFromString];
            
            self.imgView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, 0);
            self.contentTwoLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.imgView.frame), XSpan(355), 0);
            //すべての内容の高度を得る
            model.cellHeight = CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10);
        }
        
    }
    else{//movie_urlない空
        //ボディ・イメージを含むならば
        if ([model.body containsString:@"<IMAGE>"]) {
            NSArray * array = [model.body componentsSeparatedByString:@"<IMAGE>"];
            //IMAGE前の内容をタイトル下
            [self.contentOneLabel setText:array[0] textAlignment:BaseLabelLeft];
            self.contentOneLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.titleLabel.frame)+YSpan(10), XSpan(355), YSpan(80));
            [self.contentOneLabel autoLabelHeightFromString];
            //もしimage_urlは空
            if (([model.image_url isKindOfClass:[NSNull class]]||[model.image_url isEqualToString:@""])&&self.imageUrlArray.count==0) {
                //imgView設置位置と大きさ
                self.imgView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, YSpan(200));
                self.imgView.backgroundColor = [UIColor blackColor];
                //画像をロード
                [self.imgView sd_setImageWithURL:[NSURL URLWithString:model.movie_thumb_url] placeholderImage:[UIImage imageNamed:@"noImage"]];
                //再生ボタンを追加
                self.playButton.frame = CGRectMake((Screen_W-XSpan(80))/2, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(70), XSpan(80), YSpan(80));
                //足を付けるイメージの後ろの内容
                [self.contentTwoLabel setText:array[1] textAlignment:BaseLabelLeft];
                self.contentTwoLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.imgView.frame)+YSpan(10), XSpan(355), YSpan(80));
                [self.contentTwoLabel autoLabelHeightFromString];
                //すべての内容の高度を得る
                model.cellHeight = CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10);
            }
            else{//image_urlない空
            
                if (isFirst){
                    //すべての写真のは、すべての写真の中には
                    self.arrayImage = [NSMutableArray arrayWithArray:[model.image_url componentsSeparatedByString:@","]];
                    //画像配列に外部配列が入って
                    if ([[self.arrayImage objectAtIndex:0]isEqualToString:@""]) {
                        self.arrayImage = self.imageUrlArray;
                    }else{
                        [self.arrayImage addObjectsFromArray:self.imageUrlArray];
                    }
                    //足を付けるmovie_url画像配列
                    [self.arrayImage addObject:model.movie_url ];
                    //ページ数の表示文字を取得する
                    self.numStr = [NSString stringWithFormat:@"1/%ld",self.arrayImage.count];
                    if (self.arrayImage.count==1) {
                        moreImageState = NO;
                    }
                    else{
                    
                        moreImageState = YES;
                    }
                    //画像を表示しない前に文字を
                    [self.contentTwoLabel setText:array[1] textAlignment:BaseLabelLeft];
                    self.contentTwoLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), XSpan(355), YSpan(80));
                    [self.contentTwoLabel autoLabelHeightFromString];
                    //すべての内容の高度を得る
                    model.cellHeight = CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10);
                    //画像を追加
                    [self.imgView sd_setImageWithURL:[NSURL URLWithString:[self.arrayImage objectAtIndex:0]] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
                        
                        if (image==nil) {
                            image = [UIImage imageNamed:@"noImage"];
                        }
                        //scrollView設置位置と大きさ
                        self.scrollView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, Screen_W*image.size.height/image.size.width);
                        for (int i = 0; i<self.arrayImage.count; i++) {
                            //初期化scrollview上のimageview
                            self.imgScrollView = [[BaseImageView alloc]init];
                            [self.scrollView addSubview:self.imgScrollView];
                            self.imgScrollView.frame = CGRectMake(Screen_W*i, 0, Screen_W, Screen_W*image.size.height/image.size.width);
                            self.imgScrollView.tag = 233+i;
                            //画像に手を添えて
                            if (i<self.arrayImage.count-1) {
                                //i = 0時足を付ける要請のscrollViewの第一個の位置図
                                if (i==0) {
                                    self.imgScrollView.image = image;
                                }
                                else{
                                    //その他の写真を載
                                    [self.imgScrollView sd_setImageWithURL:[NSURL URLWithString:self.arrayImage[i]] placeholderImage:[UIImage imageNamed:@"noImage"]];
                                }
                                [self.imgScrollView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapClick:)]];
                                self.imgScrollView.userInteractionEnabled = YES;
                            }
                            else{
                                //動画の中にボタンを追加して
                                self.imgScrollView.userInteractionEnabled = YES;
                                //動画の画像を
                                [self.imgScrollView sd_setImageWithURL:[NSURL URLWithString:model.movie_thumb_url] placeholderImage:[UIImage imageNamed:@"noImage"]];
                                //設定ボタンの位置サイズをクリックしてクリックして事件
                                self.playButton.frame = CGRectMake((Screen_W-XSpan(80))/2, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(70), XSpan(80), YSpan(80));
                                [self.imgScrollView addSubview:self.playButton];
                                [self.playButton addTarget:self action:@selector(showVideoPlayer) forControlEvents:UIControlEventTouchUpInside];
                               
                            }
                            //下の文字に付値する
                            [self.contentTwoLabel setText:array[1] textAlignment:BaseLabelLeft];
                            //moreImageStateの値は、イエスは足を付ける画像ページの表示以外は足を付ける
                            if (moreImageState) {
                                self.numLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.scrollView.frame)+YSpan(10), XSpan(355), YSpan(30));
                                [self.numLabel setText:self.numStr];
                            }else{
                                self.numLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.scrollView.frame)+YSpan(10), XSpan(355), 0);
                            }
                            //下の文字の位置を再設定する
                            self.contentTwoLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.numLabel.frame)+YSpan(10), XSpan(355), YSpan(80));
                            [self.contentTwoLabel autoLabelHeightFromString];
                            //すべての内容の高度を得る
                            model.cellHeight = CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10);
                            if (i==0) {
                                model.cellHeight = CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10);
                                [self.delegate refreshTableView:model.cellHeight imageViewHeight:self.imgView.frame];
                                reloadImageFrame = self.imgScrollView.frame;
                            }
                            isFirst = NO;
                        }
                    }];
                 
                }
                
                self.scrollView.contentSize = CGSizeMake(Screen_W*self.arrayImage.count, 0);
                self.scrollView.pagingEnabled = YES;
                self.scrollView.delegate = self;
                
                self.scrollView.showsHorizontalScrollIndicator = NO;
                self.scrollView.showsVerticalScrollIndicator = NO;

            }
            
            
            
        }
        else{//体の中の画像はありません
            //タイトルの下の文字はbody
            [self.contentOneLabel setText:model.body textAlignment:BaseLabelLeft];
            self.contentOneLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.titleLabel.frame)+YSpan(10), XSpan(355), YSpan(80));
            [self.contentOneLabel autoLabelHeightFromString];
            //設置imgViewの大きさや位置
            self.imgView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, YSpan(200));
            self.imgView.backgroundColor = [UIColor blackColor];
            [self.imgView sd_setImageWithURL:[NSURL URLWithString:model.movie_thumb_url] placeholderImage:[UIImage imageNamed:@"noImage"]];
            //設定ボタンの位置サイズをクリックしてクリックして事件
            self.playButton.frame = CGRectMake((Screen_W-XSpan(80))/2, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(70), XSpan(80), YSpan(80));
            
            [self.contentTwoLabel setText:@"" textAlignment:BaseLabelLeft];
            self.contentTwoLabel.frame = CGRectMake(XSpan(10), CGRectGetMaxY(self.imgView.frame), XSpan(355), YSpan(80));
            //すべての内容の高度を得る
            [self.contentTwoLabel autoLabelHeightFromString];
            model.cellHeight = CGRectGetMaxY(self.contentTwoLabel.frame)+YSpan(10);
        }

        [self.playButton addTarget:self action:@selector(showVideoPlayer) forControlEvents:UIControlEventTouchUpInside];
        
    }
    
    [self.delegate getImage:[self.arrayImage objectAtIndex:0]];
    
}


//画像をクリックするイベント
-(void)tapClick:(UITapGestureRecognizer *)tap{
    
    if (_delegate &&[_delegate respondsToSelector:@selector(clickImageView:)]) {
        [_delegate clickImageView:tap];
    }
}
//再生ボタンのクリックイベント
- (void)showVideoPlayer
{
    
}

-(void)setMoreImageState:(BOOL)state{
    moreImageState = state;
}
//scrollViewの代理方法
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    NSNumber *number = [NSNumber numberWithInt:scrollView.contentOffset.x/Screen_W];
    //ページ数表示の内容
    self.numStr = [NSString stringWithFormat:@"%d/%ld",[number intValue]+1,self.arrayImage.count];
    [self.numLabel setText:self.numStr];
    [self.delegate getImage:[self.arrayImage objectAtIndex:[number intValue]]];
}

@end
