//
//  BaseTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/19.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseNoticeTableViewCell.h"
/**
 * 機能名　　　　：お知らせセル
 * 機能概要　　　：お知らせセル
 * 作成者    　 ：郭麗影　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation BaseNoticeTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imgView = [[BaseImageView alloc]init];
        [self.contentView addSubview:self.imgView];
        
        self.titleLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.titleLabel];
        
        self.bodyLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.bodyLabel];
        
        self.dateLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.dateLabel];
        
        self.authorLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.authorLabel];

    }
    return self;
}
//位置サイズ
-(void)layoutSubviews{
    
    [super layoutSubviews];
    
    self.imgView.frame = customCGRect(10, 5, 130, 100);
    self.imgView.contentMode = UIViewContentModeScaleAspectFit;
    self.imgView.backgroundColor = [UIColor clearColor];
    
    self.titleLabel.frame = CGRectMake(CGRectGetMaxX(self.imgView.frame)+XSpan(5), YSpan(10), Screen_W - CGRectGetMaxX(self.imgView.frame)-XSpan(15), YSpan(20));
    
    self.bodyLabel.frame = CGRectMake(CGRectGetMaxX(self.imgView.frame)+XSpan(5), CGRectGetMaxY(self.titleLabel.frame), Screen_W - CGRectGetMaxX(self.imgView.frame)-XSpan(15), YSpan(45));
    self.bodyLabel.numberOfLines = 0;
    
    self.dateLabel.frame = CGRectMake(CGRectGetMaxX(self.imgView.frame)+XSpan(5), CGRectGetMaxY(self.bodyLabel.frame)+YSpan(5), XSpan(135), YSpan(20));
    [self.dateLabel setTextFont:10 textColor:BaseLabelGray];

    
    self.authorLabel.frame = CGRectMake(CGRectGetMaxX(self.dateLabel.frame)+XSpan(5), CGRectGetMaxY(self.bodyLabel.frame)+YSpan(10), XSpan(80), YSpan(20));
    [self.authorLabel setTextFont:10 textColor:BaseLabelWhite];
    [self.authorLabel setFillet:5];
    self.authorLabel.backgroundColor = customGreen;
    
   
}


@end
