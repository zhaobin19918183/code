//
//  BaseCollectionView.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseCollectionView.h"
/**
 * 機能名　　　　：基類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation BaseCollectionView{
    MJRefreshGifHeader *gifHeader;//更新のヘッド
    MJRefreshAutoGifFooter *gifFooter;//更新の足
}

//初期化
-(instancetype)init{
    @try {
        self = [super init];
        if (self) {
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定
-(instancetype)initWithFrame:(CGRect)frame{
    @try {
        self = [super initWithFrame:frame];
        if (self) {
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定データ
-(void)initData{
    @try {
        self.backgroundColor = [UIColor whiteColor];
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

#pragma mark - プルダウン更新
-(void)downRefresh{
    @try {
        gifHeader = [MJDIYGifHeader headerWithRefreshingBlock:^{
            //コールバック
            if (self.headerRefreshBlock) {
                self.headerRefreshBlock(gifHeader);
            }
            [self reloadData];
            [self.mj_header endRefreshing];
        }];
        
        //隠し時間
        gifHeader.lastUpdatedTimeLabel.hidden = YES;
        
        self.mj_header = gifHeader;
        
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
    
}

#pragma mark - プルロード
-(void)upRefresh{
    @try {
        
        gifFooter = [MJDIYAutoGifFooter footerWithRefreshingBlock:^{
            //コールバック
            if (self.footerRefreshBlock) {
                self.footerRefreshBlock(gifFooter);
            }
            [self reloadData];
            [self.mj_footer endRefreshing];
        }];
        
        self.mj_footer = gifFooter;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
    
}

//ロード時のコールバック
-(void)upRefreshData:(BaseCollectionViewFooterRefresh)refresh{
    self.footerRefreshBlock = refresh;
}

//更新時のフィボナッチリトレースメント
-(void)downRefreshData:(BaseCollectionViewHeaderRefresh)refresh{
    self.headerRefreshBlock = refresh;
}

@end
