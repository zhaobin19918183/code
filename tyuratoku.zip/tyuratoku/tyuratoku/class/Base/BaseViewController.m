//
//  BaseViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"
/**
 * 機能名　　　　：基類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@interface BaseViewController ()

@end


@implementation BaseViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.translucent = NO;
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont boldSystemFontOfSize:XSpan(16)],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
    self.edgesForExtendedLayout = UIRectEdgeBottom;
    self.view.backgroundColor = [UIColor whiteColor];
    [self leftItemButton];
    [self rightItemButton];
    
}

- (void)leftItemButton{
    self.leftButton = [[BaseButton alloc] init];
    self.leftButton.frame = customCGRect(0, 0, 30, 30);
    //    self.leftButton.backgroundColor = [UIColor redColor];
    [self.leftButton addTarget:self action:@selector(goBackButton) forControlEvents:UIControlEventTouchUpInside];
    [self.leftButton setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:self.leftButton];
    
    self.homeButton = [[BaseButton alloc] init];
    self.homeButton.frame = customCGRect(0, 0, 30, 30);
    [self.homeButton addTarget:self action:@selector(HomeButton) forControlEvents:UIControlEventTouchUpInside];
    [self.homeButton setImage:[UIImage imageNamed:@"menu_home"] forState:UIControlStateNormal];
//    UIBarButtonItem *homeItem = [[UIBarButtonItem alloc] initWithCustomView:self.homeButton];
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                       initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       target:nil action:nil];
    negativeSpacer.width = -5;
    self.navigationItem.leftBarButtonItems = @[negativeSpacer,leftItem];
    
//    [self noTitleGoBackBtnStyle];
}

- (void)rightItemButton{
    self.rightButton = [[BaseButton alloc] init];
    self.rightButton.frame = customCGRect(0, 0, 30, 30);
//    self.rightButton.backgroundColor = [UIColor redColor];
    [self.rightButton addTarget:self action:@selector(myPocketButton) forControlEvents:UIControlEventTouchUpInside];
    [self.rightButton setImage:[UIImage imageNamed:@"myPocket"] forState:UIControlStateNormal];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:self.rightButton];
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                       initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       target:nil action:nil];
    negativeSpacer.width = -5;
    self.navigationItem.rightBarButtonItems = @[negativeSpacer,rightItem];
}

- (void)goBackButton{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)HomeButton{
    [[NSNotificationCenter defaultCenter]postNotificationName:@"home" object:nil];
}

- (void)noTitleGoBackBtnStyle{
    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(0, -60) forBarMetrics:UIBarMetricsDefault];
}

- (void)myPocketButton{
    [[NSNotificationCenter defaultCenter]postNotificationName:@"pocket" object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
