//
//  BaseImageView.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseImageView : UIImageView

/**
 初期化

 @return self
 */
-(instancetype)init;

/**
 初期設定

 @param frame コントロールサイズ
 @return self
 */
-(instancetype)initWithFrame:(CGRect)frame;


/**
 角丸サイズを設定する
 
 @param fillet 角丸サイズ
 */
-(void)setFillet:(CGFloat)fillet;

- (UIImage *)rescaleImageToSize:(CGSize)size;

@end
