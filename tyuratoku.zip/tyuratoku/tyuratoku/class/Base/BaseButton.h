//
//  BaseButton.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

/**ボタン色枚挙*/
typedef enum : NSUInteger {
    BaseButtonGray,
    BaseButtonBlack,
    BaseButtonBlue,
    BaseButtonRed,
    BaseButtonWhite,
} BaseButtonTextColor;

static CGFloat BaseButtonDefaultFont = 16;

@interface BaseButton : UIButton
/**
 初期化
 
 @return self
 */
-(instancetype)init;

/**
 初期設定
 
 @param frame コントロールサイズ
 @return self
 */
-(instancetype)initWithFrame:(CGRect)frame;

/**
 文字とフォントの色を設定して

 @param text 文字
 @param color フォント色
 */
-(void)setText:(NSString *)text textColor:(BaseButtonTextColor)color;

@end
