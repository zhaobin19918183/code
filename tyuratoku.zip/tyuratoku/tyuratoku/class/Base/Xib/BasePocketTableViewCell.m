//
//  BasePocketTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BasePocketTableViewCell.h"

@implementation BasePocketTableViewCell
/**
 * 機能名　　　　：MyPocket
 * 機能概要　　　：美ら得アプリのログイン画面です。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
//    self.contentView.backgroundColor = [UIColor colorWithRed:231.0/255.0 green:231.0/255.0 blue:231.0/255.0 alpha:1];
    if (self)
    {
        // [self.titleLabel autoLabelHeightFromString];
        self.backView = [[BaseView alloc]init];
        [self.contentView addSubview:self.backView];
        
        self.backImageVIew = [[BaseImageView alloc]init];
        [self.backView addSubview:self.backImageVIew];
        
        self.titleLabel =[[BaseLabel alloc]init];
        [self.backImageVIew addSubview:self.titleLabel];
        
        self.contentTextView =[[BaseTextView alloc]init];
        [self.backImageVIew addSubview:self.contentTextView];
        
        self.lineLabel =[[BaseView alloc]init];
        self.lineLabel.backgroundColor = [UIColor blackColor];
        [self.backImageVIew addSubview:self.lineLabel];
    }
    return self;
}
-(void)layoutSubviews
{
    self.backView.frame = customCGRect(5, 5, 365, 145);
    self.backImageVIew.frame =customCGRect(0, 0, 365, 175);
    self.titleLabel.frame = customCGRect(2, 10, 360, 40);
   
    self.titleLabel.textAlignment = NSTextAlignmentCenter ;
    self.titleLabel.textColor =[UIColor whiteColor];
   
    
    self.lineLabel.frame = customCGRect(2, self.titleLabel.frame.size.height + 10, 365, 1);
    [self drawDashLine:self.lineLabel lineLength:8*KWIDTH lineSpacing:1 lineColor:[UIColor whiteColor]];

    self.contentTextView.frame= customCGRect(2, self.lineLabel.frame.origin.y+6, 365, 130);
    self.contentTextView.textColor = [UIColor whiteColor];
    self.contentTextView.backgroundColor = [UIColor clearColor];
    self.contentTextView.font = [UIFont boldSystemFontOfSize:14];
    self.contentTextView.userInteractionEnabled= NO;
    
}

- (void)drawDashLine:(UIView *)lineView lineLength:(int)lineLength lineSpacing:(int)lineSpacing lineColor:(UIColor *)lineColor
{
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    [shapeLayer setBounds:lineView.bounds];
    [shapeLayer setPosition:CGPointMake(CGRectGetWidth(lineView.frame) / 2, CGRectGetHeight(lineView.frame))];
    [shapeLayer setFillColor:[UIColor clearColor].CGColor];
    [shapeLayer setStrokeColor:lineColor.CGColor];
    [shapeLayer setLineWidth:CGRectGetHeight(lineView.frame)];
    [shapeLayer setLineJoin:kCALineJoinRound];

    [shapeLayer setLineDashPattern:[NSArray arrayWithObjects:[NSNumber numberWithInt:lineLength], [NSNumber numberWithInt:lineSpacing], nil]];

    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, 0, 0);
    CGPathAddLineToPoint(path, NULL, CGRectGetWidth(lineView.frame), 0);
    
    [shapeLayer setPath:path];
    CGPathRelease(path);
    [lineView.layer addSublayer:shapeLayer];
}

-(void)myPocketCell:(MyProcketModel *)model
{
    NSMutableParagraphStyle  *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle  setLineSpacing:10];

    NSMutableAttributedString  *setString = [[NSMutableAttributedString alloc] initWithString:model.titleStr];
    [setString  addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [model.titleStr length])];
    
    [self.titleLabel  setAttributedText:setString];
    
    [self.titleLabel autoLabelHeightFromString];
    self.contentTextView.text = [NSString stringWithFormat:@"      %@",model.contentStr];
    

}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
