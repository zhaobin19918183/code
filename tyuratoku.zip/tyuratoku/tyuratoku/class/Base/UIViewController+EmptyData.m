//
//  UIViewController+EmptyData.m
//  Beautiful
//
//  Created by newland on 2017/7/21.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "UIViewController+EmptyData.h"
/**
 * 機能名　　　　：拡張類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/08/1
 ***********************************************************************
 ***********************************************************************
 */
@implementation UIViewController (EmptyData)
static BaseView *errorView = nil;
static UIViewController *vc = nil;

- (void)setErrorView:(id)data{
    //dic
    if ([data isKindOfClass:[NSDictionary class]]||[data isKindOfClass:[NSMutableDictionary class]]) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        
        if ([data isKindOfClass:[NSDictionary class]]) {
            dic = [NSMutableDictionary dictionaryWithDictionary:data];
        }else{
            dic = data;
        }
        if ([dic allKeys]==0) {
            data = nil;
        }
    }
    //array
    if ([data isKindOfClass:[NSArray class]]||[data isKindOfClass:[NSMutableArray class]]) {
        NSMutableArray *array = [NSMutableArray array];
        
        if ([data isKindOfClass:[NSArray class]]) {
            array = [NSMutableArray arrayWithArray:data];
        }else{
            array = data;
        }
        if (array.count==0) {
            data = nil;
        }
    }
    
//    表示を判断する
    if ((data==nil||[data isEqual:[NSNull null]])&&errorView==nil) {
        if (vc != [NetWorkManager getCurrentVC]) {
            [self creatView:YES];
        }
    }else{
        [errorView removeFromSuperview];
    }
    
    
//    [self noNetView];
    vc = [NetWorkManager getCurrentVC];
}

//創建ui
- (void)creatView:(BOOL)state{
    errorView = [[BaseView alloc]init];
    errorView.frame = [NetWorkManager getCurrentVC].view.frame;
    errorView.tag = 666;
    errorView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:errorView];
    
    //画像
    BaseImageView *noNetImageView = [[BaseImageView alloc]init];
    noNetImageView.frame = CGRectMake((errorView.frame.size.width-XSpan(150))/2, (errorView.frame.size.width-XSpan(150))/2, XSpan(150), YSpan(150));
    if (state) {
        noNetImageView.image = [UIImage imageNamed:@"noData"];
    }else{
        noNetImageView.image = [UIImage imageNamed:@"failed"];
    }
    [errorView addSubview:noNetImageView];
    
    //再ロードボタン
    BaseButton *errorButton = [[BaseButton alloc]initWithFrame:CGRectMake(noNetImageView.frame.origin.x, CGRectGetMaxY(noNetImageView.frame)+YSpan(20), noNetImageView.frame.size.width, YSpan(45))];
//    errorButton.backgroundColor = [UIColor orangeColor];
    [errorButton addTarget:self action:@selector(upRefreshData) forControlEvents:UIControlEventTouchUpInside];
    [errorButton setText:@"mnPlayerNoNetHint" textColor:BaseButtonBlack];
    errorButton.titleLabel.numberOfLines = 0;
    [errorView addSubview:errorButton];
}

//block
- (void)upRefreshData{
}

//ネットワーク状況に傍受する
//- (void)noNetView{
//    [[NSNotificationCenter defaultCenter]addObserverForName:@"noNet" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
//        if (errorView==nil) {
//            [self creatView:NO];
//        }
//        
//    }];
//}


- (void)upRefreshData:(id)data{
    [self setErrorView:data];
}

- (void)NOData:(id)data{
    //dic
    if ([data isKindOfClass:[NSDictionary class]]||[data isKindOfClass:[NSMutableDictionary class]]) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        
        if ([data isKindOfClass:[NSDictionary class]]) {
            dic = [NSMutableDictionary dictionaryWithDictionary:data];
        }else{
            dic = data;
        }
        if ([dic allKeys]==0) {
            data = nil;
        }
    }
    //array
    if ([data isKindOfClass:[NSArray class]]||[data isKindOfClass:[NSMutableArray class]]) {
        NSMutableArray *array = [NSMutableArray array];
        
        if ([data isKindOfClass:[NSArray class]]) {
            array = [NSMutableArray arrayWithArray:data];
        }else{
            array = data;
        }
        if (array.count==0) {
            data = nil;
        }
    }
    
    //    表示を判断する
    if ((data==nil||[data isEqual:[NSNull null]])) {
        [self creatSubView];
    }else{
        for (UIView * view in [self.view subviews]) {
            if (view.tag==123) {
                [view removeFromSuperview];
            }
        }
    }
    
}

//创建 view
-(void)creatSubView{
    
  
    BaseImageView * img = [[BaseImageView alloc]init];

    img.frame = CGRectMake((self.view.frame.size.width-YSpan(100))/2, (self.view.frame.size.width-100 * KHEIGHT)/2, YSpan(100), YSpan(110));
    img.image = [UIImage imageNamed:@"page_failed"];
    [self.view addSubview:img];
    img.tag = 123;
    
    UILabel * label = [[UILabel alloc]init];
    label.frame = CGRectMake((self.view.frame.size.width-200 * KHEIGHT)/2, CGRectGetMaxY(img.frame)+YSpan(10), 200 * KHEIGHT, 20 * KHEIGHT);
    label.text = @"データがありません";
    label.font = [UIFont systemFontOfSize:XSpan(16)];
    label.textColor = [UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1];
    label.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:label];
    label.tag = 123;
    
}

@end
