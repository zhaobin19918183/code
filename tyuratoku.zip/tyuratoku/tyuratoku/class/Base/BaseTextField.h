//
//  BaseTextField.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTextField : UITextField
/**
 初期化
 
 @return self
 */
-(instancetype)init;

/**
 初期設定
 
 @param frame コントロールサイズ
 @return self
 */
-(instancetype)initWithFrame:(CGRect)frame;
@end
