//
//  BaseTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/19.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNoticeTableViewCell : UITableViewCell

@property(nonatomic,strong)BaseImageView  * imgView;
@property(nonatomic,strong)BaseLabel  * titleLabel;
@property(nonatomic,strong)BaseLabel  * bodyLabel;
@property(nonatomic,strong)BaseLabel  * dateLabel;
@property(nonatomic,strong)BaseLabel  * authorLabel;

@end
