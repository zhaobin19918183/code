//
//  BaseButton.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseButton.h"
/**
 * 機能名　　　　：基類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation BaseButton

//初期化
-(instancetype)init{
    @try {
        self = [super init];
        if (self) {
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定
-(instancetype)initWithFrame:(CGRect)frame{
    @try {
        self = [super initWithFrame:frame];
        if (self) {
            self.frame = frame;
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定データ
-(void)initData{
    @try {
        self.titleLabel.font = [UIFont systemFontOfSize:BaseButtonDefaultFont];
        [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//文字とフォントの色を設定して
-(void)setText:(NSString *)text textColor:(BaseButtonTextColor)color{
    //フォントの色を設定して
    switch (color) {
        case BaseLabelGray:
            [self setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            break;
        case BaseLabelBlue:
            [self setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
            break;
        case BaseLabelBlack:
            [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            break;
        case BaseLabelWhite:
            [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            break;
        case BaseLabelRed:
            [self setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    //空に判断して判断する
    if ([text isKindOfClass:[NSNull class]]||text==nil) {
        text = @"";
    }
    //文字セット
    [self setTitle:CountryLanguage(text) forState:UIControlStateNormal];
}

@end
