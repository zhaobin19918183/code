//
//  BaseModel.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"
/**
 * 機能名　　　　：基類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation BaseModel

//辞書が回る model
-(instancetype)initWithDic:(NSDictionary *)dic{
    @try {
        if (!dic || ![dic isKindOfClass:[NSDictionary class]]) {
            return nil;
        }
        if (self = [super init]) {
            for (NSString *key in [dic allKeys]) {
                id value = dic[key];
                //1.処理対象タイプと配列タイプ
                if ([value isKindOfClass:[NSArray class]] || [value isKindOfClass:[NSDictionary class]]) {
                    [self setValue:value forKeyPath:key];
                }else if ([value isKindOfClass:[NSNull class]]||value==nil||value==NULL) {
                    //2.処理空タイプ：unRecognized selector exceptionを防ぐ
                    [self setValue:nil forKey:key];
                }else{
                    //3.その他のタイプ：処理を含む数字、文字列、ブール、全部使用NSString処理
                    [self setValue:[NSString stringWithFormat:@"%@",value] forKeyPath:key];
                    
                }
            }
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//model 辞書を回転する
-(NSDictionary *)getModelDic{
    @try {
        //初期化辞書
        NSMutableDictionary *props = [NSMutableDictionary dictionary];
        
        unsigned int outCount, i;
        
        //序列化
        objc_property_t *properties = class_copyPropertyList([self class], &outCount);
        
        //出力
        for (i = 0; i<outCount; i++){
            objc_property_t property = properties[i];
            const char *char_f = property_getName(property);
            NSString *propertyName = [NSString stringWithUTF8String:char_f];
            id propertyValue = [self valueForKey:(NSString *)propertyName];
            if (propertyValue) [props setObject:propertyValue forKey:propertyName];
        }
        
        free(properties);
        
        return props;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
-(void)setNilValueForKey:(NSString *)key{
    
}
//@try {
//    <#Code that can potentially throw an exception#>
//} @catch (NSException *exception) {
//    NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
//}
@end
