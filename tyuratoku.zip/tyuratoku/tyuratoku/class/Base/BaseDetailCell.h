//
//  BaseDetailCell.h
//  Beautiful
//
//  Created by newland on 2017/8/16.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NoticeModel.h"
#import "SRVideoPlayer.h"

@protocol clickImageDelegate <NSObject>

-(void)refreshTableView:(float)cellHeight imageViewHeight:(CGRect)imageFrame;
@optional
-(void)getImage:(NSString *)image;
-(void)clickImageView:(UITapGestureRecognizer *)tap;

@end

@interface BaseDetailCell : UITableViewCell<UIScrollViewDelegate>

@property(nonatomic,strong)BaseLabel *titleLabel;//title
@property (nonatomic,strong)UIScrollView *scrollView;//ScrollView
@property(nonatomic,strong)BaseImageView *imgScrollView;//imag
@property(nonatomic,strong)BaseImageView *imgView;//image
@property(nonatomic,strong)BaseLabel *contentOneLabel;//Picture above text
@property(nonatomic,strong)BaseLabel *contentTwoLabel;//Text below picture
@property(nonatomic,strong)BaseButton *playButton;
@property(nonatomic,strong)SRVideoPlayer *videoPlayer;
@property(nonatomic,assign)CGRect imageFrame;
@property(nonatomic,strong)NSMutableArray *imageUrlArray;
@property(nonatomic,weak)id<clickImageDelegate>delegate;
@property(nonatomic,strong)UIView  * line;
@property(nonatomic,strong)NSMutableArray <NSString*>*arrayImage;
@property(nonatomic,copy) NSString *numStr;
@property(nonatomic,strong) BaseLabel *numLabel;

-(void)setSubviewFrame:(NoticeModel *)model;
-(void)setMoreImageState:(BOOL)state;
@end
