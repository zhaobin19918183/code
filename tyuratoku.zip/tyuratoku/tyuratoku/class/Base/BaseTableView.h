//
//  BaseTableView.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTableView : UITableView<UIScrollViewDelegate>

/**
 更新状態のフィボナッチリトレースメントに入る
 */
typedef void (^BaseTableViewHeaderRefresh)();
typedef void (^BaseTableViewFooterRefresh)();

/**
 更新しているフィボナッチリトレースメント
 */
@property(strong, nonatomic) BaseTableViewHeaderRefresh headerRefreshBlock;
@property(strong, nonatomic) BaseTableViewFooterRefresh footerRefreshBlock;

/**
 初期化
 
 @return self
 */
-(instancetype)init;

/**
 初期設定
 
 @param frame コントロールサイズ
 @return self
 */
-(instancetype)initWithFrame:(CGRect)frame;

/**
 指定の cell
 
 @param indexPath indexPath
 @return cell
 */
-(UITableViewCell *)getCell:(NSIndexPath *)indexPath;

/**
 更新一つ cell
 
 @param row 行
 @param section 組
 */
-(void)refreshCell:(NSInteger)row section:(NSInteger)section;

/**
 更新一つ section
 
 @param section 組
 */
-(void)refreshSection:(NSInteger)section;

/**プルロード*/
-(void)upRefresh;

/**
 ロード時のコールバック
 
 @param refresh MJRefreshGifHeader
 */
-(void)upRefreshData:(BaseTableViewFooterRefresh)refresh;

/**プルダウン更新*/
-(void)downRefresh;

/**
 更新時のフィボナッチリトレースメント
 
 @param refresh MJRefreshAutoGifFooter
 */
-(void)downRefreshData:(BaseTableViewHeaderRefresh)refresh;

@end
