//
//  BaseViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController
@property (strong,nonatomic) BaseButton *rightButton;
@property (strong,nonatomic) BaseButton *leftButton;
@property (strong,nonatomic) BaseButton *homeButton;

/**
 navigationBar 右ボタン
 */
-(void)rightItemButton;

/**
 navigationBar 左ボタン
 */
-(void)leftItemButton;

@end
