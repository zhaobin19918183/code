//
//  BaseTableView.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseTableView.h"
/**
 * 機能名　　　　：基類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation BaseTableView{
    MJRefreshGifHeader *gifHeader;//更新のヘッド
    MJRefreshAutoGifFooter *gifFooter;//更新の足
}

//初期化
-(instancetype)init{
    @try {
        self = [super init];
        if (self) {
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定
-(instancetype)initWithFrame:(CGRect)frame{
    @try {
        self = [super initWithFrame:frame];
        if (self) {
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定データ
-(void)initData{
    @try {
        self.backgroundColor = [UIColor whiteColor];
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        [self viewDidLayoutSubviews];
        [self setExtraCellLineHidden:self];
        
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}
-(void)setExtraCellLineHidden: (UITableView *)tableView
{
    UIView *view = [UIView new];
    
    view.backgroundColor = [UIColor clearColor];
    
    [tableView setTableFooterView:view];
}

-(void)viewDidLayoutSubviews {
    
    if ([self respondsToSelector:@selector(setSeparatorInset:)]) {
        [self setSeparatorInset:UIEdgeInsetsZero];
        
    }
    if ([self respondsToSelector:@selector(setLayoutMargins:)])  {
        [self setLayoutMargins:UIEdgeInsetsZero];
    }
    
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPat{
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]){
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
}
#pragma mark - cell
//指定の cell
-(UITableViewCell *)getCell:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [self cellForRowAtIndexPath:indexPath];
    return cell;
}

//更新一つ cell
-(void)refreshCell:(NSInteger)row section:(NSInteger)section{
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:section];
    [self reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
}

//更新一つ section
-(void)refreshSection:(NSInteger)section{
    NSIndexSet *indexSet = [[NSIndexSet alloc]initWithIndex:section];
    [self reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - プルダウン更新
-(void)downRefresh{
    @try {
        gifHeader = [MJDIYGifHeader headerWithRefreshingBlock:^{
            //コールバック
            if (self.headerRefreshBlock) {
                self.headerRefreshBlock(gifHeader);
            }
            [self reloadData];
            [self.mj_header endRefreshing];
        }];
        
        //隠し時間
        gifHeader.lastUpdatedTimeLabel.hidden = YES;
        
        self.mj_header = gifHeader;
        
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
    
}

#pragma mark - プルロード
-(void)upRefresh{
    @try {
        
        gifFooter = [MJDIYAutoGifFooter footerWithRefreshingBlock:^{
            //コールバック
            if (self.footerRefreshBlock) {
                self.footerRefreshBlock(gifFooter);
            }
            [self reloadData];
            [self.mj_footer endRefreshing];
        }];
        
        self.mj_footer = gifFooter;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
    
}

//ロード時のコールバック
-(void)upRefreshData:(BaseTableViewFooterRefresh)refresh{
    self.footerRefreshBlock = refresh;
}

//更新時のフィボナッチリトレースメント
-(void)downRefreshData:(BaseTableViewHeaderRefresh)refresh{
    self.headerRefreshBlock = refresh;
}

@end
