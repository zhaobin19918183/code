//
//  BaseImageView.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseImageView.h"
/**
 * 機能名　　　　：基類
 * 機能概要　　　：補助開発
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation BaseImageView

//初期化
-(instancetype)init{
    @try {
        self = [super init];
        if (self) {
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定
-(instancetype)initWithFrame:(CGRect)frame{
    @try {
        self = [super initWithFrame:frame];
        if (self) {
            self.frame = frame;
            [self initData];
        }
        return self;
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

//初期設定データ
-(void)initData{
    @try {
        self.image = [UIImage imageNamed:@"noImage"];
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

/**
 角丸サイズを設定する
 
 @param fillet 角丸サイズ
 */
-(void)setFillet:(CGFloat)fillet{
    self.layer.masksToBounds = YES;
    if (fillet==0) {
        self.layer.cornerRadius = self.frame.size.width/2;
    }else{
        self.layer.cornerRadius = XSpan(fillet);
    }
}

#pragma mark 图片自适应
- (UIImage *)rescaleImageToSize:(CGSize)size {
    
    CGRect rect = CGRectMake(0.0, 0.0, size.width, size.height);
    
    UIGraphicsBeginImageContext(rect.size);
    
    [self.image drawInRect:rect];  // scales image to rect
    
    UIImage *resImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return resImage;
    
}

@end
