//
//  BaseDetailViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseDetailViewController : BaseViewController<UIWebViewDelegate>

@property(nonatomic,strong) UIView * bottomView;//bottom View;
@property(nonatomic,strong) BaseButton * linkBut;
@property(nonatomic,strong) BaseButton * shareBut;
@property(nonatomic,strong) BaseButton * pocketButton;
-(void)NavigationTitle:(NSString *)titleStr;

-(void)shareButton;

-(void)pocketButtonClick;

-(void)CreatBottomViewSubviews:(NSDictionary *)dic;

-(CGFloat)getTableViewHeight;

-(void)backBtn;

@end
