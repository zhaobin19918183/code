//
//  BaseDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseDetailViewController.h"
#import "AppDelegate.h"

@interface BaseDetailViewController ()


@end
/**
 * 機能名　　　　：お知らせ詳しい
 * 機能概要　　　：お知らせリスト詳しい
 * 作成者    　 ：郭麗影　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation BaseDetailViewController
//二級のメニューは引き出しのメニューを表示しない
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillDisappear:animated];
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.mmdVc setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeNone];
//    [app.mmdVc setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeNone];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self BackButton];//ナビゲーションボタンを返します
    [self NavigationRightButton];//航行権を共有すると私のポケットのボタン
    [self CreatBottomView];//底面図作成
}

//ナビゲーションボタンを返します
-(void)BackButton{

//    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"back"] style:UIBarButtonItemStylePlain target:self action:@selector(backBtn)];
//    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];

    BaseButton * but = [[BaseButton alloc] init];
    but.frame = customCGRect(0, 0, 30, 30);
   
    [but addTarget:self action:@selector(backBtn) forControlEvents:UIControlEventTouchUpInside];
    [but setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:but];
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                       initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       target:nil action:nil];
    negativeSpacer.width = -5;
    self.navigationItem.leftBarButtonItems = @[negativeSpacer,leftItem];
}

//復帰ボタンイベント
-(void)backBtn{

    [self.navigationController popViewControllerAnimated:YES];
}

//ナビゲーション・タイトル
-(void)NavigationTitle:(NSString *)titleStr{

    self.navigationItem.title = CountryLanguage(titleStr);
    
}

//航行権を共有すると私のポケットのボタン
-(void)NavigationRightButton{

    self.shareBut = [[BaseButton alloc] init];
    self.shareBut.frame = customCGRect(0, 0, 30, 30);
    [self.shareBut addTarget:self action:@selector(shareButton) forControlEvents:UIControlEventTouchUpInside];
    [self.shareBut setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    UIBarButtonItem *shareItem = [[UIBarButtonItem alloc] initWithCustomView:self.shareBut];
    
    self.pocketButton = [[BaseButton alloc] init];
    self.pocketButton.frame = customCGRect(0, 0, 30, 30);
    [self.pocketButton addTarget:self action:@selector(pocketButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.pocketButton setImage:[UIImage imageNamed:@"myPocket"] forState:UIControlStateNormal];
    UIBarButtonItem *pocketItem = [[UIBarButtonItem alloc] initWithCustomView:self.pocketButton];

    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                       initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       target:nil action:nil];
    negativeSpacer.width = -5;
    
    NSArray *actionButtonItems = @[negativeSpacer,pocketItem,shareItem];
    self.navigationItem.rightBarButtonItems = actionButtonItems;
}

//共有ボタンクリックイベント
-(void)shareButton{
}

//私のポケットのボタンクリックイベント
-(void)pocketButtonClick{
    [[NSNotificationCenter defaultCenter]postNotificationName:@"pocket" object:nil];
}

//底面図作成
-(void)CreatBottomView{

    self.bottomView = [[UIView alloc]init];
//    self.bottomView.frame = CGRectMake(0, Screen_H-YSpan(130)-64, Screen_W, YSpan(130));
    self.bottomView.frame = CGRectMake(0, Screen_H-YSpan(75)-64, Screen_W, YSpan(75));
    self.bottomView.backgroundColor = RGBA(238, 238, 238, 1);
    [self.view addSubview:self.bottomView];
    
   //hio self.bottomView.hidden = YES;
}

//底面図ビューを作成する
-(void)CreatBottomViewSubviews:(NSDictionary *)dic{

    if ([dic[@"rel_url_ios"] isEqualToString:@""]&&[dic[@"rel_url"] isEqualToString:@""]) {
        self.bottomView.hidden = YES;
    }
    else{
    
        self.bottomView.hidden = NO;
        
//        for (int i = 0; i<3; i++) {
//            BaseButton *but = [BaseButton buttonWithType:UIButtonTypeCustom];
//            but.frame = CGRectMake(XSpan(100)+(Screen_W-XSpan(200)-YSpan(120))/2*i + YSpan(40)*i, YSpan(15), YSpan(40), YSpan(40));
//            //        but.backgroundColor = [UIColor blackColor];
//            [self.bottomView addSubview:but];
//            if (i==0) {
//                [but setImage:[UIImage imageNamed:@"facebook"] forState:UIControlStateNormal];
//            }else if (i==1){
//                [but setImage:[UIImage imageNamed:@"twitter"] forState:UIControlStateNormal];
//            }else{
//                [but setImage:[UIImage imageNamed:@"line"] forState:UIControlStateNormal];
//            }
//            
//            but.tag = i;
//            [but addTarget:self action:@selector(BottomViewButtonClick:dic:) forControlEvents:UIControlEventTouchUpInside];
//        }
//        
        self.linkBut = [[BaseButton alloc]init];
        [self.bottomView addSubview:self.linkBut];
        self.linkBut.layer.cornerRadius = XSpan(5);
        self.linkBut.frame = customCGRect(40, 15, 295, 45);
        self.linkBut.backgroundColor = [UIColor whiteColor];
        self.linkBut.tag = 3;
        [self.linkBut addTarget:self action:@selector(BottomViewButtonClick:dic:) forControlEvents:UIControlEventTouchUpInside];
        if ([dic[@"rel_url_label"] isEqualToString:@""]||[dic[@"rel_url_label"] isKindOfClass:[NSNull class]]) {
            
            [self.linkBut setText:@"Cooperative web title" textColor:BaseButtonBlack];
        }
        else{
            
            [self.linkBut setText:dic[@"rel_url_label"] textColor:BaseButtonBlack];
        }
    }
}


//下のボタンをクリックしてイベントを見る
-(void)BottomViewButtonClick:(UIButton *)button dic:(NSDictionary *)dic{

    switch (button.tag) {
        case 3:
        {
        
            NSLog(@"3");
            
        }
            break;
        default:
            break;
    }

}

-(CGFloat)getTableViewHeight{
    return Screen_H-YSpan(120)-64;
}



@end
