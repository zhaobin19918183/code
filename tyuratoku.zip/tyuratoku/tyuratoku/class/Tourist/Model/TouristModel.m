//
//  TouristModel.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristModel.h"
/**
 * 機能名　　　　：観光地
 * 機能概要　　　：観光地のデータ
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation TouristModel

@end
