//
//  TouristAreaCollectionViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristAreaCollectionViewCell.h"
/**
 * 機能名　　　　：観光地
 * 機能概要　　　：観光地の名称リストcell
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation TouristAreaCollectionViewCell{
    /**写真*/
    BaseImageView *imageView;
    /**店名*/
    BaseLabel *addresLabel;
}

//初期化セル
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        [self createSubviews];
    }
    return self;
}

//創建ui
- (void)createSubviews{
    //写真
    imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.width);
    [imageView setFillet:0];
    [self.contentView addSubview:imageView];
    
    //店名
    addresLabel = [[BaseLabel alloc]init];
    addresLabel.frame = CGRectMake(0, CGRectGetMaxY(imageView.frame), imageView.frame.size.width, self.contentView.frame.size.height-CGRectGetMaxY(imageView.frame));
    [addresLabel setText:@"" textAlignment:BaseLabelCenter];
    [addresLabel setTextFont:13 textColor:BaseLabelBlack];
    [self.contentView addSubview:addresLabel];
}

//写真を得る
- (BaseImageView *)getImageView{
    return imageView;
}

//店名を得る
- (BaseLabel *)getAddresLabel{
    return addresLabel;
}

@end
