//
//  TouristAreaCollectionViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TouristAreaCollectionViewCell : UICollectionViewCell

/**
 初期化セル

 @param frame フレーム
 @return セル
 */
- (instancetype)initWithFrame:(CGRect)frame;

/**
 写真を得る

 @return BaseImageView
 */
- (BaseImageView *)getImageView;

/**
 地点名を得る

 @return BaseLabel
 */
- (BaseLabel *)getAddresLabel;

@end
