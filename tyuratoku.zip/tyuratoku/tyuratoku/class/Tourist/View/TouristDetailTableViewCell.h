//
//  TouristDetailTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TouristModel.h"
#import "NoticeModel.h"

@interface TouristDetailTableViewCell : BaseDetailCell

//モデル
@property(nonatomic,strong)TouristModel *detailCellModel;

@end
