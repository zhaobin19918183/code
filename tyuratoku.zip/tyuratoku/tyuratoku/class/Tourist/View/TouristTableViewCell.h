//
//  TouristTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TouristModel.h"

@interface TouristTableViewCell : UITableViewCell

/**
 初期化セル

 @param style UITableViewCellStyle
 @param reuseIdentifier 重用識別子
 @param frame フレーム
 @param model モデル
 @return セル
 */
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame model:(TouristModel *)model;

@end
