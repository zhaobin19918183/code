//
//  TouristDetailTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristDetailTableViewCell.h"
/**
 * 機能名　　　　：観光地
 * 機能概要　　　：観光地の詳細cell
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation TouristDetailTableViewCell

//モデル付値
- (void)setDetailCellModel:(TouristModel *)detailCellModel{
    _detailCellModel = detailCellModel;
    [self setSubviewFrame:(NoticeModel*)detailCellModel];
}

//ビデオ
- (void)showVideoPlayer{
    self.imgView.hidden =YES;

    //ビデオビュー
    UIView *playerView = [[UIView alloc] init];
    playerView.frame = CGRectMake((self.arrayImage.count-1) * Screen_W, 0, Screen_W, self.imgScrollView.frame.size.height);
    [self.scrollView addSubview:playerView];
    
    //プレーヤー
    self.videoPlayer = [SRVideoPlayer playerWithVideoURL:[self urlstring:_detailCellModel.movie_url] playerView:playerView playerSuperView:playerView.superview];
    self.videoPlayer.playerEndAction = SRVideoPlayerEndActionDestroy;
    [self.videoPlayer play];
}

//ビデオurl
- (NSURL *)urlstring:(NSString *)movieUrl{
    NSURL *fileURL = [NSURL URLWithString:movieUrl];
    return fileURL;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    NSNumber *number = [NSNumber numberWithInt:scrollView.contentOffset.x/Screen_W];
    
    self.numStr = [NSString stringWithFormat:@"%d/%ld",[number intValue]+1,self.arrayImage.count];
    [self.numLabel setText:self.numStr];
    
    [self.delegate getImage:[self.arrayImage objectAtIndex:[number intValue]]];
    if ([self.numStr intValue]==self.arrayImage.count) {
        
    }
    else{
    
        [self.videoPlayer pause];
    }
}

@end
