//
//  TouristTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristTableViewCell.h"
/**
 * 機能名　　　　：観光地
 * 機能概要　　　：観光地リストcell
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation TouristTableViewCell{
    /**モデル*/
    TouristModel *eventModel;
}

//初期化セル
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame model:(TouristModel *)model{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        eventModel = model;
        [self creatSubview];
    }
    return self;
}

//創建ui
- (void)creatSubview{
    //画像
    BaseImageView *imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(XSpan(4), YSpan(4), self.contentView.frame.size.width-XSpan(8), self.contentView.frame.size.height-YSpan(4));
    [imageView sd_setImageWithURL:[NSURL URLWithString:eventModel.category_image_url] placeholderImage:[UIImage imageNamed:@"noImage"]];
    [self.contentView addSubview:imageView];
    
    //タイトル
    BaseLabel *titleLabel = [[BaseLabel alloc]init];
    titleLabel.frame = CGRectMake(0, 0, imageView.frame.size.width, YSpan(30));
    titleLabel.center = imageView.center;
    [titleLabel setText:eventModel.category_name textAlignment:BaseLabelCenter];
    [titleLabel setTextFont:20 textColor:BaseLabelWhite];
    [imageView addSubview:titleLabel];
}

@end
