//
//  TouristAreaViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristAreaViewController.h"
#import "AppDelegate.h"

/**重用識別子*/
static NSString *reuse = @"reuse";
/**アイテムの高*/
static CGFloat itemHeight = 0;
/**アイテムの幅*/
static CGFloat itemWidth = 0;

@interface TouristAreaViewController (){
    /**リスト*/
    BaseCollectionView *touristAreaCollectionView;
    /**リストデータ*/
    NSMutableArray <TouristModel*>*areaDataArray;
}

@end
/**
 * 機能名　　　　：観光地
 * 機能概要　　　：観光地カテゴリ名
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation TouristAreaViewController

//二級のメニューは引き出しのメニューを表示しない
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillDisappear:animated];
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.mmdVc setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeNone];
    [app.mmdVc setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeNone];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //タイトル
    self.title = _eventModel.category_name;
    [self leftItemButton];
    areaDataArray = [NSMutableArray array];
    
    //layout
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    //リスト作成
    touristAreaCollectionView = [[BaseCollectionView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-64) collectionViewLayout:layout];
    touristAreaCollectionView.backgroundColor = [UIColor clearColor];
    touristAreaCollectionView.delegate = self;
    touristAreaCollectionView.dataSource = self;
    [self.view addSubview:touristAreaCollectionView];
    
    //register
    [touristAreaCollectionView registerClass:[TouristAreaCollectionViewCell class] forCellWithReuseIdentifier:reuse];
    
    //請求データ
    [self getDBData];
}

#pragma mark - collectionView
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return areaDataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    TouristAreaCollectionViewCell *cell = [[TouristAreaCollectionViewCell alloc]initWithFrame:CGRectMake(0, 0,itemWidth, itemHeight)];
    //セル付値
    cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    [[cell getImageView]sd_setImageWithURL:[NSURL URLWithString:[areaDataArray objectAtIndex:indexPath.row].list_thumb_url] placeholderImage:[UIImage imageNamed:@"noImage"]];
    [[cell getAddresLabel]setText:[areaDataArray objectAtIndex:indexPath.row].title];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    itemHeight = (collectionView.frame.size.height-YSpan(50))/4;
    itemWidth = (collectionView.frame.size.width-XSpan(50))/3;
    return CGSizeMake(itemWidth, itemHeight);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(YSpan(10), XSpan(10), YSpan(10), XSpan(10));
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    TouristDetailViewController *deatilVc = [[TouristDetailViewController alloc]init];
    deatilVc.detailModel = [areaDataArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:deatilVc animated:YES];
}

#pragma mark - DB
- (void)getDBData{
    //データベースデータを検索する
    NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAnd(eventDBName, [NetWorkManager getCurrentTimeStr], self.eventModel.category_id) DBName:eventDBName];
    //arrayに足を付けるデータ
    for (NSMutableDictionary *dic in array) {
        [areaDataArray addObject:[[TouristModel alloc]initWithDic:dic]];
    }
    //更新リスト
    [touristAreaCollectionView reloadData];
}

@end
