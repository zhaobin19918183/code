//
//  TouristAreaViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"
#import "TouristAreaCollectionViewCell.h"
#import "TouristDetailViewController.h"
#import "TouristModel.h"

@interface TouristAreaViewController : BaseViewController<UICollectionViewDataSource,UICollectionViewDelegate>

/**モデル*/
@property(nonatomic,strong)TouristModel *eventModel;

@end
