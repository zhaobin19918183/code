//
//  TouristViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"
#import "TouristTableViewCell.h"
#import "TouristAreaViewController.h"
#import "TouristModel.h"

@interface TouristViewController : BaseViewController<UITableViewDelegate,UITableViewDataSource>

@end
