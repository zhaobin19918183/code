//
//  TouristViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "TouristViewController.h"

@interface TouristViewController (){
    /**リスト*/
    BaseTableView *touristTableView;
    /**リストデータ*/
    NSMutableArray <TouristModel*>*eventDataArray;
    /**サーバーラストパラメータ*/
    NSString *lastTime;
    /**表示或非表示活動指示器*/
    BOOL showHUDState;
}

@end
/**
 * 機能名　　　　：観光地
 * 機能概要　　　：観光のプレビュー
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation TouristViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //初期設定データ
    [self initData];
    
    //リスト作成
    touristTableView = [[BaseTableView alloc]init];
    touristTableView.frame = CGRectMake(0, 0, self.view.frame.size.width, MainVc_H);
    touristTableView.delegate = self;
    touristTableView.dataSource = self;
    touristTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:touristTableView];
    
    //プルダウン更新
    [touristTableView downRefresh];
    //プルダウン更新操作
    [touristTableView downRefreshData:^{
        //表示 HUD
        showHUDState = NO;
        //ラストの値を取る
        lastTime = [NetWorkManager getLastTimeForDBName:eventDBName];
        //請求データ
        [self getRequest];
    }];
    
    //請求データ
    [self getRequest];
}

- (void)initData{
    //表示HUD
    showHUDState = YES;
    
    //初期化
    eventDataArray = [NSMutableArray array];
    
    //データベースデータを読み取る
    NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:[NSString stringWithFormat:SQL_groupBy(eventDBName),eventDBName] DBName:eventDBName];
    if (array.count>0) {
        for (NSMutableDictionary *dic in array) {
            [eventDataArray addObject:[[TouristModel alloc] initWithDic:dic]];
        }
        //非表示 HUD
        showHUDState = NO;
    }
    
    //ラストの値を取る
    lastTime = [NetWorkManager getLastTimeForDBName:eventDBName];
}

#pragma mark - tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return eventDataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return (tableView.frame.size.height-XSpan(4))/3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *reuse = [NSString stringWithFormat:@"%ld%ld",indexPath.section,indexPath.row];
    TouristTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[TouristTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse frame:CGRectMake(0, 0, tableView.frame.size.width, [self tableView:tableView heightForRowAtIndexPath:indexPath]) model:[eventDataArray objectAtIndex:indexPath.row]];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    TouristAreaViewController *touristAreaVc = [[TouristAreaViewController alloc]init];
    touristAreaVc.eventModel = [eventDataArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:touristAreaVc animated:YES];
}

#pragma mark - request
- (void)getRequest{
    [NetWorkManager POST:listUrl paraments:[NSString stringWithFormat:@"_=%@&feature_key=leisure&last=%@",[NetWorkManager getTicket],lastTime] showHUD:showHUDState success:^(id responseObject) {
        //成功後に戻りのデータを求めます
        NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
        
        //データを取り出す
        NSMutableArray *modelDataArray = [dataDic valueForKey:@"data"];
        //追加データ
        for (int i = 0; i<modelDataArray.count; i++) {
            //請求パラメータを取り出して dic
            NSDictionary *dic = [modelDataArray objectAtIndex:i];
            //dic 转モデル
            TouristModel *dbModel = [[TouristModel alloc] initWithDic:dic];
            //データベースには、data_id値があるかどうか
            NSMutableArray *dbArray = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_selectDataId(eventDBName, dbModel.data_id) DBName:eventDBName];
            //cellHeight データには、カスタマイズするために、ここに追加する必要がありません
            NSMutableDictionary *dataDic = [NSMutableDictionary dictionary];
            dataDic = [NSMutableDictionary dictionaryWithDictionary:dic];
            [dataDic setValue:@"0" forKey:@"cellHeight"];
            [dataDic setValue:@"0" forKey:@"delete_date"];
            //もしarrayの量は0より大きくて
            if (dbArray.count==0) {
                //存在しないと添加の
                [[FMDBTool sharedManager]Queue_addDataToDataBase:dataDic DBName:eventDBName];
            }else{
                //存在が更新さ
                [[FMDBTool sharedManager]Queue_updateDataWithDic:dataDic DBName:eventDBName];
            }
            if (dbModel.delete_date>0){
                //現在のデータを削除する
                [[FMDBTool sharedManager]Queue_deleteDBAllData:dbModel.data_id DBName:eventDBName];
            }
        }
        
        //パケットデータを取り出す
        NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:[NSString stringWithFormat:SQL_groupBy(eventDBName),eventDBName] DBName:eventDBName];
        [eventDataArray removeAllObjects];
        for (NSDictionary *dic in array) {
            [eventDataArray addObject:[[TouristModel alloc] initWithDic:dic]];
        }
        
        //ラストの設定値
        [NetWorkManager setLastTimeForDBName:eventDBName];
        //更新リスト
        [touristTableView reloadData];
        //非表示活動指示器
        showHUDState = NO;
    } failure:^(NSError *error) {
    }];
}

//無インターネットまたは無データ時のフィボナッチリトレースメン
- (void)upRefreshData{
    [self getRequest];
}

@end
