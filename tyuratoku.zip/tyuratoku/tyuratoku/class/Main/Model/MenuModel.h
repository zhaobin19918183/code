//
//  MenuModel.h
//  Beautiful
//
//  Created by newland on 2017/9/4.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"

@interface MenuModel : BaseModel
@property(nonatomic,copy)NSString *menu_id;
@property(nonatomic,copy)NSString *menu_feature_key;
@property(nonatomic,copy)NSString *menu_title;
@property(nonatomic,copy)NSString *menu_small_icon_enable;
@property(nonatomic,copy)NSString *menu_small_icon_pushed;
@property(nonatomic,copy)NSString *menu_small_icon_selected;
@property(nonatomic,copy)NSString *menu_small_color_enable;
@property(nonatomic,copy)NSString *menu_small_color_pushed;
@property(nonatomic,copy)NSString *menu_small_color_selected;
@property(nonatomic,copy)NSString *menu_large_icon_enable;
@property(nonatomic,copy)NSString *menu_large_icon_pushed;
@property(nonatomic,copy)NSString *menu_large_icon_selected;
@property(nonatomic,copy)NSString *menu_large_color_enable;
@property(nonatomic,copy)NSString *menu_large_color_pushed;
@property(nonatomic,copy)NSString *menu_large_color_selected;
@property(nonatomic,copy)NSString *status;
@end
