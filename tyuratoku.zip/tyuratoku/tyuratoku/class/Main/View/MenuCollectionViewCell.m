//
//  MenuCollectionViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MenuCollectionViewCell.h"

@implementation MenuCollectionViewCell{
    BaseImageView *imageView;//画像
    BaseLabel *menuLabel;//メニュー
}

//初期化セル
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        [self createSubviews];
    }
    return self;
}

//創建ui
- (void)createSubviews{
    //画像
    imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(XSpan(10), (self.contentView.frame.size.height-YSpan(30))/2, XSpan(30), YSpan(30));
    [self.contentView addSubview:imageView];
    
    //メニュー
    menuLabel = [[BaseLabel alloc]init];
    menuLabel.frame = CGRectMake(CGRectGetMaxX(imageView.frame)+XSpan(10), YSpan(5), self.contentView.frame.size.width-CGRectGetMaxX(imageView.frame)-XSpan(20), self.contentView.frame.size.height-YSpan(10));
    [menuLabel setTextFont:13.5 textColor:BaseLabelWhite];
    [self.contentView addSubview:menuLabel];
}

//画像得る
- (BaseImageView *)getImageView{
    return imageView;
}

//メニューオプション名
- (BaseLabel *)getmenuLabel{
    return menuLabel;
}

//画像と文字の色を設定して
- (void)setImageView:(NSString *)imageName color:(UIColor *)color{
    imageView.image = [UIImage imageNamed:imageName];
    menuLabel.textColor = color;
}

@end
