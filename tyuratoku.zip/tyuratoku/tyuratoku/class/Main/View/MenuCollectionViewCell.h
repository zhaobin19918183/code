//
//  MenuCollectionViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#define menuLabelHeight YSpan(30) 

@interface MenuCollectionViewCell : UICollectionViewCell

/**
 初期化セル

 @param frame フレーム
 @return セル
 */
- (instancetype)initWithFrame:(CGRect)frame;

/**
 画像得る

 @return BaseImageView
 */
- (BaseImageView *)getImageView;

/**
 メニューオプション名

 @return BaseLabel
 */
- (BaseLabel *)getmenuLabel;

/**
 画像と文字の色を設定して

 @param imageName 画像
 @param color 文字の色
 */
- (void)setImageView:(NSString *)imageName color:(UIColor *)color;

@end
