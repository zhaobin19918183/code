//
//  HomeCollectionCell.h
//  Beautiful
//
//  Created by newland on 2017/7/20.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeCollectionCell : UICollectionViewCell

//画像
@property(nonatomic,strong)UIImageView *imgView;
//タイトル
@property(nonatomic,strong)BaseLabel *titleLabel;

@end
