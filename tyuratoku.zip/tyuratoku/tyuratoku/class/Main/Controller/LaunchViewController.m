//
//  LaunchViewController.m
//  Beautiful
//
//  Created by newland on 2017/8/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "LaunchViewController.h"
#import "AppDelegate.h"

@interface LaunchViewController (){
    NSUserDefaults *info;//ローカルメモリー
    NSArray *Coupons;
    NSMutableArray *setDataArr;
    NSMutableArray *ssbpDicArray;
    NSMutableArray *idArray;
    NSMutableArray * valueArray;
    NSMutableArray *idDetailArray ;
    NSMutableArray *detailArray;
}

@end
/**
 * 機能名　　　　：スタートページ
 * 機能概要　　　：app起動時のデータをロード
 * 作成者    　 ：郭詠明　2017/08/18
 ***********************************************************************
 ***********************************************************************
 */
@implementation LaunchViewController
//二級のメニューは引き出しのメニューを表示しない
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillDisappear:animated];
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.mmdVc setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeNone];
    [app.mmdVc setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeNone];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
     [[SSBPSdkIF sharedInstance] applicationNewActive];
    self.navigationController.navigationBarHidden = YES;
    info = [NSUserDefaults standardUserDefaults];
    
    [SSBPSdkIF sharedInstance].delegateIF = self;
    [[SSBPSdkIF sharedInstance] getAttributes];
    [[SSBPSdkIF sharedInstance] getUtilityContents];

 
    setDataArr       =[[NSMutableArray alloc]init];
    detailArray    =[[NSMutableArray alloc]init];
    idDetailArray  =[[NSMutableArray alloc]init];

    [self LaunchImageView];
    [self getRequest];
    
}
- (void)ssbpSdkIFDidFinishGetAttributes {
    dispatch_async(dispatch_get_main_queue(), ^{

        [self SSBPData];
        [[SSBPSdkIF sharedInstance] getDeviceInfo];
        
    });
}
-(void)SSBPData
{
    
    NSInteger qNum = [SSBPSdkIF sharedInstance].attrQuestions.count;
    for (int index = 0; index < qNum; index++)
    {
        SSBPQuestion* question = [[SSBPSdkIF sharedInstance].attrQuestions objectAtIndex:index];
        [setDataArr addObject:question.attrName];
        [self setDetailSSBP:question];
    }
    
  
}
- (void)setDetailSSBP:(SSBPQuestion*)question
{
    valueArray =[[NSMutableArray alloc]init];
    idArray =[[NSMutableArray alloc]init];
  
    ssbpDicArray   =[[NSMutableArray alloc]init];

    NSMutableDictionary* dic = [NSMutableDictionary dictionary];
    for (int i = 0; i < question.answers.count; i++) {
        SSBPAnswer* answer = [question.answers objectAtIndex:i];
        [dic setObject:answer.answerBody forKey:answer.answerId];
        [idArray addObject:answer.answerId];
        [ssbpDicArray addObject:answer.answerBody];
        [valueArray addObject:answer];
    }
    
    [idDetailArray addObject:idArray];
    [detailArray addObject:ssbpDicArray];
  
}

-(void)LaunchImageView{
    //起動図
    BaseImageView *imgView = [[BaseImageView alloc]initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H)];
    imgView.image = [UIImage imageNamed:@"App"];
    [self.view addSubview:imgView];
    
    //応用名
    BaseLabel *label = [[BaseLabel alloc]initWithFrame:CGRectMake(0, 0, Screen_W, 43)];
    label.center = imgView.center;
    [label setText:@"app_name" textAlignment:BaseLabelCenter];
    [label setTextFont:34 textColor:BaseLabelWhite];
    [label setFont:[UIFont fontWithName:@"Helvetica-Bold" size:34]];
    [self.view addSubview:label];
}

- (void)getRequest{
    
    [NetWorkManager POST:[NSString stringWithFormat:@"%@/api/service/ticket/get",serviceUrl] paraments:@"service_token=b04afccb19bedfc720e6462218b17cad" showHUD:NO success:^(id responseObject) {
        //成功後に戻りのデータを求めます
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
        //获取チケット
        [info setObject:dic[@"data"][@"ticket"] forKey:@"ticket"];
        
        //データ取得メニュー
        [NetWorkManager POST:mainPage paraments:[NSString stringWithFormat:@"_=%@",[NetWorkManager getTicket]] showHUD:NO success:^(id responseObject) {
            //成功後に戻りのデータを求めます
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
            
            //データ取得データ
            NSArray *dataArray = [NSArray array];
            dataArray = [dic valueForKey:@"data"];
            for (NSDictionary *dic in dataArray) {
                NSString *feature_key = [dic valueForKey:@"feature_key"];
                NSString *feature_name = [dic valueForKey:@"feature_name"];
                NSString *status = [dic valueForKey:@"status"];
                [[FMDBTool sharedManager]Queue_updateDataToDataBase:SQL_updateMenuName(menuDBName, feature_name, status,feature_key)];
            }
            
            //メニュータイプ
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            NSMutableArray *detail= [defaults objectForKey:@"detailArray"];
          
            if (detail.count == 0 )
            {
                [defaults setObject:idDetailArray forKey:@"idDetailArray"];
                [defaults setObject:detailArray forKey:@"detailArray"];
                [defaults setObject:setDataArr forKey:@"setDataArr"];
            }
          
            //ホームにリダイレクトする
            [[NSNotificationCenter defaultCenter]postNotificationName:@"home" object:nil];
            
        } failure:^(NSError *error) {
            //ホームにリダイレクトする
            NSDictionary *dic = [NSDictionary dictionary];
            dic = @{@"誤り":@"Menuフィールド"};
            [[NSNotificationCenter defaultCenter]postNotificationName:@"home" object:nil userInfo:dic];
        }];
        
    } failure:^(NSError *error) {
        //ホームにリダイレクトする
        NSDictionary *dic = [NSDictionary dictionary];
        dic = @{@"誤り":@"Ticketフィールド"};
        [[NSNotificationCenter defaultCenter]postNotificationName:@"home" object:nil userInfo:dic];
    }];
    
}

@end
