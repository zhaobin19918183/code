//
//  HomeViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/19.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "HomeViewController.h"
#import "MenuViewController.h"
#import "NoticeDetailViewController.h"
#import "HomeCollectionCell.h"
#import "AppDelegate.h"
#import "NoticeModel.h"
#import "NoticeCell.h"
#import <AudioToolbox/AudioServices.h>

//重用識別子
static NSString *reuse = @"reuse";
/**ここの設定が必要99、初めて入る際メニューも選ばれた設定なので、大きな数*/
static NSInteger homeSelectedButtonIndex = 99;

@interface HomeViewController (){
    /**頭部ビュー*/
    BaseView *topView;
    /**リスト*/
    BaseTableView *noticeTable;
    /**リストデータ*/
    NSMutableArray <NoticeModel*>*homeArray;
    /**底ビュー*/
    BaseView *bottomView;
    /**メニューリスト*/
    BaseCollectionView *menuCollectionView;
    
    /**選んだ後の画像*/
    NSMutableArray <NSString *>*chooseImageArray;
    /**画像を黙認する*/
    NSMutableArray <NSString *>*defaultImageArray;
    /**選択後の画像を選択*/
    NSMutableArray <NSString *>*selecteImageArray;
    /**フォントの色*/
    NSMutableArray <UIColor *>*defaultColorArray;
    /**選択後の書体色*/
    NSMutableArray <UIColor *>*chooseColorArray;
    /**選択後のフォントカラー*/
    NSMutableArray <UIColor *>*selecteColorArray;
    /**タイトル*/
    NSMutableArray <NSString *>*titleArray;
    /**メモリセル*/
    NSMutableArray <HomeCollectionCell*>* cellArray;
    /**メニュータイプ*/
    NSMutableArray *menuArray;
    /**サーバーラストパラメータ*/
    NSString *lastTime;
    /**表示或非表示活動指示器*/
    BOOL showHUDState;

    
    NSArray *Coupons;
    
    CBCentralManager *bluetoothManager;

}


@end
/**
 * 機能名　　　　：トップページ
 * 機能概要　　　：トップページ表示
 * 作成者    　 ：郭麗影　2017/07/19
 ***********************************************************************
 ***********************************************************************
 */
@implementation HomeViewController


- (void)viewWillAppear:(BOOL)animated{

    [[SSBPSdkIF sharedInstance] applicationNewActive];
   
    [[SSBPSdkIF sharedInstance] scanStart];
    [[SSBPSdkIF sharedInstance] setDetectBeacon:1];


    [self bluetoothManager];
    UIApplicationState state = [UIApplication sharedApplication].applicationState;
    BOOL result = (state == UIApplicationStateActive);
    if (result == YES)
    {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addnotice:) name:@"pocketnotice" object:nil];
    }
    

}

-(CBCentralManager *)bluetoothManager {
    if (bluetoothManager == nil) {
        bluetoothManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return bluetoothManager;
}
-(void)centralManagerDidUpdateState:(CBCentralManager* )central {
   
    switch (central.state) {
            
        case CBCentralManagerStatePoweredOff:{
           // [mainView makeToast:@"蓝牙没有开启，在设置中打开蓝牙"];
        }
            break;
        case CBCentralManagerStatePoweredOn:
            break;
        case CBCentralManagerStateResetting:
            break;
        case CBCentralManagerStateUnauthorized:
            break;
        case CBCentralManagerStateUnknown:
            break;
        case CBCentralManagerStateUnsupported:
         //   [mainView makeToast:@"当前设备不支持蓝牙"];
            break;
        default:
            break;
    }
}


-(void)addnotice:(NSNotification *)sender
{
    TSsbpContent  *content = sender.object;
    if (content.contentType!=nil) {
        UIApplicationState state = [UIApplication sharedApplication].applicationState;
        BOOL result = (state == UIApplicationStateActive);
        if (result == YES)
        {
            [self showAlert:content];
        }

    }
    
    
}
-(void)showAlert:(TSsbpContent *)content {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"MyPocketへ追加されました" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
        NSLog(@"点击OK");
        
    }]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"MyPocketへ移動" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        NSLog(@"MyPocketへ移動");
        [[NSNotificationCenter defaultCenter]postNotificationName:@"pocket" object:nil];
        
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:@"詳細を見る" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"詳細を見る");
        [[NSNotificationCenter defaultCenter]postNotificationName:@"pocket" object:content];
        
        
    }]];
    
    [self presentViewController:alertController animated:true completion:nil];
}

- (void)viewDidDisappear:(BOOL)animated {
 
}
- (void)ssbpSdkIFAddContent:(NSString*)contentId
{
    Coupons = [[NSArray alloc]init];
    Coupons = [[SSBPContentIF sharedInstance] getInnerContents:@"setting"];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[SSBPSdkIF sharedInstance] getUtilityContents];
    [[SSBPSdkIF sharedInstance] getAttributes];
    [SSBPSdkIF sharedInstance].delegateIF = self;
    [self.navigationItem setHidesBackButton:YES animated:NO];
    self.leftButton.hidden = YES;
    self.title = CountryLanguage(@"app_name");
    
    [self leftItemButton];
    [self.leftButton setImage:[UIImage imageNamed:@"menu"] forState:UIControlStateNormal];
    [self.leftButton addTarget:self action:@selector(mainLeftButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [self rightItemButton];
    [self.rightButton addTarget:self action:@selector(mainRightButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [self initData];//アレイの初期化データを追加する
    [self CreatBackImage];//背景画像作成
    [self CreatTopView];//topviewクリエイト
    [self CreatTableview];//tableviewクリエイト
    [self CreatBottomView];//bottomviewクリエイト
    
}

//ポップアップメニュー
- (void)mainLeftButton:(BaseButton *)button{
    AppDelegate *app =  (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.mmdVc toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

//ポケモンにジャンプする
- (void)mainRightButton:(BaseButton *)button{
    [[NSNotificationCenter defaultCenter]postNotificationName:@"pocket" object:nil];
}

//背景画像作成
- (void)CreatBackImage{

    UIImageView *backimg = [[UIImageView alloc]init];
    backimg.frame = CGRectMake(0, 0, Screen_W, Screen_H);
    [self.view addSubview:backimg];
    backimg.image = [UIImage imageNamed:@"bg"];
}

//topviewクリエイト
- (void)CreatTopView{

    topView = [[BaseView alloc]init];
    topView.frame = customCGRect(0, 0, 375, 37);
    topView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:topView];
    
    BaseLabel *titlelabel = [[BaseLabel alloc]init];
    titlelabel.frame = customCGRect(10, 0, 355, 36);
    [titlelabel setText:@"新着情報" textAlignment:BaseLabelCenter];
    [titlelabel setTextFont:18 textColor:BaseLabelBlack];
    titlelabel.textColor = customGreen;
    [topView addSubview:titlelabel];
    
    BaseView *lineView = [[BaseView alloc]init];
    lineView.frame = customCGRect(10, 29, 355, 1);
    lineView.backgroundColor = customGreen;
    [topView addSubview:lineView];
}

//tableviewクリエイト
- (void)CreatTableview{
    
    //リスト作成
    noticeTable = [[BaseTableView alloc]init];
    noticeTable.frame = CGRectMake(0, 0, self.view.frame.size.width, Screen_H - 64- YSpan(237));
    noticeTable.delegate = self;
    noticeTable.dataSource = self;
    noticeTable.backgroundColor = [UIColor clearColor];
    noticeTable.tableHeaderView = topView;
    noticeTable.scrollEnabled = NO;//滑りのない
    [self.view addSubview:noticeTable];
    noticeTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    //請求データ
    [self getRequest];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return homeArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return YSpan(110);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    NoticeCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[NoticeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor clearColor];
    cell.cellModel = homeArray[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NoticeDetailViewController *noticeDetail = [[NoticeDetailViewController alloc]init];
    noticeDetail.detailModel = [homeArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:noticeDetail animated:YES];
}

#pragma mark - リクエスト
- (void)getRequest{
    [NetWorkManager POST:[NSString stringWithFormat:@"%@/api/service/ticket/get",serviceUrl] paraments:@"service_token=b04afccb19bedfc720e6462218b17cad" showHUD:NO success:^(id responseObject) {
        //成功後に戻りのデータを求めます
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
        //获取チケット
        NSUserDefaults *info = [NSUserDefaults standardUserDefaults];
        [info setObject:dic[@"data"][@"ticket"] forKey:@"ticket"];
        
        //リストデータを請求する
        [NetWorkManager POST:listUrl paraments:[NSString stringWithFormat:@"_=%@&feature_key=notice&last=%@",[NetWorkManager getTicket],lastTime] showHUD:showHUDState success:^(id responseObject) {
            //成功後に戻りのデータを求めます
            NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
            
            //データを取り出す
            NSMutableArray *modelDataArray = [dataDic valueForKey:@"data"];
            
            //追加データ
            
            for (int i = 0; i<modelDataArray.count; i++) {
                //請求パラメータを取り出して dic
                NSDictionary *dic = [modelDataArray objectAtIndex:i];
                //dic 转モデル
                NoticeModel *dbModel = [[NoticeModel alloc] initWithDic:dic];
                //データベースには、data_id値があるかどうか
                NSMutableArray *dbArray = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_selectDataId(homeDBName, dbModel.data_id) DBName:homeDBName];
                //cellHeight データには、カスタマイズするために、ここに追加する必要がありません
                NSMutableDictionary *dataDic = [NSMutableDictionary dictionary];
                dataDic = [NSMutableDictionary dictionaryWithDictionary:dic];
                [dataDic setValue:@"0" forKey:@"cellHeight"];
                //もしarrayの量は0より大きくて
                if (dbArray.count==0) {
                    //存在しないと添加の
                    [[FMDBTool sharedManager]Queue_addDataToDataBase:dataDic DBName:homeDBName];
                }else {
                    //存在が更新さ
                    [[FMDBTool sharedManager]Queue_updateDataWithDic:dataDic DBName:homeDBName];
                }
                if ([dbModel.delete_date integerValue]>0){
                    //現在のデータを削除する
                    [[FMDBTool sharedManager]Queue_deleteDBAllData:dbModel.data_id DBName:homeDBName];
                }
            }
            //パケットデータを取り出す
            NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAndDate(homeDBName, lastTime) DBName:homeDBName];
            [homeArray removeAllObjects];
            for (NSDictionary *dic in array) {
                [homeArray addObject:[[NoticeModel alloc] initWithDic:dic]];
            }
            
            //更新リスト
            [noticeTable reloadData];
            //設置ラスト・フィールド
            [NetWorkManager setLastTimeForDBName:homeDBName];
            //非表示活動指示器
            showHUDState = NO;
        } failure:^(NSError *error) {
        }];
    } failure:^(NSError *error) {
    }];
    
}

//bottomviewクリエイト
- (void)CreatBottomView{

    bottomView = [[BaseView alloc]init];
    bottomView.frame = CGRectMake(0, Screen_H - 64- YSpan(237), Screen_W, YSpan(237));
    bottomView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:bottomView];
    
    BaseLabel *label = [[BaseLabel alloc]init];
    label.frame = customCGRect(10, 0, 355, 36);
    [label setText:@"コンテンツ" textAlignment:BaseLabelCenter];
    [label setTextFont:18 textColor:BaseLabelGreen];
    [bottomView addSubview:label];
    
    BaseView *lineView = [[BaseView alloc]init];
    lineView.frame = customCGRect(10, 29, 355, 1);
    lineView.backgroundColor = customGreen;
    [bottomView addSubview:lineView];
    
    [self CreatCollectionView];
}

- (void)CreatCollectionView{

    //レイアウト
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    //クリエイトcollectionview
    menuCollectionView = [[BaseCollectionView alloc] initWithFrame:CGRectMake(0, YSpan(30), Screen_W, YSpan(200)) collectionViewLayout:layout];
    menuCollectionView.backgroundColor = [UIColor clearColor];
    menuCollectionView.delegate = self;
    menuCollectionView.dataSource = self;
    [bottomView addSubview:menuCollectionView];
    
    //レジスタ
    [menuCollectionView registerClass:[HomeCollectionCell class] forCellWithReuseIdentifier:reuse];
}

//アレイの初期化データを追加する
- (void)initData{
    self.homeButton.hidden = YES;
    
    homeArray = [NSMutableArray array];
    //メニュータイプ
    menuArray = [NSMutableArray array];
    //タイトル
    titleArray = [NSMutableArray array];
    //画像を黙認する
    defaultImageArray = [NSMutableArray array];
    //選んだ後の画像
    chooseImageArray = [NSMutableArray array];
    //選択後の画像を選択
    selecteImageArray = [NSMutableArray array];
    //フォントの色
    defaultColorArray = [NSMutableArray array];
    //選択後の書体色
    chooseColorArray = [NSMutableArray array];
    //選択後のフォントカラー
    selecteColorArray = [NSMutableArray array];
    //メモリセル
    cellArray = [NSMutableArray array];
    
    menuArray = [NSMutableArray arrayWithArray:[NetWorkManager getDBMenuKeyArray]];
    [menuArray removeObject:@"home"];
    [menuArray removeObject:@"setting"];
    titleArray = [NSMutableArray arrayWithArray:[NetWorkManager getDBMenuShowTitleArray]];
    [titleArray removeObject:@"Home"];
    [titleArray removeObject:@"設定"];
    
    for (int i = 0; i<menuArray.count; i++) {
//        [titleArray addObject:[NetWorkManager getInfoStr:MenuTitle fromDic:[menuArray objectAtIndex:i]]];
        
        //デフォルト
        [defaultImageArray addObject:[NSString stringWithFormat:@"%@/%@",[NetWorkManager getZipPath],[NetWorkManager getInfoStr:MenuBigImageDefault fromDic:[menuArray objectAtIndex:i]]]];
        [defaultColorArray addObject:[NetWorkManager getHexColor:[NetWorkManager getInfoStr:MenuBigColorDefault fromDic:[menuArray objectAtIndex:i]]]];
       
        //を選んでください
        [chooseImageArray addObject:[NSString stringWithFormat:@"%@/%@",[NetWorkManager getZipPath],[NetWorkManager getInfoStr:MenuBigImageChoose fromDic:[menuArray objectAtIndex:i]]]];
        [chooseColorArray addObject:[NetWorkManager getHexColor:[NetWorkManager getInfoStr:MenuBigColorChoose fromDic:[menuArray objectAtIndex:i]]]];
        
        //さん関連商品
        [selecteImageArray addObject:[NSString stringWithFormat:@"%@/%@",[NetWorkManager getZipPath],[NetWorkManager getInfoStr:MenuBigImageSelected fromDic:[menuArray objectAtIndex:i]]]];
        [selecteColorArray addObject:[NetWorkManager getHexColor:[NetWorkManager getInfoStr:MenuBigColorSelected fromDic:[menuArray objectAtIndex:i]]]];
    }
    
    //表示HUD
    showHUDState = YES;
    
    //初期化
    homeArray = [NSMutableArray arrayWithCapacity:3];
    //第2回入り後にラスト付値
    lastTime = [NetWorkManager getLastTimeForDBName:homeDBName];
    //データベースデータを読み取る
    NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAndDate(homeDBName, lastTime) DBName:homeDBName];
    if (array.count>0) {
        for (NSMutableDictionary *dic in array) {
            [homeArray addObject:[[NoticeModel alloc] initWithDic:dic]];
        }
        //非表示 HUD
        showHUDState = NO;
    }
    
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return menuArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    HomeCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    //セル付値
    [cell.titleLabel setText:[titleArray objectAtIndex:indexPath.row]
               textAlignment:BaseLabelCenter];
    if (homeSelectedButtonIndex==indexPath.row) {
        cell.imgView.image = [UIImage imageNamed:[selecteImageArray objectAtIndex:indexPath.row]];
        cell.titleLabel.textColor = [selecteColorArray objectAtIndex:indexPath.row];
    }else{
        cell.imgView.image = [UIImage imageNamed:[defaultImageArray objectAtIndex:indexPath.row]];
        cell.titleLabel.textColor = [defaultColorArray objectAtIndex:indexPath.row];
    }
    
    cell.backgroundColor = [UIColor clearColor];;
    [cellArray addObject:cell];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(collectionView.frame.size.width/3, YSpan(100));
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(YSpan(0), XSpan(0), YSpan(0), XSpan(0));
}

//各項目間の間隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}

//異なる行の間の線の間隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    homeSelectedButtonIndex = indexPath.row;
    [MenuViewController setSelectedButtonIndex:homeSelectedButtonIndex];
    HomeCollectionCell *cell = [cellArray objectAtIndex:indexPath.row];
    cell.imgView.image = [UIImage imageNamed:[chooseImageArray objectAtIndex:indexPath.row]];
    cell.titleLabel.textColor = [chooseColorArray objectAtIndex:indexPath.row];
    [[NSNotificationCenter defaultCenter] postNotificationName:[menuArray objectAtIndex:indexPath.row] object:nil];
}

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    HomeCollectionCell *cell = [cellArray objectAtIndex:indexPath.row];
    cell.imgView.image = [UIImage imageNamed:[defaultImageArray objectAtIndex:indexPath.row]];
    cell.titleLabel.textColor = [defaultColorArray objectAtIndex:indexPath.row];
}


- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

//- (void)collectionView:(UICollectionView *)collectionView didHighlightItemAtIndexPath:(NSIndexPath *)indexPath{
//    HomeCollectionCell *cell = [cellArray objectAtIndex:indexPath.row];
//    cell.imgView.image = [UIImage imageNamed:[selecteImageArray objectAtIndex:indexPath.row]];
//    cell.titleLabel.textColor = [selecteColorArray objectAtIndex:indexPath.row];
//}

+ (void)setHomeSelectedButtonIndex:(NSInteger)index{
    homeSelectedButtonIndex = index-1;
}

- (void)myPocketButton{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark SSBPSdkIFDelegate override

//- (void)ssbpScannerChangeBeacon:(SSBPRegionInfo*)info {
////    [self setInfo];
//}
//
//- (void)ssbpSdkIFAddContent:(NSString*)contentId {
//    dispatch_async(dispatch_get_main_queue(), ^{
//        TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:contentId];
//        if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"navi"]) {
//        } else if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"coupon"] || [[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"info"]) {
//
//        }
//    });
//}


@end
