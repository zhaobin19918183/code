//
//  HomeViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/19.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"
#import "MenuCollectionViewCell.h"
#import <CoreBluetooth/CoreBluetooth.h>

@interface HomeViewController : BaseViewController<UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource,SSBPSdkIFDelegate,CBCentralManagerDelegate>

+ (void)setHomeSelectedButtonIndex:(NSInteger)index;

@end
