//
//  MainViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MainViewController.h"
#import "NinaPagerView.h"
#import "PhotoViewController.h"
#import "MyPocketViewController.h"
#import "NoticeViewController.h"
#import "TouristViewController.h"
#import "ShopViewController.h"
#import "AnimationViewController.h"
#import "MenuViewController.h"
#import "AppDelegate.h"

@interface MainViewController ()

@end
/**
 * 機能名　　　　：ホームページ面
 * 機能概要　　　：選択メニュー
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = CountryLanguage(@"app_name");
    
    UIApplicationState state = [UIApplication sharedApplication].applicationState;
    BOOL result = (state == UIApplicationStateActive);
    if (result == YES)
    {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addnotice:) name:@"pocketnotice" object:nil];
    }
    [self leftItemButton];
    [self.leftButton setImage:[UIImage imageNamed:@"menu"] forState:UIControlStateNormal];
    [self.leftButton addTarget:self action:@selector(mainLeftButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [self rightItemButton];
    
    //標題
    NSMutableArray *titleArray = [NSMutableArray array];
    titleArray = [NSMutableArray arrayWithArray:[NetWorkManager getDBMenuShowTitleArray]];
    [titleArray removeObject:@"Home"];
    [titleArray removeObject:@"設定"];
    
    //コントローラ
    NSMutableArray *vcsArray = [NSMutableArray array];
    //メニュータイプ
    NSMutableArray *modelArray = [NSMutableArray arrayWithArray:[NetWorkManager getDBMenuKeyArray]];
    [modelArray removeObject:@"home"];
    [modelArray removeObject:@"setting"];
    for (int i = 0; i<modelArray.count; i++) {
        NSString *menuName = [NetWorkManager getInfoStr:MenuKey fromDic:[modelArray objectAtIndex:i]];
        if ([menuName isEqualToString:@"notice"]){
            [vcsArray addObject:[[NoticeViewController alloc]init]];
        }else if ([menuName isEqualToString:@"leisure"]){
            [vcsArray addObject:[[TouristViewController alloc]init]];
        }else if ([menuName isEqualToString:@"photo"]) {
            [vcsArray addObject:[[PhotoViewController alloc]init]];
        }else if ([menuName isEqualToString:@"movie"]){
            [vcsArray addObject:[[AnimationViewController alloc]init]];
        }else if ([menuName isEqualToString:@"pocket"]){
            [vcsArray addObject:[[MyPocketViewController alloc]init]];
        }else if ([menuName isEqualToString:@"shop"]){
            [vcsArray addObject:[[ShopViewController alloc]init]];
        }
    }

    //スクロールメニュー
    self.ninaPagerView = [[NinaPagerView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H) WithTitles:titleArray WithVCs:vcsArray];
    self.ninaPagerView.delegate = self;
    self.ninaPagerView.underLineHidden = YES;
    self.ninaPagerView.nina_navigationBarHidden = NO;
    self.ninaPagerView.nina_autoBottomLineEnable = YES;
    self.ninaPagerView.ninaDefaultPage = self.pageindex;
    self.ninaPagerView.titleFont = XSpan(12);
    self.ninaPagerView.selectTitleColor = customGreen;
    self.ninaPagerView.underlineColor = customGreen;
    [self.view addSubview:self.ninaPagerView];
}
-(void)addnotice:(NSNotification *)sender
{
    TSsbpContent  *content = sender.object;
    if (content.contentType!=nil)
    {
        UIApplicationState state = [UIApplication sharedApplication].applicationState;
        BOOL result = (state == UIApplicationStateActive);
        if (result == YES)
        {
            [self showAlert:content];
        }
    
    }
  
 
}
-(void)showAlert:(TSsbpContent *)content {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"MyPocketへ追加されました" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
        NSLog(@"点击OK");
        
    }]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"MyPocketへ移動" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
      
        NSLog(@"MyPocketへ移動");
        [[NSNotificationCenter defaultCenter]postNotificationName:@"pocket" object:nil];
        
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:@"詳細を見る" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
      NSLog(@"詳細を見る");
          [[NSNotificationCenter defaultCenter]postNotificationName:@"pocket" object:content];

        
    }]];
    
    [self presentViewController:alertController animated:true completion:nil];
}
//ポップアップメニュー
- (void)mainLeftButton:(BaseButton *)button{
    AppDelegate *app =  (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.mmdVc toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

//釈放メモリ
- (BOOL)deallocVCsIfUnnecessary{
    return YES;
}

@end
