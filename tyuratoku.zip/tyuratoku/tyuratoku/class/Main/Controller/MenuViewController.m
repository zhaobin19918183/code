//
//  MenuViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "MenuViewController.h"
#import "HomeViewController.h"

static NSString *reuse = @"reuse";
static CGFloat itemHeight = 0;
static CGFloat itemWidth = 0;
/**ここの設定が必要99、初めて入る際メニューも選ばれた設定なので、大きな数*/
static NSInteger selectedButtonIndex = 99;

@interface MenuViewController (){
    /**リスト*/
    BaseCollectionView *menuCollectionView;
    /**選んだ後の画像*/
    NSMutableArray <NSString *>*chooseImageArray;
    /**画像を黙認する*/
    NSMutableArray <NSString *>*defaultImageArray;
    /**選択後の画像を選択*/
    NSMutableArray <NSString *>*selecteImageArray;
    /**フォントの色*/
    NSMutableArray <UIColor *>*defaultColorArray;
    /**選択後の書体色*/
    NSMutableArray <UIColor *>*chooseColorArray;
    /**選択後のフォントカラー*/
    NSMutableArray <UIColor *>*selecteColorArray;
    /**タイトル*/
    NSMutableArray <NSString *>*titleArray;
    /**メモリセル*/
    NSMutableArray <MenuCollectionViewCell*>* cellArray;
    /**メニュータイプ*/
    NSMutableArray *modelArray;
}

@end
/**
 * 機能名　　　　：メニュー
 * 機能概要　　　：高速選択指定機能
 * 作成者    　 ：郭詠明　2017/07/14
 ***********************************************************************
 ***********************************************************************
 */
@implementation MenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = customGreen;
    //初期化
    [self initData];
    //隠しボタンを隠して
    [self.navigationItem setHidesBackButton:YES animated:NO];
    
    //layout
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    //リスト作成
    menuCollectionView = [[BaseCollectionView alloc] initWithFrame:CGRectMake(0, 0, XSpan(150), self.view.frame.size.height) collectionViewLayout:layout];
    menuCollectionView.backgroundColor = [UIColor clearColor];
    menuCollectionView.delegate = self;
    menuCollectionView.dataSource = self;
    [self.view addSubview:menuCollectionView];
    
    //重用識別子
    [menuCollectionView registerClass:[MenuCollectionViewCell class] forCellWithReuseIdentifier:reuse];
    [menuCollectionView registerClass:[UICollectionViewCell class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerId"];
}

- (void)initData{
    //メニュータイプ
    modelArray = [NSMutableArray array];
    //タイトル
    titleArray = [NSMutableArray array];
    //画像を黙認する
    defaultImageArray = [NSMutableArray array];
    //選んだ後の画像
    chooseImageArray = [NSMutableArray array];
    //選択後の画像を選択
    selecteImageArray = [NSMutableArray array];
    //フォントの色
    defaultColorArray = [NSMutableArray array];
    //選択後の書体色
    chooseColorArray = [NSMutableArray array];
    //選択後のフォントカラー
    selecteColorArray = [NSMutableArray array];
    //メモリセル
    cellArray = [NSMutableArray array];
    
    [modelArray addObjectsFromArray:[NetWorkManager getDBMenuKeyArray]];
    titleArray = [NSMutableArray arrayWithArray:[NetWorkManager getDBMenuShowTitleArray]];
    
    for (int i = 0; i<modelArray.count; i++) {
//        [titleArray addObject:[NetWorkManager getInfoStr:MenuTitle fromDic:[modelArray objectAtIndex:i]]];
        //default
        [defaultImageArray addObject:[NSString stringWithFormat:@"%@/%@",[NetWorkManager getZipPath],[NetWorkManager getInfoStr:MenuSmallImageDefault fromDic:[modelArray objectAtIndex:i]]]];
        [defaultColorArray addObject:[NetWorkManager getHexColor:[NetWorkManager getInfoStr:MenuSmallColorDefault fromDic:[modelArray objectAtIndex:i]]]];
        
        //choose
        [chooseImageArray addObject:[NSString stringWithFormat:@"%@/%@",[NetWorkManager getZipPath],[NetWorkManager getInfoStr:MenuSmallImageChoose fromDic:[modelArray objectAtIndex:i]]]];
        [chooseColorArray addObject:[NetWorkManager getHexColor:[NetWorkManager getInfoStr:MenuSmallColorChoose fromDic:[modelArray objectAtIndex:i]]]];
        
        //selecte
        [selecteImageArray addObject:[NSString stringWithFormat:@"%@/%@",[NetWorkManager getZipPath],[NetWorkManager getInfoStr:MenuSmallImageSelected fromDic:[modelArray objectAtIndex:i]]]];
        [selecteColorArray addObject:[NetWorkManager getHexColor:[NetWorkManager getInfoStr:MenuSmallColorSelected fromDic:[modelArray objectAtIndex:i]]]];
    }
    
}

#pragma mark - collectionView
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return modelArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    MenuCollectionViewCell *cell = [[MenuCollectionViewCell alloc]initWithFrame:CGRectMake(0, 0,itemWidth, itemHeight)];
    cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    //セル付値
    if (selectedButtonIndex==indexPath.row) {
        [cell setImageView:[selecteImageArray objectAtIndex:indexPath.row]
                     color:[selecteColorArray objectAtIndex:indexPath.row]];
    }else{
        [cell setImageView:[defaultImageArray objectAtIndex:indexPath.row]
                     color:[defaultColorArray objectAtIndex:indexPath.row]];
    }
    [[cell getmenuLabel] setText:[titleArray objectAtIndex:indexPath.row]
                   textAlignment:BaseLabelLeft];
    
    [cellArray addObject:cell];
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    itemHeight = collectionView.frame.size.height/13;
    itemWidth = collectionView.frame.size.width;
    return CGSizeMake(itemWidth, itemHeight);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(YSpan(0), XSpan(0), YSpan(0), XSpan(0));
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //ページジャンプ
//    MenuCollectionViewCell *cell = [cellArray objectAtIndex:indexPath.row];
//    [cell getImageView].image = [UIImage imageNamed:[chooseImageArray objectAtIndex:indexPath.row]];
//    [cell getmenuLabel].textColor = [chooseColorArray objectAtIndex:indexPath.row];
    selectedButtonIndex = indexPath.row;
    if (cellArray.count>indexPath.row&&indexPath.row>0) {
        [HomeViewController setHomeSelectedButtonIndex:selectedButtonIndex];
    }
    MenuCollectionViewCell *cell = [cellArray objectAtIndex:indexPath.row];
    [cell setImageView:[selecteImageArray objectAtIndex:indexPath.row]
                 color:[selecteColorArray objectAtIndex:indexPath.row]];
    [[NSNotificationCenter defaultCenter]postNotificationName:[modelArray objectAtIndex:indexPath.row] object:nil];
}

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath{
    MenuCollectionViewCell *cell = [cellArray objectAtIndex:indexPath.row];
    [cell setImageView:[defaultImageArray objectAtIndex:indexPath.row]
                 color:[defaultColorArray objectAtIndex:indexPath.row]];
}

- (void)collectionView:(UICollectionView *)collectionView didHighlightItemAtIndexPath:(NSIndexPath *)indexPath{
    MenuCollectionViewCell *cell = [cellArray objectAtIndex:indexPath.row];
    [cell setImageView:[selecteImageArray objectAtIndex:indexPath.row]
                 color:[selecteColorArray objectAtIndex:indexPath.row]];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return CGSizeMake(collectionView.frame.size.width, YSpan(20));
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    if([kind isEqualToString:UICollectionElementKindSectionHeader]){
        UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"headerId" forIndexPath:indexPath];
        if(headerView == nil){
            headerView = [[UICollectionReusableView alloc] init];
        }
        headerView.backgroundColor = [UIColor clearColor];
        
        return headerView;
    }
    return nil;
}

+ (void)setSelectedButtonIndex:(NSInteger)index{
    selectedButtonIndex = index+1;
}

@end
