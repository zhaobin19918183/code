//
//  AnimationDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationDetailViewController.h"
#import "AnimationDetailCell.h"

@interface AnimationDetailViewController (){
    /**リスト*/
    BaseTableView *animationTableView;
    /**分かち合う時の画像アドレス*/
    NSString *shareImageStr;
}

@end
/**
 * 機能名　　　　：アニメ
 * 機能概要　　　：動画リストを選択すると表示される画面  DBに取得保持済みの動画情報を取得して詳細表示。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation AnimationDetailViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = CountryLanguage(self.detailModel.title);
    [self CreatTableview];
}

- (void)CreatTableview{
    //creat tableview
    animationTableView = [[BaseTableView alloc]init];
    
    if ([self.detailModel.rel_url_ios isEqualToString:@""]&&[self.detailModel.rel_url isEqualToString:@""]) {
        animationTableView.frame = CGRectMake(0, 0,Screen_W , Screen_H -64);
    }else{
        animationTableView.frame = CGRectMake(0, 0,Screen_W , Screen_H - YSpan(130)-64);
    }
    
    animationTableView.delegate = self;
    animationTableView.dataSource = self;
    [self.view addSubview:animationTableView];
    animationTableView.separatorStyle = UITableViewCellStyleDefault;
    //底面のボタンを作成する
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
    [dic setValue:self.detailModel.rel_url forKey:@"rel_url"];
    [dic setValue:self.detailModel.rel_url_label forKey:@"rel_url_label"];
    [self CreatBottomViewSubviews:dic];
}

#pragma mark - tableView
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.detailModel.cellHeight == 0) {
        return tableView.frame.size.height;
    }else{
        return self.detailModel.cellHeight;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    AnimationDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell == nil) {
        cell = [[AnimationDetailCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    cell.detailCellModel = self.detailModel;
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (void)shareButton{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:shareImageStr forKey:@"image"];
    [dic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
    [dic setValue:self.detailModel.title forKey:@"title"];
    [NetWorkManager setShareInfoDic:dic];
}

#pragma mark - delegate
- (void)getImage:(NSString *)image{
    shareImageStr = image;
}

//下のボタンをクリックしてイベントを見る
- (void)BottomViewButtonClick:(UIButton *)button dic:(NSDictionary *)dic{
    
    switch (button.tag) {
        case 0:
            NSLog(@"0");
            break;
        case 1:
            NSLog(@"1");
            break;
        case 2:
            NSLog(@"2");
            break;
        case 3:
        {
            //rel_url_iosが空の場合、オープンrel_url
            if ([self.detailModel.rel_url_ios isKindOfClass:[NSNull class]]||[self.detailModel.rel_url_ios isEqualToString:@""]) {
                
                NSURL *cleanURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@", self.detailModel.rel_url]];
                [[UIApplication sharedApplication] openURL:cleanURL];
                
            }else{
                
                NSURL *cleanURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@", [self.detailModel.rel_url_ios stringByRemovingPercentEncoding]]];
                [[UIApplication sharedApplication] openURL:cleanURL];
                NSMutableDictionary *dic = [NSMutableDictionary dictionary];
                [dic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
                [NetWorkManager OpenUrl:[self.detailModel.rel_url_ios stringByRemovingPercentEncoding] download:self.detailModel.rel_url dic:dic];
            }
            
        }
            break;
        default:
            break;
    }
}

@end
