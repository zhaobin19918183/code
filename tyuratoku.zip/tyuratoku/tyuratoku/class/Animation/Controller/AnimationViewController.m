//
//  AnimationViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationViewController.h"
#import "AnimationModel.h"
#import "AnimationTableViewCell.h"
#import "AnimationDetailViewController.h"

@interface AnimationViewController (){
    /**リスト*/
    BaseTableView *animationTableView;
    /**リストデータ*/
    NSMutableArray <AnimationModel*>*animationArray;
    /**サーバーラストパラメータ*/
    NSString *lastTime;
    /**表示或非表示活動指示器*/
    BOOL showHUDState;
}

@end
/**
 * 機能名　　　　：アニメ
 * 機能概要　　　：動画メニューを選択すると表示される画面  ヘッダー下にサブメニューが有り、Home及び設定以外のコン
 テンツへ遷移可能  CMSから動画情報を取得してリスト表示。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation AnimationViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    [self layoutView];
    [self initData];
    [self getRequest];
}

- (void)initData{
    //表示HUD
    showHUDState = YES;
    
    //初期化
    animationArray = [NSMutableArray array];
    //ラストの値を取る
    lastTime = [NetWorkManager getLastTimeForDBName:animationDBName];
    
    //データベースデータを読み取る
    NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAndDate(animationDBName, lastTime) DBName:animationDBName];
    if (array.count>0) {
        for (NSMutableDictionary *dic in array) {
            [animationArray addObject:[[AnimationModel alloc] initWithDic:dic]];
        }
        //非表示 HUD
        showHUDState = NO;
    }
}
//サーバーにデータを申請する
- (void)getRequest{
    [NetWorkManager POST:listUrl paraments:[NSString stringWithFormat:@"_=%@&feature_key=movie&last=%@",[NetWorkManager getTicket],lastTime] showHUD:showHUDState success:^(id responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
        //        NSLog(@"dict === %@",dict);
        
        //データを取り出す
        NSMutableArray *modelDataArray = [dict valueForKey:@"data"];
        
        //追加データ
        for (int i = 0; i<modelDataArray.count; i++) {
            //請求パラメータを取り出して dic
            NSMutableDictionary *dic = [modelDataArray objectAtIndex:i];
            //dic 转モデル
            AnimationModel *dbModel = [[AnimationModel alloc] initWithDic:dic];
            //データベースには、data_id値があるかどうか
            NSMutableArray *dbArray = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_selectDataId(animationDBName, dbModel.data_id) DBName:animationDBName];
            NSMutableDictionary *dataDictionary = [NSMutableDictionary dictionary];
            dataDictionary = [NSMutableDictionary dictionaryWithDictionary:dic];
            [dataDictionary setValue:@"0" forKey:@"cellHeight"];
            //もしarrayの量は0より大きくて
            if (dbArray.count==0) {
                //存在しないと添加の
                [[FMDBTool sharedManager]Queue_addDataToDataBase:dataDictionary DBName:animationDBName];
            }else{
                //存在が更新さ
                [[FMDBTool sharedManager]Queue_updateDataWithDic:dataDictionary DBName:animationDBName];
            }
            if ([dbModel.delete_date integerValue]>0){
                //現在のデータを削除する
                [[FMDBTool sharedManager]Queue_deleteDBAllData:dbModel.data_id DBName:animationDBName];
            }
        }
        
        //パケットデータを取り出す
        NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAndDate(animationDBName, lastTime) DBName:animationDBName];
        [animationArray removeAllObjects];
        for (NSDictionary *dic in array) {
            [animationArray addObject:[[AnimationModel alloc] initWithDic:dic]];
        }
        
        //ラストの設定値
        [NetWorkManager setLastTimeForDBName:animationDBName];
        //更新リスト
        [animationTableView reloadData];
        //非表示活動指示器
        showHUDState = NO;
        //出入りリストパラメーター、表示エラーが表示されます
//        [self upRefreshData:animationArray];
    } failure:^(NSError *error) {
    }];
    
}

- (void)layoutView{
    //creat tableview
    animationTableView = [[BaseTableView alloc]init];
    animationTableView.frame = CGRectMake(0, 0, self.view.frame.size.width, MainVc_H);
    animationTableView.delegate = self;
    animationTableView.dataSource = self;
    animationTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [animationTableView downRefresh];
    [self.view addSubview:animationTableView];
}

#pragma mark - tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return animationArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return YSpan(110);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    AnimationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell == nil){
        cell = [[AnimationTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    [cell setAnimationModel:[animationArray objectAtIndex:indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    AnimationDetailViewController *detail = [[AnimationDetailViewController alloc]init];
    detail.index = indexPath;
    detail.detailModel = [animationArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:detail animated:YES];
}

@end
