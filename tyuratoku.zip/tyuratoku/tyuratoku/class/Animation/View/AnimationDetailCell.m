//
//  AnimationDetailCell.m
//  Beautiful
//
//  Created by newland on 2017/8/8.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationDetailCell.h"

@implementation AnimationDetailCell


-(void)setDetailCellModel:(AnimationModel *)detailCellModel{

    _detailCellModel = detailCellModel;
    [self setSubviewFrame:(NoticeModel *)detailCellModel];
}

-(void)setModel:(AnimationModel *)model{
    
    _detailCellModel = model;
    
    [self setSubviewFrame:(NoticeModel *)model];

}

- (void)showVideoPlayer
{
    self.imgView.hidden =YES;
    UIView *playerView = [[UIView alloc] init];
    playerView.frame =CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, YSpan(200));
    [self.contentView addSubview:playerView];
    
    self.videoPlayer = [SRVideoPlayer playerWithVideoURL:[self urlstring:_detailCellModel.movie_url] playerView:playerView playerSuperView:playerView.superview];
    self.videoPlayer.playerEndAction = SRVideoPlayerEndActionStop;
    [self.videoPlayer play];
}

- (NSURL *)urlstring:(NSString *)movieUrl{
    if (movieUrl.length ==0) {
    }
    
    NSURL *fileURL = [NSURL URLWithString:movieUrl];
    return fileURL;
}



@end
