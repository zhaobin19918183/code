//
//  AnimationTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationTableViewCell.h"

@implementation AnimationTableViewCell
/**
 * 機能名　　　　：アニメ
 * 機能概要　　　：美ら得アプリのログイン画面です。
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.photoImagView = [[BaseImageView alloc]init];
        
        [self.contentView addSubview:self.photoImagView];
        
        self.titleLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.titleLabel];
        
        self.dateLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.dateLabel];
        
        self.authorLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.authorLabel];
        [self creatSubView];
    }
    return self;
}

- (void)creatSubView{
    
    [super layoutSubviews];
    
    self.photoImagView.frame = customCGRect(10, 5, 130, 100);
    self.photoImagView.contentMode = UIViewContentModeScaleAspectFit;
    self.photoImagView.backgroundColor = [UIColor whiteColor];
    
    self.titleLabel.frame = CGRectMake(CGRectGetMaxX(self.photoImagView.frame)+XSpan(5), 10*KHEIGHT, Screen_W - CGRectGetMaxX(self.photoImagView.frame)-XSpan(15), YSpan(20));
    [self.titleLabel setTextFont:14 textColor:BaseLabelBlack];
    
    self.authorLabel.frame = CGRectMake(CGRectGetMaxX(self.photoImagView.frame)+XSpan(5), CGRectGetMaxY(self.titleLabel.frame)- YSpan(5), XSpan(240), YSpan(40));
    self.authorLabel.numberOfLines = 2;
    [self.authorLabel setTextFont:14 textColor:BaseLabelBlack];
    
    self.dateLabel.frame = CGRectMake(CGRectGetMaxX(self.photoImagView.frame)+XSpan(5), CGRectGetMaxY(self.authorLabel.frame)+YSpan(30), XSpan(125), YSpan(20));
    [self.dateLabel setTextFont:10 textColor:BaseLabelBlack];
    
}

- (void)setAnimationModel:(AnimationModel *)model{

    [self.titleLabel setText:model.title textAlignment:BaseLabelLeft];
    
    [self.dateLabel setText:[NSString stringWithFormat:@"更新日:%@",[NetWorkManager currentDateStr:model.publish_date]] textAlignment:BaseLabelLeft];
    [self.dateLabel setTextFont:10 textColor:BaseLabelGray];
    [self.authorLabel setText:model.sub_title textAlignment:BaseLabelLeft];
    
    [self.photoImagView sd_setImageWithURL:serviceImageUrl(model.list_thumb_url) placeholderImage:[UIImage imageNamed:@"noImage"]];

}


@end
