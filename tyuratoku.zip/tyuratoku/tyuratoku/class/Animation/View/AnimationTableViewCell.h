//
//  AnimationTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AnimationModel.h"

@interface AnimationTableViewCell : UITableViewCell

/**写真*/
@property(nonatomic,strong)BaseImageView *photoImagView;
/**タイトル*/
@property(nonatomic,strong)BaseLabel *titleLabel;
/**日付*/
@property(nonatomic,strong)BaseLabel *dateLabel;
/**著者*/
@property(nonatomic,strong)BaseLabel *authorLabel;

/**
 入力モデル

 @param model モデル
 */
- (void)setAnimationModel:(AnimationModel *)model;

@end
