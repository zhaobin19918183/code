//
//  AnimationModel.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AnimationModel.h"

@implementation AnimationModel
+(AnimationModel *)animationDic :(NSMutableDictionary *)dic
{
    AnimationModel *model = [[AnimationModel alloc]initWithDic:dic];
    model.category_name   = [dic valueForKey:@"category_name"];
    model.list_thumb_url       = [dic valueForKey:@"list_thumb_url"];
    model.publish_date    = [NSString stringWithFormat:@"%@",[dic valueForKey:@"publish_date"]] ;
    model.title           = [dic valueForKey:@"title"];
    model.start_date      = [dic valueForKey:@"start_date"];
    model.end_date        = [dic valueForKey:@"end_date"];
    model.data_id         = [dic valueForKey:@"data_id"];
    model.sub_title       = [dic valueForKey:@"sub_title"];
    model.extra_text_1    = [dic valueForKey:@"extra_text_1"];
    model.extra_text_2    = [dic valueForKey:@"extra_text_2"];
    model.movie_url       = [dic valueForKey:@"movie_url"];
    model.movie_name      = [dic valueForKey:@"movie_name"];
    model.movie_thumb_url = [dic valueForKey:@"movie_thumb_url"];
    model.body            = [dic valueForKey:@"body"];
    model.image_url       = [dic valueForKey:@"image_url"];
    return model;
}
@end
