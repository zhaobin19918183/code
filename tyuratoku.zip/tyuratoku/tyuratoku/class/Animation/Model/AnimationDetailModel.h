//
//  AnimationDetailModel.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"
@interface AnimationDetailModel : BaseModel
/**モデル*/
@property(nonatomic,strong)NSString  * title;
@property(nonatomic,strong)NSString  * sub_title;
@property(nonatomic,strong)NSString  * extra_text_1;
@property(nonatomic,strong)NSString  * extra_text_2;
@property(nonatomic,strong)NSString  * image_thumb_url;
@property(nonatomic,strong)NSString  * movie_thumb_url;
@property(nonatomic,strong)NSString  * movie_name;
@property(nonatomic,strong)NSString  * movie_url;
@property(nonatomic,strong)NSString  * image_url;
@property(nonatomic,strong)NSString  * body;

@property float cellHeight;
+(AnimationDetailModel *)animationDic :(NSMutableDictionary *)dic;
@end
