//
//  SettingModel.h
//  Beautiful
//
//  Created by newland on 2017/8/16.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SettingModel : NSObject
/**モデル*/
@property(nonatomic,strong)NSString  * title;

+(SettingModel *)settingDic :(NSMutableDictionary *)dic;
@end
