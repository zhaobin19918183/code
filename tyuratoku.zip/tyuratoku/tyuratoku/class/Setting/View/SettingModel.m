//
//  SettingModel.m
//  Beautiful
//
//  Created by newland on 2017/8/16.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "SettingModel.h"

@implementation SettingModel
/**
 * 機能名　　　　：設定
 * 機能概要　　　：設定データ
 * 作成者    　 ：趙ビン　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
+(SettingModel *)settingDic :(NSMutableDictionary *)dic
{
    SettingModel *setting=[[SettingModel alloc]init];
    setting.title =[dic valueForKey:@"title"];
    return setting;
}
@end
