//
//  SettingTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/8/16.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SettingModel.h"
@interface SettingTableViewCell : UITableViewCell
/**
設定のタイトル
 
 @return BaseLabel
 */
@property(nonatomic,strong)BaseLabel  * titleLabel;

@property(nonatomic,strong)UISwitch *switchButton;
/**
 設定の選択ボタン
 
 @return BaseButton
 */
@property(nonatomic,strong)BaseButton  * selectButton;
-(void)settingModel:(SettingModel *)model indexPath:(NSIndexPath *)indexPath;
- (void)setDetailSSBPdata:(SSBPQuestion*)question;
- (void)setDetailSSBPDetail:(NSString *)name;
@end
