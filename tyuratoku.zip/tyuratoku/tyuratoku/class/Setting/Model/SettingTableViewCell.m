//
//  SettingTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/8/16.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "SettingTableViewCell.h"

@implementation SettingTableViewCell


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
//初期化セル
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {

        
        self.titleLabel = [[BaseLabel alloc]init];
        [self.contentView addSubview:self.titleLabel];
        
        self.selectButton = [[BaseButton alloc]init];
        [self.contentView addSubview:self.selectButton];
        
        self.switchButton =[[UISwitch alloc]init];
        self.switchButton.onTintColor=[UIColor cyanColor];
        [self.contentView addSubview:self.switchButton];
        
    
    }
    return self;
}
//創建ui
-(void)layoutSubviews{
    
    [super layoutSubviews];
    self.titleLabel.frame =customCGRect(20, 30, 200, 30);
    self.switchButton.frame =customCGRect(Screen_W - 80, 30, 30, 30);
    self.selectButton.frame = customCGRect(Screen_W - 60, 30, 30, 30);
    
    self.selectButton.clipsToBounds=YES;
    self.selectButton.layer.cornerRadius=15;
    [ self.selectButton.layer setMasksToBounds:YES];
    [ self.selectButton.layer setBorderWidth:1.0];   //フレーム幅設定

    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGColorRef colorref = CGColorCreate(colorSpace,(CGFloat[]){ 217/255.0, 217/255.0, 217/255.0, 1 });
    [ self.selectButton.layer setBorderColor:colorref];//フレームの色を設定する
 
   
}
//設定付値
-(void)settingModel:(SettingModel *)model indexPath:(NSIndexPath *)indexPath
{
    self.titleLabel.text = model.title;
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    if (indexPath.row ==0) {
        self.titleLabel.text =[NSString stringWithFormat:@"Ver.%@.0",app_Version];
    }
    self.switchButton.hidden = YES;
 
}
//設定付値
- (void)setDetailSSBPdata:(NSString *)question
{
    self.switchButton.hidden= YES;
    self.titleLabel.text = question;


}
- (void)setDetailSSBPDetail:(NSString *)name
{
    self.switchButton.hidden= YES;
    self.titleLabel.text = name;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
