//
//  SetDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/8/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "SetDetailViewController.h"
#import "SettingTableViewCell.h"
#import "SetViewController.h"
@interface SetDetailViewController ()
{
    
    BaseTableView *settingDetaliTableView;
    NSMutableArray *dataArray;
    NSMutableArray *detailArray;
    NSMutableArray *ssbpDicArray;
    NSMutableArray *idArray;
    NSMutableArray *idDetailArray;
    NSMutableArray *valueArray;
    SSBPAnswer* answerView;
    NSArray *Coupons;
   
}
@end
/**
 * 機能名　　　　：設定詳しい
 * 機能概要　　　：SSBPSdkIFのgetUtilityContentsを実行すると、ssbpScannerHitUtilityContents  でコ              ンテンツが返却され取得できます。  contentActionがsettingとなっているコンテンツが必要なコンテンツとなります。
 * 作成者    　 ：趙ビン　2017/08/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation SetDetailViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
   
    [SSBPSdkIF sharedInstance].delegateIF = self;
    
    [[SSBPSdkIF sharedInstance] getAttributes];
  
    

   
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title  = CountryLanguage(@"app_name");
    detailArray =[[NSMutableArray alloc]init];
    idDetailArray =[[NSMutableArray alloc]init];
    dataArray       =[[NSMutableArray alloc]init];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    detailArray= [defaults objectForKey:@"detailArray"];
    idDetailArray= [defaults objectForKey:@"idDetailArray"];
    dataArray= [defaults objectForKey:@"setDataArr"];
 
    [self layoutView];
    // Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)layoutView
{
    //creat tableview
    settingDetaliTableView = [[BaseTableView alloc]init];
    settingDetaliTableView.frame = CGRectMake(0, 0, Screen_W, Screen_H);
    settingDetaliTableView.delegate = self;
    settingDetaliTableView.dataSource = self;
    
    [self.view addSubview:settingDetaliTableView];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80*KHEIGHT;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuse = @"reuse";
    SettingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil)
    {
        cell = [[SettingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectButton.hidden=YES;
    if (dataArray.count!=0)
    {
         [cell setDetailSSBPdata:[dataArray objectAtIndex:indexPath.row]];
    }
   
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
// で展開されたアプリ構成ファイルを元に以下の設定を反映
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

        SSBPViewController *ssbpView=[[SSBPViewController alloc]init];
    
        if (indexPath.row == dataArray.count -1)
        {
            ssbpView.allowSelect = 1;
        }
        ssbpView.index= [NSString stringWithFormat:@"%ld",(long)indexPath.row];
        ssbpView.ssbpArray = [detailArray objectAtIndex:indexPath.row];
        ssbpView.idArray   = [idDetailArray objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:ssbpView animated:YES];

}

#pragma mark SSBPSdkIFDelegate override

- (void)ssbpSdkIFDidFinishGetAttributes {
    dispatch_async(dispatch_get_main_queue(), ^{

        [[SSBPSdkIF sharedInstance] getDeviceInfo];
      
    });
}

- (void)ssbpSdkIFDidFinishGetDeviceInfo {

    dispatch_async(dispatch_get_main_queue(), ^{
        //update
        for (SSBPQuestion* question in [SSBPSdkIF sharedInstance].attrQuestions) {
            for (int i = 0; i < question.answers.count; i++) {
                SSBPAnswer* answer = [question.answers objectAtIndex:i];
                NSString* value = [[SSBPSdkIF sharedInstance].attrAnswers objectForKey:answer.answerId];
                NSLog(@"value ===== %@",value);

            }
        }
        
    });
}

- (void)ssbpSdkIFDidFinishUpdateDeviceInfo {
    if (self.navigationController.viewControllers.count <= 1) {
       // [self dismissViewControllerAnimated:true completion:nil];
    } else {
      //  [self.navigationController popViewControllerAnimated:true];
    }
}


@end
