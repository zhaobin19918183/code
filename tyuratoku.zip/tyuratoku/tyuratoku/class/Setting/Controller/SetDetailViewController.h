//
//  SetDetailViewController.h
//  Beautiful
//
//  Created by newland on 2017/8/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SSBPSdkIF.h"
#import "SSBPViewController.h"
@interface SetDetailViewController : BaseViewController <SSBPSdkIFDelegate,UITableViewDelegate,UITableViewDataSource>
/**モデル*/
@property(nonatomic,strong)BaseView  * nameView;
@property(nonatomic,strong)NSString  * titleString;
@end
