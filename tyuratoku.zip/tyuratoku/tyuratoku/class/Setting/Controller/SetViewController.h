//
//  SetViewController.h
//  Beautiful
//
//  Created by newland on 2017/8/28.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseViewController.h"

@interface SetViewController : BaseViewController
/**モデル*/
@property(nonatomic,strong)NSString  * titleString;
@property(nonatomic,strong)NSString  * contentString;

@end
