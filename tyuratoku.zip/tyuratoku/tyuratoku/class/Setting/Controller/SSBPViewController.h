//
//  SSBPViewController.h
//  Beautiful
//
//  Created by newland on 2017/8/21.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SSBPViewController : BaseViewController<UITableViewDelegate,UITableViewDataSource>
/**モデル*/
@property(nonatomic,strong)NSMutableArray  * ssbpArray;
@property(nonatomic,strong)NSMutableArray  *idArray;
@property(nonatomic,strong)NSMutableArray  *valueArray;
@property(nonatomic,strong)SSBPAnswer* answer;
@property(nonatomic,assign)NSInteger allowSelect;
@property(nonatomic,assign)NSString *index;
@end
