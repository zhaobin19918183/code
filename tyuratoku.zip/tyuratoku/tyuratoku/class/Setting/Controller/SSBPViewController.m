//
//  SSBPViewController.m
//  Beautiful
//
//  Created by newland on 2017/8/21.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "SSBPViewController.h"
#import "SettingTableViewCell.h"
#import "SetDetailViewController.h"
@interface SSBPViewController ()
{
    
    BaseTableView *settingDetaliTableView;
    NSInteger selectYes;
    NSInteger selectNo;
    BOOL isbool;
    
}
@end
/**
 * 機能名　　　　：設定詳しい
 * 機能概要　　　：SSBPSdkIFのgetUtilityContentsを実行すると、ssbpScannerHitUtilityContents  でコ              ンテンツが返却され取得できます。  contentActionがsettingとなっているコンテンツが必要なコンテンツとなります。
 * 作成者    　 ：趙ビン　2017/08/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation SSBPViewController

-(void)viewWillDisappear:(BOOL)animated
{
    [[SSBPSdkIF sharedInstance] updateDeviceInfo];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUserDefaults *defa = [NSUserDefaults standardUserDefaults];
    NSString *firstString = [defa objectForKey:@"first"];
    _valueArray = [[NSMutableArray alloc]init];
    if (firstString.length == 0)
    {
        isbool = YES;
        for (int i = 0; i < self.idArray.count; i++)
        {
            NSString* value = [[SSBPSdkIF sharedInstance].attrAnswers objectForKey:[self.idArray objectAtIndex:i]];
            [_valueArray addObject:value];
            
        }
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:_valueArray forKey:@"valueArray"];
        [defa setObject:@"first" forKey:@"first"];
    }
    else
    {
        self.valueArray = [defa objectForKey:self.index];
    }
    
    if (self.valueArray.count == 0 )
    {
        self.valueArray = [defa objectForKey:@"valueArray"];
    }
    
    self.title  = CountryLanguage(@"app_name");
   
    [self layoutView];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
//創建ui
-(void)layoutView
{
//詳細は詳細を設定する
    settingDetaliTableView = [[BaseTableView alloc]init];
    settingDetaliTableView.frame = CGRectMake(0, 0, Screen_W, Screen_H - 66);
    settingDetaliTableView.delegate = self;
    settingDetaliTableView.dataSource = self;
    
    if (_allowSelect == 1) {
        settingDetaliTableView.allowsMultipleSelection = YES;
        
    }
    settingDetaliTableView.tableHeaderView.hidden= NO;
    [self.view addSubview:settingDetaliTableView];
    
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat sectionHeaderHeight = 80*KHEIGHT;
    if(scrollView.contentOffset.y<=sectionHeaderHeight&&scrollView.contentOffset.y>=0) {
        scrollView.contentInset = UIEdgeInsetsMake(-scrollView.contentOffset.y, 0, 0,0);
    } else if (scrollView.contentOffset.y>=sectionHeaderHeight) {
        scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, 0, 0);
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (_allowSelect != 1)
    {
        return 80*KHEIGHT;
    }
    return 0;
    
}
//詳細は詳細を設定する
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    BaseView* headerView = [[BaseView alloc] initWithFrame:CGRectMake(0, 0, Screen_W , 80*KHEIGHT)];
    
    BaseButton *selectButton = [[BaseButton alloc]init];;
    BaseLabel *titleLabel = [[BaseLabel alloc]init];
    BaseLabel *lineLabel = [[BaseLabel alloc]init];
    lineLabel.frame =customCGRect(0, 80*KHEIGHT-1*KHEIGHT, Screen_W, 1*KHEIGHT);
    lineLabel.backgroundColor =[UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1];
    [headerView addSubview:lineLabel];
    titleLabel.frame =customCGRect(30, 30, 200, 30);
    titleLabel.text=@"--  選択してください  --";
    selectButton.frame = customCGRect(Screen_W - 60, 30, 30, 30);
    selectButton.clipsToBounds=YES;
    selectButton.layer.cornerRadius=15;
    [selectButton.layer setMasksToBounds:YES];
    [selectButton.layer setBorderWidth:1.0];   //フレーム幅設定
    [selectButton addTarget:self action:@selector(deletSelectButton:) forControlEvents:UIControlEventTouchDown];
    
    if (![self.valueArray containsObject:@"1"])
    {
        [selectButton setBackgroundImage:[UIImage imageNamed:@"ico_selected"] forState:UIControlStateNormal];
    }
    else
    {
        [selectButton setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    }
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGColorRef colorref = CGColorCreate(colorSpace,(CGFloat[]){ 217/255.0, 217/255.0, 217/255.0, 1 });
    [selectButton.layer setBorderColor:colorref];//フレームの色を設定する

    [headerView addSubview:selectButton];
    [headerView addSubview:titleLabel];
    
    if (_allowSelect != 1)
    {
        return headerView;
    }
    return nil;
}
//全キャンセルボタン
-(void)deletSelectButton:(BaseButton *)button
{
    NSArray* keys = self.idArray;
    isbool = YES;
    for (NSString* key in keys) {
        [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"0" forKey:key];
    }
    button.selected=!button.selected;
    if (button.selected)
    {
        
        [button setBackgroundImage:[UIImage imageNamed:@"ico_selected"] forState:UIControlStateNormal];
        
    }
    else
    {
        [button setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    }
    
    NSMutableArray *valueArr= [[NSMutableArray alloc]init];
    for (int i = 0; i < self.idArray.count; i++)
    {
        [valueArr addObject:@"0"];
    }
    self.valueArray = valueArr;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:_valueArray forKey:self.index];
    [[SSBPSdkIF sharedInstance] updateDeviceInfo];
    [settingDetaliTableView reloadData];
    
    
}
//データ数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.idArray.count;
}
//高さ
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80*KHEIGHT;
}
//リスト詳細データ
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuse = @"reuse";
    SettingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil)
    {
        cell = [[SettingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    [cell setDetailSSBPDetail:[_ssbpArray objectAtIndex:indexPath.row]];
    
    cell.selectButton.tag = indexPath.row;
    [cell.selectButton addTarget:self action:@selector(selectAction:) forControlEvents:UIControlEventTouchDown];
    NSString* valueString = [[SSBPSdkIF sharedInstance].attrAnswers objectForKey:[self.valueArray objectAtIndex:indexPath.row]];
    NSString* value = [self.valueArray objectAtIndex:indexPath.row];
    if (![self.valueArray containsObject:@"1"])
    {
        value = valueString;
    }
    
    if ([value isEqualToString:@"1"])
    {
        cell.selectButton.selected=YES;
        [cell.selectButton setBackgroundImage:[UIImage imageNamed:@"ico_selected"] forState:UIControlStateNormal];
        selectNo= indexPath.row;
        
    }
    else
    {
        
        cell.selectButton.selected=NO;
        [cell.selectButton setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    }
    cell.selectButton.selected = cell.selected;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)selectAction:(BaseButton *)button
{
   
    button.selected=!button.selected;
    isbool = NO;
    if (self.allowSelect !=1)
    {
        for (NSString* key in self.idArray) {
            [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"0" forKey:key];
        }
        [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"1" forKey:[self.idArray objectAtIndex:button.tag]];
        NSMutableArray *valueArr= [[NSMutableArray alloc]init];
        for (int i = 0; i < self.idArray.count; i++)
        {
            NSString* value = [[SSBPSdkIF sharedInstance].attrAnswers objectForKey:[self.idArray objectAtIndex:i]];
            [valueArr addObject:value];
            
        }
        self.valueArray = valueArr;
        
        
    }
    else
    {

        NSString* value = [_valueArray objectAtIndex:button.tag];
        if ([value isEqualToString:@"0"]) {
            [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"1" forKey:[self.idArray objectAtIndex:button.tag]];
        }
        else
        {
            [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"0" forKey:[self.idArray objectAtIndex:button.tag]];
            
        }
        NSString* valueStr = [[SSBPSdkIF sharedInstance].attrAnswers objectForKey:[self.idArray objectAtIndex:button.tag]];
        [self.valueArray replaceObjectAtIndex:button.tag withObject:valueStr];
        [self cellDidSelect:button.tag];
        
    }
    
    [[SSBPSdkIF sharedInstance] updateDeviceInfo];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:_valueArray forKey:self.index];
    [settingDetaliTableView reloadData];
    
}
-(void)cellDidSelect:(NSInteger )indexPath
{
    NSString* value = [[SSBPSdkIF sharedInstance].attrAnswers objectForKey:[_idArray objectAtIndex:indexPath]];
    if ([value isEqualToString:@"0"]) {
        [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"1" forKey:[self.idArray objectAtIndex:indexPath]];
    }
    else
    {
        [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"0" forKey:[self.idArray objectAtIndex:indexPath]];
    }
}

@end
