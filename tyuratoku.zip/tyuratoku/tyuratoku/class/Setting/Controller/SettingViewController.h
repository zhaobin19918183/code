//
//  SettingViewController.h
//  Beautiful
//
//  Created by newland on 2017/8/16.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SettingTableViewCell.h"
@interface SettingViewController : BaseViewController<UITableViewDelegate,UITableViewDataSource,SSBPSdkIFDelegate>

@end
