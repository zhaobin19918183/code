//
//  SetViewController.m
//  Beautiful
//
//  Created by newland on 2017/8/28.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "SetViewController.h"

@interface SetViewController ()

@end

@implementation SetViewController
/**
 * 機能名　　　　：設定詳しい
 * 機能概要　　　： SSBPSdkIFのgetUtilityContentsを実行すると、ssbpScannerHitUtilityContents  でコ              ンテンツが返却され取得できます。  contentActionがsettingとなっているコンテンツが必要なコンテンツとなります。
 * 作成者    　 ：趙ビン　2017/08/17
 ***********************************************************************
 ***********************************************************************
 */
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = _titleString;
    BaseTextView *contentTextView = [[BaseTextView alloc]init];
    contentTextView.frame = CGRectMake(XSpan(10),YSpan(0), Screen_W - 10*KWIDTH,Screen_H- 70*KHEIGHT);
    contentTextView.text = self.contentString;
    contentTextView.editable = NO;
    [self.view addSubview:contentTextView];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
