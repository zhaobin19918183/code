//
//  SettingViewController.m
//  Beautiful
//
//  Created by newland on 2017/8/16.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "SettingViewController.h"
#import "SetDetailViewController.h"
#import "SettingModel.h"
#import "AppDelegate.h"
#import "SetViewController.h"
@interface SettingViewController ()
{
 
    BaseTableView *settingTableView;
    NSMutableArray *dataArray;
//    NSMutableArray *detailArray;
    NSArray *Coupons;
}
@end

/**
 * 機能名　　　　：設定
 * 機能概要　　　：設定メニューを選択すると表示される画面
 * 作成者    　 ：趙ビン　2017/08/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation SettingViewController

-(void)viewWillAppear:(BOOL)animated
{
    //getUtilityContents

}
- (void)ssbpSdkIFAddContent:(NSString*)contentId
{
    Coupons = [[NSArray alloc]init];
    Coupons = [[SSBPContentIF sharedInstance] getInnerContents:@"setting"];

    NSLog(@"123456789");

}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = CountryLanguage(@"app_name");
    Coupons = [[NSArray alloc]init];
   
    [[SSBPSdkIF sharedInstance] getAttributes];
    [SSBPSdkIF sharedInstance].delegateIF = self;
    [self layoutView];
    [self dataPlist];
    [self leftItemButton];
   
}
- (void)leftItemButton
{
    self.leftButton = [[BaseButton alloc] init];
    self.leftButton.frame = customCGRect(0, 0, 30, 30);
    [self.leftButton addTarget:self action:@selector(goBackButton) forControlEvents:UIControlEventTouchUpInside];
    [self.leftButton setImage:[UIImage imageNamed:@"menu"] forState:UIControlStateNormal];
    UIBarButtonItem *leftItem =[[UIBarButtonItem alloc] initWithCustomView:self.leftButton];

    self.navigationItem.leftBarButtonItems = @[leftItem];
  
}
-(void)goBackButton
{
    AppDelegate *app =  (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.mmdVc toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];


}
-(void)dataPlist
{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"dataPlist" ofType:@"plist"];
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:plistPath];
    dataArray = [[NSMutableArray alloc]init];
    dataArray = [data valueForKey:@"Setting"];
    
}

-(void)layoutView
{
    //creat tableview
    settingTableView = [[BaseTableView alloc]init];
    settingTableView.frame = CGRectMake(0, 0, Screen_W, Screen_H);
    settingTableView.delegate = self;
    settingTableView.dataSource = self;
    Coupons = [[SSBPContentIF sharedInstance] getInnerContents:@"setting"];
    [[SSBPSdkIF sharedInstance] getUtilityContents];
    [self.view addSubview:settingTableView];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80*KHEIGHT;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuse = @"reuse";
    SettingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil)
    {
        cell = [[SettingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    [cell settingModel:[SettingModel settingDic:[dataArray objectAtIndex:indexPath.row]] indexPath:indexPath];
    cell.selectButton.hidden = YES;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
// ユーザー設定は、SSBP SampleAppのUser Settingを参考に、必要な情報を展開
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row !=0)
    {
        
        if (Coupons.count!=0&&indexPath.row!=3) {
            
            SetViewController *setview =[[SetViewController alloc]init];
            setview.titleString =  [[dataArray objectAtIndex:indexPath.row]valueForKey:@"title" ];
            TSsbpContent *tss = Coupons[0];
            if (indexPath.row  == 1)
            {
                setview.contentString = tss.contentBody1;
            }
            if (indexPath.row  == 2)
            {
                setview.contentString = tss.contentBody2;
            }
            [self.navigationController pushViewController:setview animated:YES];
            
        }
        
        if (indexPath.row == 3)
        {
            SetDetailViewController *setDetail = [[SetDetailViewController alloc]init];
            setDetail.titleString = [[dataArray objectAtIndex:3] valueForKey:@"title"] ;
            [self.navigationController pushViewController:setDetail animated:YES];
            
        }
    }
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
