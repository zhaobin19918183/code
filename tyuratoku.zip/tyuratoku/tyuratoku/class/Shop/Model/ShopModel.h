//
//  ShopModel.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"

@interface ShopModel : BaseModel
//データベースフィールド
@property(nonatomic,copy)NSString *body;
@property(nonatomic,assign)NSInteger category_id;
@property(nonatomic,copy)NSString *category_image_url;
@property(nonatomic,copy)NSString *category_name;
@property(nonatomic,copy)NSString *data_id;
@property(nonatomic,assign)NSInteger delete_date;
@property(nonatomic,assign)NSInteger end_date;
@property(nonatomic,copy)NSString *extra_data;
@property(nonatomic,copy)NSString *extra_text_1;
@property(nonatomic,copy)NSString *extra_text_2;
@property(nonatomic,copy)NSString *image_name;
@property(nonatomic,copy)NSString *image_url;
@property(nonatomic,copy)NSString *list_thumb_url;
@property(nonatomic,copy)NSString *modified_date;
@property(nonatomic,copy)NSString *movie_name;
@property(nonatomic,copy)NSString *movie_thumb_url;
@property(nonatomic,copy)NSString *movie_url;
@property(nonatomic,copy)NSString *publish_date;
@property(nonatomic,copy)NSString *rel_url;
@property(nonatomic,copy)NSString *rel_url_android;
@property(nonatomic,copy)NSString *rel_url_ios;
@property(nonatomic,copy)NSString *rel_url_label;
@property(nonatomic,assign)NSInteger start_date;
@property(nonatomic,copy)NSString *sub_title;
@property(nonatomic,copy)NSString *title;

@property float cellHeight;

@end
