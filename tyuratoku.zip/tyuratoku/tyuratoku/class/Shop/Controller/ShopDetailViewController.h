//
//  ShopDetailViewController.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseDetailViewController.h"
#import "ShopDetailTableViewCell.h"
#import "ShopModel.h"

@interface ShopDetailViewController : BaseDetailViewController<UITableViewDelegate,UITableViewDataSource,clickImageDelegate>

/**モデル*/
@property(nonatomic,strong)ShopModel *detailModel;

@end
