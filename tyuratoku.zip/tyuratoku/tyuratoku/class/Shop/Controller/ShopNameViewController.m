//
//  ShopNameViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopNameViewController.h"
#import "AppDelegate.h"

@interface ShopNameViewController (){
    /**リスト*/
    BaseTableView *shopNameTableView;
    /**リストデータ*/
    NSMutableArray <ShopModel*>*shopNameArray;
}

@end

/**
 * 機能名　　　　：店名
 * 機能概要　　　：ショップ名リスト
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopNameViewController

//二級のメニューは引き出しのメニューを表示しない
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillDisappear:animated];
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.mmdVc setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeNone];
    [app.mmdVc setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeNone];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //タイトル
    self.title = self.nameModel.category_name;
    shopNameArray = [NSMutableArray array];
    [self leftItemButton];
    
    //リスト作成
    shopNameTableView = [[BaseTableView alloc]init];
    shopNameTableView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-64);
    shopNameTableView.delegate = self;
    shopNameTableView.dataSource = self;
    shopNameTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:shopNameTableView];
    
    //請求データ
    [self getDBData];
}

#pragma mark - tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return shopNameArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return tableView.frame.size.height/6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *reuse = [NSString stringWithFormat:@"%ld%ld",indexPath.section,indexPath.row];
    ShopNameTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell == nil) {
        cell = [[ShopNameTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse frame:CGRectMake(0, 0, tableView.frame.size.width, [self tableView:tableView heightForRowAtIndexPath:indexPath]) model:[shopNameArray objectAtIndex:indexPath.row]];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    ShopDetailViewController *detailVc = [[ShopDetailViewController alloc]init];
    detailVc.detailModel = [shopNameArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:detailVc animated:YES];
}

#pragma mark - DB
- (void)getDBData{
    //データベースデータを検索する
    NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAnd(shopDBName, [NetWorkManager getCurrentTimeStr], self.nameModel.category_id) DBName:shopDBName];
    //arrayに足を付けるデータ
    for (NSMutableDictionary *dic in array) {
        [shopNameArray addObject:[[ShopModel alloc]initWithDic:dic]];
    }
    //更新リスト
    [shopNameTableView reloadData];
}

@end
