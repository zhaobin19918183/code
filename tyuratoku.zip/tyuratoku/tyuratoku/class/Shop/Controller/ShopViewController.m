//
//  ShopViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopViewController.h"

/**重用識別子*/
static NSString *reuse = @"reuse";

@interface ShopViewController (){
    /**リスト*/
    BaseCollectionView *shopCollectionView;
    /**リストデータ*/
    NSMutableArray <ShopModel*>*shopDataArray;
    /**サーバーラストパラメータ*/
    NSString *lastTime;
    /**表示或非表示活動指示器*/
    BOOL showHUDState;
}

@end

/**
 * 機能名　　　　：商店
 * 機能概要　　　：ショップリスト
 * 作成者    　 ：郭詠明　2017/07/13
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initData];
    
    //layout
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    //リスト作成
    shopCollectionView = [[BaseCollectionView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, MainVc_H) collectionViewLayout:layout];
    shopCollectionView.backgroundColor = [UIColor clearColor];
    shopCollectionView.delegate = self;
    shopCollectionView.dataSource = self;
    [self.view addSubview:shopCollectionView];
    
    //register
    [shopCollectionView registerClass:[ShopCollectionViewCell class] forCellWithReuseIdentifier:reuse];
    
    //プルダウン更新
    [shopCollectionView downRefresh];
    //プルダウン更新操作
    [shopCollectionView downRefreshData:^{
        //表示 HUD
        showHUDState = NO;
        //ラストの値を取る
        lastTime = [NetWorkManager getLastTimeForDBName:shopDBName];
        //請求データ
        [self getRequest];
    }];
    //請求データ
    [self getRequest];
}

#pragma mark - 初期化
- (void)initData{
    //表示HUD
    showHUDState = YES;
    
    //初期化
    shopDataArray = [NSMutableArray array];
    
    //データベースデータを読み取る
    NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_groupBy(shopDBName) DBName:shopDBName];
    if (array.count>0) {
        for (NSMutableDictionary *dic in array) {
            [shopDataArray addObject:[[ShopModel alloc] initWithDic:dic]];
        }
        //非表示 HUD
        showHUDState = NO;
    }
    
    //ラストの値を取る
    lastTime = [NetWorkManager getLastTimeForDBName:shopDBName];
    
}

#pragma mark - collectionView
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return shopDataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ShopCollectionViewCell *cell = [[ShopCollectionViewCell alloc]initWithFrame:CGRectMake(0, 0,(collectionView.frame.size.width-XSpan(30))/2, (collectionView.frame.size.height-YSpan(50))/4)];
    //セル付値
    cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuse forIndexPath:indexPath];
    [[cell getImageView]sd_setImageWithURL:[NSURL URLWithString:[shopDataArray objectAtIndex:indexPath.row].category_image_url]];
    [[cell getShopLabel]setText:[shopDataArray objectAtIndex:indexPath.row].category_name textAlignment:BaseLabelCenter];
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake((collectionView.frame.size.width-XSpan(30))/2, (collectionView.frame.size.height-YSpan(50))/4);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(YSpan(10), XSpan(10), YSpan(10), XSpan(10));
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    ShopNameViewController *shopNameVc = [[ShopNameViewController alloc]init];
    shopNameVc.nameModel = [shopDataArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:shopNameVc animated:YES];
}

#pragma mark - request
- (void)getRequest{
    [NetWorkManager POST:listUrl paraments:[NSString stringWithFormat:@"_=%@&feature_key=shop&last=%@",[NetWorkManager getTicket],lastTime] showHUD:showHUDState success:^(id responseObject) {
        //成功後に戻りのデータを求めます
        NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
        
        //データを取り出す
        NSMutableArray *modelDataArray = [dataDic valueForKey:@"data"];
        
        //追加データ
        for (int i = 0; i<modelDataArray.count; i++) {
            //請求パラメータを取り出して dic
            NSDictionary *dic = [modelDataArray objectAtIndex:i];
            //dic 转モデル
            ShopModel *dbModel = [[ShopModel alloc] initWithDic:dic];
            //データベースには、data_id値があるかどうか
            NSMutableArray *dbArray = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_selectDataId(shopDBName, dbModel.data_id) DBName:shopDBName];
            //cellHeight データには、カスタマイズするために、ここに追加する必要がありません
            NSMutableDictionary *dataDic = [NSMutableDictionary dictionary];
            dataDic = [NSMutableDictionary dictionaryWithDictionary:dic];
            [dataDic setValue:@"0" forKey:@"cellHeight"];
            [dataDic setValue:@"0" forKey:@"delete_date"];
            //もしarrayの量は0より大きくて
            if (dbArray.count==0) {
                //存在しないと添加の
                [[FMDBTool sharedManager]Queue_addDataToDataBase:dataDic DBName:shopDBName];
            }else{
                //存在が更新さ
                [[FMDBTool sharedManager]Queue_updateDataWithDic:dataDic DBName:shopDBName];
            }
            if (dbModel.delete_date>0){
                //現在のデータを削除する
                [[FMDBTool sharedManager]Queue_deleteDBAllData:dbModel.data_id DBName:shopDBName];
            }
        }
        
        
        //パケットデータを取り出す
        NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_groupBy(shopDBName) DBName:shopDBName];
        [shopDataArray removeAllObjects];
        for (NSDictionary *dic in array) {
            [shopDataArray addObject:[[ShopModel alloc] initWithDic:dic]];
        }
        
            
        //ラストの設定値
        [NetWorkManager setLastTimeForDBName:shopDBName];
        //更新リスト
        [shopCollectionView reloadData];
        //非表示活動指示器
        showHUDState = NO;
    } failure:^(NSError *error) {
    }];
}

//無インターネットまたは無データ時のフィボナッチリトレースメント
- (void)upRefreshData{
    [self getRequest];
}

@end
