//
//  ShopDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopDetailViewController.h"

@interface ShopDetailViewController (){
    /**リスト*/
    BaseTableView *ShopDetailTableView;
    /**分かち合う時の画像アドレス*/
    NSString *shareImageStr;
    /**底部交わdicモデル */
    NSMutableDictionary *modelDic;
}

@end
/**
 * 機能名　　　　：商店
 * 機能概要　　　：店の詳細
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.detailModel.title;
    
    //リスト作成
    ShopDetailTableView = [[BaseTableView alloc]init];
    if ([self.detailModel.rel_url_ios isEqualToString:@""]&&
        [self.detailModel.rel_url isEqualToString:@""]) {
        ShopDetailTableView.frame = CGRectMake(0, 0, Screen_W , Screen_H - 64);
    }else{
        ShopDetailTableView.frame = CGRectMake(0, 0, Screen_W , Screen_H - YSpan(75) - 64);
    }
    ShopDetailTableView.delegate = self;
    ShopDetailTableView.dataSource = self;
    ShopDetailTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:ShopDetailTableView];
    
    //底面のボタンを作成する
    modelDic = [NSMutableDictionary dictionary];
    [modelDic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
    [modelDic setValue:self.detailModel.rel_url forKey:@"rel_url"];
    [modelDic setValue:self.detailModel.rel_url_label forKey:@"rel_url_label"];
    [self CreatBottomViewSubviews:modelDic];
}

#pragma mark - tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.detailModel.cellHeight == 0) {
        return tableView.frame.size.height;
    }else{
        return self.detailModel.cellHeight;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    ShopDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell == nil) {
        cell = [[ShopDetailTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    //セル付値
    NSMutableArray *imageUrlArray = [NetWorkManager getImageUrlArray:self.detailModel.extra_data];
    
    //写真がたくさんあるかどうか
    if (imageUrlArray.count > 0) {
        [cell setMoreImageState:YES];
    }else{
        [cell setMoreImageState:NO];
    }
    
    cell.imageUrlArray = imageUrlArray;
    cell.detailCellModel = self.detailModel;
    cell.delegate = self;
    return cell;
}

//分かち合う
- (void)shareButton{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:shareImageStr forKey:@"image"];
    [dic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
    [dic setValue:self.detailModel.title forKey:@"title"];
    [NetWorkManager setShareInfoDic:dic];
}

#pragma mark - delegate
- (void)getImage:(NSString *)image{
    shareImageStr = image;
}

//ズーム写真
- (void)clickImageView:(UITapGestureRecognizer *)tap{
    AmplifyView *amplifyView = [[AmplifyView alloc] initWithFrame:self.view.bounds andGesture:tap andSuperView:self.view];
    [[UIApplication sharedApplication].keyWindow addSubview:amplifyView];
}

//画像は成功後のフィボナッチリトレースメントを得る
- (void)refreshTableView:(float)cellHeight imageViewHeight:(CGRect)imageFrame{
    //セルの高さに再付値
    self.detailModel.cellHeight = cellHeight;
    //更新リスト
    [ShopDetailTableView reloadData];
}

//下のボタンをクリックしてイベントを見る
- (void)BottomViewButtonClick:(UIButton *)button dic:(NSDictionary *)dic{
    switch (button.tag) {
        case 0:
            NSLog(@"0");
            break;
        case 1:
            NSLog(@"1");
            break;
        case 2:
            NSLog(@"2");
            break;
        case 3:
        {
            //rel_url_iosが空の場合、オープンrel_url
            if ([self.detailModel.rel_url_ios isKindOfClass:[NSNull class]]||[self.detailModel.rel_url_ios isEqualToString:@""]) {
                
                NSURL *cleanURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@", self.detailModel.rel_url]];
                [[UIApplication sharedApplication] openURL:cleanURL];
                
            }else{
                NSURL *cleanURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@", [self.detailModel.rel_url_ios stringByRemovingPercentEncoding]]];
                [[UIApplication sharedApplication] openURL:cleanURL];
                [NetWorkManager OpenUrl:[self.detailModel.rel_url_ios stringByRemovingPercentEncoding] download:self.detailModel.rel_url dic:modelDic];
            }
            
        }
            break;
        default:
            break;
    }
}


@end
