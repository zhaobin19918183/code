//
//  ShopDetailTableViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopModel.h"
#import "NoticeModel.h"

@interface ShopDetailTableViewCell : BaseDetailCell

//モデル
@property(nonatomic,strong)ShopModel *detailCellModel;

@end
