//
//  ShopCollectionViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopCollectionViewCell.h"
/**
 * 機能名　　　　：商店
 * 機能概要　　　：商店 cell
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopCollectionViewCell{
    /**画像*/
    BaseImageView *imageView;
    /**店名*/
    BaseLabel *shopLabel;
}

//初期化セル
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        [self createSubviews];
    }
    return self;
}

//創建ui
- (void)createSubviews{
    //画像
    imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height-shopLabelHeight);
    [self.contentView addSubview:imageView];
    
    //店名
    shopLabel = [[BaseLabel alloc]init];
    shopLabel.frame = CGRectMake(0, CGRectGetMaxY(imageView.frame), imageView.frame.size.width, self.contentView.frame.size.height-CGRectGetMaxY(imageView.frame));
    shopLabel.numberOfLines = 2;
    [self.contentView addSubview:shopLabel];
}

//写真を得る
- (BaseImageView *)getImageView{
    return imageView;
}

//店名を得る
- (BaseLabel *)getShopLabel{
    return shopLabel;
}

@end
