//
//  ShopNameTableViewCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "ShopNameTableViewCell.h"
/**
 * 機能名　　　　：店名
 * 機能概要　　　：店名cell
 * 作成者    　 ：郭詠明　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation ShopNameTableViewCell{
    ShopModel *cellModel;
}

//初期化セル
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier frame:(CGRect)frame model:(ShopModel *)model{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.contentView.frame = self.frame;
        cellModel = model;
        [self creatSubview];
    }
    return self;
}

//創建ui
- (void)creatSubview{
    //画像
    BaseImageView *imageView = [[BaseImageView alloc]init];
    imageView.frame = CGRectMake(XSpan(10), YSpan(5), (self.contentView.frame.size.width-XSpan(20))/3, self.contentView.frame.size.height-YSpan(10));
    [imageView sd_setImageWithURL:[NSURL URLWithString:cellModel.list_thumb_url] placeholderImage:[UIImage imageNamed:@"noImage"]];
    [self.contentView addSubview:imageView];
    
    //タイトル
    BaseLabel *titleLabel = [[BaseLabel alloc]init];
    titleLabel.frame = CGRectMake(CGRectGetMaxX(imageView.frame)+XSpan(10), imageView.frame.origin.y, self.contentView.frame.size.width-CGRectGetMaxX(imageView.frame)-XSpan(20), imageView.frame.size.height/4);
    [titleLabel setText:cellModel.title textAlignment:BaseLabelLeft];
    [titleLabel setNumberOfLines:1];
    [self.contentView addSubview:titleLabel];
    
    //サブタイトル
    BaseLabel *contextLabel = [[BaseLabel alloc]init];
    contextLabel.frame = CGRectMake(titleLabel.frame.origin.x, CGRectGetMaxY(titleLabel.frame), titleLabel.frame.size.width, titleLabel.frame.size.height*2);
    [contextLabel setText:cellModel.sub_title textAlignment:BaseLabelLeft];
    [titleLabel setNumberOfLines:2];
    [self.contentView addSubview:contextLabel];
    
    //著者
    BaseLabel *authorLabel = [[BaseLabel alloc]init];
    authorLabel.frame = CGRectMake(self.contentView.frame.size.width-XSpan(10)-XSpan(102), CGRectGetMaxY(contextLabel.frame), XSpan(102), titleLabel.frame.size.height);
    authorLabel.backgroundColor = customGreen;
    [authorLabel setFillet:5];
    [authorLabel setTextFont:BaseLabelDefaultFont textColor:BaseLabelWhite];
    if (cellModel.rel_url_ios == NULL||
        cellModel.rel_url_ios == nil||
        [cellModel.rel_url_ios isKindOfClass:[NSNull class]]||
        [cellModel.rel_url_ios isEqualToString:@""]) {
        authorLabel.hidden = YES;
    }
    [authorLabel setText:cellModel.rel_url_ios textAlignment:BaseLabelCenter];
//    [self.contentView addSubview:authorLabel];
}

@end
