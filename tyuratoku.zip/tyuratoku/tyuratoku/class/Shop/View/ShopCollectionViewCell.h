//
//  ShopCollectionViewCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#define shopLabelHeight YSpan(30)

@interface ShopCollectionViewCell : UICollectionViewCell

/**
 初期化セル

 @param frame フレーム
 @return セル
 */
- (instancetype)initWithFrame:(CGRect)frame;

/**
 写真を得る

 @return BaseImageView
 */
- (BaseImageView *)getImageView;

/**
 店名を得る

 @return BaseLabel
 */
- (BaseLabel *)getShopLabel;

@end
