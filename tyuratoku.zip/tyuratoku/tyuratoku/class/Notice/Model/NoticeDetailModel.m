//
//  NoticeDetailModel.m
//  Beautiful
//
//  Created by newland on 2017/7/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NoticeDetailModel.h"
/**
 * 機能名　　　　：詳しくお知らせするモデル
 * 機能概要　　　：モデル
 * 作成者    　 ：郭麗影　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation NoticeDetailModel

@end
