//
//  NoticeDetailModel.h
//  Beautiful
//
//  Created by newland on 2017/7/18.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "BaseModel.h"

@interface NoticeDetailModel : BaseModel
@property(nonatomic,copy)NSString *sub_title;
@property(nonatomic,copy)NSString *extra_text_1;
@property(nonatomic,copy)NSString *image_url;
@property(nonatomic,copy)NSString *extra_text_2;
@property(nonatomic,copy)NSString *body;
@property(nonatomic,copy)NSString *extra_data;
@property float cellHeight;

@property(nonatomic,copy)NSString *movie_thumb_url;
@property(nonatomic,copy)NSString *movie_url;
@property(nonatomic,copy)NSString *movie_name;

@end
