//
//  NoticeDetailCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NoticeDetailCell.h"

@implementation NoticeDetailCell

//モデル付値
- (void)setDetailCellModel:(NoticeModel *)detailCellModel{
    _detailCellModel = detailCellModel;
    [self setSubviewFrame:detailCellModel];
}

//ビデオ
- (void)showVideoPlayer{
    self.imgView.hidden =YES;
    //ビデオビュー
    UIView *playerView = [[UIView alloc] init];
    playerView.frame = CGRectMake(0, CGRectGetMaxY(self.contentOneLabel.frame)+YSpan(10), Screen_W, YSpan(200));
    [self.contentView addSubview:playerView];
    
    //プレーヤー
    self.videoPlayer = [SRVideoPlayer playerWithVideoURL:[self urlstring:_detailCellModel.movie_url] playerView:playerView playerSuperView:playerView.superview];
    self.videoPlayer.playerEndAction = SRVideoPlayerEndActionStop;
    [self.videoPlayer play];
}

//ビデオurl
- (NSURL *)urlstring:(NSString *)movieUrl{
    NSURL *fileURL = [NSURL URLWithString:movieUrl];
    return fileURL;
}


@end
