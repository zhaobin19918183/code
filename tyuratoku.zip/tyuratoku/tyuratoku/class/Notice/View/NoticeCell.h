//
//  NoticeCell.h
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NoticeModel.h"

@interface NoticeCell : BaseNoticeTableViewCell

/**モデル*/
@property(nonatomic,strong)NoticeModel *cellModel;

@end
