//
//  NoticeCell.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NoticeCell.h"

@implementation NoticeCell
//モデル付値
- (void)setCellModel:(NoticeModel *)cellModel{
    //モデル付値
    _cellModel = cellModel;
    

    //画像
    [self.imgView sd_setImageWithURL:[NSURL URLWithString:cellModel.list_thumb_url] placeholderImage:[UIImage imageNamed:@"noImage"]];
    
    //タイトル
    [self.titleLabel setText:cellModel.title textAlignment:BaseLabelLeft];
    
    //サブタイトル
    [self.bodyLabel setText:cellModel.sub_title textAlignment:BaseLabelLeft];
    
    //時間
    [self.dateLabel setText:[NSString stringWithFormat:@"更新日:%@",[NetWorkManager currentDateStr:cellModel.publish_date]] textAlignment:BaseLabelLeft];
    
//    //著者
//    if (([model.rel_url_ios  isEqualToString:@""]||[model.rel_url_ios  isKindOfClass:[NSNull class]]||model.rel_url_ios==nil)&&([model.rel_url isEqualToString:@""]||[model.rel_url isKindOfClass:[NSNull class]]||model.rel_url==nil)){
//        self.authorLabel.hidden = YES;
//    }else{
//        self.authorLabel.hidden = NO;
//        //表示Cooperative web titleを判断する
//        if ([model.rel_url_label isEqualToString:@""]||[model.rel_url_label isKindOfClass:[NSNull class]]||model.rel_url_label==nil) {
//            [self.authorLabel setText:@"Cooperative web title" textAlignment:BaseLabelCenter];
//        }else{
//            [self.authorLabel setText:model.rel_url_label textAlignment:BaseLabelCenter];
//        }
//    }
    
    self.authorLabel.hidden = YES;
}

@end
