//
//  NoticeDetailViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/17.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NoticeDetailViewController.h"
#import "NoticeDetailCell.h"
#import "NoticeModel.h"


@interface NoticeDetailViewController ()<clickImageDelegate>{
    /**リスト*/
    BaseTableView *noticeTableView;
    /**<#注释#>*/
    NSMutableDictionary *modelDic;
    /**画像を共有する */
    NSString *shareImageStr;
    
}


@end
/**
 * 機能名　　　　：お知らせリスト
 * 機能概要　　　：お知らせリスト詳しい
 * 作成者    　 ：郭麗影　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation NoticeDetailViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self CreatTableview];
    
}

//tableviewクリエイト
- (void)CreatTableview{
    [self NavigationTitle:self.detailModel.title];
    
    //tableviewクリエイト
    noticeTableView = [[BaseTableView alloc]init];
    //下のラベルがあるかどうか決定するため
    if ([self.detailModel.rel_url_ios isEqualToString:@""]&&
        [self.detailModel.rel_url isEqualToString:@""]) {
        noticeTableView.frame = CGRectMake(0, 0,Screen_W , Screen_H -64);
    }else{
        noticeTableView.frame = CGRectMake(0, 0,Screen_W , Screen_H - YSpan(75)-64);
    }
    noticeTableView.delegate = self;
    noticeTableView.dataSource = self;
    noticeTableView.estimatedRowHeight = XSpan(600);
    [self.view addSubview:noticeTableView];
    noticeTableView.separatorStyle = UITableViewCellStyleDefault;
    
    //底面のボタンを作成する
    modelDic = [NSMutableDictionary dictionary];
    [modelDic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
    [modelDic setValue:self.detailModel.rel_url forKey:@"rel_url"];
    [modelDic setValue:self.detailModel.rel_url_label forKey:@"rel_url_label"];
    [self CreatBottomViewSubviews:modelDic];
}

#pragma mark - tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"self.detailModel.cellHeight-----%f",self.detailModel.cellHeight);
    if (self.detailModel.cellHeight==0) {
        return tableView.frame.size.height;
    }else{
        return self.detailModel.cellHeight;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    NoticeDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[NoticeDetailCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    //セル付値
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.detailCellModel = self.detailModel;
    
    cell.delegate = self;
    
    return cell;
}

- (void)shareButton{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:shareImageStr forKey:@"image"];
    [dic setValue:self.detailModel.rel_url_ios forKey:@"rel_url_ios"];
    [dic setValue:self.detailModel.title forKey:@"title"];
    [NetWorkManager setShareInfoDic:dic];
}

#pragma mark - delegate
- (void)getImage:(NSString *)image{
    shareImageStr = image;
}
//ズーム写真
- (void)clickImageView:(UITapGestureRecognizer *)tap{
    AmplifyView *amplifyView = [[AmplifyView alloc] initWithFrame:self.view.bounds andGesture:tap andSuperView:self.view];
    [[UIApplication sharedApplication].keyWindow addSubview:amplifyView];
}

//画像は成功後のフィボナッチリトレースメントを得る
- (void)refreshTableView:(float)cellHeight imageViewHeight:(CGRect)imageFrame{
    //セルの高さに再付値
    self.detailModel.cellHeight = cellHeight;
    //更新リスト
    [noticeTableView reloadData];
}

//下のボタンをクリックしてイベントを見る
- (void)BottomViewButtonClick:(UIButton *)button dic:(NSDictionary *)dic{
    
    switch (button.tag) {
        case 0:
            NSLog(@"0");
            break;
        case 1:
            NSLog(@"1");
            break;
        case 2:
            NSLog(@"2");
            break;
        case 3:
        {
            //rel_url_iosが空の場合、オープンrel_url
            if ([self.detailModel.rel_url_ios isKindOfClass:[NSNull class]]||[self.detailModel.rel_url_ios isEqualToString:@""]) {
      
                NSURL *cleanURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@", self.detailModel.rel_url]];
                [[UIApplication sharedApplication] openURL:cleanURL];

            }else{
                NSLog(@" ----7777--%@-------%@-------%@",self.detailModel.rel_url_ios,self.detailModel.rel_url,modelDic);
                NSURL *cleanURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@", [self.detailModel.rel_url_ios stringByRemovingPercentEncoding]]];
                [[UIApplication sharedApplication] openURL:cleanURL];
                
                [NetWorkManager OpenUrl:[self.detailModel.rel_url_ios stringByRemovingPercentEncoding] download:self.detailModel.rel_url dic:modelDic];
                
//                [self OpenUrl:@"comgooglemaps-x-callback:" download:@"https://itunes.apple.com/cn/app/google-maps/id585027354?mt=8"];
//                [self OpenUrl:@"twitter://" download:@"https://itunes.apple.com/us/app/twitter/id333903271?mt=8"];
                
                
                
//                [NetWorkManager OpenUrl:@"comgooglemaps-x-callback:" download:@"itms-apps://itunes.apple.com/app/id585027354" dic:modelDic];
//                [NetWorkManager OpenUrl:@"twitter://" download:@"itms-apps://itunes.apple.com/app/id333903271" dic:modelDic];
                
                
                
//                [self OpenUrl:@"comgooglemaps-x-callback:" download:@"itms-apps://itunes.apple.com/app/id585027354"];
//                [self OpenUrl:@"twitter://" download:@"itms-apps://itunes.apple.com/app/id333903271"];https://itunes.apple.com/cn/app/id414478124?mt=8
          
            }
       
        }
            break;
        default:
            break;
    }
}

@end
