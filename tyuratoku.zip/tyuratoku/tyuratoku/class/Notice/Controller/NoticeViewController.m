//
//  NoticeViewController.m
//  Beautiful
//
//  Created by newland on 2017/7/14.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "NoticeViewController.h"
#import "NoticeCell.h"
#import "NoticeDetailViewController.h"
#import "MainViewController.h"
#import "NoticeModel.h"

@interface NoticeViewController (){
    /**リスト*/
    BaseTableView *noticeTableView;
    /**リストデータ*/
    NSMutableArray <NoticeModel*>*noticeArray;
    /**サーバーラストパラメータ*/
    NSString *lastTime;
    /**表示或非表示活動指示器*/
    BOOL showHUDState;
}

@end
/**
 * 機能名　　　　：お知らせ
 * 機能概要　　　：お知らせリスト
 * 作成者    　 ：郭麗影　2017/07/17
 ***********************************************************************
 ***********************************************************************
 */
@implementation NoticeViewController

-(void)viewDidDisappear:(BOOL)animated{

    [NetWorkManager hideHUD];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //初期化
    [self initData];
    
    //リスト作成
    noticeTableView = [[BaseTableView alloc]init];
    noticeTableView.frame = CGRectMake(0, 0, self.view.frame.size.width, MainVc_H);
    noticeTableView.delegate = self;
    noticeTableView.dataSource = self;
    [self.view addSubview:noticeTableView];
    noticeTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    //プルダウン更新
    [noticeTableView downRefresh];
    [noticeTableView downRefreshData:^{
        //表示 HUD
        showHUDState = NO;
        //ラストの値を取る
        lastTime = [NetWorkManager getLastTimeForDBName:noticeDBName];
        //請求データ
        [self getRequest];
    }];
    //請求データ
    [self getRequest];
    
}

- (void)initData{
    //表示HUD
    showHUDState = YES;
    
    //初期化
    noticeArray = [NSMutableArray array];
    
    //赋值给ベビー
    lastTime = [NetWorkManager getLastTimeForDBName:noticeDBName];
    
    //データベースデータを読み取る
    NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAndDate(noticeDBName, lastTime) DBName:noticeDBName];
    NSLog(@"array------%@",array);
    if (array.count>0) {
        for (NSMutableDictionary *dic in array) {
            [noticeArray addObject:[[NoticeModel alloc] initWithDic:dic]];
        }
        
        //非表示 HUD
        showHUDState = NO;
    }
    
    
    
}

#pragma mark - tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return noticeArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return YSpan(110);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuse = @"reuse";
    NoticeCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (cell==nil) {
        cell = [[NoticeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    //セル付値
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.cellModel = [noticeArray objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //ジャンプページに遷移する
    NoticeDetailViewController *noticeDetail = [[NoticeDetailViewController alloc]init];
    noticeDetail.detailModel = [noticeArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:noticeDetail animated:YES];
}

#pragma mark - request
- (void)getRequest{
    
    [NetWorkManager POST:listUrl paraments:[NSString stringWithFormat:@"_=%@&feature_key=notice&last=%@",[NetWorkManager getTicket],lastTime] showHUD:showHUDState success:^(id responseObject) {
        NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:nil];
        
        //データを取り出す
        NSMutableArray *modelDataArray = [dataDic valueForKey:@"data"];
        
        //追加データ
        for (int i = 0; i<modelDataArray.count; i++) {
            //請求パラメータを取り出して dic
            NSDictionary *dic = [modelDataArray objectAtIndex:i];
            //dic 转モデル
            NoticeModel *dbModel = [[NoticeModel alloc] initWithDic:dic];
            //データベースには、data_id値があるかどうか
            NSMutableArray *dbArray = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_selectDataId(noticeDBName, dbModel.data_id) DBName:noticeDBName];
            //cellHeight データには、カスタマイズするために、ここに追加する必要がありません
            NSMutableDictionary *dataDic = [NSMutableDictionary dictionary];
            dataDic = [NSMutableDictionary dictionaryWithDictionary:dic];
            [dataDic setValue:@"0" forKey:@"cellHeight"];
            //もしarrayの量は0より大きくて
            if (dbArray.count==0) {
                //存在しないと添加の
                [[FMDBTool sharedManager]Queue_addDataToDataBase:dataDic DBName:noticeDBName];
            }else{
                //存在が更新さ
                [[FMDBTool sharedManager]Queue_updateDataWithDic:dataDic DBName:noticeDBName];
            }
            if ([dbModel.delete_date integerValue]>0){
                //現在のデータを削除する
                [[FMDBTool sharedManager]Queue_deleteDBAllData:dbModel.data_id DBName:noticeDBName];
            }
        }
        
        //パケットデータを取り出す
        NSMutableArray *array = [[FMDBTool sharedManager]Queue_searchDataBaseReslust:SQL_betweenAndDate(noticeDBName, lastTime) DBName:noticeDBName];
        [noticeArray removeAllObjects];
        for (NSDictionary *dic in array) {
            [noticeArray addObject:[[NoticeModel alloc] initWithDic:dic]];
        }
        
        //ラストの設定値
        [NetWorkManager setLastTimeForDBName:noticeDBName];
        //更新リスト
        [noticeTableView reloadData];
        //非表示活動指示器
        showHUDState = NO;
        //出入りリストパラメーター、表示エラーが表示されます
//        [self upRefreshData:noticeArray];
    } failure:^(NSError *error) {
        //エラーを請求してエラーページを表示する
//        [self upRefreshData:nil];
    }];
}

//無インターネットまたは無データ時のフィボナッチリトレースメン
- (void)upRefreshData{
    [self getRequest];
}



@end
