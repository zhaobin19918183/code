//
//  AppDelegate.h
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "HomeViewController.h"
#import "MenuViewController.h"
#import "MMDrawerController.h"
#import "SettingViewController.h"
#import "LaunchViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate,SSZipArchiveDelegate>

@property(strong,nonatomic)UIWindow *window;
/**ホームページ面*/
@property(strong,nonatomic)MainViewController *mainVc;
/**ホーム*/
@property(strong,nonatomic)HomeViewController *homeVc;
/**メニュー*/
@property(strong,nonatomic)MenuViewController *menuVc;
/**引き出し主制御装置*/
@property(strong,nonatomic)MMDrawerController *mmdVc;
/**設置*/
@property(strong,nonatomic)SettingViewController *settingVc;
/**スタートページ*/
@property(strong,nonatomic) LaunchViewController *launchVc;
/**主制御装置*/
@property(strong,nonatomic)UINavigationController *mainNc;

@end

