//
//  AppDelegate.m
//  Beautiful
//
//  Created by newland on 2017/7/13.
//  Copyright © 2017年 newland. All rights reserved.
//

#import "AppDelegate.h"
#import "AnimationModel.h"
#import "ShopModel.h"
#import "NoticeModel.h"
#import "TouristModel.h"
#import "PhotoModel.h"
#import "MyProcketModel.h"
#import "MenuModel.h"
#import "SSBPSdkIF.h"
#import "MyPockerDetailViewController.h"

@interface AppDelegate (){
    NSUserDefaults *info;
    NSString* type;
}

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //window
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[UIViewController alloc] init];
    [self.window makeKeyAndVisible];
    if ([launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey]) {
        // アプリ完全終了状態で通知から起動した場合に、通常のトップ画面ではなく特定の画面に遷移させたい場合はここで処理
        NSLog(@"UIApplicationLaunchOptionsLocalNotificationKey");
        UILocalNotification* notification = [launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
        if (notification != nil) {
            [self openCustomPage:notification.userInfo];
        }
    }
    //初期設定対象
    [NetWorkManager shareManager];
    //初期設定データ
    [self dataInit];
    //SSBP初期設定
   
   

    return YES;
}

- (void)application:(UIApplication*)application didReceiveLocalNotification:(UILocalNotification*)notification {
    NSLog(@"didReceiveLocalNotification %@", notification.userInfo);
    if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive)
    {
        
    } else
    {
        NSDictionary* userInfo = notification.userInfo;
        [self openCustomPage:userInfo];
    }
}
// 通常のトップ画面ではなく特定の画面に遷移させたい場合はここで処理
//  最後に表示していた画面が遷移可能な同一階層のTabBarControllerであれば単純な切り替え
//  それ以外の状態からであれば、オープニングからとする
- (void)openCustomPage:(NSDictionary*)userInfo {
    if (userInfo == nil) return;
    type = [userInfo objectForKey:SSBP_NOTIFICATION_ID];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:type forKey:SSBP_NOTIFICATION_ID];

    if(type!=nil)
    {
    
     [[NSNotificationCenter defaultCenter]postNotificationName:@"pocketcontent" object:type];
     [self goToChooseModel:4];
    
    }
//    [[NSNotificationCenter defaultCenter]addObserverForName:@"pocketDetail" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
//        [self goToChooseModel:0];
//       
//        [self getMenuTypeArrayOfNotificationCenter:note];
//    }];
//    
//    [[NSNotificationCenter defaultCenter]addObserverForName:@"pocket" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
//        [self goToChooseModel:0];
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"pocketnotice" object:userInfo];
//        [self getMenuTypeArrayOfNotificationCenter:note];
//    }];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}
- (void)applicationDidEnterBackground:(UIApplication *)application {
    [[SSBPSdkIF sharedInstance] applicationEnterBackground];
}
- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}
- (void)applicationDidBecomeActive:(UIApplication *)application {
//    [[NSNotificationCenter defaultCenter]addObserverForName:@"pocketcontentBack" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
//        [[NSNotificationCenter defaultCenter]postNotificationName:@"pocketcontent" object:note.object];
//        [self goToChooseModel:0];
//        [self getMenuTypeArrayOfNotificationCenter:note];
//    }];

    [[SSBPSdkIF sharedInstance] applicationBecomeActive];
}
- (void)applicationWillTerminate:(UIApplication *)application {
    [[SSBPSdkIF sharedInstance] applicationTerminate];
}

//初期設定データ
- (void)dataInit{
    info = [NSUserDefaults standardUserDefaults];
    
    //通知を受けてページにジャンプする
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(selectHome:) name:@"home" object:nil];
//    [[NSNotificationCenter defaultCenter]addObserverForName:@"home" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
//        [self goToChooseModel:1];
//        self.mainVc.pageindex = 0;
//        
//    }];
    
    [[NSNotificationCenter defaultCenter]addObserverForName:@"photo" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        [self goToChooseModel:0];
        [self getMenuTypeArrayOfNotificationCenter:note];
    }];
    
    [[NSNotificationCenter defaultCenter]addObserverForName:@"pocket" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        [self goToChooseModel:0];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"pocketcontent" object:note.object];
        [self getMenuTypeArrayOfNotificationCenter:note];
    }];
    
    [[NSNotificationCenter defaultCenter]addObserverForName:@"notice" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        [self goToChooseModel:0];
        [self getMenuTypeArrayOfNotificationCenter:note];
    }];
    
    [[NSNotificationCenter defaultCenter]addObserverForName:@"leisure" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        [self goToChooseModel:0];
        [self getMenuTypeArrayOfNotificationCenter:note];
    }];
    
    [[NSNotificationCenter defaultCenter]addObserverForName:@"shop" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        [self goToChooseModel:0];
        [self getMenuTypeArrayOfNotificationCenter:note];
    }];
    
    [[NSNotificationCenter defaultCenter]addObserverForName:@"movie" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        [self goToChooseModel:0];
        [self getMenuTypeArrayOfNotificationCenter:note];
    }];
    
    [[NSNotificationCenter defaultCenter]addObserverForName:@"setting" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        [[SSBPSdkIF sharedInstance] applicationBecomeActive];
        [self goToChooseModel:2];
    }];
    
    //データベース建表
    [self creatDBTable];
    //解凍zipバッグ
    [self getZip];
    //再設定コントローラ
    [self goToChooseModel:3];
    self.mainVc.pageindex = 2;
    
}

//データベースのデータを作成する
- (void)creatDBTable{
    [[FMDBTool sharedManager] Queue_createTableWith:[AnimationModel class] primaryKey:nil attribute:IntegerType DBName:animationDBName];
    [[FMDBTool sharedManager] Queue_createTableWith:[ShopModel class] primaryKey:nil attribute:IntegerType DBName:shopDBName];
    [[FMDBTool sharedManager] Queue_createTableWith:[TouristModel class] primaryKey:nil attribute:IntegerType DBName:eventDBName];
    [[FMDBTool sharedManager] Queue_createTableWith:[NoticeModel class] primaryKey:nil attribute:IntegerType DBName:noticeDBName];
    [[FMDBTool sharedManager] Queue_createTableWith:[PhotoModel class] primaryKey:nil attribute:IntegerType DBName:photoDBName];
    [[FMDBTool sharedManager] Queue_createTableWith:[NoticeModel class] primaryKey:nil attribute:IntegerType DBName:homeDBName];
    [[FMDBTool sharedManager] Queue_createTableWith:[MenuModel class] primaryKey:nil attribute:IntegerType DBName:menuDBName];
}

- (void)getMenuTypeArrayOfNotificationCenter:(NSNotification *)center{
    NSMutableArray *modelArray = [NSMutableArray arrayWithArray:[NetWorkManager getDBMenuKeyArray]];
    [modelArray removeObject:@"home"];
    [modelArray removeObject:@"setting"];
    NSNumber *number = [NSNumber numberWithUnsignedInteger:[modelArray indexOfObject:center.name]];
    self.mainVc.pageindex = [number intValue];
}

- (void)selectHome:(NSNotification *)notification{
    [self goToChooseModel:1];
    self.mainVc.pageindex = 0;
    NSString *errorMessage = [notification.userInfo valueForKey:@"error"];
    if (errorMessage.length>0) {
//        [NetWorkManager showAlertWithTitle:@"error" message:errorMessage];
    }
}

- (void)goToChooseModel:(NSInteger)state{
    if (state==0) {
        self.mainVc = [[MainViewController alloc] init];
        self.mainNc = [[UINavigationController alloc] initWithRootViewController:self.mainVc];
    }else if (state==1){
        self.homeVc = [[HomeViewController alloc] init];
        self.mainNc = [[UINavigationController alloc] initWithRootViewController:self.homeVc];
    }else if (state==2){
        self.settingVc = [[SettingViewController alloc] init];
        self.mainNc = [[UINavigationController alloc] initWithRootViewController:self.settingVc];
    }else if (state==3){
        self.launchVc = [[LaunchViewController alloc] init];
        self.mainNc = [[UINavigationController alloc] initWithRootViewController:self.launchVc];
    }
    else if (state==4){
        MyPockerDetailViewController *pocketVc = [[MyPockerDetailViewController alloc] init];
        self.mainNc = [[UINavigationController alloc] initWithRootViewController:pocketVc];
    }
    //UINavigationBar color
    [[UINavigationBar appearance]setBarTintColor:[NetWorkManager getBaseColor]];
    
    //UINavigationBar set Title Text color
    [[UINavigationBar appearance]setTitleTextAttributes:
  @{NSFontAttributeName:[UIFont systemFontOfSize:XSpan(16)],
    NSForegroundColorAttributeName:[NetWorkManager getTextColor]}];
    
    self.menuVc = [[MenuViewController alloc]init];
    self.mmdVc = [[MMDrawerController alloc]initWithCenterViewController:self.mainNc leftDrawerViewController:self.menuVc rightDrawerViewController:nil];
    [self.mmdVc setShowsShadow:NO];
    [self.mmdVc setShadowRadius:1.0];
    self.mmdVc.maximumLeftDrawerWidth = XSpan(150);
    [self.mmdVc setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeBezelPanningCenterView];
    [self.mmdVc setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
    self.window.rootViewController = self.mmdVc;
    
}

#pragma mark - zip
- (void)getZip{
    @try {
        //creat path
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSString *documentsPaths = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        NSString *folderPath = [documentsPaths stringByAppendingPathComponent:@"zip"];
        
        BOOL Exists = [fileManager fileExistsAtPath:folderPath];
        
        if(!Exists){
            //creat Floder
            BOOL res = [fileManager createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:nil];
            if (res) {
                NSLog(@"creat floder success");
            }else{
                NSLog(@"creat floder field");
            }
            
            NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"initial_pack" ofType:@"zip"];
            [SSZipArchive unzipFileAtPath:plistPath toDestination:folderPath delegate:self];
        }
        
    } @catch (NSException *exception) {
        NSLog(@"==========で%sエラーが出て:%@==========",__func__,exception);
    }
}

- (void)zipArchiveDidUnzipArchiveAtPath:(NSString *)path zipInfo:(unz_global_info)zipInfo unzippedPath:(NSString *)unzippedPath{
//    [info setObject:[NSString stringWithFormat:@"%@/initial_pack",unzippedPath] forKey:@"zipPath"];
    
    //取得ジェーソン
    NSString *jsonPath = [unzippedPath stringByAppendingPathComponent:@"/initial_pack/app_set_list.json"];
    NSError *error;
    NSString *jsonStr = [NSString stringWithContentsOfFile:jsonPath encoding:NSUTF8StringEncoding error:&error];
    
    
    NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&error];
    
    //基礎フィールドを保存する
    [info setObject:jsonDic forKey:@"jsonDic"];
    [info setObject:[jsonDic valueForKey:@"base_color"] forKey:@"base_color"];
    [info setObject:[jsonDic valueForKey:@"text_color"] forKey:@"text_color"];
    [info setObject:[jsonDic valueForKey:@"version"] forKey:@"version"];
    
    
    NSArray *menuArray = [[[jsonDic valueForKey:@"languages"] objectAtIndex:0]valueForKey:@"menus"];
    [info setObject:menuArray forKey:@"menuArray"];
    
    [info synchronize];
    for (NSDictionary *dic in menuArray) {
        NSMutableDictionary *dataDic = [NSMutableDictionary dictionary];
        dataDic = [NSMutableDictionary dictionaryWithDictionary:dic];
        [dataDic setValue:@"表示" forKey:@"status"];
        [[FMDBTool sharedManager]Queue_addDataToDataBase:dataDic DBName:menuDBName];
    }
}



@end
