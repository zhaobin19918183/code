//
//  TSsbpFacility.h
//
//  Copyright (c) 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_TFacility_h
#define SSBP_AppSDK_Static_TFacility_h

#import <Foundation/Foundation.h>

@interface TSsbpFacility : NSObject

@property (copy, nonatomic) NSString* facilityId;
@property (copy, nonatomic) NSString* facilityName;
@property (copy, nonatomic) NSString* uuid;

@end

#endif
