//
//  TSsbpEdge.h
//
//  Copyright (c) 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_TEdge_h
#define SSBP_AppSDK_Static_TEdge_h

#import <Foundation/Foundation.h>

@interface TSsbpEdge : NSObject

// ID
@property (assign, nonatomic) NSInteger nId;

// Edge Info
@property (copy, nonatomic) NSString* edgeId;
@property (copy, nonatomic) NSString* nodeOut;
@property (copy, nonatomic) NSString* nodeIn;
@property (assign, nonatomic) NSInteger cost;

@property (copy, nonatomic) NSString* createdDate;
@property (copy, nonatomic) NSString* updatedDate;

@end

#endif
