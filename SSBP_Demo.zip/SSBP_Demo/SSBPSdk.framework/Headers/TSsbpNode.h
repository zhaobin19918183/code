//
//  TSsbpNode.h
//
//  Copyright (c) 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_TNode_h
#define SSBP_AppSDK_Static_TNode_h

#import <Foundation/Foundation.h>

@interface TSsbpNode : NSObject

// ID
@property (assign, nonatomic) NSInteger nId;

// Node Info
@property (copy, nonatomic) NSString* nodeId;
@property (copy, nonatomic) NSString* nodeName;
@property (assign, nonatomic) NSInteger nodeType;
@property (copy, nonatomic) NSString* facilityId;
@property (copy, nonatomic) NSString* floorId;
@property (assign, nonatomic) NSInteger relativeX;
@property (assign, nonatomic) NSInteger relativeY;
@property (assign, nonatomic) NSInteger goalFlag;
@property (copy, nonatomic) NSString* iconImageURL;
@property (copy, nonatomic) NSData* iconImage;
@property (copy, nonatomic) NSString* beaconId;
@property (copy, nonatomic) NSString* nodeAction;

@property (copy, nonatomic) NSString* createdDate;
@property (copy, nonatomic) NSString* updatedDate;

@end

#endif
