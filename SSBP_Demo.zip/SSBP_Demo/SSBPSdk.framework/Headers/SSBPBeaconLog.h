//
//  SSBPBeaconLog.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_BeaconLog_h
#define SSBP_AppSDK_Static_BeaconLog_h

@interface SSBPBeaconLog : NSObject <NSCoding>

@property (copy, nonatomic) NSString* beaconId;
@property (assign, nonatomic) NSInteger proximity;
@property (copy, nonatomic) NSString* accuracy;
@property (copy, nonatomic) NSString* rssi;
@property (copy, nonatomic) NSString* latitude;
@property (copy, nonatomic) NSString* longitude;
@property (copy, nonatomic) NSString* gpsAccuracy;
@property (assign, nonatomic) NSInteger battery;
@property (strong, nonatomic) NSDate* timestamp;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
