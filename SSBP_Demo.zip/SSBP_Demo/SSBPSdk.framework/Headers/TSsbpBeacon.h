//
//  TSsbpBeacon.h
//
//  Copyright (c) 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_TBeacon_h
#define SSBP_AppSDK_Static_TBeacon_h

#import <Foundation/Foundation.h>

@interface TSsbpBeacon : NSObject

// ID
@property (assign, nonatomic) NSInteger nId;
// ビーコンID
@property (copy, nonatomic) NSString* beaconId;
// ビーコン名
@property (copy, nonatomic) NSString* beaconName;
// 識別子
@property (copy, nonatomic) NSString* uuid;
@property (copy, nonatomic) NSString* major;
@property (copy, nonatomic) NSString* minor;
// 距離(４段階)
@property (assign, nonatomic) NSInteger proximity;
// CoreBluetoothで判別に利用するもの
@property (copy, nonatomic) NSString* localName;
@property (copy, nonatomic) NSString* moduleId;
// GPSを取得して座標判定に利用するもの
@property (copy, nonatomic) NSString* latitude;
@property (copy, nonatomic) NSString* longitude;
@property (copy, nonatomic) NSString* altitude;
// 施設ID
@property (copy, nonatomic) NSString* facilityId;
// フロアID
@property (copy, nonatomic) NSString* floorId;
// ポジション
@property (assign, nonatomic) NSInteger relativeX;
@property (assign, nonatomic) NSInteger relativeY;
// 検知後のアクション種別
@property (copy, nonatomic) NSString* actions;

// CoreBluetoothで取得してログに利用するもの
@property (assign, nonatomic) NSInteger batteryLevel;
@property (assign, nonatomic) NSInteger rssi;

@property (copy, nonatomic) NSString* createdDate;
@property (copy, nonatomic) NSString* updatedDate;

@end

#endif
