//
//  SSBPContentLog.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_ContentLog_h
#define SSBP_AppSDK_Static_ContentLog_h

@interface SSBPContentLog : NSObject <NSCoding>

@property (assign, nonatomic) NSInteger type;
@property (copy, nonatomic) NSString* contentId;
@property (copy, nonatomic) NSString* beaconId;
@property (copy, nonatomic) NSString* latitude;
@property (copy, nonatomic) NSString* longitude;
@property (copy, nonatomic) NSString* accuracy;
@property (strong, nonatomic) NSDate* getTimestamp;
@property (strong, nonatomic) NSDate* useTimestamp;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
