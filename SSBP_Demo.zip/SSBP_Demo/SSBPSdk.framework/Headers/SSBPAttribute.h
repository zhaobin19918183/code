//
//  SSBPAttribute.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Attribute_h
#define SSBP_AppSDK_Static_Attribute_h

@interface SSBPAttribute : NSObject

@property (copy, nonatomic) NSString* attrId;
@property (copy, nonatomic) NSArray<NSString*>* answerId;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
