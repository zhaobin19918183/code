//
//  SSBPAnswer.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Answer_h
#define SSBP_AppSDK_Static_Answer_h

@interface SSBPAnswer : NSObject

@property (copy, nonatomic) NSString* answerId;
@property (copy, nonatomic) NSString* answerBody;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
