//
//  SSBPFacility.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Facility_h
#define SSBP_AppSDK_Static_Facility_h

#import "SSBPFloor.h"

@interface SSBPFacility : NSObject

@property (copy, nonatomic) NSString* facilityId;
@property (copy, nonatomic) NSString* facilityName;
@property (copy, nonatomic) NSString* uuid;
@property (copy, nonatomic) NSArray<SSBPFloor*>* floors;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
