//
//  SSBPQuestion.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Question_h
#define SSBP_AppSDK_Static_Question_h

#import "SSBPAnswer.h"

@interface SSBPQuestion : NSObject

@property (copy, nonatomic) NSString* attrId;
@property (copy, nonatomic) NSString* attrName;
@property (copy, nonatomic) NSString* attrDescription;
@property (assign, nonatomic) NSInteger multipleAllowed;
@property (copy, nonatomic) NSArray<SSBPAnswer*>* answers;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
