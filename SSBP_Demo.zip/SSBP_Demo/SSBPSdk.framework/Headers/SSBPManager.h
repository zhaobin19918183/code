//
//  SSBPManager.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Manager_h
#define SSBP_AppSDK_Static_Manager_h

#import "SSBPSysParam.h"
#import "SSBPLocale.h"
#import "SSBPFacility.h"
#import "SSBPBeacon.h"
#import "SSBPContent.h"
#import "SSBPQuestion.h"
#import "SSBPAttribute.h"
#import "SSBPNode.h"
#import "SSBPEdge.h"
#import "SSBPRoute.h"
#import "SSBPBeaconLog.h"
#import "SSBPContentLog.h"
#import "SSBPGeofence.h"

@interface SSBPManager : NSObject

@property (copy, nonatomic) NSString* localeId;
@property (copy, nonatomic, readonly) NSString* localeDefault;
@property (copy, nonatomic, readonly) NSString* deviceId;
@property (copy, nonatomic) NSString* deviceToken;
@property (copy, nonatomic, readonly) NSString* mqUUID;

+ (SSBPManager*)sharedManager;

- (BOOL)initialize:(NSArray<SSBPStore*>*)parameters storeKey:(NSString*)storeKey;
- (BOOL)setSessionParam:(NSInteger)timeoutInterval retryCount:(NSInteger)retryCount retryInterval:(NSInteger)retryInterval;
- (void)authentication:(void(^)(BOOL status, NSError* error))result;

- (void)getSysParams:(void(^)(NSArray<SSBPSysParam*>* ssbpSysParams, NSError* error))result;
- (void)getLocales:(void(^)(NSArray<SSBPLocale*>* ssbpLocales, NSError* error))result;

- (void)getDeltaFacilities:(NSString*)since completionHandler:(void(^)(NSArray<SSBPFacility*>* ssbpAddFacilities, NSArray<SSBPFacility*>* ssbpDelFacilities, NSError* error))result;
- (void)getDeltaBeacons:(NSString*)since completionHandler:(void(^)(NSArray<SSBPBeacon*>* ssbpAddBeacons, NSArray<SSBPBeacon*>* ssbpDelBeacons, NSError* error))result;
- (void)getDeltaNodes:(NSString*)since facilityId:(NSString*)facilityId floorId:(NSString*)floorId completionHandler:(void(^)(NSArray<SSBPNode*>* ssbpAddNodes, NSArray<SSBPNode*>* ssbpDelNodes, NSError* error))result;
- (void)getDeltaEdges:(NSString*)since facilityId:(NSString*)facilityId completionHandler:(void(^)(NSArray<SSBPEdge*>* ssbpAddEdges, NSArray<SSBPEdge*>* ssbpDelEdges, NSError* error))result;

- (void)getDeltaGeofences:(NSString*)since completionHandler:(void(^)(NSArray<SSBPGeofence*>* ssbpAddGeofences, NSArray<SSBPGeofence*>* ssbpDelGeofences, NSError* error))result;

- (void)getDeltaPublicFacilities:(NSString*)since completionHandler:(void(^)(NSArray<SSBPFacility*>* ssbpAddFacilities, NSArray<SSBPFacility*>* ssbpDelFacilities, NSError* error))result;
- (void)getDeltaPublicBeacons:(NSString*)since completionHandler:(void(^)(NSArray<SSBPBeacon*>* ssbpAddBeacons, NSArray<SSBPBeacon*>* ssbpDelBeacons, NSError* error))result;

- (void)getFacilities:(void(^)(NSArray<SSBPFacility*>* ssbpFacilities, NSError* error))result;
- (void)getBeacons:(void(^)(NSArray<SSBPBeacon*>* ssbpBeacons, NSError* error))result;
- (void)getBeaconContents:(NSString*)beaconId completionHandler:(void(^)(NSArray<SSBPContent*>* ssbpContents, NSError* error))result;

- (void)getGeofenceContents:(NSString*)geofenceId completionHandler:(void(^)(NSArray<SSBPContent*>* ssbpContents, NSError* error))result;

- (void)getUtilityContents:(void(^)(NSArray<SSBPContent*>* ssbpContents, NSError* error))result;

- (void)getAttributes:(void(^)(NSArray<SSBPQuestion*>* ssbpQuestions, NSError* error)) result;
- (void)getDeviceInfo:(void(^)(NSArray<SSBPAttribute*>* ssbpAttributes, NSError* error))result;
- (void)updateDeviceInfo:(NSArray<SSBPAttribute*>*)params completionHandler:(void(^)(NSString* deviceId, NSError* error))result;

- (void)getNodes:(NSString*)facilityId floorId:(NSString*)floorId completionHandler:(void(^)(NSArray<SSBPNode*>* ssbpNodes, NSError* error))result;
- (void)getEdges:(NSString*)facilityId completionHandler:(void(^)(NSArray<SSBPEdge*>* ssbpEdges, NSError* error))result;
- (void)getRoute:(NSString*)startNodeId goalNodeId:(NSString*)goalNodeId completionHandler:(void(^)(NSArray<SSBPRoute*>* ssbpRoute, NSError* error))result;

- (void)storeBeaconLog:(NSArray<SSBPBeaconLog*>*)logs;
- (void)allClearBeaconLog;
- (void)addBeaconLog:(void(^)(NSError* error))result;
- (void)addBeaconLogMq:(void(^)(NSError* error))result;

- (void)storeContentLog:(NSArray<SSBPContentLog*>*)logs;
- (void)allClearContentLog;
- (void)addContentLog:(void(^)(NSError* error))result;

- (void)setDeviceLocale:(void(^)(BOOL change, NSError* error))result;

- (void)registerDeviceToken:(NSData*)deviceToken;

- (NSString*)makeAuthDigest;

@end

#endif
