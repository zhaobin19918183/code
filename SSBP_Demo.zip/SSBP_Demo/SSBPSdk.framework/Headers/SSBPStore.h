//
//  SSBPStore.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Store_h
#define SSBP_AppSDK_Static_Store_h

@interface SSBPStore : NSObject

@property (copy, nonatomic) NSString* key;
@property (copy, nonatomic) NSString* value;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
