//
//  SSBPGeofence.h
//  SSBPSdk
//
//  Copyright (c) 2016年 Switch Smile Co., Ltd. All rights reserved.
//

#ifndef SSBP_AppSDK_Static_Geofence_h
#define SSBP_AppSDK_Static_Geofence_h

@interface SSBPGeofence : NSObject

@property (copy, nonatomic) NSString* geofenceId;
@property (copy, nonatomic) NSString* geofenceMessage;
@property (copy, nonatomic) NSString* latitude;
@property (copy, nonatomic) NSString* longitude;
@property (assign, nonatomic) double radius;
@property (strong, nonatomic) NSDate* geofenceStartAt;
@property (strong, nonatomic) NSDate* geofenceEndAt;

- (NSString*)makeStringForDigest;
- (void)initWithDictionary:(NSDictionary*)dictionary;

@end

#endif
