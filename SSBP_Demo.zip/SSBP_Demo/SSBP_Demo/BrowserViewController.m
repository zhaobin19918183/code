//
//  BrowserViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define UIKitLocalizedString(key) [[NSBundle bundleWithIdentifier:@"com.apple.UIKit"] localizedStringForKey:key value:@"" table:nil]

#import "BrowserViewController.h"

#import "VideoViewController.h"

@implementation BrowserViewController {
    __weak IBOutlet UIWebView* webview;
    __weak IBOutlet UIView* webWait;

    __weak IBOutlet UIButton* btnBack;
    __weak IBOutlet UIButton* btnForward;
    __weak IBOutlet UIButton* btnReload;
    __weak IBOutlet UIButton* btnSafari;
    __weak IBOutlet UIButton* btnClose;
}

- (void)awakeFromNib {
    [super awakeFromNib];

    self.url = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnForward != nil) {
        btnForward.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnReload != nil) {
        btnReload.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnSafari != nil) {
        btnSafari.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnClose != nil) {
        btnClose.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }

    // storyboardでの設定を忘れた場合の保険
    if (webview != nil) {
        [webview setScalesPageToFit:true];
    }

    webview.delegate = self;
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.url] cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:60.0];
    [webview loadRequest:request];
    //[webview loadRequest:request progress:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) { } success:^NSString* (NSHTTPURLResponse* response, NSString* HTML) { return HTML; } failure:^(NSError* error) { }];
    // appleがjavascriptcoreを修正したlibWTFをリリースしない限り、memory leakが発生するはず
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    webview.delegate = self;
}

- (void)viewDidDisappear:(BOOL)animated {
    [self stopActivityIndicator];
    [webview stopLoading];
    webview.delegate = nil;

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return true;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    UIDeviceOrientation rotate = [UIDevice currentDevice].orientation;
    switch (rotate) {
        case UIDeviceOrientationPortrait:
            return UIInterfaceOrientationPortrait;
            break;
        case UIDeviceOrientationLandscapeLeft:
            return UIInterfaceOrientationLandscapeRight;
            break;
        case UIDeviceOrientationLandscapeRight:
            return UIInterfaceOrientationLandscapeLeft;
            break;
        default:
            return UIInterfaceOrientationPortrait;
            break;
    }
}

#pragma mark -
#pragma mark IBOutlet Events

- (IBAction)didPushBack:(UIButton*)sender {
    [webview goBack];
}

- (IBAction)didPushForward:(UIButton*)sender {
    [webview goForward];
}

- (IBAction)didPushReload:(UIButton*)sender {
    // キャッシュをクリアする必要がある場合、この方法しかなさそう
    //[[NSURLCache sharedURLCache] removeAllCachedResponses];
    [webview reload];
}

- (IBAction)didPushSafari:(UIButton*)sender {
    [self showAlert:2 title:@"" message:NSLocalizedString(@"captionSafariMessage", @"") handler:^(UIAlertAction *action) {
        NSString* URLString = [webview stringByEvaluatingJavaScriptFromString:@"document.URL"];
        NSURL* URL = [NSURL URLWithString:URLString];
        [[UIApplication sharedApplication] openURL:URL];
    }];
}

- (IBAction)didPushClose:(UIButton*)sender {
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

#pragma mark -
#pragma mark Private Method

- (void)startActivityIndicator {
    webWait.hidden = false;

    [[UIApplication sharedApplication]setNetworkActivityIndicatorVisible:true];
    [self updateBrowserButtonStatus];
}

- (void)stopActivityIndicator {
    webWait.hidden = true;

    [[UIApplication sharedApplication]setNetworkActivityIndicatorVisible:false];
    [self updateBrowserButtonStatus];
}

// ボタンの状態を更新
- (void)updateBrowserButtonStatus {
    btnBack.enabled = webview.canGoBack;
    btnForward.enabled = webview.canGoForward;
}

#pragma mark -
#pragma mark WebViewDelegate override

- (void)webViewDidStartLoad:(UIWebView*)webView {
    [self startActivityIndicator];
}

- (void)webViewDidFinishLoad:(UIWebView*)webView {
    [self stopActivityIndicator];
    NSString* strUrl = [webview stringByEvaluatingJavaScriptFromString:@"document.URL"];
    NSLog(@"FinishLoad url:%@", strUrl);
    NSString* strTitle = [webview stringByEvaluatingJavaScriptFromString:@"document.title"];
    NSLog(@"FinishLoad title:%@", strTitle);

    // バウンスをさせないためのおまじない
    webView.scrollView.bounces = false;
}

- (BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType {
    NSLog(@"request:%@", request);
    NSLog(@"navigationType(%ld)", (long)navigationType);

    // なぜか動かなくなってしまったため、下記のように明記するように修正
    NSURL* url = request.URL;
    if ([url.scheme isEqualToString:@"tel"]) {
        [self stopActivityIndicator];
        [webview stopLoading];

        if ([[UIApplication sharedApplication] canOpenURL:request.URL]) {
            NSString* message = [request.URL.relativeString stringByReplacingOccurrencesOfString:@"tel:" withString:@""];
            [self showAlert:1 title:@"" message:message handler:^(UIAlertAction *action) {
                [[UIApplication sharedApplication]openURL:request.URL];
            }];

            return false;
        }
    }

    if (![url.scheme isEqualToString:@"http"] && ![url.scheme isEqualToString:@"https"] && ![url.scheme isEqualToString:@"file"]) {
        if ([[UIApplication sharedApplication]canOpenURL:url]) {
            [self stopActivityIndicator];
            [webview stopLoading];

            if (navigationType != UIWebViewNavigationTypeLinkClicked) {
                [self.navigationController popViewControllerAnimated:false];
            }
            [[UIApplication sharedApplication]openURL:url];

            return false;
        }
    }

    // iOS8以降から、動画再生のviewが終了しても生き残るようになったので、回避させる方法として以下の対応
    // iOS8未満も、この方法がすっきり動作で良好と思われる
    // サポートする拡張子に変動がある場合は増減すること
    // ただし、ブラウザでも対応できないavi/mpeg/mpv/amr/oggは動作しないが、VideoViewControllerで吸収させるものとする
    if (navigationType == UIWebViewNavigationTypeLinkClicked) {
        NSArray* supported = [NSArray arrayWithObjects:@"mp4", @"3gp", @"mov", @"avi", @"mpeg", @"mpv", @"aac", @"amr", @"mp3", @"aiff", @"caf", @"m4a", @"ogg", @"wav", nil];
        NSString* path = [url absoluteString];
        NSString* ext = [path pathExtension];

        if ([supported containsObject:ext]) {
            [self stopActivityIndicator];
            [webview stopLoading];

            dispatch_async(dispatch_get_main_queue(), ^{
                VideoViewController* video = [VideoViewController new];
                video.url = path;
                video.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                [self presentViewController:video animated:true completion:NULL];
            });

            return false;
        }
    }

    return true;
}

- (void)webView:(UIWebView*)webView didFailLoadWithError:(NSError*)error {
    [self stopActivityIndicator];

    NSLog(@"webView didFailLoadWithError:");
    if (error == nil) return;
    NSLog(@"%@", [error description]);
    NSLog(@"code(%ld)", (long)error.code);

    // 動画再生の場合
    if ((error.code == 204) && [error.domain isEqualToString:@"WebKitErrorDomain"]) {
        // 必ずpluginエラーが発生するため、この場合は正常とする
        return;
    }

    // AppStoreへのリンクの場合
    if ((error.code == 102) && [error.domain isEqualToString:@"WebKitErrorDomain"]) {
        return;
    }

    if (error.code == NSURLErrorCancelled) {
        return;
    }

    NSString* title = [error.userInfo objectForKey:@"NSErrorFailingURLStringKey"];
    NSString* message = error.localizedDescription;
    [self showAlert:0 title:title message:message handler:nil];
}

#pragma mark -
#pragma mark View Change

- (void)showAlert:(NSInteger)type title:(NSString*)title message:(NSString*)message handler:(void (^ __nullable)(UIAlertAction *action))handler {
    NSString* pos = nil;
    NSString* neg = nil;

    if (type == 0) { // Fail Load
        pos = UIKitLocalizedString(@"OK");
        neg = nil;
    } else if (type == 1) { // Open tel:
        pos = NSLocalizedString(@"captionTelButton", @"");
        neg = UIKitLocalizedString(@"Cancel");
    } else if (type == 2) { // Open Safari
        pos = NSLocalizedString(@"captionSafariButton", @"");
        neg = UIKitLocalizedString(@"Cancel");
    } else {
        return;
    }

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:handler]];
    if (neg != nil) {
        [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:nil]];
    }

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

@end
