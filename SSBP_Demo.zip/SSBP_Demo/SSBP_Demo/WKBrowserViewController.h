//
//  WKBrowserViewController.h
//
//  Created by Ayumi Togashi on 2016/06/17.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface WKBrowserViewController : UIViewController<WKNavigationDelegate>

@property (copy, nonatomic) NSString* url;

@end
