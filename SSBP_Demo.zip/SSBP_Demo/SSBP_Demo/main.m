//
//  main.m
//  SSBP_Demo
//
//  Created by Ayumi Togashi on 2017/05/17.
//  Copyright © 2017年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
