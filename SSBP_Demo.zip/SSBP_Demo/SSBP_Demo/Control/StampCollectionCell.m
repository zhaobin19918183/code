//
//  StampCollectionCell.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#import "StampCollectionCell.h"

@implementation StampCollectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setStatus:(NSInteger)status {
    self.layer.borderWidth = 0.75;
    self.layer.borderColor = RGBA(160, 160, 160, 0.8).CGColor;
    self.layer.cornerRadius = 4;

    if (status == 1) {
        [self.done setHidden:false];
        [self.yet setHidden:true];
    } else {
        [self.done setHidden:true];
        [self.yet setHidden:false];
    }
}

@end
