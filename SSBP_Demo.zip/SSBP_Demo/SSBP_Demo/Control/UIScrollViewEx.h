//
//  UIScrollViewEx.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollViewEx : UIScrollView

@end
