//
//  OverallView.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SSBPSdkIF.h"

@protocol OverallDelegate <NSObject>

@optional

- (void)didSetSize;

@end

@interface OverallView : UIImageView

@property (weak, nonatomic) id<OverallDelegate>delegateO;

@property (copy, nonatomic) NSString* nowNodeId;
@property (copy, nonatomic) NSArray<TSsbpFloor*>* floorList;
@property (copy, nonatomic) NSArray<TSsbpNode*>* routeList;
@property (copy, nonatomic) NSArray<TSsbpBeaconAction*>* actionList;
@property (copy, nonatomic) NSArray<TSsbpNode*>* actionNodes;

- (void)setDraw:(CGSize)baseSize;

@end
