//
//  GoalTreeNode.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GoalTreeNode : NSObject

@property (copy, nonatomic) NSString* nodeId;
@property (copy, nonatomic) NSString* title;
@property (assign, nonatomic) BOOL isExpand;
@property (assign, nonatomic) NSInteger level;
@property (copy, nonatomic) NSArray<GoalTreeNode*>* children;

- (void)addChild:(GoalTreeNode*)newChild;

@end
