//
//  StampCollectionCell.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StampCollectionCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView* done;
@property (weak, nonatomic) IBOutlet UIImageView* yet;
@property (weak, nonatomic) IBOutlet UILabel* title;

- (void)setStatus:(NSInteger)status;

@end
