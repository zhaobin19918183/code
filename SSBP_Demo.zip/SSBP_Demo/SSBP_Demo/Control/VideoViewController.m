//
//  VideoViewController.m
//
//  Created by Ayumi Togashi on 2017/05/24.
//  Copyright © 2017年 Switch Smile co.,ltd. All rights reserved.
//

#import "VideoViewController.h"

@implementation VideoViewController {
    AVPlayerViewController* moviePlayer;
}

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    moviePlayer = [AVPlayerViewController new];
    moviePlayer.view.frame = self.view.frame;
    AVPlayerItem* playerItem = [[AVPlayerItem alloc] initWithURL:[NSURL URLWithString:self.url]];
    AVPlayer* player = [[AVPlayer alloc] initWithPlayerItem:playerItem];
    moviePlayer.player = player;

    [self addChildViewController:moviePlayer];
    [self.view addSubview:moviePlayer.view];

    [moviePlayer.player addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];

    [NSNotificationCenter.defaultCenter addObserver:self
                                           selector:@selector(didMoviePlayerFinished:)
                                               name:AVPlayerItemDidPlayToEndTimeNotification
                                             object:playerItem];}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (BOOL)prefersStatusBarHidden {
    return true;
}

- (UIModalPresentationStyle)modalPresentationStyle {
    return UIModalPresentationFullScreen;
}

#pragma mark -
#pragma mark 開始処理

- (void)observeValueForKeyPath:(NSString*)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id>*)change context:(void*)context {
    // イベント削除
    switch (moviePlayer.player.status) {
        case AVPlayerItemStatusReadyToPlay:
            // イベント削除
            [moviePlayer.player removeObserver:self forKeyPath:@"status"];

            // 再生開始
            [moviePlayer.player play];
            return;
        default:
            break;
    }
    [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
}

#pragma mark -
#pragma mark 終了処理

- (void)didMoviePlayerFinished:(NSNotification*)notification {
    AVPlayerItem* playerItem = [notification object];
    // イベント削除
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:playerItem];

    // 中断の場合に落ちる事例有、以下の処理で対処できたため念のため残す
    [moviePlayer.player pause];
    [moviePlayer.player setActionAtItemEnd:AVPlayerActionAtItemEndNone];

    // 画面終了
    [self dismissViewControllerAnimated:false completion:^{
        [moviePlayer willMoveToParentViewController:nil];
        [moviePlayer.view removeFromSuperview];
        [moviePlayer removeFromParentViewController];
    }];
}

@end
