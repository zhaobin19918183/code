//
//  CouponCell.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "CouponCell.h"

@implementation CouponCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setStatus:(NSInteger)status {
    if (status == 1) {
        [self.markUse setHidden:false];
    } else {
        [self.markUse setHidden:true];
    }
}

@end
