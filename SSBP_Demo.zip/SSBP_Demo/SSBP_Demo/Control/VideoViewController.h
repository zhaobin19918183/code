//
//  VideoViewController.h
//
//  Created by Ayumi Togashi on 2017/05/24.
//  Copyright © 2017年 Switch Smile co.,ltd. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

@interface VideoViewController : UIViewController

@property (copy, nonatomic) NSString* url;

@end


