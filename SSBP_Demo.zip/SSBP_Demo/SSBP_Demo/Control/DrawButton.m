//
//  DrawButton.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "DrawButton.h"

@implementation DrawButton

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
    }
    return self;
}

// storyboard上で反映するにはこれが必要
- (void)prepareForInterfaceBuilder {
    [self drawRect:self.bounds];
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];

    self.layer.cornerRadius = self.cornerRadius;
    self.layer.borderWidth = self.borderWidth;

    if (self.borderColor != nil) {
        self.layer.borderColor = self.borderColor.CGColor;
    } else {
        self.layer.borderColor = nil;
    }

    [self.layer setMasksToBounds:true];

    if ((self.topColor != nil) && (self.bottomColor != nil)) {
        CAGradientLayer* gradientLayer = [CAGradientLayer layer];
        gradientLayer.frame = rect;

        if (self.centerColor == nil) {
            gradientLayer.colors = [NSArray arrayWithObjects: (id)self.topColor.CGColor, (id)self.bottomColor.CGColor, nil];
            gradientLayer.locations = @[@0.0, @1.0];
        } else {
            gradientLayer.colors = [NSArray arrayWithObjects: (id)self.topColor.CGColor, (id)self.centerColor.CGColor, (id)self.centerColor.CGColor, (id)self.bottomColor.CGColor, nil];
            gradientLayer.locations = @[@0.0, @0.5, @0.51, @1.0];
        }

        gradientLayer.startPoint = CGPointMake(0, 0);
        gradientLayer.endPoint = CGPointMake(0, 1);

        UIGraphicsBeginImageContextWithOptions(rect.size, false, 0);
        [gradientLayer renderInContext:UIGraphicsGetCurrentContext()];
        UIImage* image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();

        [self setBackgroundImage:image forState:UIControlStateNormal];
    }
}

@end
