//
//  GoalTreeNode.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "GoalTreeNode.h"

@implementation GoalTreeNode

- (void)addChild:(GoalTreeNode*)newChild {
    @autoreleasepool {
        if (self.children == nil) self.children = [NSArray array];
        newChild.level = self.level + 1;

        NSMutableArray* tempArray = [self.children mutableCopy];
        [tempArray addObject:newChild];
        self.children = [tempArray copy];
    }
}

@end
