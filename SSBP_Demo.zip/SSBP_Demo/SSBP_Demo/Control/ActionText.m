//
//  ActionText.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#import "ActionText.h"

@implementation ActionText {
    UIView* actionView;
    UIView* actionHeader;
    UIPickerView* picker;

    NSDictionary* list;
    BOOL isMove;

    NSString* tagString;
}

- (void)awakeFromNib {
    [super awakeFromNib];

    self.frame = CGRectZero; //ダミーなので表示しない
    self.hidden = true; // 念のため非表示
}

- (void)dealloc {
    for (UIGestureRecognizer* ges in picker.gestureRecognizers) {
        ges.delegate = nil;
    }
    picker.delegate = nil;
    picker = nil;
    for (UIView* view in actionHeader.subviews) {
        [view removeFromSuperview];
    }
    for (UIView* view in actionView.subviews) {
        [view removeFromSuperview];
    }
    self.inputView = nil;
    self.inputAccessoryView = nil;
}

- (void)setView:(CGSize)baseSize {
    @autoreleasepool {
        UIColor* topColor = RGBA(255, 255, 255, 0.2);
        UIColor* centerColor = RGBA(255, 255, 255, 0.15);
        UIColor* bottomColor = RGBA(255, 255, 255, 0.1);

        float btnHeight = 44;
        float btnWidth = baseSize.width / 8;

        CGRect doneRect = CGRectMake(0, 0, btnWidth * 2, btnHeight);
        DrawButton* doneBtn = [DrawButton buttonWithType:UIButtonTypeCustom];
        [doneBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [doneBtn setTitle:@"Done" forState:UIControlStateNormal];
        doneBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        doneBtn.frame = CGRectInset(doneRect, 5, 5);
        [doneBtn addTarget:self action:@selector(didFinishSelect) forControlEvents:UIControlEventTouchUpInside];
        doneBtn.topColor = topColor;
        doneBtn.centerColor = centerColor;
        doneBtn.bottomColor = bottomColor;
        doneBtn.borderColor = [UIColor whiteColor];
        doneBtn.borderWidth = 0.75;
        doneBtn.cornerRadius = 6;

        CGRect cancelRect = CGRectMake(btnWidth * 5, 0, btnWidth * 3, btnHeight);
        DrawButton* cancelBtn = [DrawButton buttonWithType:UIButtonTypeCustom];
        [cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [cancelBtn setTitle:@"Cancel" forState:UIControlStateNormal];
        cancelBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        cancelBtn.frame = CGRectInset(cancelRect, 5, 5);
        [cancelBtn addTarget:self action:@selector(cancelSelect) forControlEvents:UIControlEventTouchUpInside];
        cancelBtn.topColor = topColor;
        cancelBtn.centerColor = centerColor;
        cancelBtn.bottomColor = bottomColor;
        cancelBtn.borderColor = [UIColor whiteColor];
        cancelBtn.borderWidth = 0.75;
        cancelBtn.cornerRadius = 6;

        // ピッカーの作成
        float pickerWidth = baseSize.width - 20;
        float pickerHeight = pickerWidth * 0.5;

        picker = [[UIPickerView alloc] initWithFrame:CGRectMake(10, 44 + 10, pickerWidth, pickerHeight)];
        picker.backgroundColor = [UIColor whiteColor];
        picker.dataSource = self;
        picker.delegate = self;
        picker.showsSelectionIndicator = true;

        UITapGestureRecognizer* tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pickerViewHitTest:)];
        tap.delegate = self;
        [picker addGestureRecognizer:tap];

        actionHeader = [[UIView alloc] initWithFrame:CGRectMake(0, 0, baseSize.width, 44)];
        actionHeader.backgroundColor = RGBA(76, 172, 155, 1.0);
        [actionHeader addSubview:doneBtn];
        [actionHeader addSubview:cancelBtn];

        // アクションシート代替えのUITextFieldへの埋め込み
        actionView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, baseSize.width, picker.frame.origin.y + picker.bounds.size.height + 10)];
        [actionView setBackgroundColor:RGBA(218, 255, 230, 1.0)];
        [actionView addSubview:picker];
        [actionView addSubview:actionHeader];
        self.inputView = actionView;

        UIView* accessoryView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, baseSize.width, baseSize.height - actionView.frame.size.height)];
        accessoryView.backgroundColor = [UIColor clearColor];
        self.inputAccessoryView = accessoryView;
    }
}

- (void)showPickerView:(NSString*)type key:(NSString*)key dic:(NSDictionary*)dic {
    tagString = type;
    list = [dic copy];

    // 初期表示時に選択状態にする
    [picker reloadAllComponents];

    NSArray* keys = [list allKeys];
    keys = [keys sortedArrayUsingComparator:^(id o1, id o2) {
        return [o1 compare:o2];
    }];
    if ((key != nil) && (key.length > 0)) {
        NSInteger index = [keys indexOfObject:key];
        if (index == NSNotFound) index = 0;
        [picker selectRow:index inComponent:0 animated:false];
    } else {
        [picker selectRow:0 inComponent:0 animated:false];
    }

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            [self becomeFirstResponder];
        });
    });
}

- (void)actionTextOpen {
    @autoreleasepool {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.2];
        [UIView setAnimationDelay:0.0];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
        [self becomeFirstResponder];
        [UIView commitAnimations];
    }
}

- (void)actionTextClose {
    @autoreleasepool {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [UIView setAnimationDelay:0.0];
        [UIView setAnimationCurve:UIViewAnimationCurveLinear];
        [self resignFirstResponder];
        [UIView commitAnimations];
    }
}

- (void)cancelSelect {
    [self actionTextClose];
}

- (void)didFinishSelect {
    if (self.delegateAT && [self.delegateAT respondsToSelector:@selector(actionTextDidSelect:selected:)]) {
        NSInteger selected = [picker selectedRowInComponent:0];
        NSArray* keys = [list allKeys];
        keys = [keys sortedArrayUsingComparator:^(id o1, id o2) {
            return [o1 compare:o2];
        }];
        if (keys.count > selected) {
            [self.delegateAT actionTextDidSelect:tagString selected:keys[selected]];
        } else {
            [self.delegateAT actionTextDidSelect:tagString selected:@""];
        }
    }

    [self actionTextClose];
}

#pragma mark -
#pragma mark UIPickerViewDataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView*)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView*)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [list count];
}

#pragma mark -
#pragma mark UIPickerViewDelegate

- (NSString*)pickerView:(UIPickerView*)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSArray* keys = [list allKeys];
    keys = [keys sortedArrayUsingComparator:^(id o1, id o2) {
        return [o1 compare:o2];
    }];
    return [list objectForKey:keys[row]];
}

#pragma mark -
#pragma mark UIGestureRecognizerDelegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer*)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer*)otherGestureRecognizer {
    return true;
}

- (void)touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event {
    isMove = false;
}

- (void)touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event {
    isMove = true;
}

- (void)pickerViewHitTest:(UIGestureRecognizer*)sender {
    if (!isMove) {
        if (sender.state == UIGestureRecognizerStateEnded) {
            @autoreleasepool {
                CGPoint tapPoint = [sender locationInView:sender.view];
                CGRect rect = CGRectInset(picker.bounds, 0, picker.frame.size.height * 0.4);
                if (CGRectContainsPoint(rect, tapPoint)) {
                    [self didFinishSelect];
                }
            }
        }
    }
}

@end
