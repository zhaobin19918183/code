//
//  ActionText.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DrawButton.h"

@protocol ActionTextDelegate <NSObject>

@optional

- (void)actionTextDidSelect:(NSString*)type selected:(NSString*)selected;

@end

@interface ActionText : UITextField<UIPickerViewDelegate, UIPickerViewDataSource, UIGestureRecognizerDelegate>

@property (weak, nonatomic) id<ActionTextDelegate>delegateAT;

- (void)setView:(CGSize)baseSize;
- (void)showPickerView:(NSString*)type key:(NSString*)key dic:(NSDictionary*)dic;

@end
