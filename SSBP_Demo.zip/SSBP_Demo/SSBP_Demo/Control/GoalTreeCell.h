//
//  GoalTreeCell.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoalTreeCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView* expand;
@property (weak, nonatomic) IBOutlet UILabel* title;

@property (assign, nonatomic) NSInteger level;

@end
