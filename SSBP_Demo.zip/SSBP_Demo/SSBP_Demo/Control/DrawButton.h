//
//  DrawButton.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE

@interface DrawButton : UIButton

@property (copy, nonatomic) NSString* tagString;

@property (nonatomic) IBInspectable UIColor* topColor;
@property (nonatomic) IBInspectable UIColor* centerColor;
@property (nonatomic) IBInspectable UIColor* bottomColor;
@property (nonatomic) IBInspectable CGFloat cornerRadius;
@property (nonatomic) IBInspectable CGFloat borderWidth;
@property (nonatomic) IBInspectable UIColor* borderColor;

@end
