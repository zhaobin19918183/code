//
//  SettingPickerButton.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "SettingPickerButton.h"

@implementation SettingPickerButton

- (void)awakeFromNib {
    [super awakeFromNib];
}

@end
