//
//  OverallView.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define MARK_SCALE 8.6
#define MARK_OFFSET 60 // statusbar

#import "OverallView.h"

@implementation OverallView {
    UIImage* nowImage;
    UIImage* infoActImage;
    UIImage* infoDisImage;
    UIImage* startImage;
    UIImage* goalImage;
    UIImage* upImage;
    UIImage* downImage;
    UIImage* moveImage;

    CGFloat scale_map;
    CGFloat base_width;
    CGFloat base_height;

    SSBPHttpRequester* requester;
}

- (void)awakeFromNib {
    [super awakeFromNib];
}

#pragma mark -
#pragma mark Delay Event

- (void)setRedraw {
    [self setDraw:CGSizeMake(base_width, base_height)];
}

#pragma mark -
#pragma mark private

- (TSsbpFloor*)getFloor:(NSString*)floorId {
    if ((self.floorList != nil) && (self.floorList.count > 0)) {
        for (TSsbpFloor* floor in self.floorList) {
            if ([[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:floorId]) return floor;
        }
    }
    return nil;
}

#pragma mark -
#pragma mark Draw

- (void)setDraw:(CGSize)baseSize {
    base_width = (CGFloat)baseSize.width;
    base_height = (CGFloat)baseSize.height;

    if ((self.floorList == nil) || (self.floorList.count == 0)) {
        return;
    }

    CGFloat offsetY = 0;
    scale_map = 1;
    for (NSInteger index = self.floorList.count - 1; index >= 0; index--) {
        __block TSsbpFloor* floor = [self.floorList objectAtIndex:index];
        UIImage* floorImage = [[UIImage alloc] initWithData:floor.mapImage];
        if (floorImage == nil) {
            if ([floor.mapImageURL hasPrefix:@"http"]) {
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    if (requester == nil) requester = [SSBPHttpRequester new];
                    [requester httpRequestGet:floor.mapImageURL withParam:nil completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
                        if ((error != nil) || (data == nil)) return;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            floor.mapImage = data;
                            [[SSBPScannerManager sharedManager] addFloor:floor];

                            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(setRedraw) object:nil];
                            [self performSelector:@selector(setRedraw) withObject:nil afterDelay:1];
                        });
                    }];
                });
            }
        }
        if (floorImage == nil) continue;

        CGFloat width = (float)floorImage.size.width;
        CGFloat height = (float)floorImage.size.height;
        scale_map = base_width / width;
        if (scale_map == 0) continue;

        if (offsetY != 0) offsetY += 20;

        offsetY += height * scale_map;
    }
    self.frame = CGRectMake(0, 0, baseSize.width, offsetY);
    [self draw:self.frame.size];

    if (self.delegateO && [self.delegateO respondsToSelector:@selector(didSetSize)]) {
        [self.delegateO didSetSize];
    }
}

- (void)draw:(CGSize)drawSize {
    if ((self.floorList == nil) || (self.floorList.count == 0)) return;

    @autoreleasepool {
        if (nowImage == nil) nowImage = [self pathForResource:@"now"];
        if (infoActImage == nil) infoActImage = [self pathForResource:@"contents_on"];
        if (infoDisImage == nil) infoDisImage = [self pathForResource:@"contents_off"];
        if (startImage == nil) startImage = [self pathForResource:@"start"];
        if (goalImage == nil) goalImage = [self pathForResource:@"goal"];
        if (downImage == nil) downImage = [self pathForResource:@"step_down"];
        if (upImage == nil) upImage = [self pathForResource:@"step_up"];
        if (moveImage == nil) moveImage = [self pathForResource:@"step_move"];

        TSsbpNode* nowNode = [[SSBPScannerManager sharedManager] getInnerNode:self.nowNodeId];

        // 描画開始
        UIGraphicsBeginImageContextWithOptions(drawSize, false, 0);
        CGContextRef context = UIGraphicsGetCurrentContext();
        if (context == nil) {
            UIGraphicsEndImageContext();
            return;
        }

        // 表示のソート複数条件(階数昇順, 登録順降順)
        NSSortDescriptor* floorNumDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"self.floorNum" ascending:true];
        NSSortDescriptor* nIdDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"self.nId" ascending:false];
        NSArray* sortedFloorList = (NSMutableArray *)[self.floorList sortedArrayUsingDescriptors:@[floorNumDescriptor, nIdDescriptor]];

        CGFloat offsetY = 0;
        scale_map = 1;
        for (NSInteger index = sortedFloorList.count - 1; index >= 0; index--) {
            TSsbpFloor* floor = [sortedFloorList objectAtIndex:index];
            UIImage* floorImage = [[UIImage alloc] initWithData:floor.mapImage];
            if (floorImage == nil) continue;

            CGFloat width = (float)floorImage.size.width;
            CGFloat height = (float)floorImage.size.height;
            scale_map = base_width / width;
            if (scale_map == 0) continue;

            if (offsetY != 0) offsetY += 20;

            // フロアマップ描画--
            CGContextSaveGState(context); // Save
            CGContextTranslateCTM(context, 0, offsetY);
            CGContextScaleCTM(context, scale_map, scale_map);
            [floorImage drawAtPoint:CGPointMake(0, 0)];
            CGContextRestoreGState(context); // Restore
            // --フロアマップ描画

            if ((self.routeList != nil) && (self.routeList.count > 0)) {
                // ルート描画--
                CGContextSaveGState(context); // Save
                // 線種設定
                CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
                CGContextSetLineWidth(UIGraphicsGetCurrentContext(), 5.0 * scale_map);
                CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 252.0 / 255.0, 0 / 255.0, 0 / 255.0, 0.8);

                for (NSInteger root_num = 1; root_num < self.routeList.count; root_num++) {
                    TSsbpNode* node1 = [self.routeList objectAtIndex:root_num - 1];
                    TSsbpNode* node2 = [self.routeList objectAtIndex:root_num];

                    if ((node1 == nil) || (node2 == nil)) continue;
                    if (![[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:node1.floorId]) continue;
                    if (![[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:node2.floorId]) continue;

                    // 線描画
                    CGContextMoveToPoint(UIGraphicsGetCurrentContext(), node1.relativeX * scale_map, (node1.relativeY * scale_map) + offsetY);
                    CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), node2.relativeX * scale_map, (node2.relativeY * scale_map) + offsetY);
                    CGContextStrokePath(UIGraphicsGetCurrentContext());
                }
                CGContextRestoreGState(context); // Restore
                // --ルート描画

                // ノードマーク描画--
                CGContextSaveGState(context); // Save
                float mark_margin = 6 * scale_map;
                float mark_range = mark_margin * 1.5 * scale_map;
                for (NSInteger root_num = 0; root_num < self.routeList.count; root_num++) {
                    TSsbpNode* node = [self.routeList objectAtIndex:root_num];

                    if (node == nil) continue;
                    if (![[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:node.floorId]) continue;

                    CGRect mark_size = CGRectMake((node.relativeX * scale_map) - mark_range, (node.relativeY * scale_map) - mark_range + offsetY, mark_range * 2, mark_range * 2);
                    CGRect mark_b_size = CGRectInset(mark_size, -0.15 * scale_map, -0.15 * scale_map);
                    CGRect mark_i_size = CGRectMake((node.relativeX * scale_map) - mark_margin, (node.relativeY * scale_map) - mark_margin + offsetY, mark_margin * 2, mark_margin * 2);

                    // 外丸塗りつぶし
                    CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 1, 1, 1, 1);
                    CGContextFillEllipseInRect(UIGraphicsGetCurrentContext(), mark_size);

                    // 縁線
                    CGContextSetLineWidth(UIGraphicsGetCurrentContext(), 0.5);
                    CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 31.0 / 255.0, 235.0 / 255.0, 6.0 / 255.0, 0.8);
                    CGContextStrokeEllipseInRect(UIGraphicsGetCurrentContext(), mark_b_size);

                    // 中丸塗りつぶし
                    CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 31.0 / 255.0, 235.0 / 255.0, 6.0 / 255.0, 0.8);
                    CGContextFillEllipseInRect(UIGraphicsGetCurrentContext(), mark_i_size);
                }
                CGContextRestoreGState(context); // Restore
                // --ノードマーク描画

                // Up/Down/Moveマーク描画--
                NSInteger move_count = 0;
                for (NSInteger root_num = 1; root_num < self.routeList.count; root_num++) {
                    TSsbpNode* node1 = [self.routeList objectAtIndex:root_num - 1];
                    TSsbpNode* node2 = [self.routeList objectAtIndex:root_num];
                    if ((node1 == nil) || (node2 == nil)) continue;

                    BOOL isFloor = [[SSBPSdkIF sharedInstance] checkSame:node1.floorId val2:node2.floorId];
                    if (!isFloor) { move_count++; }
                    BOOL isFloor1 = [[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:node1.floorId];
                    BOOL isFloor2 = [[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:node2.floorId];
                    if (isFloor1 == isFloor2) continue;

                    TSsbpFloor* floor1 = [self getFloor:node1.floorId];
                    TSsbpFloor* floor2 = [self getFloor:node2.floorId];
                    if ((floor1 == nil) || (floor2 == nil)) continue;

                    if (isFloor1) {
                        NSString* marker = [NSString stringWithFormat:@"%ld", (long)move_count];
                        if (floor1.floorNum == floor2.floorNum) {
                            [self drawMoveMark:context image:moveImage marker:marker pos_x:node1.relativeX * scale_map pos_y:node1.relativeY * scale_map + offsetY scale:MARK_SCALE];
                        }
                        if (floor1.floorNum < floor2.floorNum) {
                            [self drawMoveMark:context image:upImage marker:marker pos_x:node1.relativeX * scale_map pos_y:node1.relativeY * scale_map + offsetY scale:MARK_SCALE];
                        }
                        if (floor1.floorNum > floor2.floorNum) {
                            [self drawMoveMark:context image:downImage marker:marker pos_x:node1.relativeX * scale_map pos_y:node1.relativeY * scale_map + offsetY scale:MARK_SCALE];
                        }
                    } else {
                        NSString* marker = [NSString stringWithFormat:@"%ld'", (long)move_count];
                        if (floor1.floorNum == floor2.floorNum) {
                            [self drawMoveMark:context image:moveImage marker:marker pos_x:node2.relativeX * scale_map pos_y:node2.relativeY * scale_map + offsetY scale:MARK_SCALE];
                        }
                        if (floor1.floorNum < floor2.floorNum) {
                            [self drawMoveMark:context image:upImage marker:marker pos_x:node2.relativeX * scale_map pos_y:node2.relativeY * scale_map + offsetY scale:MARK_SCALE];
                        }
                        if (floor1.floorNum > floor2.floorNum) {
                            [self drawMoveMark:context image:downImage marker:marker pos_x:node2.relativeX * scale_map pos_y:node2.relativeY * scale_map + offsetY scale:MARK_SCALE];
                        }
                    }
                }
                // --Up/Down/Moveマーク描画

                // スタートマーク描画--
                TSsbpNode* start_node = [self.routeList objectAtIndex:0];
                if (start_node != nil) {
                    if ([[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:start_node.floorId]) {
                        [self drawGoal:context image:startImage pos_x:start_node.relativeX * scale_map pos_y:start_node.relativeY * scale_map + offsetY scale:MARK_SCALE];
                    }
                }
                // --スタートマーク描画

                // ゴールマーク描画--
                TSsbpNode* goal_node = [self.routeList objectAtIndex:self.routeList.count - 1];
                if (goal_node != nil) {
                    if ([[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:goal_node.floorId]) {
                        [self drawGoal:context image:goalImage pos_x:goal_node.relativeX * scale_map pos_y:goal_node.relativeY * scale_map + offsetY scale:MARK_SCALE];
                    }
                }
                // --ゴールマーク描画
            }

            // コンテンツマーク描画--
            if ((self.actionList != nil) && (self.actionNodes != nil)) {
                for (TSsbpBeaconAction* action in self.actionList) {
                    if (action.status == 0) continue;
                    for (TSsbpNode* node in self.actionNodes) {
                        if (![[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:node.floorId]) continue;
                        if (![[SSBPSdkIF sharedInstance] checkSame:action.beaconId val2:node.beaconId]) continue;
                        [self drawContent:context pos_x:node.relativeX * scale_map pos_y:node.relativeY * scale_map + offsetY status:action.status scale:MARK_SCALE];
                    }
                }
            }
            // --コンテンツマーク描画

            // 現在地マーク描画--
            if (nowNode != nil) {
                if ([[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:nowNode.floorId]) {
                    [self drawMark:context image:nowImage pos_x:nowNode.relativeX * scale_map pos_y:nowNode.relativeY * scale_map + offsetY scale:MARK_SCALE];
                }
            }
            // --現在地マーク描画

            offsetY += height * scale_map;
        }

        // 描画終了(更新＆クリア)
        self.image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
}

- (void)drawMark:(CGContextRef)context image:(UIImage*)image pos_x:(CGFloat)pos_x pos_y:(CGFloat)pos_y scale:(CGFloat)scale {
    if (image == nil) return;

    @autoreleasepool {
        CGFloat mark_width = base_width;
        CGFloat mark_height = base_height;
        if (mark_width < mark_height) {
            mark_width = mark_height * scale_map / scale;
        } else {
            mark_width = (mark_width - MARK_OFFSET) * scale_map / scale;
        }

        CGFloat draw_width = (float)image.size.width;
        CGFloat draw_height = (float)image.size.height;
        CGFloat draw_scale = mark_width / draw_width;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) draw_scale = draw_scale / 2;

        CGContextSaveGState(context); // Save
        CGContextTranslateCTM(context, pos_x, pos_y);
        CGContextScaleCTM(context, draw_scale, draw_scale);
        [image drawAtPoint:CGPointMake(-draw_width / 2, -draw_height)];
        CGContextRestoreGState(context); // Restore
    }
}

- (void)drawMoveMark:(CGContextRef)context image:(UIImage*)image marker:(NSString*)marker pos_x:(CGFloat)pos_x pos_y:(CGFloat)pos_y scale:(CGFloat)scale {
    if (image == nil) return;

    @autoreleasepool {
        CGFloat mark_width = base_width;
        CGFloat mark_height = base_height;
        if (mark_width < mark_height) {
            mark_width = mark_height * scale_map / scale;
        } else {
            mark_width = (mark_width - MARK_OFFSET) * scale_map / scale;
        }

        CGFloat draw_width = (float)image.size.width;
        CGFloat draw_height = (float)image.size.height;
        CGFloat draw_scale = mark_width / draw_width;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) draw_scale = draw_scale / 2;

        CGFloat marker_width = draw_width * 0.9;
        NSMutableParagraphStyle *paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
        paragraphStyle.lineBreakMode = NSLineBreakByTruncatingTail;
        paragraphStyle.alignment = NSTextAlignmentRight;

        CGContextSaveGState(context); // Save
        CGContextTranslateCTM(context, pos_x, pos_y);
        CGContextScaleCTM(context, draw_scale, draw_scale);
        [image drawAtPoint:CGPointMake(-draw_width / 2, -draw_height)];
        [marker drawInRect:CGRectMake(-marker_width / 2, -40, marker_width, 40) withAttributes:@{ NSFontAttributeName:[UIFont boldSystemFontOfSize:36], NSForegroundColorAttributeName:[UIColor whiteColor], NSParagraphStyleAttributeName:paragraphStyle }];
        CGContextRestoreGState(context); // Restore
    }
}

- (void)drawGoal:(CGContextRef)context image:(UIImage*)image pos_x:(CGFloat)pos_x pos_y:(CGFloat)pos_y scale:(CGFloat)scale {
    if (image == nil) return;

    @autoreleasepool {
        CGFloat mark_width = base_width;
        CGFloat mark_height = base_height;
        if (mark_width < mark_height) {
            mark_width = mark_height * scale_map / scale;
        } else {
            mark_width = (mark_width - MARK_OFFSET) * scale_map / scale;
        }

        CGFloat draw_width = (float)image.size.width;
        CGFloat draw_height = (float)image.size.height;
        CGFloat draw_scale = mark_width / draw_width;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) draw_scale = draw_scale / 2;

        CGContextSaveGState(context); // Save
        CGContextTranslateCTM(context, pos_x, pos_y);
        CGContextScaleCTM(context, draw_scale, draw_scale);
        [image drawAtPoint:CGPointMake(-draw_width / 6, -draw_height)];
        CGContextRestoreGState(context); // Restore
    }
}

- (void)drawContent:(CGContextRef)context pos_x:(CGFloat)pos_x pos_y:(CGFloat)pos_y status:(NSInteger)status scale:(CGFloat)scale {
    if (status < 1) return;

    @autoreleasepool {
        UIImage* image;
        if (status == 2) {
            image = infoDisImage;
        } else {
            image = infoActImage;
        }
        if (image == nil) return;

        CGFloat mark_width = base_width;
        CGFloat mark_height = base_height;
        if (mark_width < mark_height) {
            mark_width = mark_height * scale_map / scale;
        } else {
            mark_width = (mark_width - MARK_OFFSET) * scale_map / scale;
        }

        CGFloat draw_width = (float)image.size.width;
        CGFloat draw_height = (float)image.size.height;
        CGFloat draw_scale = mark_width / draw_width;
        if (status == 1) draw_scale = draw_scale * 2;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) draw_scale = draw_scale / 2;

        CGContextSaveGState(context); // Save
        CGContextTranslateCTM(context, pos_x, pos_y);
        CGContextScaleCTM(context, draw_scale, draw_scale);
        [image drawAtPoint:CGPointMake(-draw_width / 2, -draw_height)];
        CGContextRestoreGState(context); // Restore
    }
}

#pragma mark -
#pragma mark Etc

- (UIImage*)pathForResource:(NSString*)fname {
    @autoreleasepool {
        if (fname.length > 0) {
            UIImage* image = [UIImage imageNamed:fname];
            return image;
        } else return nil;
    }
}

@end
