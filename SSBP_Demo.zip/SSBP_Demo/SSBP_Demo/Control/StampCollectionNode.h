//
//  StampCollectionNode.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StampCollectionNode : NSObject

@property (copy, nonatomic) NSString* nodeId;
@property (copy, nonatomic) NSString* contentId;
@property (copy, nonatomic) NSString* title;
@property (assign, nonatomic) NSInteger status;

@end
