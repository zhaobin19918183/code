//
//  TabBarControllerEx.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "TabBarControllerEx.h"

@implementation TabBarControllerEx

- (void)viewDidLoad {
    [super viewDidLoad];
    [[UITabBar appearance] setTintColor:[UIColor whiteColor]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(BOOL)shouldAutorotate {
    if (self.selectedViewController != nil)
        return [self.selectedViewController shouldAutorotate];
    else
        return [[self.viewControllers lastObject] shouldAutorotate];
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    if (self.selectedViewController != nil)
        return [self.selectedViewController supportedInterfaceOrientations];
    else
        return [[self.viewControllers lastObject] supportedInterfaceOrientations];
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    if (self.selectedViewController != nil)
        return [self.selectedViewController supportedInterfaceOrientations];
    else
        return [[self.viewControllers lastObject] supportedInterfaceOrientations];
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    if (self.selectedViewController != nil)
        return [self.selectedViewController preferredInterfaceOrientationForPresentation];
    else
        return [[self.viewControllers lastObject] preferredInterfaceOrientationForPresentation];
}

@end
