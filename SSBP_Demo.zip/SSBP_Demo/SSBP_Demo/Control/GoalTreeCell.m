//
//  GoalTreeCell.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "GoalTreeCell.h"

@implementation GoalTreeCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

@end
