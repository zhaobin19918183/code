//
//  DetectViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define UIKitLocalizedString(key) [[NSBundle bundleWithIdentifier:@"com.apple.UIKit"] localizedStringForKey:key value:@"" table:nil]

#import <AudioToolbox/AudioServices.h>

#import "DetectViewController.h"

#import "VideoViewController.h"
#import "BrowserViewController.h"
#import "WKBrowserViewController.h"

@implementation DetectViewController {
    __weak IBOutlet UITextView* textView;
    __weak IBOutlet UISwitch* swSend;

    NSString* alert_type;
    NSString* open_contentId;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (swSend != nil) {
        [swSend setOn:[[SSBPSdkIF sharedInstance] getDetectBeacon]];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [SSBPSdkIF sharedInstance].delegateIF = self;

    [self setInfo];
}

- (void)viewDidDisappear:(BOOL)animated {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(startScan) object:nil];

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Events

- (IBAction)sendChange:(UISwitch*)sender {
    [[SSBPSdkIF sharedInstance] setDetectBeacon:swSend.isOn];

    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(startScan) object:nil];
    [self performSelector:@selector(startScan) withObject:nil afterDelay:1];
}

#pragma mark -
#pragma mark Delay Event

- (void)startScan {
    if ([[SSBPSdkIF sharedInstance] getDetectBeacon]) {
        [[SSBPSdkIF sharedInstance] scanStart];
    } else {
        [[SSBPSdkIF sharedInstance] scanStop];
    }
}

#pragma mark -
#pragma mark Info View

- (void)setInfo {
    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
            NSArray* infos = [[SSBPScannerManager sharedManager] getRegionInfoList];

            BOOL isUnknown = true;
            NSMutableString* htmlString = [NSMutableString stringWithString:@""];

            if (infos != nil) {
                BOOL isBR = false;

                for (SSBPRegionInfo* info in infos) {
                    TSsbpBeacon* ssbpBeacon = [[SSBPScannerManager sharedManager] getInnerBeacon:info.beaconId];
                    if ((ssbpBeacon == nil) && (info.proximity != CLProximityUnknown)) continue;
                    isUnknown = false;

                    if (isBR) [htmlString appendString:@"<br>"];
                    isBR = true;

                    switch (info.proximity) {
                        case CLProximityImmediate:
                            [htmlString appendFormat:@"<div Align=\"center\"><font size=\"5\" color=\"#555555\">%@</font><font size=\"6\" color=\"#3C887E\"> : Immediate</font></div>", ssbpBeacon.beaconName];
                            break;
                        case CLProximityNear:
                            [htmlString appendFormat:@"<div Align=\"center\"><font size=\"5\" color=\"#555555\">%@</font><font size=\"6\" color=\"#3C887E\"> : Near</font></div>", ssbpBeacon.beaconName];
                            break;
                        case CLProximityFar:
                            [htmlString appendFormat:@"<div Align=\"center\"><font size=\"5\" color=\"#555555\">%@</font><font size=\"6\" color=\"#3C887E\"> : Far</font></div>", ssbpBeacon.beaconName];
                            break;
                        default:
                            if (infos.count == 1) {
                            } else {
                                isBR = false;
                            }
                            break;
                    }
                }
            }

            if (isUnknown) {
                [htmlString appendString:@"<div Align=\"center\"><font size=\"6\" color=\"#FF0000\">Unknown</font></div>"];
            }

            [textView setAttributedText:[[NSAttributedString alloc]
                                         initWithData:[htmlString dataUsingEncoding:NSUTF8StringEncoding]
                                         options:@{NSDocumentTypeDocumentAttribute:NSHTMLTextDocumentType, NSCharacterEncodingDocumentAttribute:@(NSUTF8StringEncoding)}
                                         documentAttributes:nil error:nil]];
        }
    });
}

#pragma mark -
#pragma mark SSBPSdkIFDelegate override

- (void)ssbpScannerChangeBeacon:(SSBPRegionInfo*)info {
    [self setInfo];
}

- (void)ssbpSdkIFAddContent:(NSString*)contentId {
    dispatch_async(dispatch_get_main_queue(), ^{
        TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:contentId];
        if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"navi"]) {
        } else if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"coupon"] || [[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"info"]) {
            [self playSystemSound:1000];
            [self showAlert:content];
        }
    });
}

#pragma mark -
#pragma mark View Change

- (void)showAlert:(TSsbpContent*)content {
    NSString* pos = NSLocalizedString(@"captionGoList", @"");
    NSString* ntr = nil;
    NSString* neg = UIKitLocalizedString(@"OK");

    alert_type = content.contentAction;

    NSString* title = @"";
    if ([[SSBPSdkIF sharedInstance] checkSame:alert_type val2:@"coupon"]) {
        title = NSLocalizedString(@"captionAddCouponTitle", @"");
    } else if ([[SSBPSdkIF sharedInstance] checkSame:alert_type val2:@"info"]) {
        title = NSLocalizedString(@"captionAddInformationTitle", @"");
        if (open_contentId.length == 0) {
            ntr = NSLocalizedString(@"captionInfoOpen", @"");
            open_contentId = content.contentId;
        }
    } else {
        return;
    }

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:content.contentName preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
        if ([[SSBPSdkIF sharedInstance] checkSame:alert_type val2:@"coupon"]) {
            [self changeCouponView];
        } else if ([[SSBPSdkIF sharedInstance] checkSame:alert_type val2:@"info"]) {
            [self changeInfoView];
        }
        open_contentId = nil;
    }]];
    if (ntr.length > 0) {
        [alertController addAction:[UIAlertAction actionWithTitle:ntr style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self useDB];
                
                TSsbpContent* _content = [[SSBPContentIF sharedInstance] getInnerContent:open_contentId];
                if (_content != nil) {
                    [self openContent:_content.contentURL];
                }
                open_contentId = nil;
            });
        }]];
    }
    [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        open_contentId = nil;
    }]];

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

- (void)changeCouponView {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.tabBarController.selectedIndex = 1;
    });
}

- (void)changeInfoView {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.tabBarController.selectedIndex = 2;
    });
}

// 拡張子判定による、WebBrowser/MediaPlayerの呼び出し
- (void)openContent:(NSString*)strUrl {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSArray* supported = [NSArray arrayWithObjects:@"mp4", @"3gp", @"mov", @"avi", @"mpeg", @"mpv", @"aac", @"amr", @"mp3", @"aiff", @"caf", @"m4a", @"ogg", @"wav", nil];
        NSString* ext = [strUrl pathExtension];

        if ([supported containsObject:ext]) {
            VideoViewController* video = [VideoViewController new];
            video.url = strUrl;
            video.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
            [self presentViewController:video animated:true completion:NULL];
        } else {
            BrowserViewController* browserView = [self.storyboard instantiateViewControllerWithIdentifier:@"BrowserViewID"];
            //WKBrowserViewController* browserView = [self.storyboard instantiateViewControllerWithIdentifier:@"WKBrowserViewID"];
            browserView.url = strUrl;
            [self presentViewController:browserView animated:true completion:nil];
        }
    });
}

#pragma mark -
#pragma mark DB's

- (void)useDB {
    @autoreleasepool {
        if (open_contentId.length > 0) {
            [[SSBPSdkIF sharedInstance] useContent:open_contentId];
        }
    }
}

#pragma mark -
#pragma mark Etc

- (void)playSystemSound:(SystemSoundID)soundId {
    @autoreleasepool {
        AudioServicesPlaySystemSound(soundId);
    }
}

@end
