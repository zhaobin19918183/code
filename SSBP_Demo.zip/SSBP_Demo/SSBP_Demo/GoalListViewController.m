//
//  GoalListViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#import "GoalListViewController.h"

#import "GoalTreeNode.h"
#import "GoalTreeCell.h"

#import "NavigationViewController.h"

@implementation GoalListViewController {
    __weak IBOutlet UIButton* btnBack;
    __weak IBOutlet UITableView* tblView;

    GoalTreeNode* Goals;
    NSMutableArray* viewGoals;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [SSBPSdkIF sharedInstance].delegateIF = nil;

    tblView.dataSource = self;
    tblView.delegate = self;

    [self loadDB];
}

- (void)viewDidDisappear:(BOOL)animated {
    tblView.dataSource = nil;
    tblView.delegate = nil;

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Event

- (IBAction)backTap:(UIButton*)sender {
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

#pragma mark -
#pragma mark DB's

- (void)loadDB {
    @autoreleasepool {
        Goals = nil;
        NSArray* floors = [[SSBPScannerManager sharedManager] getInnerFloors:self.facilityId];

        if ((floors != nil) && (floors.count > 0)) {
            for (TSsbpFloor* floor in floors) {
                NSArray* goals = [[SSBPScannerManager sharedManager] getInnerGoals:@"" floorId:floor.floorId];
                if ((goals != nil) && (goals.count > 0)) {
                    for (TSsbpNode* goal in goals) {
                        [self addGoal:goal floorName:floor.floorName];
                    }
                }
            }
        }

        [self setViewGoal];
        [tblView reloadData];
    }
}

- (void)addGoal:(TSsbpNode*)goalNode floorName:(NSString*)floorName {
    @autoreleasepool {
        if (Goals == nil) {
            Goals = [GoalTreeNode new];
            Goals.nodeId = @"";
            Goals.isExpand = false;
            Goals.level = 0;
        }

        GoalTreeNode* floor;
        BOOL check = false;
        if (Goals.children != nil) {
            for (GoalTreeNode* child in Goals.children) {
                if ([[SSBPSdkIF sharedInstance] checkSame:child.nodeId val2:goalNode.floorId]) {
                    check = true;
                    floor = child;
                    break;
                }
            }
        }
        if (!check) {
            floor = [GoalTreeNode new];
            floor.nodeId = goalNode.floorId;
            floor.title = floorName;
            floor.isExpand = false;
            [Goals addChild:floor];
        }

        GoalTreeNode* goal = [GoalTreeNode new];;
        goal.nodeId = goalNode.nodeId;
        goal.title = [NSString stringWithFormat:@" - %@", goalNode.nodeName];
        goal.isExpand = false;
        [floor addChild:goal];
    }
}

- (void)setViewGoal {
    @autoreleasepool {
        if (viewGoals == nil) {
            viewGoals = [NSMutableArray array];
        } else {
            if (viewGoals.count > 0) {
                [viewGoals removeAllObjects];
            }
        }

        if (Goals == nil) return;

        if (Goals.children != nil) {
            for (GoalTreeNode* floor in Goals.children) {
                if (floor.children != nil) [viewGoals addObject:floor];
                if (!floor.isExpand) {
                    for (GoalTreeNode* goal in floor.children) {
                        [viewGoals addObject:goal];
                    }
                }
            }
        }
    }
}

#pragma mark -
#pragma mark DataSource's

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
    if (viewGoals == nil) {
        return 0;
    } else {
        return viewGoals.count;
    }
}

#pragma mark -
#pragma mark TableView's

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    UITableViewCell* cell = [self getCell:indexPath];
    return cell;
}

- (UITableViewCell*)getCell:(NSIndexPath*)indexPath {
    GoalTreeCell* goalCell = [tblView dequeueReusableCellWithIdentifier:@"GoalTreeCell" forIndexPath:indexPath];
    if (goalCell == nil) goalCell = [tblView dequeueReusableCellWithIdentifier:@"GoalTreeCell"];
    if ((viewGoals != nil) && (viewGoals.count > indexPath.row)) {
        [self setGoalCell:goalCell indexPath:indexPath];
    }
    return goalCell;
}

- (void)setGoalCell:(GoalTreeCell*)cell indexPath:(NSIndexPath*)indexPath {
    @autoreleasepool {
        GoalTreeNode* goal = [viewGoals objectAtIndex:indexPath.row];
        cell.title.text = goal.title;
        if (goal.level == 1) {
            cell.backgroundColor = RGBA(103, 192, 254, 1);
            cell.title.textColor = [UIColor whiteColor];
            cell.title.font = [UIFont boldSystemFontOfSize:cell.title.font.pointSize];
            [cell.expand setHidden:false];
            if (goal.isExpand) {
                cell.expand.image = [self pathForResource:@"arrow_r"];
            } else {
                cell.expand.image = [self pathForResource:@"arrow_u"];
            }
        } else if (goal.level == 2) {
            cell.backgroundColor = RGBA(238, 239, 240, 1);
            cell.title.textColor = [UIColor blackColor];
            cell.title.font = [UIFont systemFontOfSize:cell.title.font.pointSize];
            [cell.expand setHidden:true];
        }
    }
}

- (void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:true];

    @autoreleasepool {
        if (viewGoals.count > indexPath.row) {
            GoalTreeNode* goal = [viewGoals objectAtIndex:indexPath.row];
            if (goal.level == 1) {
                goal.isExpand = !goal.isExpand;
                [self setViewGoal];
                [tblView reloadData];
            } else if (goal.level == 2) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    NavigationViewController* navigationView = [self.storyboard instantiateViewControllerWithIdentifier:@"NavigationViewID"];
                    navigationView.goalNodeId = goal.nodeId;
                    [self presentViewController:navigationView animated:true completion:nil];
                });
            }
        }
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer*)gestureRecognizer shouldReceiveTouch:(UITouch*)touch {
    // おまじない
    // 子viewのtapを期待通りに動作させるための対策
    if ((touch.view != gestureRecognizer.view) && [touch.view isKindOfClass:[UIControl class]]) {
        return false;
    }
    return true;
}

#pragma mark -
#pragma mark Etc

- (UIImage*)pathForResource:(NSString*)fname {
    @autoreleasepool {
        if (fname.length > 0) {
            UIImage* image = [UIImage imageNamed:fname];
            return image;
        } else return nil;
    }
}

@end
