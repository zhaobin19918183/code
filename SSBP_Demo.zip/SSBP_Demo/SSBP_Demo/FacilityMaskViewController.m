//
//  FacilityMaskViewController.m
//
//  Created by Ayumi Togashi on 2017/04/06.
//  Copyright © 2017年 Switch Smile co.,ltd. All rights reserved.
//

#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#import "FacilityMaskViewController.h"

#import "DrawButton.h"

@implementation FacilityMaskViewController {
    __weak IBOutlet UIButton* btnBack;

    __weak IBOutlet UIButton* btnRadioNon;
    __weak IBOutlet UIButton* btnRadioUse;
    __weak IBOutlet UIButton* btnRadioUnuse;

    __weak IBOutlet UIView* base;
    __weak IBOutlet UIScrollView* scroll;

    NSArray* Facilities;
    NSMutableDictionary* MaskFacilityIds;

    BOOL isChange;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnRadioNon != nil) {
        btnRadioNon.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnRadioUse != nil) {
        btnRadioUse.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnRadioUnuse != nil) {
        btnRadioUnuse.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [[SSBPSdkIF sharedInstance] scanStop];

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self loadDB];
    });
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];

    [[SSBPSdkIF sharedInstance] scanStart];
}

- (void)dealloc {
    for (UIView* view in self.view.subviews) {
        [view removeFromSuperview];
    }
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Events

- (IBAction)backTap:(UIButton*)sender {
    if (isChange) {
        NSMutableArray* facilityIds = [NSMutableArray array];
        for (TSsbpFacility* facility in Facilities) {
            NSString* value = [MaskFacilityIds objectForKey:facility.facilityId];
            if ([[SSBPSdkIF sharedInstance] checkSame:value val2:@"1"]) {
                [facilityIds addObject:facility.facilityId];
            }
        }

        if (btnRadioNon.selected) {
            // 施設マスク設定をクリア
            [[SSBPScannerManager sharedManager] setScanFacilityMask:[NSMutableArray array] enaFlag:true];
        } else if (btnRadioUse.selected) {
            // 施設有効設定
            [[SSBPScannerManager sharedManager] setScanFacilityMask:facilityIds enaFlag:true];
        } else if (btnRadioUnuse.selected) {
            // 施設無効設定
            [[SSBPScannerManager sharedManager] setScanFacilityMask:facilityIds enaFlag:false];
        }

    }

    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

- (IBAction)radioTap:(UIButton*)sender {
    isChange = true;
    if (sender == btnRadioNon) {
        btnRadioNon.selected = true;
        btnRadioUse.selected = false;
        btnRadioUnuse.selected = false;
    } else if (sender == btnRadioUse) {
        btnRadioNon.selected = false;
        btnRadioUse.selected = true;
        btnRadioUnuse.selected = false;
    } else if (sender == btnRadioUnuse) {
        btnRadioNon.selected = false;
        btnRadioUse.selected = false;
        btnRadioUnuse.selected = true;
    }
}

- (IBAction)tapCheckButton:(DrawButton*)sender {
    isChange = true;
    sender.selected = !sender.selected;

    if (sender.selected) {
        [MaskFacilityIds setObject:@"1" forKey:sender.tagString];
    } else {
        [MaskFacilityIds setObject:@"0" forKey:sender.tagString];
    }
}

#pragma mark -
#pragma mark DB's

- (void)loadDB {
    @autoreleasepool {
        isChange = false;
        Facilities = nil;

        Facilities = [[SSBPScannerManager sharedManager] getInnerFacilities];
        NSArray* enaFacilityIds = [[SSBPScannerManager sharedManager] getScanFacilityMask:true];
        NSArray* disFacilityIds = [[SSBPScannerManager sharedManager] getScanFacilityMask:false];

        if (MaskFacilityIds == nil) {
            MaskFacilityIds = [NSMutableDictionary dictionary];
        } else {
            if (MaskFacilityIds.count > 0) {
                [MaskFacilityIds removeAllObjects];
            }
        }

        for (TSsbpFacility* facility in Facilities) {
            [MaskFacilityIds setObject:@"0" forKey:facility.facilityId];
        }
        
        if (enaFacilityIds.count > 0) {
            for (NSString* facilityId in enaFacilityIds) {
                [MaskFacilityIds setObject:@"1" forKey:facilityId];
            }
            [self radioTap:btnRadioUse];
        } else if (disFacilityIds.count > 0) {
            for (NSString* facilityId in disFacilityIds) {
                [MaskFacilityIds setObject:@"1" forKey:facilityId];
            }
            [self radioTap:btnRadioUnuse];
        }
    }

    dispatch_async(dispatch_get_main_queue(), ^{
        [self createView];
    });
}

#pragma mark -
#pragma mark Set View

- (void)createView {
    @autoreleasepool {
        for (UIView* subView in [scroll subviews]) {
            [subView removeFromSuperview];
        }

        CGRect base_rect = [base bounds];

        // サイズ関連
        CGFloat baseMargin = 10;

        CGFloat chkWidth = base_rect.size.width * 0.8;
        CGFloat chkHeight = chkWidth * 0.2;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            chkHeight = chkWidth * 0.1;
        }

        CGFloat btnX = (base_rect.size.width - chkWidth) / 2;
        CGFloat itemY = baseMargin;

        // タイトルとボタンを貼り付ける
        NSInteger fNum = Facilities.count;
        [self addCheckButton:btnX itemY:itemY btnAreaWidth:chkWidth btnAreaHeight:chkHeight];

        // サイズ判定
        CGFloat sumHeight = baseMargin * 2 + (chkHeight * fNum);
        BOOL isOver = (sumHeight > base_rect.size.height);

        if (!isOver) {
            [scroll setContentSize:base_rect.size];
        } else {
            [scroll setContentSize:CGSizeMake(base_rect.size.width, sumHeight)];
        }

        scroll.bounces = false;
    }
}

- (void)addCheckButton:(CGFloat)btnX itemY:(CGFloat)itemY btnAreaWidth:(CGFloat)btnAreaWidth btnAreaHeight:(CGFloat)btnAreaHeight {
    NSInteger fNum = Facilities.count;
    CGFloat btnMargin = btnAreaHeight * 0.2;
    CGFloat btnHeight = btnAreaHeight - (btnMargin * 2);
    CGFloat btnFontSize = (int)(btnHeight / 2);

    for (int i = 0; i < fNum; i++) {
        TSsbpFacility* facility = [Facilities objectAtIndex:i];
        DrawButton* btn = [DrawButton buttonWithType:UIButtonTypeCustom];
        btn.imageView.contentMode = UIViewContentModeScaleAspectFit;

        [btn setImage:[self pathForResource:@"unchecked"] forState:UIControlStateNormal];
        [btn setImage:[self pathForResource:@"checked"] forState:UIControlStateSelected];
        [btn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
        [btn setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];

        [btn setTitleColor:RGBA(0, 0, 0, 1.0) forState:UIControlStateNormal];
        [btn setTitleColor:RGBA(0, 0, 0, 0.6) forState:UIControlStateHighlighted];
        [btn.titleLabel setTextAlignment:NSTextAlignmentLeft];
        btn.titleLabel.numberOfLines = 1;

        btn.tagString = facility.facilityId;
        [btn setTitle:facility.facilityName forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:btnFontSize];
        btn.titleLabel.adjustsFontSizeToFitWidth = true;

        btn.frame = CGRectMake(btnX, itemY + (btnAreaHeight * i), btnAreaWidth, btnHeight);

        NSString* value = [MaskFacilityIds objectForKey:facility.facilityId];
        if ([[SSBPSdkIF sharedInstance] checkSame:value val2:@"1"]) {
            btn.selected = true;
        } else {
            btn.selected = false;
        }

        [btn addTarget:self action:@selector(tapCheckButton:) forControlEvents:UIControlEventTouchUpInside];
        [scroll addSubview:btn];
    }
}

#pragma mark -
#pragma mark Etc

- (UIImage*)pathForResource:(NSString*)fname {
    @autoreleasepool {
        if (fname.length > 0) {
            UIImage* image = [UIImage imageNamed:fname];
            return image;
        } else return nil;
    }
}

@end
