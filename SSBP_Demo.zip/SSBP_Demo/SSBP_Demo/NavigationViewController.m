//
//  NavigationViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define UIKitLocalizedString(key) [[NSBundle bundleWithIdentifier:@"com.apple.UIKit"] localizedStringForKey:key value:@"" table:nil]
#define MARK_SCALE 8.6
#define MARK_OFFSET 110 // statusbar + footer

#import <AudioToolbox/AudioServices.h>

#import "NavigationViewController.h"

#import "GoalTreeNode.h"
#import "GoalTreeCell.h"

#import "VideoViewController.h"
#import "BrowserViewController.h"
#import "WKBrowserViewController.h"

#import "StampListViewController.h"
#import "CouponListViewController.h"
#import "InfoListViewController.h"

@implementation NavigationViewController {
    __weak IBOutlet UIButton* btnBack;
    __weak IBOutlet UILabel* lblTitle;
    __weak IBOutlet UIButton* btnMenu;

    __weak IBOutlet UIScrollViewEx* scroll;

    __weak IBOutlet UIButton* btnCurrent;
    __weak IBOutlet UIButton* btnStamp;
    __weak IBOutlet UIButton* btnOverall;
    __weak IBOutlet UISwitch* swCompass;

    __weak IBOutlet UIView* wait;

    __weak IBOutlet UIView* popGoal;
    __weak IBOutlet UIView* goalInfo;
    __weak IBOutlet UILabel* lblGoal;
    __weak IBOutlet UITableView* tblView;

    __weak IBOutlet UIView* popReroute;
    __weak IBOutlet UIButton* btnReroute;

    __weak IBOutlet UIView* popOverall;
    __weak IBOutlet UIScrollView* scrollOverall;
    __weak IBOutlet UIButton* btnOverallBack;

    NSString* startNodeId;

    NSString* nowBeaconId;
    NSString* nowNodeId;
    TSsbpNode* nowNode;
    NSArray<TSsbpFloor*>* floorList;
    NSArray<TSsbpNode*>* routeList;
    NSArray<TSsbpBeaconAction*>* actionList;
    NSArray<TSsbpNode*>* actionNodes;

    UIView* zoomView;

    UIImageView* drawView;
    UIImage* floorImage;

    UIImageView* markView;
    UIImage* nowImage;
    UIImage* infoActImage;
    UIImage* infoDisImage;
    UIImage* startImage;
    UIImage* goalImage;
    UIImage* upImage;
    UIImage* downImage;
    UIImage* moveImage;

    OverallView* overall;

    CGFloat offset_angle;
    CGFloat angle;
    BOOL isFinished;

    SSBPHttpRequester* requester;

    GoalTreeNode* Goals;
    NSMutableArray* viewGoals;

    NSString* alert_type;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnMenu != nil) {
        btnMenu.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnCurrent != nil) {
        btnCurrent.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnOverall != nil) {
        btnOverall.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnStamp != nil) {
        btnStamp.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnReroute != nil) {
        btnReroute.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnOverallBack != nil) {
        btnOverallBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }

    zoomView = [UIView new];
    [zoomView setUserInteractionEnabled:false];

    drawView = [UIImageView new];
    [zoomView addSubview:drawView];
    markView = [UIImageView new];
    [zoomView addSubview:markView];

    if (scroll != nil) {
        [scroll addSubview:zoomView];
        scroll.maximumZoomScale = 2;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) scroll.maximumZoomScale = 4;
    }

    if (popGoal != nil) {
        popGoal.layer.borderWidth = 0.75;
        popGoal.layer.borderColor = RGBA(160, 160, 160, 0.8).CGColor;
        popGoal.layer.cornerRadius = 4;
    }

    overall = [OverallView new];
    if (scrollOverall != nil) {
        [scrollOverall addSubview:overall];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [self setButtonState:false];
    isFinished = false;

    [SSBPSdkIF sharedInstance].delegateIF = self;

    @autoreleasepool {
        NSArray* infos = [[SSBPScannerManager sharedManager] getRegionInfoList];
        if (infos != nil) {
            NSString* nearestBeaconId = @"";
            NSDate* updatedDate;

            for (SSBPRegionInfo* info in infos) {
                if (info.nearestBeaconId.length > 0) {
                    if (updatedDate == nil) {
                        updatedDate = info.updatedDate;
                    } else {
                        NSComparisonResult result = [updatedDate compare:info.updatedDate];
                        if (result != NSOrderedAscending) continue;
                        updatedDate = info.updatedDate;
                    }
                    TSsbpNode* newNode = [[SSBPScannerManager sharedManager] getInnerBeaconNode:info.nearestBeaconId];
                    if (newNode == nil) continue;
                    nearestBeaconId = info.nearestBeaconId;
                }
            }

            if (nearestBeaconId.length > 0) {
                [self ssbpScannerChangeNearest:nearestBeaconId];
            }
        }
    }

    tblView.dataSource = self;
    tblView.delegate = self;
    scroll.delegate = self;
    overall.delegateO = self;

    [self compassChange:nil];
}

- (void)viewDidDisappear:(BOOL)animated {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(viewPopReroute) object:nil];
    [self hidePopGoal];

    tblView.dataSource = nil;
    tblView.delegate = nil;
    scroll.delegate = nil;
    overall.delegateO = nil;

    [[SSBPScannerManager sharedManager] compassStop];

    nowBeaconId = @"";
    nowNodeId = @"";
    nowNode = nil;
    floorList = nil;
    routeList = nil;
    actionList = nil;
    actionNodes = nil;

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return true;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    UIDeviceOrientation rotate = [UIDevice currentDevice].orientation;
    switch (rotate) {
        case UIDeviceOrientationPortrait:
            return UIInterfaceOrientationPortrait;
            break;
        case UIDeviceOrientationLandscapeLeft:
            return UIInterfaceOrientationLandscapeRight;
            break;
        case UIDeviceOrientationLandscapeRight:
            return UIInterfaceOrientationLandscapeLeft;
            break;
        default:
            return UIInterfaceOrientationPortrait;
            break;
    }
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    if (floorImage == nil) {
        [self setButtonState:false];
    } else {
        overall.nowNodeId = nowNodeId;
        [overall setDraw:scrollOverall.bounds.size];
        [scrollOverall setContentSize:overall.frame.size];

        scroll.zoomScale = 1;
        [self setNodePos];
        scroll.minimumZoomScale = scroll.bounds.size.width / floorImage.size.width;
    }
}

#pragma mark -
#pragma mark IBOutlet Event

- (IBAction)backTap:(UIButton*)sender {
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

- (IBAction)currentTap:(UIButton*)sender {
    scroll.zoomScale = 1;
    [self setNodePos];
}

- (IBAction)stampTap:(UIButton*)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        StampListViewController* stampListView = [self.storyboard instantiateViewControllerWithIdentifier:@"StampListViewID"];
        stampListView.nowBeaconId = nowBeaconId;
        [self presentViewController:stampListView animated:true completion:nil];
    });
}

- (IBAction)overallTap:(UIButton*)sender {
    overall.nowNodeId = nowNodeId;
    [overall setDraw:scrollOverall.bounds.size];
    [scrollOverall setContentSize:overall.frame.size];

    if (!popGoal.isHidden) {
        [self hidePopGoal];
    }

    [self viewPopOverall];
}

- (IBAction)menuTap:(UIButton*)sender {
    if (popGoal.isHidden) {
        [self viewPopGoal];
    } else {
        [self hidePopGoal];
    }
}

- (IBAction)rerouteTap:(UIButton*)sender {
    isFinished = false;
    if (sender != nil) {
        startNodeId = @"";
    }
    [self setRouteList];
}

- (IBAction)overallBackTap:(UIButton*)sender {
    [self hidePopOverall];
}

- (IBAction)compassChange:(UISwitch*)sender {
    [swCompass setEnabled:false];
    if (swCompass.isOn) {
        [[SSBPScannerManager sharedManager] compassStart];
    } else {
        [[SSBPScannerManager sharedManager] compassStop];
        dispatch_async(dispatch_get_main_queue(), ^{
            angle = 0;
            scroll.transform = CGAffineTransformMakeRotation(0);
            [self onMark];
        });
    }
}

#pragma mark -
#pragma mark private

- (void)setFloorList:(NSString*)newBeaconId {
    if ([[SSBPSdkIF sharedInstance] checkSame:nowBeaconId val2:newBeaconId]) return;

    TSsbpNode* newNode = [[SSBPScannerManager sharedManager] getInnerBeaconNode:newBeaconId];
    if (newNode == nil) return;

    if ((floorList != nil) && (nowBeaconId.length > 0)) {
        TSsbpNode* node = [[SSBPScannerManager sharedManager] getInnerBeaconNode:nowBeaconId];
        if (node != nil) {
            if ([[SSBPSdkIF sharedInstance] checkSame:node.facilityId val2:newNode.facilityId]) return;
        }
    }
    floorList = [[SSBPScannerManager sharedManager] getInnerFloors:newNode.facilityId];
    if (overall != nil) overall.floorList = floorList;

    [self loadDB];
}

- (TSsbpFloor*)getFloor:(NSString*)floorId {
    if ((floorList != nil) && (floorList.count > 0)) {
        for (TSsbpFloor* floor in floorList) {
            if ([[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:floorId]) {
                return floor;
            }
        }
    }
    return nil;
}

- (void)setRouteList {
    routeList = nil;

    @autoreleasepool {
        if (nowNode == nil) {
            nowNode = [[SSBPScannerManager sharedManager] getInnerBeaconNode:nowBeaconId];
        }
        if (nowNode == nil) return;

        if (self.goalNodeId.length > 0) {
            if (startNodeId.length > 0) {
                [[SSBPScannerManager sharedManager] getRoute:startNodeId goalId:self.goalNodeId];
            } else {
                startNodeId = nowNode.nodeId;
                //[[SSBPScannerManager sharedManager] getRoute:nowNode.nodeId goalId:self.goalNodeId];
                [[SSBPScannerManager sharedManager] getInnerRoute:nowNode.nodeId goalId:self.goalNodeId];
            }
        }
    }
}

- (void)setActionList {
    actionList = nil;
    actionNodes = nil;
    NSMutableArray* array1 = [NSMutableArray array];
    NSMutableArray* array2 = [NSMutableArray array];

    @autoreleasepool {
        NSArray* actions = [[SSBPScannerManager sharedManager] getBeaconActions];
        if ((actions != nil) && (actions.count > 0)) {
            for (TSsbpBeaconAction* action in actions) {
                if (action.status == 0) continue;
                TSsbpNode* node = [[SSBPScannerManager sharedManager] getInnerBeaconNode:action.beaconId];
                if ([[SSBPSdkIF sharedInstance] checkSame:node.nodeAction val2:@"stamp"]) {
                    [array1 addObject:action];
                    [array2 addObject:node];
                }
            }
        }
    }

    actionList = [array1 copy];
    if (overall != nil) overall.actionList = [array1 copy];
    actionNodes = [array2 copy];
    if (overall != nil) overall.actionNodes = [array2 copy];
}

- (void)setButtonState:(BOOL)status {
    [wait setHidden:status];
    [btnMenu setEnabled:status];
    [btnCurrent setEnabled:status];
    [btnOverall setEnabled:status];
    [btnStamp setEnabled:status];
    [swCompass setEnabled:status];
}

- (void)setMapImage {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self setButtonState:false];
    });

    @autoreleasepool {
        if (nowNode == nil) return;
        __block TSsbpFloor* newFloor = [self getFloor:nowNode.floorId];
        if (newFloor == nil) return;

        offset_angle = newFloor.floorDeg;

        scroll.zoomScale = 1; // Mapが変わったらスケールを元に戻す
        floorImage = nil;
        if (newFloor.mapImage != nil) {
            floorImage = [[UIImage alloc] initWithData:newFloor.mapImage];
            [self onDraw];
        } else {
            // 非同期で処理
            if ([newFloor.mapImageURL hasPrefix:@"http"]) {
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    if (requester == nil) requester = [SSBPHttpRequester new];
                    [requester httpRequestGet:newFloor.mapImageURL withParam:nil completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
                        if ((error != nil) || (data == nil)) return;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            newFloor.mapImage = data;
                            [[SSBPScannerManager sharedManager] addFloor:newFloor];
                            floorImage = [[UIImage alloc] initWithData:newFloor.mapImage];
                            [self onDraw];
                        });
                    }];
                });
            }
        }
    }
}

- (void)setNodePos {
    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
            TSsbpNode* newNode = [[SSBPScannerManager sharedManager] getInnerBeaconNode:nowBeaconId];
            if (newNode == nil) return;
            __block NSString* newNodeId = newNode.nodeId;
            BOOL isChange = ![[SSBPSdkIF sharedInstance] checkSame:nowNode.floorId val2:newNode.floorId];

            if ((routeList != nil) && (routeList.count > 0)) {
                NSInteger nowNo = -1;
                NSInteger endNo = -1;
                for (int index = 0; index < routeList.count; index++) {
                    TSsbpNode* node = [routeList objectAtIndex:index];
                    if ([[SSBPSdkIF sharedInstance] checkSame:node.nodeId val2:nowNodeId]) nowNo = index;
                    if ([[SSBPSdkIF sharedInstance] checkSame:node.nodeId val2:newNode.nodeId]) endNo = index;
                }

                if ((nowNo >= 0) && (endNo >= 0) && (nowNo != endNo)) {
                    if (nowNo > endNo) {
                        newNode = [routeList objectAtIndex:nowNo - 1];
                    } else {
                        newNode = [routeList objectAtIndex:nowNo + 1];
                    }
                }
                isChange = ![[SSBPSdkIF sharedInstance] checkSame:nowNode.floorId val2:newNode.floorId];
            }
            nowNodeId = newNode.nodeId;
            nowNode = [[SSBPScannerManager sharedManager] getInnerNode:nowNodeId];

            if ([[SSBPSdkIF sharedInstance] checkSame:newNodeId val2:nowNode.nodeId]) {
                [self setActionList];
            }

            CGFloat new_x = (newNode.relativeX * scroll.zoomScale) - (scroll.bounds.size.width / 2);
            CGFloat new_y = (newNode.relativeY * scroll.zoomScale) - (scroll.bounds.size.height / 2);

            if (isChange) {
                [self setMapImage];
                [scroll setContentOffset:CGPointMake(new_x, new_y) animated:false];

                if (![[SSBPSdkIF sharedInstance] checkSame:newNodeId val2:nowNode.nodeId]) {
                    [self performSelector:@selector(setNodePos) withObject:nil afterDelay:0.5];
                }
            } else {
                [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut
                                 animations:^{
                                     scroll.contentOffset = CGPointMake(new_x, new_y);
                                 } completion:^(BOOL finished) {
                                     if (![[SSBPSdkIF sharedInstance] checkSame:newNodeId val2:nowNode.nodeId]) {
                                         [self setNodePos];
                                     }
                                 }
                 ];
            }

            [self onMark];
            [self setButtonState:true];
        }
    });
}

#pragma mark -
#pragma mark Draw

- (void)onDraw {
    if (nowNode == nil) return;
    if (floorImage == nil) return;

    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
            CGFloat scale = scroll.zoomScale;
            scroll.zoomScale = 1; // スケールを元に戻してからcontentSizeを設定しないとおかしな状態になる
            if (scroll.bounds.size.width < floorImage.size.width) {
                scroll.minimumZoomScale = scroll.bounds.size.width / floorImage.size.width;
            } else {
                scroll.minimumZoomScale = 1;
            }

            TSsbpFloor* floor = [self getFloor:nowNode.floorId];
            if (floor != nil) {
                lblTitle.text = [NSString stringWithFormat:@"%@ : %@", floor.facilityName, floor.floorName];
            } else return;

            TSsbpNode* goal = [[SSBPScannerManager sharedManager] getInnerNode:self.goalNodeId];
            [goalInfo setHidden:true];
            lblGoal.text = @"";
            if (goal != nil) {
                lblGoal.text = goal.nodeName;
                if (lblGoal.text.length > 0)
                    [goalInfo setHidden:false];
            }
            if (isFinished) {
                [goalInfo setHidden:true];
            }

            zoomView.frame = CGRectMake(0, 0, floorImage.size.width, floorImage.size.height);
            drawView.frame = CGRectMake(0, 0, floorImage.size.width, floorImage.size.height);

            scroll.contentSize = drawView.bounds.size;
            scroll.zoomScale = scale;

            // 描画開始
            UIGraphicsBeginImageContextWithOptions(drawView.frame.size, false, 0);
            CGContextRef context = UIGraphicsGetCurrentContext();
            if (context == nil) {
                UIGraphicsEndImageContext();
                return;
            }

            // フロアマップ描画--
            // Imageは上下逆にする必要が有り
            CGContextSaveGState(context); // Save
            CGContextTranslateCTM(context, 0, floorImage.size.height);
            CGContextScaleCTM(context, 1.0, -1.0);
            CGContextDrawImage(context, drawView.frame, [floorImage CGImage]);
            CGContextRestoreGState(context); // Restore
            // --フロアマップ描画

            if ((routeList != nil) && (routeList.count > 0)) {
                // ルート描画--
                CGContextSaveGState(context); // Save
                // 線種設定
                CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
                CGContextSetLineWidth(UIGraphicsGetCurrentContext(), 5.0);
                CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 252.0 / 255.0, 0 / 255.0, 0 / 255.0, 0.8);

                for (NSInteger root_num = 1; root_num < routeList.count; root_num++) {
                    TSsbpNode* node1 = [routeList objectAtIndex:root_num - 1];
                    TSsbpNode* node2 = [routeList objectAtIndex:root_num];

                    if ((node1 == nil) || (node2 == nil)) continue;
                    if (![[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:node1.floorId]) continue;
                    if (![[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:node2.floorId]) continue;

                    // 線描画
                    CGContextMoveToPoint(UIGraphicsGetCurrentContext(), node1.relativeX, node1.relativeY);
                    CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), node2.relativeX, node2.relativeY);
                    CGContextStrokePath(UIGraphicsGetCurrentContext());
                }
                CGContextRestoreGState(context); // Restore
                // --ルート描画

                // ノードマーク描画--
                CGContextSaveGState(context); // Save
                float mark_margin = 6;
                float mark_range = mark_margin * 1.5;
                for (NSInteger root_num = 0; root_num < routeList.count; root_num++) {
                    TSsbpNode* node = [routeList objectAtIndex:root_num];
                    if (node == nil) continue;
                    if (![[SSBPSdkIF sharedInstance] checkSame:floor.floorId val2:node.floorId]) continue;

                    CGRect mark_size = CGRectMake(node.relativeX - mark_range, node.relativeY - mark_range, mark_range * 2, mark_range * 2);
                    CGRect mark_b_size = CGRectInset(mark_size, -0.15, -0.15);
                    CGRect mark_i_size = CGRectMake(node.relativeX - mark_margin, node.relativeY - mark_margin, mark_margin * 2, mark_margin * 2);

                    // 外丸塗りつぶし
                    CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 1, 1, 1, 1);
                    CGContextFillEllipseInRect(UIGraphicsGetCurrentContext(), mark_size);

                    // 縁線
                    CGContextSetLineWidth(UIGraphicsGetCurrentContext(), 0.5);
                    CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 31.0 / 255.0, 235.0 / 255.0, 6.0 / 255.0, 0.8);
                    CGContextStrokeEllipseInRect(UIGraphicsGetCurrentContext(), mark_b_size);

                    // 中丸塗りつぶし
                    CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 31.0 / 255.0, 235.0 / 255.0, 6.0 / 255.0, 0.8);
                    CGContextFillEllipseInRect(UIGraphicsGetCurrentContext(), mark_i_size);
                }
                CGContextRestoreGState(context); // Restore
                // --ノードマーク描画
            }

            // 描画終了(更新＆クリア)
            drawView.image = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();

            TSsbpNode* newNode = [[SSBPScannerManager sharedManager] getInnerBeaconNode:nowBeaconId];
            if (newNode != nil) {
                if ([[SSBPSdkIF sharedInstance] checkSame:nowNodeId val2:newNode.nodeId]) {
                    [self setNodePos];
                }
            }
        }
    });
}

- (void)onMark {
    if (nowNode == nil) return;
    if (floorImage == nil) return;

    if (nowImage == nil) nowImage = [self pathForResource:@"now"];
    if (infoActImage == nil) infoActImage = [self pathForResource:@"contents_on"];
    if (infoDisImage == nil) infoDisImage = [self pathForResource:@"contents_off"];
    if (startImage == nil) startImage = [self pathForResource:@"start"];
    if (goalImage == nil) goalImage = [self pathForResource:@"goal"];
    if (downImage == nil) downImage = [self pathForResource:@"step_down"];
    if (upImage == nil) upImage = [self pathForResource:@"step_up"];
    if (moveImage == nil) moveImage = [self pathForResource:@"step_move"];
    [swCompass setEnabled:true];

    @autoreleasepool {
        markView.frame = CGRectMake(0, 0, floorImage.size.width, floorImage.size.height);

        // 描画開始
        UIGraphicsBeginImageContextWithOptions(markView.frame.size, false, 0);
        CGContextRef context = UIGraphicsGetCurrentContext();
        if (context == nil) {
            UIGraphicsEndImageContext();
            return;
        }

        // スタート/ゴール/Up/Downマーク描画
        if ((routeList != nil) && (routeList.count > 0)) {
            if (!isFinished) {
                if ([[SSBPSdkIF sharedInstance] checkSame:self.goalNodeId val2:nowNode.nodeId]) {
                    [goalInfo setHidden:true];
                    isFinished = false;
                    routeList = nil;
                    overall.routeList = nil;
                    startNodeId = @"";
                    self.goalNodeId = @"";
                    [self onDraw];
                    [self showAlert:0];
                    return;
                }
            }

            // Up/Down/Moveマーク描画--
            NSInteger move_count = 0;
            for (NSInteger root_num = 1; root_num < routeList.count; root_num++) {
                TSsbpNode* node1 = [routeList objectAtIndex:root_num - 1];
                TSsbpNode* node2 = [routeList objectAtIndex:root_num];
                if ((node1 == nil) || (node2 == nil)) continue;

                BOOL isFloor1 = [[SSBPSdkIF sharedInstance] checkSame:nowNode.floorId val2:node1.floorId];
                BOOL isFloor2 = [[SSBPSdkIF sharedInstance] checkSame:nowNode.floorId val2:node2.floorId];
                if (isFloor1 == isFloor2) continue;

                TSsbpFloor* floor1 = [self getFloor:node1.floorId];
                TSsbpFloor* floor2 = [self getFloor:node2.floorId];
                if ((floor1 == nil) || (floor2 == nil)) continue;

                if (isFloor1) {
                    move_count++;
                    NSString* marker = [NSString stringWithFormat:@"%ld", (long)move_count];
                    if (floor1.floorNum == floor2.floorNum) {
                        [self drawMoveMark:context image:moveImage marker:marker pos_x:node1.relativeX pos_y:node1.relativeY scale:MARK_SCALE];
                    }
                    if (floor1.floorNum < floor2.floorNum) {
                        [self drawMoveMark:context image:upImage marker:marker pos_x:node1.relativeX pos_y:node1.relativeY scale:MARK_SCALE];
                    }
                    if (floor1.floorNum > floor2.floorNum) {
                        [self drawMoveMark:context image:downImage marker:marker pos_x:node1.relativeX pos_y:node1.relativeY scale:MARK_SCALE];
                    }
                } else {
                    NSString* marker = [NSString stringWithFormat:@"%ld'", (long)move_count];
                    if (floor1.floorNum == floor2.floorNum) {
                        [self drawMoveMark:context image:moveImage marker:marker pos_x:node1.relativeX pos_y:node1.relativeY scale:MARK_SCALE];
                    }
                    if (floor1.floorNum < floor2.floorNum) {
                        [self drawMoveMark:context image:upImage marker:marker pos_x:node1.relativeX pos_y:node1.relativeY scale:MARK_SCALE];
                    }
                    if (floor1.floorNum > floor2.floorNum) {
                        [self drawMoveMark:context image:downImage marker:marker pos_x:node1.relativeX pos_y:node1.relativeY scale:MARK_SCALE];
                    }
                }
            }
            // --Up/Down/Moveマーク描画

            // スタートマーク描画--
            TSsbpNode* start_node = [routeList objectAtIndex:0];
            if (start_node != nil) {
                if ([[SSBPSdkIF sharedInstance] checkSame:nowNode.floorId val2:start_node.floorId]) {
                    [self drawGoal:context image:startImage pos_x:start_node.relativeX pos_y:start_node.relativeY scale:MARK_SCALE];
                }
            }
            // --スタートマーク描画

            // ゴールマーク描画--
            TSsbpNode* goal_node = [routeList objectAtIndex:routeList.count - 1];
            if (goal_node != nil) {
                if ([[SSBPSdkIF sharedInstance] checkSame:nowNode.floorId val2:goal_node.floorId]) {
                    [self drawGoal:context image:goalImage pos_x:goal_node.relativeX pos_y:goal_node.relativeY scale:MARK_SCALE];
                }
            }
            // --ゴールマーク描画
        }

        // コンテンツマーク描画--
        if ((actionList != nil) && (actionNodes != nil)) {
            for (TSsbpBeaconAction* action in actionList) {
                if (action.status == 0) continue;
                for (TSsbpNode* node in actionNodes) {
                    if (![[SSBPSdkIF sharedInstance] checkSame:nowNode.floorId val2:node.floorId]) continue;
                    if (![[SSBPSdkIF sharedInstance] checkSame:action.beaconId val2:node.beaconId]) continue;
                    [self drawContent:context pos_x:node.relativeX pos_y:node.relativeY status:action.status scale:MARK_SCALE];
                }
            }
        }
        // --コンテンツマーク描画

        // 現在地マーク描画--
        if (nowNode != nil) {
            [self drawMark:context image:nowImage pos_x:nowNode.relativeX pos_y:nowNode.relativeY scale:MARK_SCALE];
        }
        // --現在地マーク描画

        // 描画終了(更新＆クリア)
        markView.image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
}

- (void)drawMark:(CGContextRef)context image:(UIImage*)image pos_x:(CGFloat)pos_x pos_y:(CGFloat)pos_y scale:(CGFloat)scale {
    if (image == nil) return;

    @autoreleasepool {
        CGFloat mark_width = (float)scroll.bounds.size.width;
        CGFloat mark_height = (float)scroll.bounds.size.height;
        if (mark_width < mark_height) {
            mark_width = mark_height / scale;
        } else {
            mark_width = (mark_width - MARK_OFFSET) / scale;
        }

        CGFloat draw_width = (float)image.size.width;
        CGFloat draw_height = (float)image.size.height;
        CGFloat draw_scale = mark_width / draw_width;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) draw_scale = draw_scale / 2;

        CGContextSaveGState(context); // Save
        CGContextTranslateCTM(context, pos_x, pos_y);
        CGContextRotateCTM(context, -angle);
        CGContextScaleCTM(context, draw_scale, draw_scale);
        [image drawAtPoint:CGPointMake(-draw_width / 2, -draw_height)];
        CGContextRestoreGState(context); // Restore
    }
}

- (void)drawMoveMark:(CGContextRef)context image:(UIImage*)image marker:(NSString*)marker pos_x:(CGFloat)pos_x pos_y:(CGFloat)pos_y scale:(CGFloat)scale {
    if (image == nil) return;

    @autoreleasepool {
        CGFloat mark_width = (float)scroll.bounds.size.width;
        CGFloat mark_height = (float)scroll.bounds.size.height;
        if (mark_width < mark_height) {
            mark_width = mark_height / scale;
        } else {
            mark_width = (mark_width - MARK_OFFSET) / scale;
        }

        CGFloat draw_width = (float)image.size.width;
        CGFloat draw_height = (float)image.size.height;
        CGFloat draw_scale = mark_width / draw_width;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) draw_scale = draw_scale / 2;

        CGFloat marker_width = draw_width * 0.9;
        NSMutableParagraphStyle* paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
        paragraphStyle.lineBreakMode = NSLineBreakByTruncatingTail;
        paragraphStyle.alignment = NSTextAlignmentRight;

        CGContextSaveGState(context); // Save
        CGContextTranslateCTM(context, pos_x, pos_y);
        CGContextRotateCTM(context, -angle);
        CGContextScaleCTM(context, draw_scale, draw_scale);
        [image drawAtPoint:CGPointMake(-draw_width / 2, -draw_height)];
        [marker drawInRect:CGRectMake(-marker_width / 2, -40, marker_width, 40) withAttributes:@{ NSFontAttributeName:[UIFont boldSystemFontOfSize:36], NSForegroundColorAttributeName:[UIColor whiteColor], NSParagraphStyleAttributeName:paragraphStyle }];
        CGContextRestoreGState(context); // Restore
    }
}

- (void)drawGoal:(CGContextRef)context image:(UIImage*)image pos_x:(CGFloat)pos_x pos_y:(CGFloat)pos_y scale:(CGFloat)scale {
    if (image == nil) return;

    @autoreleasepool {
        CGFloat mark_width = (float)scroll.bounds.size.width;
        CGFloat mark_height = (float)scroll.bounds.size.height;
        if (mark_width < mark_height) {
            mark_width = mark_height / scale;
        } else {
            mark_width = (mark_width - MARK_OFFSET) / scale;
        }

        CGFloat draw_width = (float)image.size.width;
        CGFloat draw_height = (float)image.size.height;
        CGFloat draw_scale = mark_width / draw_width;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) draw_scale = draw_scale / 2;

        CGContextSaveGState(context); // Save
        CGContextTranslateCTM(context, pos_x, pos_y);
        CGContextRotateCTM(context, -angle);
        CGContextScaleCTM(context, draw_scale, draw_scale);
        [image drawAtPoint:CGPointMake(-draw_width / 6, -draw_height)];
        CGContextRestoreGState(context); // Restore
    }
}

- (void)drawContent:(CGContextRef)context pos_x:(CGFloat)pos_x pos_y:(CGFloat)pos_y status:(NSInteger)status scale:(CGFloat)scale {
    if (status < 1) return;

    @autoreleasepool {
        UIImage* image;
        if (status == 2) {
            image = infoDisImage;
        } else {
            image = infoActImage;
        }
        if (image == nil) return;

        CGFloat mark_width = (float)scroll.bounds.size.width;
        CGFloat mark_height = (float)scroll.bounds.size.height;
        if (mark_width < mark_height) {
            mark_width = mark_height / scale;
        } else {
            mark_width = (mark_width - MARK_OFFSET) / scale;
        }

        CGFloat draw_width = (float)image.size.width;
        CGFloat draw_height = (float)image.size.height;
        CGFloat draw_scale = mark_width / draw_width;
        if (status == 1) draw_scale = draw_scale * 2;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) draw_scale = draw_scale / 2;

        CGContextSaveGState(context); // Save
        CGContextTranslateCTM(context, pos_x, pos_y);
        CGContextRotateCTM(context, -angle);
        CGContextScaleCTM(context, draw_scale, draw_scale);
        [image drawAtPoint:CGPointMake(-draw_width / 2, -draw_height)];
        CGContextRestoreGState(context); // Restore
    }
}

#pragma mark -
#pragma mark touches Event

- (void)touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event {
}

-(void)touchesEnded:(NSSet*)touches withEvent:(UIEvent*)event {
    @autoreleasepool {
        if (touches.count == 1) {
            if ([event touchesForView:scroll]) {
                UITouch* touch = [touches anyObject];
                CGPoint touchLocation = [touch locationInView:scroll];
                NSString* beaconId = [self hitTestAction:touchLocation];
                if (beaconId.length > 0) {
                    NSLog(@"hit beaconId(%ld)", (long)beaconId);
                    [self startContent:beaconId];
                }
            }
        }
    }
}

- (NSString*)hitTestAction:(CGPoint)point {
    if (scroll == nil) return @"";
    if (infoActImage == nil) return @"";

    @autoreleasepool {
        CGFloat mark_width = (float)scroll.bounds.size.width;
        CGFloat mark_height = (float)scroll.bounds.size.height;
        if (mark_width < mark_height) {
            mark_width = mark_height / MARK_SCALE;
        } else {
            mark_width = (mark_width - MARK_OFFSET) / MARK_SCALE;
        }

        CGFloat draw_width = (float)infoActImage.size.width;
        CGFloat draw_height = (float)infoActImage.size.height;
        CGFloat draw_scale = mark_width / draw_width;
        draw_scale = draw_scale * 2;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) draw_scale = draw_scale / 2;
        draw_width = draw_width * draw_scale;
        draw_height = draw_height * draw_scale;

        if (actionList != nil) {
            for (TSsbpBeaconAction* action in actionList) {
                if (action.status != 1) continue; // コンテンツ未確認のみは1だけ、再利用可能にするなら1以上
                for (TSsbpNode* node in actionNodes) {
                    if (![[SSBPSdkIF sharedInstance] checkSame:nowNode.floorId val2:node.floorId]) continue;
                    if (![[SSBPSdkIF sharedInstance] checkSame:action.beaconId val2:node.beaconId]) continue;

                    CGRect rect = CGRectMake((node.relativeX - (draw_width * 0.5)) * scroll.zoomScale, (node.relativeY - draw_height) * scroll.zoomScale, draw_width * scroll.zoomScale, draw_height * scroll.zoomScale);

                    // コンテンツマークのアンカーポイント
                    CGFloat offset_x = rect.origin.x + rect.size.width / 2;
                    CGFloat offset_y = rect.origin.y + rect.size.height;

                    // 回転している場合の位置出し
                    CGAffineTransform transform = CGAffineTransformIdentity;
                    CGAffineTransform offset = CGAffineTransformMakeTranslation(-offset_x, -offset_y);
                    CGAffineTransform rotate = CGAffineTransformMakeRotation(-angle);
                    transform = CGAffineTransformConcat(transform, offset);
                    transform = CGAffineTransformConcat(transform, rotate);
                    rect = CGRectApplyAffineTransform(rect, transform);

                    CGAffineTransform transform2 = CGAffineTransformIdentity;
                    CGAffineTransform offset2 = CGAffineTransformMakeTranslation(offset_x, offset_y);
                    transform2 = CGAffineTransformConcat(transform2, offset2);
                    rect = CGRectApplyAffineTransform(rect, transform2);

                    if (CGRectContainsPoint(rect, point)) {
                        return node.beaconId;
                    }
                }
            }
        }
    }

    return @"";
}

- (void)startContent:(NSString*)beaconId {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSArray* contents = [[SSBPContentIF sharedInstance] getInnerBeaconContents:beaconId];
        if (contents == nil) return;
        if (contents.count == 0) return;

        [self updateStatus:beaconId status:2];
        [self setActionList];

        [SSBPSdkIF sharedInstance].delegateIF = nil;

        for (TSsbpContent* content in contents) {
            if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"navi"]) {
                [self useDB:content.contentId];
                [self openContent:content.contentURL];
                break;
            }
        }
    });
}

#pragma mark -
#pragma mark UIScrollViewDelegate override

- (UIView*)viewForZoomingInScrollView:(UIScrollView*)scrollView {
    return zoomView;
}

#pragma mark -
#pragma mark OverallDelegate override

- (void)didSetSize {
    [scrollOverall setContentSize:overall.frame.size];
}

#pragma mark -
#pragma mark SSBPSdkIFDelegate override

- (void)ssbpScannerHitRoute:(NSArray<NSString*>*)ssbpRoute {
    routeList = nil;
    overall.routeList = nil;

    dispatch_async(dispatch_get_main_queue(), ^{
        //NSLog(@"routes (%@)", ssbpRoute);
        if ((ssbpRoute != nil) && (ssbpRoute.count > 0)) {
            NSMutableArray* array = [NSMutableArray array];
            for (int i = 0; i < ssbpRoute.count; i++) {
                [array addObject:[[SSBPScannerManager sharedManager] getInnerNode:[ssbpRoute objectAtIndex:i]]];
            }
            routeList = [array copy];
            overall.routeList = [array copy];
        }
        [self onDraw];
        [self ssbpScannerChangeNearest:nowBeaconId];

        if ((routeList == nil) || (routeList.count == 0)) {
            [self showAlert:1];
        }
    });
}

- (void)ssbpScannerChangeNearest:(NSString*)beaconId {
    @autoreleasepool {
        TSsbpNode* newNode = [[SSBPScannerManager sharedManager] getInnerBeaconNode:beaconId];
        if (newNode == nil) return;

        [self setFloorList:newNode.beaconId];
        nowBeaconId = newNode.beaconId;

        NSInteger status = [self checkStatus:nowBeaconId];
        if (status == 0) {
            [self updateStatus:nowBeaconId status:1];
        }

        if ((routeList != nil) && (routeList.count > 0)) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(viewPopReroute) object:nil];
            });

            BOOL isRoute = false;
            for (TSsbpNode* node in routeList) {
                if ([[SSBPSdkIF sharedInstance] checkSame:nowBeaconId val2:node.beaconId]) {
                    isRoute = true;
                    break;
                }
            }
            if (isRoute) {
                [self hidePopReroute];
            } else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self performSelector:@selector(viewPopReroute) withObject:nil afterDelay:5];
                });
            }
        } else {
            if (self.goalNodeId.length > 0) {
                [self rerouteTap:nil];
                return;
            }
        }

        [self setNodePos];
    }
}

- (void)ssbpScannerDidFinishHeading {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!swCompass.isOn) return;
        angle = 2 * M_PI * -([SSBPScannerManager sharedManager].magneticHeading + offset_angle) / 360.0;
        scroll.transform = CGAffineTransformMakeRotation(angle);
        [self onMark];
    });
}

- (void)ssbpSdkIFAddContent:(NSString*)contentId {
    TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:contentId];
    if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"navi"]) {
        NSInteger status = [self checkStatus:nowBeaconId];
        if (status == 0) {
            [self updateStatus:nowBeaconId status:1];
            [self setNodePos];
        }
    } else if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"coupon"] || [[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"info"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self playSystemSound:1000];
            [self showAlert:content.contentAction message:content.contentName];
        });
    }
}

- (void)updateStatus:(NSString*)beaconId status:(NSInteger)status {
    @autoreleasepool {
        [[SSBPScannerManager sharedManager] setBeaconActionStatus:beaconId status:status];
    }
}

- (NSInteger)checkStatus:(NSString*)beaconId {
    @autoreleasepool {
        NSArray* contents = [[SSBPContentIF sharedInstance] getInnerBeaconContents:beaconId];
        if (contents == nil) return -1;
        if (contents.count == 0) return -1;

        TSsbpBeaconAction* action = [[SSBPScannerManager sharedManager] getBeaconAction:beaconId];
        if (action != nil) {
            return action.status;
        }
    }

    return -1;
}

#pragma mark -
#pragma mark DB's

- (void)loadDB {
    @autoreleasepool {
        Goals = nil;
        if ((floorList != nil) && (floorList.count > 0)) {
            for (TSsbpFloor* floor in floorList) {
                NSArray* goals = [[SSBPScannerManager sharedManager] getInnerGoals:@"" floorId:floor.floorId];
                if ((goals != nil) && (goals.count > 0)) {
                    for (TSsbpNode* goal in goals) {
                        [self addGoal:goal floorName:floor.floorName];
                    }
                }
            }
        }

        [self setViewGoal];
        [tblView reloadData];
    }
}

- (void)addGoal:(TSsbpNode*)goalNode floorName:(NSString*)floorName {
    @autoreleasepool {
        if (Goals == nil) {
            Goals = [GoalTreeNode new];
            Goals.nodeId = @"";
            Goals.isExpand = false;
            Goals.level = 0;
        }

        GoalTreeNode* floor;
        BOOL check = false;
        if (Goals.children != nil) {
            for (GoalTreeNode* child in Goals.children) {
                if ([[SSBPSdkIF sharedInstance] checkSame:goalNode.floorId val2:child.nodeId]) {
                    check = true;
                    floor = child;
                    break;
                }
            }
        }
        if (!check) {
            floor = [GoalTreeNode new];
            floor.nodeId = goalNode.floorId;
            floor.title = floorName;
            floor.isExpand = false;
            [Goals addChild:floor];
        }

        GoalTreeNode* goal = [GoalTreeNode new];;
        goal.nodeId = goalNode.nodeId;
        goal.title = [NSString stringWithFormat:@" - %@", goalNode.nodeName];
        goal.isExpand = false;
        [floor addChild:goal];
    }
}

- (void)setViewGoal {
    @autoreleasepool {
        if (viewGoals == nil) {
            viewGoals = [NSMutableArray array];
        } else {
            if (viewGoals.count > 0) {
                [viewGoals removeAllObjects];
            }
        }

        if (Goals == nil) return;

        if (Goals.children != nil) {
            for (GoalTreeNode* floor in Goals.children) {
                if (floor.children != nil) [viewGoals addObject:floor];
                if (!floor.isExpand) {
                    for (GoalTreeNode* goal in floor.children) {
                        [viewGoals addObject:goal];
                    }
                }
            }
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            if (viewGoals.count == 0) [btnMenu setHidden:true];
            else [btnMenu setHidden:false];
        });
    }
}

- (void)useDB:(NSString*)contentId {
    @autoreleasepool {
        [[SSBPSdkIF sharedInstance] useContent:contentId];
    }
}

#pragma mark -
#pragma mark DataSource's

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
    if (viewGoals == nil) {
        return 0;
    } else {
        return viewGoals.count;
    }
}

#pragma mark -
#pragma mark TableView's

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    UITableViewCell* cell = [self getCell:indexPath];
    return cell;
}

- (UITableViewCell*)getCell:(NSIndexPath*)indexPath {
    GoalTreeCell* goalCell = [tblView dequeueReusableCellWithIdentifier:@"GoalTreeCell" forIndexPath:indexPath];
    if (goalCell == nil) goalCell = [tblView dequeueReusableCellWithIdentifier:@"GoalTreeCell"];
    if ((viewGoals != nil) && (viewGoals.count > indexPath.row)) {
        [self setGoalCell:goalCell indexPath:indexPath];
    }
    return goalCell;
}

- (void)setGoalCell:(GoalTreeCell*)cell indexPath:(NSIndexPath*)indexPath {
    @autoreleasepool {
        GoalTreeNode* goal = [viewGoals objectAtIndex:indexPath.row];
        cell.title.text = goal.title;
        if (goal.level == 1) {
            cell.backgroundColor = RGBA(103, 192, 254, 1);
            cell.title.textColor = [UIColor whiteColor];
            cell.title.font = [UIFont boldSystemFontOfSize:cell.title.font.pointSize];
            [cell.expand setHidden:false];
            if (goal.isExpand) {
                cell.expand.image = [self pathForResource:@"arrow_r"];
            } else {
                cell.expand.image = [self pathForResource:@"arrow_u"];
            }
        } else if (goal.level == 2) {
            cell.backgroundColor = RGBA(238, 239, 240, 1);
            cell.title.textColor = [UIColor blackColor];
            cell.title.font = [UIFont systemFontOfSize:cell.title.font.pointSize];
            [cell.expand setHidden:true];
        }
    }
}

- (void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:true];

    @autoreleasepool {
        if (viewGoals.count > indexPath.row) {
            GoalTreeNode* goal = [viewGoals objectAtIndex:indexPath.row];
            if (goal.level == 1) {
                goal.isExpand = !goal.isExpand;
                [self setViewGoal];
                [tblView reloadData];
            } else if (goal.level == 2) {
                startNodeId = @"";
                self.goalNodeId = goal.nodeId;
                [self rerouteTap:nil];
                [self hidePopGoal];
            }
        }
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer*)gestureRecognizer shouldReceiveTouch:(UITouch*)touch {
    // おまじない
    // 子viewのtapを期待通りに動作させるための対策
    if ((touch.view != gestureRecognizer.view) && [touch.view isKindOfClass:[UIControl class]]) {
        return false;
    }
    return true;
}

#pragma mark -
#pragma mark Pop View

- (void)viewPopReroute {
    dispatch_async(dispatch_get_main_queue(), ^{
        [popReroute setHidden:false];
    });
}

- (void)hidePopReroute {
    dispatch_async(dispatch_get_main_queue(), ^{
        [popReroute setHidden:true];
    });
}

- (void)viewPopGoal {
    CGRect start = CGRectMake(wait.bounds.size.width, popGoal.frame.origin.y, popGoal.bounds.size.width, popGoal.bounds.size.height);
    CGRect end = CGRectMake(wait.bounds.size.width - popGoal.bounds.size.width, popGoal.frame.origin.y, popGoal.bounds.size.width, popGoal.bounds.size.height);
    dispatch_async(dispatch_get_main_queue(), ^{
        popGoal.frame = start;
        popGoal.alpha = 0.0;
        [popGoal setHidden:false];
        [UIView animateWithDuration:0.2 animations:^() {
            popGoal.frame = end;
            popGoal.alpha = 1.0;
        }];
    });
}

- (void)hidePopGoal {
    CGRect start = CGRectMake(wait.bounds.size.width - popGoal.bounds.size.width, popGoal.frame.origin.y, popGoal.bounds.size.width, popGoal.bounds.size.height);
    CGRect end = CGRectMake(wait.bounds.size.width, popGoal.frame.origin.y, popGoal.bounds.size.width, popGoal.bounds.size.height);
    dispatch_async(dispatch_get_main_queue(), ^{
        popGoal.frame = start;
        popGoal.alpha = 1.0;
        [UIView animateWithDuration:0.2 animations:^{
            popGoal.frame = end;
            popGoal.alpha = 0.0;
        } completion:^(BOOL finished) {
            [popGoal setHidden:true];
        }];
    });
}

- (void)viewPopOverall {
    CGRect start = CGRectMake(wait.bounds.size.width, popOverall.frame.origin.y, popOverall.bounds.size.width, popOverall.bounds.size.height);
    CGRect end = CGRectMake(wait.bounds.size.width - popOverall.bounds.size.width, popOverall.frame.origin.y, popOverall.bounds.size.width, popOverall.bounds.size.height);
    dispatch_async(dispatch_get_main_queue(), ^{
        popOverall.frame = start;
        popOverall.alpha = 0.0;
        [popOverall setHidden:false];
        [UIView animateWithDuration:0.2 animations:^() {
            popOverall.frame = end;
            popOverall.alpha = 1.0;
        }];
    });
}

- (void)hidePopOverall {
    CGRect start = CGRectMake(wait.bounds.size.width - popOverall.bounds.size.width, popOverall.frame.origin.y, popOverall.bounds.size.width, popOverall.bounds.size.height);
    CGRect end = CGRectMake(wait.bounds.size.width, popOverall.frame.origin.y, popOverall.bounds.size.width, popOverall.bounds.size.height);
    dispatch_async(dispatch_get_main_queue(), ^{
        popOverall.frame = start;
        popOverall.alpha = 1.0;
        [UIView animateWithDuration:0.2 animations:^{
            popOverall.frame = end;
            popOverall.alpha = 0.0;
        } completion:^(BOOL finished) {
            [popOverall setHidden:true];
        }];
    });
}

#pragma mark -
#pragma mark View Change

- (void)showAlert:(NSInteger)type {
    NSString* pos = UIKitLocalizedString(@"OK");

    NSString* title = @"";
    NSString* message = @"";
    if (type == 0) {
        message = NSLocalizedString(@"captionArrivalMessage", @"");
    } else if (type == 1) {
        title = NSLocalizedString(@"captionRouteErrorTitle", @"");
        message = NSLocalizedString(@"captionRerouteMessage", @"");
    } else {
        return;
    }

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:nil]];

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

- (void)showAlert:(NSString*)type message:(NSString*)message {
    NSString* pos = NSLocalizedString(@"captionGoList", @"");
    NSString* neg = UIKitLocalizedString(@"OK");

    alert_type = type;

    NSString* title = @"";
    if ([[SSBPSdkIF sharedInstance] checkSame:type val2:@"coupon"]) {
        title = NSLocalizedString(@"captionAddCouponTitle", @"");
    } else if ([[SSBPSdkIF sharedInstance] checkSame:type val2:@"info"]) {
        title = NSLocalizedString(@"captionAddInformationTitle", @"");
    } else {
        return;
    }

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
        if ([[SSBPSdkIF sharedInstance] checkSame:alert_type val2:@"coupon"]) {
            [self changeCouponView];
        } else if ([[SSBPSdkIF sharedInstance] checkSame:alert_type val2:@"info"]) {
            [self changeInfoView];
        }
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:nil]];

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

- (void)changeCouponView {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.navigationController.viewControllers.count <= 1) {
            UIViewController* rootView = [UIApplication sharedApplication].keyWindow.rootViewController;
            BOOL is_tabbar = [rootView.presentedViewController isKindOfClass:[UITabBarController class]];
            if (is_tabbar) {
                UITabBarController* childView = (UITabBarController*)rootView.presentedViewController;
                childView.selectedIndex = 1;
                [childView dismissViewControllerAnimated:true completion:nil];
            } else {
                CouponListViewController* couponListView = [self.storyboard instantiateViewControllerWithIdentifier:@"CouponListViewID"];
                [self presentViewController:couponListView animated:true completion:nil];
            }
        } else {
            self.tabBarController.selectedIndex = 1;
        }
    });
}

- (void)changeInfoView {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.navigationController.viewControllers.count <= 1) {
            UIViewController* rootView = [UIApplication sharedApplication].keyWindow.rootViewController;
            BOOL is_tabbar = [rootView.presentedViewController isKindOfClass:[UITabBarController class]];
            if (is_tabbar) {
                UITabBarController* childView = (UITabBarController*)rootView.presentedViewController;
                childView.selectedIndex = 2;
                [childView dismissViewControllerAnimated:true completion:nil];
            } else {
                InfoListViewController* infoListView = [self.storyboard instantiateViewControllerWithIdentifier:@"InfoListViewID"];
                [self presentViewController:infoListView animated:true completion:nil];
            }
        } else {
            self.tabBarController.selectedIndex = 2;
        }
    });
}

// 拡張子判定による、WebBrowser/MediaPlayerの呼び出し
- (void)openContent:(NSString*)strUrl {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSArray* supported = [NSArray arrayWithObjects:@"mp4", @"3gp", @"mov", @"avi", @"mpeg", @"mpv", @"aac", @"amr", @"mp3", @"aiff", @"caf", @"m4a", @"ogg", @"wav", nil];
        NSString* ext = [strUrl pathExtension];

        if ([supported containsObject:ext]) {
            VideoViewController* video = [VideoViewController new];
            video.url = strUrl;
            video.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
            [self presentViewController:video animated:true completion:NULL];
        } else {
            BrowserViewController* browserView = [self.storyboard instantiateViewControllerWithIdentifier:@"BrowserViewID"];
            //WKBrowserViewController* browserView = [self.storyboard instantiateViewControllerWithIdentifier:@"WKBrowserViewID"];
            browserView.url = strUrl;
            [self presentViewController:browserView animated:true completion:nil];
        }
    });
}

#pragma mark -
#pragma mark Etc

- (UIImage*)pathForResource:(NSString*)fname {
    @autoreleasepool {
        if (fname.length > 0) {
            UIImage* image = [UIImage imageNamed:fname];
            return image;
        } else return nil;
    }
}

- (void)playSystemSound:(SystemSoundID)soundId {
    @autoreleasepool {
        AudioServicesPlaySystemSound(soundId);
    }
}

@end
