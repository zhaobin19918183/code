//
//  InfoListViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define UIKitLocalizedString(key) [[NSBundle bundleWithIdentifier:@"com.apple.UIKit"] localizedStringForKey:key value:@"" table:nil]

#import "InfoListViewController.h"

#import "InfoCell.h"

#import "InfoViewController.h"

@implementation InfoListViewController {
    __weak IBOutlet UIButton* btnBack;
    __weak IBOutlet UIButton* btnClear;

    __weak IBOutlet UITableView* tblView;

    NSArray* Infos;

    SSBPHttpRequester* requester;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnClear != nil) {
        btnClear.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [SSBPSdkIF sharedInstance].delegateIF = self;

    tblView.dataSource = self;
    tblView.delegate = self;

    [self loadDB];
}

- (void)viewDidDisappear:(BOOL)animated {
    tblView.dataSource = nil;
    tblView.delegate = nil;

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Event

- (IBAction)backTap:(UIButton*)sender {
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

- (IBAction)clearTap:(UIButton*)sender {
    [self showAlert];
}

#pragma mark -
#pragma mark SSBPSdkIFDelegate override

- (void)ssbpSdkIFAddContent:(NSString*)contentId {
    TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:contentId];
    if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"info"]) {
        [self loadDB];
    }
}

#pragma mark -
#pragma mark DB's

- (void)loadDB {
    @autoreleasepool {
        Infos = nil;
        Infos = [[SSBPContentIF sharedInstance] getInnerContents:@"info"];
        [tblView reloadData];
    }
}

- (void)deleteDB:(NSInteger)index {
    if (index < 0) return;
    if (Infos.count <= index) return;

    @autoreleasepool {
        TSsbpContent* ssbpContent = [Infos objectAtIndex:index];
        [[SSBPSdkIF sharedInstance] removeContent:ssbpContent.contentId];
        [self loadDB];
    }
}

#pragma mark -
#pragma mark DataSource's

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
    if (Infos == nil) {
        return 0;
    } else {
        return Infos.count;
    }
}

#pragma mark -
#pragma mark TableView's

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    UITableViewCell* cell = [self getCell:indexPath];
    return cell;
}

- (UITableViewCell*)getCell:(NSIndexPath*)indexPath {
    InfoCell* infoCell = [tblView dequeueReusableCellWithIdentifier:@"InfoCell" forIndexPath:indexPath];
    if (infoCell == nil) infoCell = [tblView dequeueReusableCellWithIdentifier:@"InfoCell"];
    if ((Infos != nil) && (Infos.count > indexPath.row)) {
        [self setInfoCell:infoCell indexPath:indexPath];
    }
    return infoCell;
}

- (void)setInfoCell:(UITableViewCell*)cell indexPath:(NSIndexPath*)indexPath {
    @autoreleasepool {
        __block TSsbpContent* content = [Infos objectAtIndex:indexPath.row];
        NSDate* startAt = [[SSBPSdkIF sharedInstance] makeUTCDateTimeFromString:content.contentStartAt];
        NSDate* endAt = [[SSBPSdkIF sharedInstance] makeUTCDateTimeFromString:content.contentEndAt];

        __block InfoCell* infoCell = (InfoCell*)cell;

        infoCell.logo.image = [self pathForResource:@"dummy_logo"];
        if (content.contentSubImage != nil) {
            infoCell.logo.image = [[UIImage alloc] initWithData:content.contentSubImage];
        } else {
            // 非同期で処理
            if ([content.contentSubImageURL hasPrefix:@"http"]) {
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    if (requester == nil) requester = [SSBPHttpRequester new];
                    [requester httpRequestGet:content.contentSubImageURL withParam:nil completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
                        if ((error != nil) || (data == nil)) return;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            content.contentSubImage = data;
                            [[SSBPContentIF sharedInstance] addContent:content];
                            infoCell.logo.image = [[UIImage alloc] initWithData:content.contentSubImage];
                        });
                    }];
                });
            }
        }

        infoCell.title.text = content.contentName;
        infoCell.expireDate.text= [NSString stringWithFormat:@"%@ : %@ - %@", NSLocalizedString(@"captionInfoValidityPeriod", @""), [[SSBPSdkIF sharedInstance] makeLocaleDateToString:startAt], [[SSBPSdkIF sharedInstance] makeLocaleDateToString:endAt]];
    }
}

- (void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:true];

    @autoreleasepool {
        if (Infos.count > indexPath.row) {
            TSsbpContent* ssbpContent = [Infos objectAtIndex:indexPath.row];
            dispatch_async(dispatch_get_main_queue(), ^{
                InfoViewController* infoView = [self.storyboard instantiateViewControllerWithIdentifier:@"InfoViewID"];
                infoView.contentId = ssbpContent.contentId;
                [self presentViewController:infoView animated:true completion:nil];
            });
        }
    }
}

- (void)tableView:(UITableView*)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath*)indexPath {
    @autoreleasepool {
        if (editingStyle == UITableViewCellEditingStyleDelete) {
            [self deleteDB:indexPath.row];
        } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        }
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer*)gestureRecognizer shouldReceiveTouch:(UITouch*)touch {
    // おまじない
    // 子viewのtapを期待通りに動作させるための対策
    if ((touch.view != gestureRecognizer.view) && [touch.view isKindOfClass:[UIControl class]]) {
        return false;
    }
    return true;
}

#pragma mark -
#pragma mark View Change

- (void)showAlert {
    NSString* pos = UIKitLocalizedString(@"OK");
    NSString* neg = UIKitLocalizedString(@"Cancel");

    NSString* title = NSLocalizedString(@"captionInfoClearTitle", @"");
    NSString* message = NSLocalizedString(@"captionInfoClearMessage", @"");

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
        [[SSBPSdkIF sharedInstance] clearActionContent:@"info"];
        [self loadDB];
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:nil]];

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

#pragma mark -
#pragma mark Etc

- (UIImage*)pathForResource:(NSString*)fname {
    @autoreleasepool {
        if (fname.length > 0) {
            UIImage* image = [UIImage imageNamed:fname];
            return image;
        } else return nil;
    }
}

@end
