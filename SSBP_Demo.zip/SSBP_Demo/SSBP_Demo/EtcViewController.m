//
//  EtcViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "EtcViewController.h"

#import "SettingPickerButton.h"
#import "TSsbpApp.h"

#import "SettingViewController.h"
#import "FacilityMaskViewController.h"

@implementation EtcViewController {
    __weak IBOutlet DrawButton* btnSetting;
    __weak IBOutlet SettingPickerButton* btnApp;
    __weak IBOutlet DrawButton* btnMaster;
    __weak IBOutlet DrawButton* btnFacilityMask;
    __weak IBOutlet DrawButton* btnClear;
    __weak IBOutlet DrawButton* btnDigest;

    __weak IBOutlet UILabel* lblLocaleID;
    __weak IBOutlet UILabel* lblDeviceID;
    __weak IBOutlet UILabel* lblDeviceToken;

    __weak IBOutlet UIView* wait;

    ActionText* actionText;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnSetting != nil) {
        btnSetting.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnApp != nil) {
        btnApp.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnMaster != nil) {
        btnMaster.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnFacilityMask != nil) {
        btnFacilityMask.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnClear != nil) {
        btnClear.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnDigest != nil) {
        btnDigest.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }

    actionText = [[ActionText alloc] initWithFrame:CGRectZero];
    [actionText setView:self.view.frame.size];
    [self.view addSubview:actionText];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [SSBPSdkIF sharedInstance].delegateIF = self;

    [lblLocaleID setText:[NSString stringWithFormat:@"LocaleID:%@", [SSBPSdkIF sharedInstance].localeId]];
    [lblDeviceID setText:[NSString stringWithFormat:@"DeviceID:%@", [SSBPSdkIF sharedInstance].deviceId]];
    [lblDeviceToken setText:[NSString stringWithFormat:@"DeviceToken:%@", [SSBPSdkIF sharedInstance].deviceToken]];

    actionText.delegateAT = self;

    [self loadCSV];
}

- (void)viewDidDisappear:(BOOL)animated {
    actionText.delegateAT = nil;

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Events

- (IBAction)didPushApp:(SettingPickerButton*)sender {
    NSArray* keys = [sender.dic allKeys];
    keys = [keys sortedArrayUsingComparator:^(id o1, id o2) {
        return [o1 compare:o2];
    }];
    for (NSString* key in keys) {
        NSString* value = [sender.dic objectForKey:key];
        if ([[SSBPSdkIF sharedInstance] checkSame:value val2:sender.currentTitle]) {
            [actionText showPickerView:sender.tagString key:key dic:sender.dic];
            return;
        }
    }

    [actionText showPickerView:sender.tagString key:nil dic:sender.dic];
}

- (IBAction)didPushSetting:(UIButton*)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        SettingViewController* settingView = [self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewID"];
        [self presentViewController:settingView animated:true completion:nil];
    });
}

- (IBAction)didPushMaster:(UIButton*)sender {
    if (btnApp.currentTitle.length > 0) {
        [self viewWait:true];
        [[SSBPSdkIF sharedInstance] setMaster:btnApp.currentTitle];
    }
}

- (IBAction)didPushFacilityMask:(UIButton*)sender {
    if (btnApp.currentTitle.length > 0) {
        FacilityMaskViewController* facilityMaskView = [self.storyboard instantiateViewControllerWithIdentifier:@"FacilityMaskViewID"];
        [self presentViewController:facilityMaskView animated:true completion:nil];
    }
}

- (IBAction)didPushClear:(UIButton*)sender {
    [[SSBPSdkIF sharedInstance] clearAllContent];
}

- (IBAction)didPushDigest:(UIButton*)sender {
    [self makeDigest];
}

- (void)makeDigest {
    NSLog(@"%@", [[SSBPSdkIF sharedInstance] checkAuthDigest]);
}

#pragma mark -
#pragma mark CSV's

- (void)loadCSV {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self viewWait:true];

        NSArray* appInfos = [[SSBPSdkIF sharedInstance] getAppInfos];
        NSMutableDictionary* dic = [NSMutableDictionary dictionary];
        for (int i = 0; i < appInfos.count; i++) {
            TSsbpApp* appInfo = [appInfos objectAtIndex:i];
            [dic setObject:appInfo.appName forKey:appInfo.appId];
        }
        btnApp.dic = dic;

        NSString* appName = [SSBPSdkIF sharedInstance].appName;
        if (appName.length > 0) {
            [btnApp setTitle:appName forState:UIControlStateNormal];
            [btnMaster setEnabled:true];
            [btnFacilityMask setEnabled:true];
        } else {
            [btnApp setTitle:NSLocalizedString(@"captionPickerDefault", @"") forState:UIControlStateNormal];
            [btnMaster setEnabled:false];
            [btnFacilityMask setEnabled:false];
        }

        [self viewWait:false];
    });
}

- (void)viewWait:(BOOL)flag {
    if (!flag) {
        [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    } else {
        [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    }
    [wait setHidden:!flag];
}

#pragma mark -
#pragma mark SSBPSdkIFDelegate override

- (void)ssbpSdkIFDidFailCheckMaster {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self viewWait:false];
        [self showAlert];
    });
}

- (void)ssbpScannerDidFinishCheckMaster {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self viewWait:false];

        [lblLocaleID setText:[NSString stringWithFormat:@"LocaleID:%@", [SSBPSdkIF sharedInstance].localeId]];
        [lblDeviceID setText:[NSString stringWithFormat:@"DeviceID:%@", [SSBPSdkIF sharedInstance].deviceId]];
        [lblDeviceToken setText:[NSString stringWithFormat:@"DeviceToken:%@", [SSBPSdkIF sharedInstance].deviceToken]];

        NSLog(@"DeviceID=%@", [SSBPSdkIF sharedInstance].deviceId);
    });
}

#pragma mark -
#pragma mark ActionTextDelegate override

- (void)actionTextDidSelect:(NSString*)type selected:(NSString*)selected {
    NSString* value = [btnApp.dic objectForKey:selected];
    if (![[SSBPSdkIF sharedInstance] checkSame:value val2:btnApp.currentTitle]) {
        [btnApp setTitle:value forState:UIControlStateNormal];
        [btnMaster setEnabled:true];
        [btnFacilityMask setEnabled:true];
    } else {
        [btnApp setTitle:NSLocalizedString(@"captionPickerDefault", @"") forState:UIControlStateNormal];
        [btnMaster setEnabled:false];
        [btnFacilityMask setEnabled:false];
    }
}

#pragma mark -
#pragma mark View Change

- (void)showAlert {
    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"Error" message:@"Please check the network and try again." preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

@end
