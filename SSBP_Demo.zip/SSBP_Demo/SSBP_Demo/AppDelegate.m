//
//  AppDelegate.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "AppDelegate.h"

#import "SSBPSdkIF.h"

#import "TabBarControllerEx.h"
#import "OpeningViewController.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions {
    // 10秒間ルールで処理を必要とする場合で、可能なことであればここで動作させる
    if ([launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey]) {
        // アプリ完全終了状態でAPNsを受信したい場合はここか？
    }
    if ([launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey]) {
        // アプリ完全終了状態で通知から起動した場合に、通常のトップ画面ではなく特定の画面に遷移させたい場合はここで処理
        NSLog(@"UIApplicationLaunchOptionsLocalNotificationKey");
        UILocalNotification* notification = [launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
        if (notification != nil) {
            [self openCustomPage:notification.userInfo];
        }
    }
    if ([launchOptions objectForKey:UIApplicationLaunchOptionsLocationKey]) {
        // アプリ完全終了状態でBeacon/GPS受信したい場合は、ここでLocationManagerを再起動し検知デリゲートを取得できるように処理
        // 通知等の処理だけで完結するなら、CapabilitiesでBackGround ModesをONにして"location update"項目をチェックする必要無し
        [[SSBPSdkIF sharedInstance] scanStart];
    }

    UITextField* lagFreeField = [[UITextField alloc] init];
    [self.window addSubview:lagFreeField];
    [lagFreeField becomeFirstResponder];
    [lagFreeField resignFirstResponder];
    [lagFreeField removeFromSuperview];

    return true;
}

- (void)applicationWillResignActive:(UIApplication*)application {
}

- (void)applicationDidEnterBackground:(UIApplication*)application {
    [[SSBPSdkIF sharedInstance] applicationEnterBackground];
}

- (void)applicationWillEnterForeground:(UIApplication*)application {
}

- (void)applicationDidBecomeActive:(UIApplication*)application {
    [[SSBPSdkIF sharedInstance] applicationBecomeActive];
}

- (void)applicationWillTerminate:(UIApplication*)application {
    [[SSBPSdkIF sharedInstance] applicationTerminate];
}

// アプリがバックグラウンドにある状態で通知から起動した場合に、通常のトップ画面ではなく特定の画面に遷移させたい場合はここで処理
- (void)application:(UIApplication*)application didReceiveLocalNotification:(UILocalNotification*)notification {
    NSLog(@"didReceiveLocalNotification %@", notification.userInfo);
    if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive) {
    } else {
        NSDictionary* userInfo = notification.userInfo;
        [self openCustomPage:userInfo];
    }
}

// 通常のトップ画面ではなく特定の画面に遷移させたい場合はここで処理
//  最後に表示していた画面が遷移可能な同一階層のTabBarControllerであれば単純な切り替え
//  それ以外の状態からであれば、オープニングからとする
- (void)openCustomPage:(NSDictionary*)userInfo {
    if (userInfo == nil) return;

    NSString* type = [userInfo objectForKey:SSBP_NOTIFICATION_TYPE];

    OpeningViewController* ovc = nil;
    TabBarControllerEx* tbc = nil;
    if ([[[self window] rootViewController] isKindOfClass:[OpeningViewController class]]) {
        ovc = (OpeningViewController*)[[self window] rootViewController];
        if ([ovc.presentedViewController isMemberOfClass:[TabBarControllerEx class]]) {
            tbc = (TabBarControllerEx*)ovc.presentedViewController;
            if (tbc.presentedViewController != nil) {
                tbc = nil;
                UIStoryboard* sb = [[[self window] rootViewController] storyboard];
                ovc = [sb instantiateViewControllerWithIdentifier:@"OpeningViewID"];
            }
        }
    } else {
        UIStoryboard* sb = [[[self window] rootViewController] storyboard];
        ovc = [sb instantiateViewControllerWithIdentifier:@"OpeningViewID"];
    }

    if (tbc != nil) {
        if ([[SSBPSdkIF sharedInstance] checkSame:type val2:@"coupon"]) {
            tbc.selectedIndex = 1;
        }
        if ([[SSBPSdkIF sharedInstance] checkSame:type val2:@"info"]) {
            tbc.selectedIndex = 2;
        }
    } else if (ovc != nil) {
        if ([[SSBPSdkIF sharedInstance] checkSame:type val2:@"coupon"]) {
            ovc.nextPage = 1;
        }
        if ([[SSBPSdkIF sharedInstance] checkSame:type val2:@"info"]) {
            ovc.nextPage = 2;
        }

        [self.window setRootViewController:ovc];
        [self.window makeKeyAndVisible];
    }
}

/*
#pragma mark -
#pragma mark APNs関連

// iOS8以降でデバイストークンの取得に1段階必要な処理
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings {
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    // APNSへ登録成功 -> SSBPへ登録処理
    [[SSBPSdkIF sharedInstance] registerDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    // APNSへ登録失敗
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    // 結果は３パターンとなる
    //completionHandler(UIBackgroundFetchResultNewData);
    //completionHandler(UIBackgroundFetchResultNoData);
    //completionHandler(UIBackgroundFetchResultFailed);

    if (![userInfo[@"aps"][@"content-available"] intValue]) {
        // Silent Push
        completionHandler(UIBackgroundFetchResultNoData);
        return;
    }

    // ここで、なんらかの処理を行い、その結果でcompletionHandlerを返す
    if (application.applicationState == UIApplicationStateActive) {
        NSLog(@"通知受信(UIApplicationStateActive)");
    } else if (application.applicationState == UIApplicationStateInactive) {
        NSLog(@"通知受信(UIApplicationStateInactive)");
    } else {
        NSLog(@"通知受信(Etc)");
    }
    completionHandler(UIBackgroundFetchResultNewData);
}
*/

@end
