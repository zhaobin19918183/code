//
//  StampListViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define UIKitLocalizedString(key) [[NSBundle bundleWithIdentifier:@"com.apple.UIKit"] localizedStringForKey:key value:@"" table:nil]

#import "StampListViewController.h"

#import "StampCollectionNode.h"
#import "StampCollectionCell.h"

@implementation StampListViewController {
    __weak IBOutlet UIButton* btnBack;
    __weak IBOutlet UIButton* btnClear;

    __weak IBOutlet UICollectionView* tileView;

    __weak IBOutlet UIView* winView;

    NSMutableArray* viewStamps;

    SSBPHttpRequester* requester;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnClear != nil) {
        btnClear.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }

    if (tileView != nil) {
        tileView.backgroundColor = [UIColor whiteColor];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [SSBPSdkIF sharedInstance].delegateIF = nil;

    tileView.dataSource = self;
    tileView.delegate = self;

    [self loadDB];
}

- (void)viewDidDisappear:(BOOL)animated {
    tileView.dataSource = nil;
    tileView.delegate = nil;

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Event

- (IBAction)backTap:(UIButton*)sender {
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

- (IBAction)clearTap:(UIButton*)sender {
    [self showAlert];
}

#pragma mark -
#pragma mark DB's

- (void)loadDB {
    @autoreleasepool {
        if (viewStamps == nil) {
            viewStamps = [NSMutableArray array];
        } else {
            if (viewStamps.count > 0) {
                [viewStamps removeAllObjects];
            }
        }

        TSsbpNode* newNode = [[SSBPScannerManager sharedManager] getInnerBeaconNode:self.nowBeaconId];
        if (newNode == nil) return;
        NSString* facilityId = newNode.facilityId;

        int done_count = 0;
        int stamp_count = 0;

        NSArray* stamps = [[SSBPScannerManager sharedManager] getInnerNodesWithAction:@"stamp" facilityId:facilityId floorId:@""];
        if ((stamps != nil) && (stamps.count > 0)) {
            for (TSsbpNode* node in stamps) {
                stamp_count++;
                StampCollectionNode* stamp = [StampCollectionNode new];
                stamp.nodeId = node.nodeId;
                stamp.title = node.nodeName;

                NSArray* contents = [[SSBPContentIF sharedInstance] getInnerBeaconContents:node.beaconId];
                if (contents != nil) {
                    for (TSsbpContent* content in contents) {
                        if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"navi"]) {
                            stamp.contentId = content.contentId;
                            break;
                        }
                    }
                }

                TSsbpBeaconAction* action = [[SSBPScannerManager sharedManager] getBeaconAction:node.beaconId];
                if (action != nil) {
                    if (action.status > 1) {
                        done_count++;
                        stamp.status = 1;
                    } else stamp.status = 0;
                }

                [viewStamps addObject:stamp];
            }
        }
        [tileView reloadData];

        if (done_count == stamp_count) {
            [winView setHidden:false];
        } else {
            [winView setHidden:true];
        }
    }
}

#pragma mark -
#pragma mark DataSource's

- (NSInteger)collectionView:(UICollectionView*)collectionView numberOfItemsInSection:(NSInteger)section {
    if (viewStamps == nil) {
        return 0;
    } else {
        return viewStamps.count;
    }
}

#pragma mark -
#pragma mark CollectionView's

- (UICollectionViewCell*)collectionView:(UICollectionView*)collectionView cellForItemAtIndexPath:(NSIndexPath*)indexPath {
    UICollectionViewCell* cell = [self getCell:indexPath];
    return cell;
}

- (UICollectionViewCell*)getCell:(NSIndexPath*)indexPath {
    StampCollectionCell* stampCell = [tileView dequeueReusableCellWithReuseIdentifier:@"StampCollectionCell" forIndexPath:indexPath];
    if ((viewStamps != nil) && (viewStamps.count > indexPath.row)) {
        [self setStampCell:stampCell indexPath:indexPath];
    }
    return stampCell;
}

- (void)setStampCell:(StampCollectionCell*)cell indexPath:(NSIndexPath*)indexPath {
    @autoreleasepool {
        StampCollectionNode* stamp = [viewStamps objectAtIndex:indexPath.row];
        cell.title.text = stamp.title;

        TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:stamp.contentId];
        if (content != nil) {
            if ((content.stampYetImageURL.length > 0) && (content.stampYetImage == nil)) {
                [self getYetImage:cell content:content];
            } else if ((content.stampDoneImageURL.length > 0) && (content.stampDoneImage == nil)) {
                [self getDoneImage:cell content:content];
            }
            if (content.stampYetImage != nil) {
                cell.yet.image = [[UIImage alloc] initWithData:content.stampYetImage];
            } else {
                cell.yet.image = [self pathForResource:@"yet"];
            }
            if (content.stampDoneImage != nil) {
                cell.done.image = [[UIImage alloc] initWithData:content.stampDoneImage];
            } else {
                cell.done.image = [self pathForResource:@"yet"];
            }
        } else {
            cell.yet.image = [self pathForResource:@"yet"];
            cell.done.image = [self pathForResource:@"done"];
        }
        [cell setStatus:stamp.status];
    }
}

- (void)getYetImage:(StampCollectionCell*)stampCell content:(TSsbpContent*)content {
    __block StampCollectionCell* weakCell = stampCell;
    __block TSsbpContent* weakContent = content;

    // 非同期で処理
    if ([weakContent.stampYetImageURL hasPrefix:@"http"]) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            if (requester == nil) requester = [SSBPHttpRequester new];
            [requester httpRequestGet:weakContent.stampYetImageURL withParam:nil completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
                if ((error != nil) || (data == nil)) return;
                dispatch_async(dispatch_get_main_queue(), ^{
                    weakContent.stampYetImage = data;
                    [[SSBPContentIF sharedInstance] addContent:weakContent];
                    weakCell.yet.image = [[UIImage alloc] initWithData:weakContent.stampYetImage];

                    if ((weakContent.stampDoneImageURL.length > 0) && (weakContent.stampDoneImage == nil)) {
                        [self getDoneImage:weakCell content:weakContent];
                    }
                });
            }];
        });
    } else if ((weakContent.stampDoneImageURL.length > 0) && (content.stampDoneImage == nil)) {
        [self getDoneImage:weakCell content:weakContent];
    }
}

- (void)getDoneImage:(StampCollectionCell*)stampCell content:(TSsbpContent*)content {
    __block StampCollectionCell* weakCell = stampCell;
    __block TSsbpContent* weakContent = content;

    // 非同期で処理
    if ([weakContent.stampDoneImageURL hasPrefix:@"http"]) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            if (requester == nil) requester = [SSBPHttpRequester new];
            [requester httpRequestGet:weakContent.stampDoneImageURL withParam:nil completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
                if ((error != nil) || (data == nil)) return;
                dispatch_async(dispatch_get_main_queue(), ^{
                    weakContent.stampDoneImage = data;
                    [[SSBPContentIF sharedInstance] addContent:weakContent];
                    weakCell.done.image = [[UIImage alloc] initWithData:weakContent.stampDoneImage];
                });
            }];
        });
    }
}

#pragma mark -
#pragma mark FlowLayout's

- (CGSize)collectionView:(UICollectionView*)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath*)indexPath {
    CGFloat scale = [UIScreen mainScreen].scale;
    CGFloat width = [[UIScreen mainScreen] bounds].size.width;
    width = (width / 2) - (20 * scale);
    return CGSizeMake(width, width);
}

- (UIEdgeInsets)collectionView:(UICollectionView*)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    CGFloat scale = [UIScreen mainScreen].scale;
    return UIEdgeInsetsMake((10 * scale), (10 * scale), (10 * scale), (10 * scale));
}

- (CGFloat)collectionView:(UICollectionView*)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    CGFloat scale = [UIScreen mainScreen].scale;
    return (10 * scale);
}

- (CGFloat)collectionView:(UICollectionView*)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    CGFloat scale = [UIScreen mainScreen].scale;
    return (10 * scale);
}

#pragma mark -
#pragma mark View Change

- (void)showAlert {
    NSString* pos = UIKitLocalizedString(@"OK");
    NSString* neg = UIKitLocalizedString(@"Cancel");

    NSString* title = NSLocalizedString(@"captionStampClearTitle", @"");
    NSString* message = NSLocalizedString(@"captionStampClearMessage", @"");

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
        [[SSBPSdkIF sharedInstance] clearActionContent:@"navi"];
        [self loadDB];
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:nil]];

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

#pragma mark -
#pragma mark Etc

- (UIImage*)pathForResource:(NSString*)fname {
    @autoreleasepool {
        if (fname.length > 0) {
            UIImage* image = [UIImage imageNamed:fname];
            return image;
        } else return nil;
    }
}

@end
