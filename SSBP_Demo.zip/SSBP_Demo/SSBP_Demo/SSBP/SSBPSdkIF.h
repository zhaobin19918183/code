//
//  SSBPSdkIF.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_App_Static_SSBPSdkIF_h
#define SSBP_App_Static_SSBPSdkIF_h

#define SSBP_NOTIFICATION_TYPE   @"NotificationType"
#define SSBP_NOTIFICATION_ID     @"NotificationID"

#import <Foundation/Foundation.h>

#import <SSBPSdk/SSBPSDK.h>

#import "SSBPContentIF.h"
#import "TSsbpApp.h"

@protocol SSBPSdkIFDelegate <SSBPScannerDelegate>

@optional

- (void)ssbpSdkIFDidFailCheckMaster;
- (void)ssbpSdkIFDidFinishGetAttributes;
- (void)ssbpSdkIFDidFinishGetDeviceInfo;
- (void)ssbpSdkIFDidFinishUpdateDeviceInfo;
- (void)ssbpSdkIFAddContent:(NSString*)contentId;

@end

@interface SSBPSdkIF : NSObject <SSBPScannerDelegate, SSBPContentIFDelegate>

@property (weak, nonatomic) id<SSBPSdkIFDelegate>delegateIF;

@property (assign, nonatomic) BOOL useBeaconLog;
@property (assign, nonatomic) BOOL useContentLog;
@property (assign, nonatomic) BOOL useNotification;

@property (copy, nonatomic, readonly) NSString* appName;
@property (copy, nonatomic, readonly) NSString* appKey;
@property (copy, nonatomic, readonly) NSString* secretKey;
@property (copy, nonatomic, readonly) NSString* localeId;
@property (copy, nonatomic, readonly) NSString* localeDefault;
@property (copy, nonatomic, readonly) NSString* deviceId;
@property (copy, nonatomic, readonly) NSString* deviceToken;

@property (copy, nonatomic, readonly) NSArray<SSBPQuestion*>* attrQuestions;
@property (strong, nonatomic) NSMutableDictionary* attrAnswers; //strongで扱わないとcrashする？

+ (SSBPSdkIF*)sharedInstance;

- (NSArray<TSsbpApp*>*)getAppInfos;
- (void)setMaster:(NSString*)appName;

- (void)applicationNewActive;
- (void)applicationBecomeActive;
- (void)applicationEnterBackground;
- (void)applicationTerminate;

- (void)getAttributes;
- (void)getDeviceInfo;
- (void)updateDeviceInfo;

- (void)getUtilityContents;

- (void)setDetectBeacon:(BOOL)flag;
- (BOOL)getDetectBeacon;
- (void)scanStart;
- (void)scanStop;

- (BOOL)useContent:(NSString*)contentId;
- (BOOL)removeContent:(NSString*)contentId;
- (void)clearAllContent;
- (void)clearActionContent:(NSString*)action;

- (NSString*)makeUTCDateTimeToString:(NSDate*)date;
- (NSDate*)makeUTCDateTimeFromString:(NSString*)date;
- (NSString*)makeLocaleDateToString:(NSDate*)date;
- (NSString*)makeLocaleDateTimeToString:(NSDate*)date;

- (BOOL)checkSame:(NSString*)val1 val2:(NSString*)val2;

- (void)registerRemoteNotification;
- (void)registerDeviceToken:(NSData*)deviceToken;

- (NSString*)checkAuthDigest;

@end

#endif
