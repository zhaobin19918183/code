//
//  DBSsbpContent.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define DATABASE_NAME                 @"ssbp_content.db"
#define TABLE_NAME                    @"t_content"

#define COL_ID                        @"_id"
#define COL_CONTENT_ID                @"contentId"
#define COL_CONTENT_NAME              @"name"
#define COL_CONTENT_ACTION            @"action"
#define COL_CONTENT_URL               @"url"
#define COL_CONTENT_MAIN_IMAGE_URL    @"mainImageURL"
#define COL_CONTENT_MAIN_IMAGE        @"mainImage"
#define COL_CONTENT_SUB_IMAGE_URL     @"subImageURL"
#define COL_CONTENT_SUB_IMAGE         @"subImage"
#define COL_STAMP_YET_IMAGE_URL       @"stampYetImageURL"
#define COL_STAMP_YET_IMAGE           @"stampYetImage"
#define COL_STAMP_DONE_IMAGE_URL      @"stampDoneImageURL"
#define COL_STAMP_DONE_IMAGE          @"stampDoneImage"
#define COL_CONTENT_MAIN_DESCRIPTION  @"mainDescription"
#define COL_CONTENT_SUB_DESCRIPTION   @"subDescription"
#define COL_CONTENT_SOUND             @"sound"
#define COL_CONTENT_START_AT          @"startAt"
#define COL_CONTENT_END_AT            @"endAt"
#define COL_BEACON_ID                 @"beaconId"
#define COL_GEOFENCE_ID               @"geofenceId"
#define COL_STATUS                    @"status"
#define COL_ACQUIRED                  @"acquired_date"
#define COL_USED                      @"used_date"
#define COL_CREATED                   @"created_date"
#define COL_UPDATED                   @"last_update"

#import "DBSsbpContent.h"

@implementation DBSsbpContent

- (id)init {
    self = [super init];
    [self initializeDatabase];
    return self;
}

- (void)initializeDatabase {
    @autoreleasepool {
        NSString* SQL_CREATE1 = [NSString stringWithFormat:@"create table %@", TABLE_NAME];
        NSString* SQL_CREATE2 = [NSString stringWithFormat:@" (%@ integer primary key autoincrement not null, ", COL_ID];
        NSString* SQL_CREATE3 = [NSString stringWithFormat:@"%@ text not null, ", COL_CONTENT_ID];
        NSString* SQL_CREATE4 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_NAME];
        NSString* SQL_CREATE5 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_ACTION];
        NSString* SQL_CREATE6 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_URL];
        NSString* SQL_CREATE7 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_MAIN_IMAGE_URL];
        NSString* SQL_CREATE8 = [NSString stringWithFormat:@"%@ blob, ", COL_CONTENT_MAIN_IMAGE];
        NSString* SQL_CREATE9 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_SUB_IMAGE_URL];
        NSString* SQL_CREATE10 = [NSString stringWithFormat:@"%@ blob, ", COL_CONTENT_SUB_IMAGE];
        NSString* SQL_CREATE11 = [NSString stringWithFormat:@"%@ text, ", COL_STAMP_YET_IMAGE_URL];
        NSString* SQL_CREATE12 = [NSString stringWithFormat:@"%@ blob, ", COL_STAMP_YET_IMAGE];
        NSString* SQL_CREATE13 = [NSString stringWithFormat:@"%@ text, ", COL_STAMP_DONE_IMAGE_URL];
        NSString* SQL_CREATE14 = [NSString stringWithFormat:@"%@ blob, ", COL_STAMP_DONE_IMAGE];
        NSString* SQL_CREATE15 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_MAIN_DESCRIPTION];
        NSString* SQL_CREATE16 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_SUB_DESCRIPTION];
        NSString* SQL_CREATE17 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_SOUND];
        NSString* SQL_CREATE18 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_START_AT];
        NSString* SQL_CREATE19 = [NSString stringWithFormat:@"%@ text, ", COL_CONTENT_END_AT];
        NSString* SQL_CREATE20 = [NSString stringWithFormat:@"%@ text, ", COL_BEACON_ID];
        NSString* SQL_CREATE21 = [NSString stringWithFormat:@"%@ text, ", COL_GEOFENCE_ID];
        NSString* SQL_CREATE22 = [NSString stringWithFormat:@"%@ integer not null default 0, ", COL_STATUS];
        NSString* SQL_CREATE23 = [NSString stringWithFormat:@"%@ text, ", COL_ACQUIRED];
        NSString* SQL_CREATE24 = [NSString stringWithFormat:@"%@ text, ", COL_USED];
        NSString* SQL_CREATE25 = [NSString stringWithFormat:@"%@ text, ", COL_CREATED];
        NSString* SQL_CREATE26 = [NSString stringWithFormat:@"%@ text);", COL_UPDATED];

        NSMutableString* initSQL = [NSMutableString	string];
        [initSQL appendString:SQL_CREATE1];
        [initSQL appendString:SQL_CREATE2];
        [initSQL appendString:SQL_CREATE3];
        [initSQL appendString:SQL_CREATE4];
        [initSQL appendString:SQL_CREATE5];
        [initSQL appendString:SQL_CREATE6];
        [initSQL appendString:SQL_CREATE7];
        [initSQL appendString:SQL_CREATE8];
        [initSQL appendString:SQL_CREATE9];
        [initSQL appendString:SQL_CREATE10];
        [initSQL appendString:SQL_CREATE11];
        [initSQL appendString:SQL_CREATE12];
        [initSQL appendString:SQL_CREATE13];
        [initSQL appendString:SQL_CREATE14];
        [initSQL appendString:SQL_CREATE15];
        [initSQL appendString:SQL_CREATE16];
        [initSQL appendString:SQL_CREATE17];
        [initSQL appendString:SQL_CREATE18];
        [initSQL appendString:SQL_CREATE19];
        [initSQL appendString:SQL_CREATE20];
        [initSQL appendString:SQL_CREATE21];
        [initSQL appendString:SQL_CREATE22];
        [initSQL appendString:SQL_CREATE23];
        [initSQL appendString:SQL_CREATE24];
        [initSQL appendString:SQL_CREATE25];
        [initSQL appendString:SQL_CREATE26];
        
        NSArray* paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, true);
        NSString* dir = [paths objectAtIndex:0];
        NSString* strFilePath = [dir stringByAppendingPathComponent:DATABASE_NAME];

        NSFileManager* fileManager = [NSFileManager defaultManager];
        if (![fileManager fileExistsAtPath:strFilePath]) {
            db = [FMDatabase databaseWithPath:strFilePath];
            [db open];
            BOOL bRet = [db executeStatements:initSQL];
            if (!bRet) {
                NSLog(@"Error: %d msg: %@", db.lastErrorCode,db.lastErrorMessage);
            }
            [db close];
        } else {
            db = [FMDatabase databaseWithPath:strFilePath];
        }
    }
}

- (void)dropDatabase {
    @autoreleasepool {
        NSArray* paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, true);
        NSString* dir = [paths objectAtIndex:0];
        NSString* strFilePath = [dir stringByAppendingPathComponent:DATABASE_NAME];

        NSFileManager* fileManager = [NSFileManager defaultManager];
        BOOL success = [fileManager fileExistsAtPath:strFilePath];
        if (success) {
            [fileManager removeItemAtPath:strFilePath error:nil];
            [self initializeDatabase];
        }
    }
}

// 一覧取得
- (NSArray<TSsbpContent*>*)getAll {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ order by %@ desc;", TABLE_NAME, COL_ID];

        [db open];
        FMResultSet* result = [db executeQuery:strSQL];
        NSArray<TSsbpContent*>* array = [self readResultSet:result];
        [db close];

        return array;
    }
}

- (NSArray<TSsbpContent*>*)getActions:(NSString*)action {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ where %@ = ? order by %@ desc;", TABLE_NAME, COL_CONTENT_ACTION, COL_ID];

        [db open];
        FMResultSet* result = [db executeQuery:strSQL, action];
        NSArray<TSsbpContent*>* array = [self readResultSet:result];
        [db close];

        return array;
    }
}

- (NSArray<TSsbpContent*>*)getBeacons:(NSString*)beaconId {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ where %@ = ? order by %@ desc;", TABLE_NAME, COL_BEACON_ID, COL_ID];

        [db open];
        FMResultSet* result = [db executeQuery:strSQL, [NSString stringWithFormat:@"%@", beaconId]];
        NSArray<TSsbpContent*>* array = [self readResultSet:result];
        [db close];

        return array;
    }
}

- (NSArray<TSsbpContent*>*)getGeofences:(NSString*)geofenceId {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ where %@ = ? order by %@ desc;", TABLE_NAME, COL_GEOFENCE_ID, COL_ID];

        [db open];
        FMResultSet* result = [db executeQuery:strSQL, [NSString stringWithFormat:@"%@", geofenceId]];
        NSArray<TSsbpContent*>* array = [self readResultSet:result];
        [db close];

        return array;
    }
}

- (TSsbpContent*)findByContentID:(NSString*)contentId {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"select * from %@ where %@ = ?;", TABLE_NAME, COL_CONTENT_ID];

        [db open];
        FMResultSet* result = [db executeQuery:strSQL, [NSString stringWithFormat:@"%@", contentId]];
        TSsbpContent* col = [self readResult:result];
        [db close];

        return col;
    }
}

- (BOOL)add:(TSsbpContent*)ssbpContent {
    @autoreleasepool {
        NSDate* now = [NSDate date];
        NSString* strNow = [self makeUTCDateTimeToString:now];

        NSArray* cols = @[COL_CONTENT_ID, COL_CONTENT_NAME,
                          COL_CONTENT_ACTION, COL_CONTENT_URL,
                          COL_CONTENT_MAIN_IMAGE_URL, COL_CONTENT_SUB_IMAGE_URL,
                          COL_STAMP_YET_IMAGE_URL, COL_STAMP_DONE_IMAGE_URL,
                          COL_CONTENT_MAIN_DESCRIPTION, COL_CONTENT_SUB_DESCRIPTION,
                          COL_CONTENT_SOUND, COL_CONTENT_START_AT, COL_CONTENT_END_AT,
                          COL_BEACON_ID, COL_GEOFENCE_ID, COL_STATUS,
                          COL_ACQUIRED, COL_USED,
                          COL_CREATED, COL_UPDATED];
        NSMutableArray* values = [NSMutableArray new];
        for (int i = 0; i < cols.count; i++) [values addObject:@"?"];
        
        NSString* strSQL = [NSString stringWithFormat:@"insert into %@ (%@) values(%@);", TABLE_NAME, [cols componentsJoinedByString:@", "], [values componentsJoinedByString:@", "]];

        NSArray* params = [NSArray arrayWithObjects:
                           [NSString stringWithFormat:@"%@", ssbpContent.contentId],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentName],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentAction],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentURL],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentMainImageURL],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentSubImageURL],
                           [NSString stringWithFormat:@"%@", ssbpContent.stampYetImageURL],
                           [NSString stringWithFormat:@"%@", ssbpContent.stampDoneImageURL],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentMainDescription],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentSubDescription],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentSound],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentStartAt],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentEndAt],
                           [NSString stringWithFormat:@"%@", ssbpContent.beaconId],
                           [NSString stringWithFormat:@"%@", ssbpContent.geofenceId],
                           [NSNumber numberWithInteger:0],
                           [NSString stringWithFormat:@"%@", strNow],
                           @"",
                           [NSString stringWithFormat:@"%@", strNow],
                           [NSString stringWithFormat:@"%@", strNow],
                           nil];

        [db open];
        BOOL bRet = [db executeUpdate:strSQL withArgumentsInArray:params];
        if (!bRet) {
            NSLog(@"Error: %d msg: %@", db.lastErrorCode,db.lastErrorMessage);
            NSString* arrString = [NSString stringWithFormat:@"%@",params];
            NSString* arrEncoding = [NSString stringWithCString:[arrString cStringUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding];
            NSLog(@"%@", arrEncoding);
        }
        [db close];

        return bRet;
    }
}

- (BOOL)update:(TSsbpContent*)ssbpContent {
    @autoreleasepool {
        NSDate* now = [NSDate date];
        NSString* strNow = [self makeUTCDateTimeToString:now];

        NSArray* cols = @[COL_CONTENT_NAME,
                          COL_CONTENT_ACTION, COL_CONTENT_URL,
                          COL_CONTENT_MAIN_IMAGE_URL, COL_CONTENT_MAIN_IMAGE,
                          COL_CONTENT_SUB_IMAGE_URL, COL_CONTENT_SUB_IMAGE,
                          COL_STAMP_YET_IMAGE_URL, COL_STAMP_YET_IMAGE,
                          COL_STAMP_DONE_IMAGE_URL, COL_STAMP_DONE_IMAGE,
                          COL_CONTENT_MAIN_DESCRIPTION, COL_CONTENT_SUB_DESCRIPTION,
                          COL_CONTENT_SOUND, COL_CONTENT_START_AT, COL_CONTENT_END_AT,
                          COL_BEACON_ID, COL_GEOFENCE_ID, COL_STATUS,
                          COL_ACQUIRED, COL_USED,
                          COL_UPDATED];

        NSString* strSQL = [NSString stringWithFormat:@"update %@ set %@ = ? where %@ = ?;", TABLE_NAME, [cols componentsJoinedByString:@" = ?, "], COL_CONTENT_ID];

        NSArray* params = [NSArray arrayWithObjects:
                           [NSString stringWithFormat:@"%@", ssbpContent.contentName],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentAction],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentURL],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentMainImageURL],
                           (ssbpContent.contentMainImage != nil) ? ssbpContent.contentMainImage : [NSNull null],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentSubImageURL],
                           (ssbpContent.contentSubImage != nil) ? ssbpContent.contentSubImage : [NSNull null],
                           [NSString stringWithFormat:@"%@", ssbpContent.stampYetImageURL],
                           (ssbpContent.stampYetImage != nil) ? ssbpContent.stampYetImage : [NSNull null],
                           [NSString stringWithFormat:@"%@", ssbpContent.stampDoneImageURL],
                           (ssbpContent.stampDoneImage != nil) ? ssbpContent.stampDoneImage : [NSNull null],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentMainDescription],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentSubDescription],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentSound],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentStartAt],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentEndAt],
                           [NSString stringWithFormat:@"%@", ssbpContent.beaconId],
                           [NSString stringWithFormat:@"%@", ssbpContent.geofenceId],
                           [NSNumber numberWithInteger:ssbpContent.status],
                           [NSString stringWithFormat:@"%@", ssbpContent.acquiredDate],
                           [NSString stringWithFormat:@"%@", ssbpContent.usedDate],
                           [NSString stringWithFormat:@"%@", strNow],
                           [NSString stringWithFormat:@"%@", ssbpContent.contentId],
                           nil];

        [db open];
        BOOL bRet = [db executeUpdate:strSQL withArgumentsInArray:params];
        if (!bRet) {
            NSLog(@"Error: %d msg: %@", db.lastErrorCode,db.lastErrorMessage);
            NSString* arrString = [NSString stringWithFormat:@"%@",params];
            NSString* arrEncoding = [NSString stringWithCString:[arrString cStringUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding];
            NSLog(@"%@", arrEncoding);
        }
        [db close];

        return bRet;
    }
}

- (BOOL)use:(NSString*)contentId {
    @autoreleasepool {
        NSDate* now = [NSDate date];
        NSString* strNow = [self makeUTCDateTimeToString:now];

        NSArray* cols = @[COL_STATUS,
                          COL_USED,
                          COL_UPDATED];

        NSString* strSQL = [NSString stringWithFormat:@"update %@ set %@ = ? where %@ = ?;", TABLE_NAME, [cols componentsJoinedByString:@" = ?, "], COL_CONTENT_ID];

        NSArray* params = [NSArray arrayWithObjects:
                           [NSNumber numberWithInteger:1],
                           [NSString stringWithFormat:@"%@", strNow],
                           [NSString stringWithFormat:@"%@", strNow],
                           [NSString stringWithFormat:@"%@", contentId],
                           nil];

        [db open];
        BOOL bRet = [db executeUpdate:strSQL withArgumentsInArray:params];
        if (!bRet) {
            NSLog(@"Error: %d msg: %@", db.lastErrorCode,db.lastErrorMessage);
            NSString* arrString = [NSString stringWithFormat:@"%@",params];
            NSString* arrEncoding = [NSString stringWithCString:[arrString cStringUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding];
            NSLog(@"%@", arrEncoding);
        }
        [db close];

        return bRet;
    }
}

- (BOOL)remove:(NSString*)contentId {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"delete from %@ where %@ = ?;", TABLE_NAME, COL_CONTENT_ID];

        [db open];
        BOOL ret = [db executeUpdate:strSQL, [NSString stringWithFormat:@"%@", contentId]];
        [db close];

        return ret;
    }
}

- (BOOL)removeAll {
    @autoreleasepool {
        NSString* strSQL = [NSString stringWithFormat:@"delete from %@;", TABLE_NAME];

        [db open];
        BOOL ret = [db executeUpdate:strSQL];
        [db close];

        return ret;
    }
}

- (NSArray<TSsbpContent*>*)readResultSet:(FMResultSet*)resultSet {
    NSMutableArray<TSsbpContent*>* array = [NSMutableArray new];
    if (resultSet == nil) return [array copy];

    int indexId = [resultSet columnIndexForName:COL_ID];
    if (indexId < 0) { return [array copy]; }

    int indexContentId = [resultSet columnIndexForName:COL_CONTENT_ID];
    int indexContentName = [resultSet columnIndexForName:COL_CONTENT_NAME];
    int indexContentAction = [resultSet columnIndexForName:COL_CONTENT_ACTION];
    int indexContentURL = [resultSet columnIndexForName:COL_CONTENT_URL];
    int indexContentMainImageURL = [resultSet columnIndexForName:COL_CONTENT_MAIN_IMAGE_URL];
    int indexContentMainImage = [resultSet columnIndexForName:COL_CONTENT_MAIN_IMAGE];
    int indexContentSubImageURL = [resultSet columnIndexForName:COL_CONTENT_SUB_IMAGE_URL];
    int indexContentSubImage = [resultSet columnIndexForName:COL_CONTENT_SUB_IMAGE];
    int indexStampYetImageURL = [resultSet columnIndexForName:COL_STAMP_YET_IMAGE_URL];
    int indexStampYetImage = [resultSet columnIndexForName:COL_STAMP_YET_IMAGE];
    int indexStampDoneImageURL = [resultSet columnIndexForName:COL_STAMP_DONE_IMAGE_URL];
    int indexStampDoneImage = [resultSet columnIndexForName:COL_STAMP_DONE_IMAGE];
    int indexContentMainDescription = [resultSet columnIndexForName:COL_CONTENT_MAIN_DESCRIPTION];
    int indexContentSubDescription = [resultSet columnIndexForName:COL_CONTENT_SUB_DESCRIPTION];
    int indexContentSound = [resultSet columnIndexForName:COL_CONTENT_SOUND];
    int indexContentStartAt = [resultSet columnIndexForName:COL_CONTENT_START_AT];
    int indexContentEndAt = [resultSet columnIndexForName:COL_CONTENT_END_AT];
    int indexBeaconId = [resultSet columnIndexForName:COL_BEACON_ID];
    int indexGeofenceId = [resultSet columnIndexForName:COL_GEOFENCE_ID];
    int indexStatus = [resultSet columnIndexForName:COL_STATUS];
    int indexAcquired = [resultSet columnIndexForName:COL_ACQUIRED];
    int indexUsed = [resultSet columnIndexForName:COL_USED];
    int indexCreated = [resultSet columnIndexForName:COL_CREATED];
    int indexUpdated = [resultSet columnIndexForName:COL_UPDATED];

    while ([resultSet next]) {
        TSsbpContent* col = [TSsbpContent new];
        col.nId = [resultSet intForColumnIndex:indexId];
        if (indexContentId >= 0) { col.contentId = [resultSet stringForColumnIndex:indexContentId]; }
        if (indexContentName >= 0) { col.contentName = [resultSet stringForColumnIndex:indexContentName]; }
        if (indexContentAction >= 0) { col.contentAction = [resultSet stringForColumnIndex:indexContentAction]; }
        if (indexContentURL >= 0) { col.contentURL = [resultSet stringForColumnIndex:indexContentURL]; }
        if (indexContentMainImageURL >= 0) { col.contentMainImageURL = [resultSet stringForColumnIndex:indexContentMainImageURL]; }
        if (indexContentMainImage >= 0) { col.contentMainImage = [resultSet dataForColumnIndex:indexContentMainImage]; }
        if (indexContentSubImageURL >= 0) { col.contentSubImageURL = [resultSet stringForColumnIndex:indexContentSubImageURL]; }
        if (indexContentSubImage >= 0) { col.contentSubImage = [resultSet dataForColumnIndex:indexContentSubImage]; }
        if (indexStampYetImageURL >= 0) { col.stampYetImageURL = [resultSet stringForColumnIndex:indexStampYetImageURL]; }
        if (indexStampYetImage >= 0) { col.stampYetImage = [resultSet dataForColumnIndex:indexStampYetImage]; }
        if (indexStampDoneImageURL >= 0) { col.stampDoneImageURL = [resultSet stringForColumnIndex:indexStampDoneImageURL]; }
        if (indexStampDoneImage >= 0) { col.stampDoneImage = [resultSet dataForColumnIndex:indexStampDoneImage]; }
        if (indexContentMainDescription >= 0) { col.contentMainDescription = [resultSet stringForColumnIndex:indexContentMainDescription]; }
        if (indexContentSubDescription >= 0) { col.contentSubDescription = [resultSet stringForColumnIndex:indexContentSubDescription]; }
        if (indexContentSound >= 0) { col.contentSound = [resultSet stringForColumnIndex:indexContentSound]; }
        if (indexContentStartAt >= 0) { col.contentStartAt = [resultSet stringForColumnIndex:indexContentStartAt]; }
        if (indexContentEndAt >= 0) { col.contentEndAt = [resultSet stringForColumnIndex:indexContentEndAt]; }
        if (indexBeaconId >= 0) { col.beaconId = [resultSet stringForColumnIndex:indexBeaconId]; }
        if (indexGeofenceId >= 0) { col.geofenceId = [resultSet stringForColumnIndex:indexGeofenceId]; }
        if (indexStatus >= 0) { col.status = [resultSet intForColumnIndex:indexStatus]; }
        if (indexAcquired >= 0) { col.acquiredDate = [resultSet stringForColumnIndex:indexAcquired]; }
        if (indexUsed >= 0) { col.usedDate = [resultSet stringForColumnIndex:indexUsed]; }
        if (indexCreated >= 0) { col.createdDate = [resultSet stringForColumnIndex:indexCreated]; }
        if (indexUpdated >= 0) { col.updatedDate = [resultSet stringForColumnIndex:indexUpdated]; }
        [array addObject:col];
    }

    return [array copy];
}

- (TSsbpContent*)readResult:(FMResultSet*)resultSet {
    if (resultSet == nil) return nil;
    
    int indexId = [resultSet columnIndexForName:COL_ID];
    if (indexId < 0) { return nil; }
    
    int indexContentId = [resultSet columnIndexForName:COL_CONTENT_ID];
    int indexContentName = [resultSet columnIndexForName:COL_CONTENT_NAME];
    int indexContentAction = [resultSet columnIndexForName:COL_CONTENT_ACTION];
    int indexContentURL = [resultSet columnIndexForName:COL_CONTENT_URL];
    int indexContentMainImageURL = [resultSet columnIndexForName:COL_CONTENT_MAIN_IMAGE_URL];
    int indexContentMainImage = [resultSet columnIndexForName:COL_CONTENT_MAIN_IMAGE];
    int indexContentSubImageURL = [resultSet columnIndexForName:COL_CONTENT_SUB_IMAGE_URL];
    int indexContentSubImage = [resultSet columnIndexForName:COL_CONTENT_SUB_IMAGE];
    int indexStampYetImageURL = [resultSet columnIndexForName:COL_STAMP_YET_IMAGE_URL];
    int indexStampYetImage = [resultSet columnIndexForName:COL_STAMP_YET_IMAGE];
    int indexStampDoneImageURL = [resultSet columnIndexForName:COL_STAMP_DONE_IMAGE_URL];
    int indexStampDoneImage = [resultSet columnIndexForName:COL_STAMP_DONE_IMAGE];
    int indexContentMainDescription = [resultSet columnIndexForName:COL_CONTENT_MAIN_DESCRIPTION];
    int indexContentSubDescription = [resultSet columnIndexForName:COL_CONTENT_SUB_DESCRIPTION];
    int indexContentSound = [resultSet columnIndexForName:COL_CONTENT_SOUND];
    int indexContentStartAt = [resultSet columnIndexForName:COL_CONTENT_START_AT];
    int indexContentEndAt = [resultSet columnIndexForName:COL_CONTENT_END_AT];
    int indexBeaconId = [resultSet columnIndexForName:COL_BEACON_ID];
    int indexGeofenceId = [resultSet columnIndexForName:COL_GEOFENCE_ID];
    int indexStatus = [resultSet columnIndexForName:COL_STATUS];
    int indexAcquired = [resultSet columnIndexForName:COL_ACQUIRED];
    int indexUsed = [resultSet columnIndexForName:COL_USED];
    int indexCreated = [resultSet columnIndexForName:COL_CREATED];
    int indexUpdated = [resultSet columnIndexForName:COL_UPDATED];
    
    TSsbpContent* col = [TSsbpContent new];
    while ([resultSet next]) {
        col.nId = [resultSet intForColumnIndex:indexId];
        if (indexContentId >= 0) { col.contentId = [resultSet stringForColumnIndex:indexContentId]; }
        if (indexContentName >= 0) { col.contentName = [resultSet stringForColumnIndex:indexContentName]; }
        if (indexContentAction >= 0) { col.contentAction = [resultSet stringForColumnIndex:indexContentAction]; }
        if (indexContentURL >= 0) { col.contentURL = [resultSet stringForColumnIndex:indexContentURL]; }
        if (indexContentMainImageURL >= 0) { col.contentMainImageURL = [resultSet stringForColumnIndex:indexContentMainImageURL]; }
        if (indexContentMainImage >= 0) { col.contentMainImage = [resultSet dataForColumnIndex:indexContentMainImage]; }
        if (indexContentSubImageURL >= 0) { col.contentSubImageURL = [resultSet stringForColumnIndex:indexContentSubImageURL]; }
        if (indexContentSubImage >= 0) { col.contentSubImage = [resultSet dataForColumnIndex:indexContentSubImage]; }
        if (indexStampYetImageURL >= 0) { col.stampYetImageURL = [resultSet stringForColumnIndex:indexStampYetImageURL]; }
        if (indexStampYetImage >= 0) { col.stampYetImage = [resultSet dataForColumnIndex:indexStampYetImage]; }
        if (indexStampDoneImageURL >= 0) { col.stampDoneImageURL = [resultSet stringForColumnIndex:indexStampDoneImageURL]; }
        if (indexStampDoneImage >= 0) { col.stampDoneImage = [resultSet dataForColumnIndex:indexStampDoneImage]; }
        if (indexContentMainDescription >= 0) { col.contentMainDescription = [resultSet stringForColumnIndex:indexContentMainDescription]; }
        if (indexContentSubDescription >= 0) { col.contentSubDescription = [resultSet stringForColumnIndex:indexContentSubDescription]; }
        if (indexContentSound >= 0) { col.contentSound = [resultSet stringForColumnIndex:indexContentSound]; }
        if (indexContentStartAt >= 0) { col.contentStartAt = [resultSet stringForColumnIndex:indexContentStartAt]; }
        if (indexContentEndAt >= 0) { col.contentEndAt = [resultSet stringForColumnIndex:indexContentEndAt]; }
        if (indexBeaconId >= 0) { col.beaconId = [resultSet stringForColumnIndex:indexBeaconId]; }
        if (indexGeofenceId >= 0) { col.geofenceId = [resultSet stringForColumnIndex:indexGeofenceId]; }
        if (indexStatus >= 0) { col.status = [resultSet intForColumnIndex:indexStatus]; }
        if (indexAcquired >= 0) { col.acquiredDate = [resultSet stringForColumnIndex:indexAcquired]; }
        if (indexUsed >= 0) { col.usedDate = [resultSet stringForColumnIndex:indexUsed]; }
        if (indexCreated >= 0) { col.createdDate = [resultSet stringForColumnIndex:indexCreated]; }
        if (indexUpdated >= 0) { col.updatedDate = [resultSet stringForColumnIndex:indexUpdated]; }
        return col;
    }
    
    return nil;
}

- (NSString*)makeUTCDateTimeToString:(NSDate*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
        [formatter setLocale:[NSLocale systemLocale]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        return [formatter stringFromDate:date];
    }
}

@end

