//
//  TSsbpContent.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#ifndef SSBP_App_Static_TSsbpContent_h
#define SSBP_App_Static_TSsbpContent_h

#import <Foundation/Foundation.h>

@interface TSsbpContent : NSObject

// ID
@property (assign, nonatomic) NSInteger nId;

// Content Info
@property (copy, nonatomic) NSString* contentId;
@property (copy, nonatomic) NSString* contentName;
@property (copy, nonatomic) NSString* contentAction;
@property (copy, nonatomic) NSString* contentURL;
@property (copy, nonatomic) NSString* contentMainImageURL;
@property (copy, nonatomic) NSData* contentMainImage;
@property (copy, nonatomic) NSString* contentSubImageURL;
@property (copy, nonatomic) NSData* contentSubImage;
@property (copy, nonatomic) NSString* stampYetImageURL;
@property (copy, nonatomic) NSData* stampYetImage;
@property (copy, nonatomic) NSString* stampDoneImageURL;
@property (copy, nonatomic) NSData* stampDoneImage;
@property (copy, nonatomic) NSString* contentMainDescription;
@property (copy, nonatomic) NSString* contentSubDescription;
@property (copy, nonatomic) NSString* contentSound;
@property (copy, nonatomic) NSString* contentStartAt;
@property (copy, nonatomic) NSString* contentEndAt;

// 関連情報
@property (copy, nonatomic) NSString* beaconId;
@property (copy, nonatomic) NSString* geofenceId;
// ステータス
@property (assign, nonatomic) NSInteger status;
// 取得日時
@property (copy, nonatomic) NSString* acquiredDate;
// 使用日時
@property (copy, nonatomic) NSString* usedDate;

@property (copy, nonatomic) NSString* createdDate;
@property (copy, nonatomic) NSString* updatedDate;

@end

#endif
