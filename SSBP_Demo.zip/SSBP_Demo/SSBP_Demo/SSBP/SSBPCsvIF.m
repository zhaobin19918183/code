//
//  SSBPCsvIF.m
//
//  Created by Ayumi Togashi on 2016/09/27.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "SSBPCsvIF.h"

#import <SSBPSdk/SSBPFloor.h>
#import <SSBPSdk/TSsbpFloor.h>

@implementation SSBPCsvIF {
    NSString* lastUpdate;
}

#pragma mark -
#pragma mark CSV関連

- (NSArray<TSsbpApp*>*)getAppInfos {
    @autoreleasepool {
        NSString* csv = [self getCsv:@"app_info"];
        NSScanner* scanner = [NSScanner scannerWithString:csv];

        // 改行文字の選定
        NSCharacterSet* chSet = [NSCharacterSet newlineCharacterSet];
        NSString* line;

        BOOL isHeader = true;
        NSMutableArray* appInfos = [NSMutableArray array];
        while (![scanner isAtEnd]) {
            // 一行づつ読み込んでいく
            [scanner scanUpToCharactersFromSet:chSet intoString:&line];
            NSArray* items = [line componentsSeparatedByString:@","];
            // カウント数が少なければ飛ばす。
            if([items count] == 0) continue;
            if (isHeader) {
                // 1行目は読み飛ばし
                isHeader = false;
                continue;
            }

            TSsbpApp* app = [TSsbpApp new];
            NSInteger i = 0;
            for (NSString* item in items) {
                NSString* word = [self removeStartAndEndQuotes:item];
                if (i == 0) {
                    app.appId = word;
                    if (app.appId.length == 0) {
                        app = nil;
                        break;
                    }
                }
                switch (i) {
                    case 1:
                        app.appName = word;
                        break;
                    case 2:
                        app.appKey = word;
                        break;
                    case 3:
                        app.secretKey = word;
                        break;
                    case 4:
                        app.host = word;
                        break;
                    case 5:
                        app.useBeaconLog = [word boolValue];
                        break;
                    case 6:
                        app.useContentLog = [word boolValue];
                        break;
                    case 7:
                        app.useNotification = [word boolValue];
                        break;
                    case 8:
                        app.deviceId = word;
                        break;
                    case 9:
                        app.csvFacilities = word;
                        break;
                    case 10:
                        app.csvFloors = word;
                        break;
                    case 11:
                        app.csvBeacons = word;
                        break;
                    case 12:
                        app.csvNodes = word;
                        break;
                    case 13:
                        app.csvEdges = word;
                        break;
                    default:
                        break;
                }
                i++;
            }
            if (app != nil) {
                [appInfos addObject:app];
            }
        }

        return [appInfos copy];
    }
}

- (NSArray<SSBPFacility*>*)getFacilityCSV:(NSString*)localeId defLocaleId:(NSString*)defLocaleId since:(NSString*)since csvFacilities:(NSString*)csvFacilities csvFloors:(NSString*)csvFloors {
    @autoreleasepool {
        NSString* csv = [self getCsv:csvFacilities];
        NSScanner* scanner = [NSScanner scannerWithString:csv];

        // 改行文字の選定
        NSCharacterSet* chSet = [NSCharacterSet newlineCharacterSet];
        NSString* line;

        BOOL isHeader = true;
        NSString* baseId = @"";
        BOOL setLocale = false;
        NSDate* update = nil;
        if (since.length > 0) {
            update = [self makeUTCDateTimeFromString:since];
        }

        NSMutableArray* facilities = [NSMutableArray array];
        while (![scanner isAtEnd]) {
            // 一行づつ読み込んでいく
            [scanner scanUpToCharactersFromSet:chSet intoString:&line];
            NSArray* items = [line componentsSeparatedByString:@","];
            // カウント数が少なければ飛ばす。
            if([items count] == 0) continue;
            if (isHeader) {
                // 1行目は読み飛ばし
                isHeader = false;
                continue;
            }

            SSBPFacility* facility = [SSBPFacility new];
            NSInteger i = 0;
            BOOL isBase = false;
            BOOL sameDefLocale = false;
            BOOL sameLocale = false;
            for (NSString* item in items) {
                NSString* word = [self removeStartAndEndQuotes:item];
                if (i == 0) { // id
                    facility.facilityId = word;
                    if (facility.facilityId.length == 0) {
                        facility = nil;
                        break;
                    }

                    if (![self checkSame:facility.facilityId val2:baseId]) {
                        isBase = true;
                        baseId = facility.facilityId;
                        setLocale = false;
                    } else {
                        isBase = false;
                    }
                }

                switch (i) {
                    case 1: // name
                        facility.facilityName = word;
                        break;
                    case 2: // uuid
                        facility.uuid = word;
                        break;
                    case 3: // updated_at
                        //最終更新日として処理
                    {
                        if (isBase) {
                            NSDate* date = [self makeUTCDateTimeFromString:word];
                            if (update == nil) {
                                update = date;
                            } else {
                                NSComparisonResult chk_interval = [update compare:date];
                                if (chk_interval == NSOrderedAscending) { // update < date
                                    update = date;
                                }
                            }
                        }
                    }
                        break;
                    case 4: // locale_id
                        sameDefLocale = [self checkSame:defLocaleId val2:word];
                        sameLocale = [self checkSame:localeId val2:word];
                        break;
                    case 5: // locale_name
                        if (sameLocale && (word.length > 0)) {
                            // 該当言語対応
                            setLocale = true;
                            for (SSBPFacility* _facility in facilities) {
                                if ([self checkSame:_facility.facilityId val2:facility.facilityId]) {
                                    _facility.facilityName = word;
                                    break;
                                }
                            }
                        } else if (!setLocale && sameDefLocale && (word.length > 0)) {
                            // デフォルト言語対応
                            for (SSBPFacility* _facility in facilities) {
                                if ([self checkSame:_facility.facilityId val2:facility.facilityId]) {
                                    _facility.facilityName = word;
                                    break;
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                i++;
            }
            if ((facility != nil) && isBase) {
                [facilities addObject:facility];
            }
        }

        if (update != nil) {
            lastUpdate = [self makeUTCDateTimeToString:update];
        }

        NSArray<TSsbpFloor*>* _floors = [self getFloorCSV:localeId defLocaleId:defLocaleId since:lastUpdate csvFloors:csvFloors];

        for (SSBPFacility* _facility in facilities) {
            NSMutableArray* floors = nil;
            for (TSsbpFloor* _floor in _floors) {
                if ([self checkSame:_floor.facilityId val2:_facility.facilityId]) {
                    if (floors == nil) floors = [NSMutableArray array];
                    SSBPFloor* floor = [SSBPFloor new];
                    floor.floorId = _floor.floorId;
                    floor.floorName = _floor.floorName;
                    floor.mapURL = _floor.mapImageURL;
                    floor.floorNum = _floor.floorNum;
                    floor.floorDeg = _floor.floorDeg;
                    [floors addObject:floor];
                }
            }
            if (floors != nil) _facility.floors = [floors copy];
        }

        return [facilities copy];
    }
}

- (NSArray<TSsbpFloor*>*)getFloorCSV:(NSString*)localeId defLocaleId:(NSString*)defLocaleId since:(NSString*)since csvFloors:(NSString*)csvFloors {
    @autoreleasepool {
        NSString* csv = [self getCsv:csvFloors];
        NSScanner* scanner = [NSScanner scannerWithString:csv];

        // 改行文字の選定
        NSCharacterSet* chSet = [NSCharacterSet newlineCharacterSet];
        NSString* line;

        BOOL isHeader = true;
        NSString* baseId = @"";
        BOOL setLocale = false;
        NSDate* update = nil;
        if (since.length > 0) {
            update = [self makeUTCDateTimeFromString:since];
        }

        NSMutableArray* floors = [NSMutableArray array];
        while (![scanner isAtEnd]) {
            // 一行づつ読み込んでいく
            [scanner scanUpToCharactersFromSet:chSet intoString:&line];
            NSArray* items = [line componentsSeparatedByString:@","];
            // カウント数が少なければ飛ばす。
            if([items count] == 0) continue;
            if (isHeader) {
                // 1行目は読み飛ばし
                isHeader = false;
                continue;
            }

            TSsbpFloor* floor = [TSsbpFloor new];
            NSInteger i = 0;
            BOOL isBase = false;
            BOOL sameDefLocale = false;
            BOOL sameLocale = false;
            for (NSString* item in items) {
                NSString* word = [self removeStartAndEndQuotes:item];
                if (i == 0) { // id
                    floor.floorId = word;
                    if (floor.floorId.length == 0) {
                        floor = nil;
                        break;
                    }

                    if (![self checkSame:floor.floorId val2:baseId]) {
                        isBase = true;
                        baseId = floor.floorId;
                        setLocale = false;
                    } else {
                        isBase = false;
                    }
                }

                switch (i) {
                    case 1: // name
                        floor.floorName = word;
                        break;
                    case 2: // mapfile
                        floor.mapImageURL = word;
                        break;
                    case 3: // floor_num
                        if (isBase) {
                            floor.floorNum = [word intValue];
                        }
                        break;
                    case 4: // facility_id
                        floor.facilityId = word;
                        break;
                    case 5: // true_north
                        if (isBase) {
                            floor.floorDeg = [word doubleValue];
                        }
                        break;
                    case 6: // updated_at
                        //最終更新日として処理
                    {
                        if (isBase) {
                            NSDate* date = [self makeUTCDateTimeFromString:word];
                            if (update == nil) {
                                update = date;
                            } else {
                                NSComparisonResult chk_interval = [update compare:date];
                                if (chk_interval == NSOrderedAscending) { // update < date
                                    update = date;
                                }
                            }
                        }
                    }
                        break;
                    case 7: // locale_id
                        sameDefLocale = [self checkSame:defLocaleId val2:word];
                        sameLocale = [self checkSame:localeId val2:word];
                        break;
                    case 8: // locale_name
                        if (sameLocale && (word.length > 0)) {
                            // 該当言語対応
                            setLocale = true;
                            for (TSsbpFloor* _floor in floors) {
                                if ([self checkSame:_floor.floorId val2:floor.floorId]) {
                                    _floor.floorName = word;
                                    break;
                                }
                            }
                        } else if (!setLocale && sameDefLocale && (word.length > 0)) {
                            // デフォルト言語対応
                            for (TSsbpFloor* _floor in floors) {
                                if ([self checkSame:_floor.floorId val2:floor.floorId]) {
                                    _floor.floorName = word;
                                    break;
                                }
                            }
                        }
                        break;
                    case 9: // locale_mapfile
                        if (sameLocale && (word.length > 0)) {
                            // 該当言語対応
                            setLocale = true;
                            for (TSsbpFloor* _floor in floors) {
                                if ([self checkSame:_floor.floorId val2:floor.floorId]) {
                                    _floor.mapImageURL = word;
                                    break;
                                }
                            }
                        } else if (!setLocale && sameDefLocale && (word.length > 0)) {
                            // デフォルト言語対応
                            for (TSsbpFloor* _floor in floors) {
                                if ([self checkSame:_floor.floorId val2:floor.floorId]) {
                                    _floor.mapImageURL = word;
                                    break;
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                i++;
            }
            if ((floor != nil) && isBase) {
                [floors addObject:floor];
            }
        }

        if (update != nil) {
            lastUpdate = [self makeUTCDateTimeToString:update];
        }

        return [floors copy];
    }
}

- (NSArray<SSBPBeacon*>*)getBeaconCSV:(NSString*)since csvBeacons:(NSString*)csvBeacons {
    @autoreleasepool {
        NSString* csv = [self getCsv:csvBeacons];
        NSScanner* scanner = [NSScanner scannerWithString:csv];

        // 改行文字の選定
        NSCharacterSet* chSet = [NSCharacterSet newlineCharacterSet];
        NSString* line;

        BOOL isHeader = true;
        NSDate* update = nil;
        if (since.length > 0) {
            update = [self makeUTCDateTimeFromString:since];
        }

        NSMutableArray* beacons = [NSMutableArray array];
        while (![scanner isAtEnd]) {
            // 一行づつ読み込んでいく
            [scanner scanUpToCharactersFromSet:chSet intoString:&line];
            NSArray* items = [line componentsSeparatedByString:@","];
            // カウント数が少なければ飛ばす。
            if([items count] == 0) continue;
            if (isHeader) {
                // 1行目は読み飛ばし
                isHeader = false;
                continue;
            }

            SSBPBeacon* beacon = [SSBPBeacon new];
            NSInteger i = 0;
            for (NSString* item in items) {
                NSString* word = [self removeStartAndEndQuotes:item];
                if (i == 0) { // id
                    beacon.beaconId = word;
                    if (beacon.beaconId.length == 0) {
                        beacon = nil;
                        break;
                    }
                }

                switch (i) {
                    case 1: // major
                        beacon.major = word;
                        break;
                    case 2: // minor
                        beacon.minor = word;
                        break;
                    case 3: // proximity
                        beacon.proximity = [word intValue];
                        break;
                    case 4: // name
                        beacon.beaconName = word;
                        break;
                    case 5: // local_name
                        beacon.localName = word;
                        break;
                    case 6: // module_id
                        beacon.moduleId = word;
                        break;
                    case 7: // latitude
                        beacon.latitude = word;
                        break;
                    case 8: // longitude
                        beacon.longitude = word;
                        break;
                    case 9: // altitude
                        beacon.altitude = word;
                        break;
                    case 10: // facility_id
                        beacon.facilityId = word;
                        break;
                    case 11: // actions
                        beacon.actions = word;
                        break;
                    case 12: // updated_at
                        //最終更新日として処理
                    {
                        NSDate* date = [self makeUTCDateTimeFromString:word];
                        if (update == nil) {
                            update = date;
                        } else {
                            NSComparisonResult chk_interval = [update compare:date];
                            if (chk_interval == NSOrderedAscending) { // update < date
                                update = date;
                            }
                        }
                    }
                        break;
                    case 13: // relative_x
                        beacon.relativeX = [word intValue];
                        break;
                    case 14: // relative_y
                        beacon.relativeY = [word intValue];
                        break;
                    case 15: // floor_id
                        beacon.floorId = word;
                        break;
                    default:
                        break;
                }
                i++;
            }
            if (beacons != nil) {
                [beacons addObject:beacon];
            }
        }

        if (update != nil) {
            lastUpdate = [self makeUTCDateTimeToString:update];
        }

        return [beacons copy];
    }
}

- (NSArray<SSBPNode*>*)getNodeCSV:(NSString*)localeId defLocaleId:(NSString*)defLocaleId since:(NSString*)since csvNodes:(NSString*)csvNodes {
    @autoreleasepool {
        NSString* csv = [self getCsv:csvNodes];
        NSScanner* scanner = [NSScanner scannerWithString:csv];

        // 改行文字の選定
        NSCharacterSet* chSet = [NSCharacterSet newlineCharacterSet];
        NSString* line;

        BOOL isHeader = true;
        NSString* baseId = @"";
        BOOL setLocale = false;
        NSDate* update = nil;
        if (since.length > 0) {
            update = [self makeUTCDateTimeFromString:since];
        }

        NSMutableArray* nodes = [NSMutableArray array];
        while (![scanner isAtEnd]) {
            // 一行づつ読み込んでいく
            [scanner scanUpToCharactersFromSet:chSet intoString:&line];
            NSArray* items = [line componentsSeparatedByString:@","];
            // カウント数が少なければ飛ばす。
            if([items count] == 0) continue;
            if (isHeader) {
                // 1行目は読み飛ばし
                isHeader = false;
                continue;
            }

            SSBPNode* node = [SSBPNode new];
            NSInteger i = 0;
            BOOL isBase = false;
            BOOL sameDefLocale = false;
            BOOL sameLocale = false;
            for (NSString* item in items) {
                NSString* word = [self removeStartAndEndQuotes:item];
                if (i == 0) { // id
                    node.nodeId = word;
                    if (node.nodeId.length == 0) {
                        node = nil;
                        break;
                    }

                    if (![self checkSame:node.nodeId val2:baseId]) {
                        isBase = true;
                        baseId = node.nodeId;
                        setLocale = false;
                    } else {
                        isBase = false;
                    }
                }

                switch (i) {
                    case 1: // name
                        node.nodeName = word;
                        break;
                    case 2: // type
                        if (isBase) {
                            node.nodeType = [word intValue];
                        }
                        break;
                    case 3: // goal_flag
                        if (isBase) {
                            node.goalFlag = [word intValue];
                        }
                        break;
                    case 4: // facility_id
                        node.facilityId = word;
                        break;
                    case 5: // floor_id
                        node.floorId = word;
                        break;
                    case 6: // relative_x
                        if (isBase) {
                            node.relativeX = [word intValue];
                        }
                        break;
                    case 7: // relative_y
                        if (isBase) {
                            node.relativeY = [word intValue];
                        }
                        break;
                    case 8: // beacon_id
                        node.beaconId = word;
                        break;
                    case 9: // actions
                        node.nodeAction = word;
                        break;
                    case 10: // updated_at
                        //最終更新日として処理
                    {
                        if (isBase) {
                            NSDate* date = [self makeUTCDateTimeFromString:word];
                            if (update == nil) {
                                update = date;
                            } else {
                                NSComparisonResult chk_interval = [update compare:date];
                                if (chk_interval == NSOrderedAscending) { // update < date
                                    update = date;
                                }
                            }
                        }
                    }
                        break;
                    case 11: // locale_id
                        sameDefLocale = [self checkSame:defLocaleId val2:word];
                        sameLocale = [self checkSame:localeId val2:word];
                        break;
                    case 12: // locale_name
                        if (sameLocale && (word.length > 0)) {
                            // 該当言語対応
                            setLocale = true;
                            for (SSBPNode* _node in nodes) {
                                if ([self checkSame:_node.nodeId val2:node.nodeId]) {
                                    _node.nodeName = word;
                                    break;
                                }
                            }
                        } else if (!setLocale && sameDefLocale && (word.length > 0)) {
                            // デフォルト言語対応
                            for (SSBPNode* _node in nodes) {
                                if ([self checkSame:_node.nodeId val2:node.nodeId]) {
                                    _node.nodeName = word;
                                    break;
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                i++;
            }
            if ((nodes != nil) && isBase) {
                [nodes addObject:node];
            }
        }

        if (update != nil) {
            lastUpdate = [self makeUTCDateTimeToString:update];
        }

        return [nodes copy];
    }
}

- (NSArray<SSBPEdge*>*)getEdgeCSV:(NSString*)since csvEdges:(NSString*)csvEdges {
    @autoreleasepool {
        NSString* csv = [self getCsv:csvEdges];
        NSScanner* scanner = [NSScanner scannerWithString:csv];

        // 改行文字の選定
        NSCharacterSet* chSet = [NSCharacterSet newlineCharacterSet];
        NSString* line;

        BOOL isHeader = true;
        NSDate* update = nil;
        if (since.length > 0) {
            update = [self makeUTCDateTimeFromString:since];
        }

        NSMutableArray* edges = [NSMutableArray array];
        while (![scanner isAtEnd]) {
            // 一行づつ読み込んでいく
            [scanner scanUpToCharactersFromSet:chSet intoString:&line];
            NSArray* items = [line componentsSeparatedByString:@","];
            // カウント数が少なければ飛ばす。
            if([items count] == 0) continue;
            if (isHeader) {
                // 1行目は読み飛ばし
                isHeader = false;
                continue;
            }

            SSBPEdge* edge = [SSBPEdge new];
            NSInteger i = 0;
            for (NSString* item in items) {
                NSString* word = [self removeStartAndEndQuotes:item];
                if (i == 0) { // id
                    edge.edgeId = word;
                    if (edge.edgeId.length == 0) {
                        edge = nil;
                        break;
                    }
                }

                switch (i) {
                    case 1: // node_out
                        edge.nodeOut = word;
                        break;
                    case 2: // node_in
                        edge.nodeIn = word;
                        break;
                    case 3: // cost
                        edge.cost = [word intValue];
                        break;
                    case 4: // updated_at
                        //最終更新日として処理
                    {
                        NSDate* date = [self makeUTCDateTimeFromString:word];
                        if (update == nil) {
                            update = date;
                        } else {
                            NSComparisonResult chk_interval = [update compare:date];
                            if (chk_interval == NSOrderedAscending) { // update < date
                                update = date;
                            }
                        }
                    }
                        break;
                    default:
                        break;
                }
                i++;
            }
            if (edges != nil) {
                [edges addObject:edge];
            }
        }

        if (update != nil) {
            lastUpdate = [self makeUTCDateTimeToString:update];
        }

        return [edges copy];
    }
}

- (NSArray<SSBPGeofence*>*)getGeofenceCSV:(NSString*)localeId defLocaleId:(NSString*)defLocaleId since:(NSString*)since csvGeofences:(NSString*)csvGeofences {
    @autoreleasepool {
        NSString* csv = [self getCsv:csvGeofences];
        NSScanner* scanner = [NSScanner scannerWithString:csv];

        // 改行文字の選定
        NSCharacterSet* chSet = [NSCharacterSet newlineCharacterSet];
        NSString* line;

        BOOL isHeader = true;
        NSString* baseId = @"";
        BOOL setLocale = false;
        NSDate* update = nil;
        if (since.length > 0) {
            update = [self makeUTCDateTimeFromString:since];
        }

        NSMutableArray* geofences = [NSMutableArray array];
        while (![scanner isAtEnd]) {
            // 一行づつ読み込んでいく
            [scanner scanUpToCharactersFromSet:chSet intoString:&line];
            NSArray* items = [line componentsSeparatedByString:@","];
            // カウント数が少なければ飛ばす。
            if([items count] == 0) continue;
            if (isHeader) {
                // 1行目は読み飛ばし
                isHeader = false;
                continue;
            }

            SSBPGeofence* geofence = [SSBPGeofence new];
            NSInteger i = 0;
            BOOL isBase = false;
            BOOL sameDefLocale = false;
            BOOL sameLocale = false;
            for (NSString* item in items) {
                NSString* word = [self removeStartAndEndQuotes:item];
                if (i == 0) { // id
                    geofence.geofenceId = word;
                    if (geofence.geofenceId.length == 0) {
                        geofence = nil;
                        break;
                    }

                    if (![self checkSame:geofence.geofenceId val2:baseId]) {
                        isBase = true;
                        baseId = geofence.geofenceId;
                        setLocale = false;
                    } else {
                        isBase = false;
                    }
                }

                switch (i) {
                    case 1: // message
                        geofence.geofenceMessage = word;
                        break;
                    case 2: // latitude
                        geofence.latitude = word;
                        break;
                    case 3: // longitude
                        geofence.longitude = word;
                        break;
                    case 4: // radius
                        if (isBase) {
                            geofence.radius = [word doubleValue];
                        }
                        break;
                    case 5: // start_at
                        if (isBase) {
                            geofence.geofenceStartAt = [self makeUTCDateTimeFromString:word];
                        }
                        break;
                    case 6: // end_at
                        if (isBase) {
                            geofence.geofenceEndAt = [self makeUTCDateTimeFromString:word];
                        }
                        break;
                    case 7: // updated_at
                        //最終更新日として処理
                    {
                        if (isBase) {
                            NSDate* date = [self makeUTCDateTimeFromString:word];
                            if (update == nil) {
                                update = date;
                            } else {
                                NSComparisonResult chk_interval = [update compare:date];
                                if (chk_interval == NSOrderedAscending) { // update < date
                                    update = date;
                                }
                            }
                        }
                    }
                        break;
                    case 8: // locale_id
                        sameDefLocale = [self checkSame:defLocaleId val2:word];
                        sameLocale = [self checkSame:localeId val2:word];
                        break;
                    case 9: // locale_message
                        if (sameLocale && (word.length > 0)) {
                            // 該当言語対応
                            setLocale = true;
                            for (SSBPGeofence* _geofence in geofences) {
                                if ([self checkSame:_geofence.geofenceId val2:geofence.geofenceId]) {
                                    _geofence.geofenceMessage = word;
                                    break;
                                }
                            }
                        } else if (!setLocale && sameDefLocale && (word.length > 0)) {
                            // デフォルト言語対応
                            for (SSBPGeofence* _geofence in geofences) {
                                if ([self checkSame:_geofence.geofenceId val2:geofence.geofenceId]) {
                                    _geofence.geofenceMessage = word;
                                    break;
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
                i++;
            }
            if ((geofence != nil) && isBase) {
                [geofences addObject:geofence];
            }
        }

        if (update != nil) {
            lastUpdate = [self makeUTCDateTimeToString:update];
        }

        return [geofences copy];
    }
}

- (NSString*)getLastUpdate {
    return lastUpdate;
}

- (NSString*)getCsv:(NSString*)fileNameWithoutExtension {
    @autoreleasepool {
        NSString* csvFile = [[NSBundle mainBundle] pathForResource:fileNameWithoutExtension ofType:@"csv"];
        NSData* csvData = [NSData dataWithContentsOfFile:csvFile];
        return [[NSString alloc] initWithData:csvData encoding:NSUTF8StringEncoding];
    }
}

- (NSString*)makeUTCDateTimeToString:(NSDate*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
        [formatter setLocale:[NSLocale systemLocale]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString* strDate = [formatter stringFromDate:date];
        if (strDate) {
            return strDate;
        } else {
            return @"";
        }
    }
}

- (NSDate*)makeUTCDateTimeFromString:(NSString*)date {
    @autoreleasepool {
        NSDateFormatter* formatter = [NSDateFormatter new];
        [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian]];
        [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
        [formatter setLocale:[NSLocale systemLocale]];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        return [formatter dateFromString:date];
    }
}

- (BOOL)checkSame:(NSString*)val1 val2:(NSString*)val2 {
    if ((val1 == nil) && (val2 == nil)) return true;
    else if (val1 == nil) return false;
    else if (val2 == nil) return false;
    else if ([val1 compare:val2] == NSOrderedSame) return true;
    else return false;
}

- (NSString*)removeStartAndEndQuotes:(NSString*)inputStr {
    NSRange firstQuote = [inputStr rangeOfString:@"\""];
    NSRange lastQuote = [inputStr rangeOfString:@"\"" options:NSBackwardsSearch];

    if ((firstQuote.location == 0) && (lastQuote.location == (inputStr.length - 1))) {
        inputStr = [inputStr substringWithRange:NSMakeRange(1, inputStr.length - 2)];
    }
    return inputStr;
}
@end
