//
//  WKBrowserViewController.m
//
//  Created by Ayumi Togashi on 2016/06/17.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define UIKitLocalizedString(key) [[NSBundle bundleWithIdentifier:@"com.apple.UIKit"] localizedStringForKey:key value:@"" table:nil]

#import "WKBrowserViewController.h"

#import "VideoViewController.h"

@implementation WKBrowserViewController {
    __weak IBOutlet UIView* webBase;
    __weak IBOutlet UIView* webWait;

    __weak IBOutlet UIButton* btnBack;
    __weak IBOutlet UIButton* btnForward;
    __weak IBOutlet UIButton* btnReload;
    __weak IBOutlet UIButton* btnSafari;
    __weak IBOutlet UIButton* btnClose;

    WKWebView* webview;
}

- (void)awakeFromNib {
    [super awakeFromNib];

    self.url = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnForward != nil) {
        btnForward.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnReload != nil) {
        btnReload.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnSafari != nil) {
        btnSafari.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnClose != nil) {
        btnClose.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }

    // WKWebView インスタンスの生成
    WKWebViewConfiguration* configuration = [[WKWebViewConfiguration alloc] init];
    if ([configuration respondsToSelector:@selector(setAllowsInlineMediaPlayback:)]) {
        [configuration setAllowsInlineMediaPlayback:true]; // フルスクリーンモードに移行させない
    }
    if ([configuration respondsToSelector:@selector(setAllowsAirPlayForMediaPlayback:)]) {
        [configuration setAllowsAirPlayForMediaPlayback:true];
    }
    if ([configuration respondsToSelector:@selector(setMediaPlaybackAllowsAirPlay:)]) {
        [configuration setMediaPlaybackAllowsAirPlay:true];
    }
    if ([configuration respondsToSelector:@selector(setRequiresUserActionForMediaPlayback:)]) {
        [configuration setRequiresUserActionForMediaPlayback:true]; // 埋め込み動画の自動再生はさせない
    }
    if ([configuration respondsToSelector:@selector(setMediaPlaybackRequiresUserAction:)]) {
        [configuration setMediaPlaybackRequiresUserAction:true]; // 埋め込み動画の自動再生はさせない
    }
    if ([configuration respondsToSelector:@selector(setAllowsPictureInPictureMediaPlayback:)]) {
        [configuration setAllowsPictureInPictureMediaPlayback:true];
    }

    webview = [[WKWebView alloc] initWithFrame:CGRectZero configuration:configuration];
    [webview setTranslatesAutoresizingMaskIntoConstraints:false];
    if ([webview respondsToSelector:@selector(setAllowsLinkPreview:)]) {
        [webview setAllowsLinkPreview:true];
    }
    [webview setAllowsBackForwardNavigationGestures:true]; // Flip動作設定

    if (webBase != nil) {
        [webBase insertSubview:webview atIndex:0];

        // Autolayout
        NSDictionary* views = NSDictionaryOfVariableBindings(webview);
        [webBase addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[webview(>=0)]-0-|"
                                                                        options:0
                                                                        metrics:nil
                                                                          views:views]];
        [webBase addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[webview(>=0)]-0-|"
                                                                        options:0
                                                                        metrics:nil
                                                                          views:views]];
    }

    webview.navigationDelegate = self;

    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.url] cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:10.0];
    [webview loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    webview.navigationDelegate = self;
}

- (void)viewDidDisappear:(BOOL)animated {
    [self stopActivityIndicator];
    [webview stopLoading];
    webview.navigationDelegate = nil;

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return true;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    UIDeviceOrientation rotate = [UIDevice currentDevice].orientation;
    switch (rotate) {
        case UIDeviceOrientationPortrait:
            return UIInterfaceOrientationPortrait;
            break;
        case UIDeviceOrientationLandscapeLeft:
            return UIInterfaceOrientationLandscapeRight;
            break;
        case UIDeviceOrientationLandscapeRight:
            return UIInterfaceOrientationLandscapeLeft;
            break;
        default:
            return UIInterfaceOrientationPortrait;
            break;
    }
}

#pragma mark -
#pragma mark IBOutlet Events

- (IBAction)didPushBack:(UIButton*)sender {
    [webview goBack];
}

- (IBAction)didPushForward:(UIButton*)sender {
    [webview goForward];
}

- (IBAction)didPushReload:(UIButton*)sender {
    // キャッシュをクリアする必要がある場合、この方法しかなさそう
    //[[NSURLCache sharedURLCache] removeAllCachedResponses];
    [webview reload];
}

- (IBAction)didPushSafari:(UIButton*)sender {
    [self showAlert:2 title:@"" message:NSLocalizedString(@"captionSafariMessage", @"") handler:^(UIAlertAction *action) {
        NSURL* URL = webview.URL;
        [[UIApplication sharedApplication] openURL:URL];
    }];
}

- (IBAction)didPushClose:(UIButton*)sender {
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

#pragma mark -
#pragma mark Private

- (void)startActivityIndicator {
    webWait.hidden = false;

    [[UIApplication sharedApplication]setNetworkActivityIndicatorVisible:true];
    [self updateBrowserButtonStatus];
}

- (void)stopActivityIndicator {
    webWait.hidden = true;

    [[UIApplication sharedApplication]setNetworkActivityIndicatorVisible:false];
    [self updateBrowserButtonStatus];
}

// ボタンの状態を更新
- (void)updateBrowserButtonStatus {
    btnBack.enabled = webview.canGoBack;
    btnForward.enabled = webview.canGoForward;
}

#pragma mark -
#pragma mark WKNavigationDelegate override

// ページ読み込みが開始された時
- (void)webView:(WKWebView*)webView didStartProvisionalNavigation:(WKNavigation*)navigation {
    //NSLog(@"webView didStartProvisionalNavigation");
    [self startActivityIndicator];
}

// ページ読み込みが完了した時
- (void)webView:(WKWebView*)webView didFinishNavigation:(WKNavigation*)navigation {
    //NSLog(@"webView didFinishNavigation");
    [self stopActivityIndicator];
    NSString* strUrl = webview.URL.absoluteString;
    NSLog(@"FinishLoad url:%@", strUrl);
    NSString* strTitle = webview.title;
    NSLog(@"FinishLoad title:%@", strTitle);

    // バウンスをさせないためのおまじない
    webView.scrollView.bounces = false;
}

// 遷移開始時
- (void)webView:(WKWebView*)webView didCommitNavigation:(WKNavigation*)navigation {
    //NSLog(@"webView didCommitNavigation");
}

// 遷移中にエラーが発生した時
- (void)webView:(WKWebView*)webView didFailNavigation:(WKNavigation*)navigation withError:(NSError*)error {
    NSLog(@"webView didFailNavigation:");
    [self stopActivityIndicator];
    NSLog(@"  %@", [error description]);
    NSLog(@"  code(%ld)", (long)error.code);
}

// javascriptとかtimeoutで止まった場合？
- (void)webViewWebContentProcessDidTerminate:(WKWebView*)webView {
    //NSLog(@"webView webViewWebContentProcessDidTerminate");
    [webview reload];
}

// リダイレクトされた時
- (void)webView:(WKWebView*)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation*)navigation {
    //NSLog(@"webView didReceiveServerRedirectForProvisionalNavigation");
}

// Webサイトにリクエストを送る前に判断
- (void)webView:(WKWebView*)webView decidePolicyForNavigationAction:(WKNavigationAction*)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    //NSLog(@"webView decidePolicyForNavigationAction");

    NSLog(@"webView request:%@", navigationAction.request);
    NSLog(@"webView navigationType(%ld)", (long)navigationAction.navigationType);

    // なぜか動かなくなってしまったため、下記のように明記するように修正
    NSURL* url = navigationAction.request.URL;
    if ([url.scheme isEqualToString:@"tel"]) {
        [self stopActivityIndicator];
        [webview stopLoading];

        if ([[UIApplication sharedApplication] canOpenURL:[navigationAction.request URL]]) {
            NSString* message = [navigationAction.request.URL.relativeString stringByReplacingOccurrencesOfString:@"tel:" withString:@""];
            [self showAlert:1 title:@"" message:message handler:^(UIAlertAction *action) {
                [[UIApplication sharedApplication]openURL:url];
            }];
        }
        decisionHandler(WKNavigationActionPolicyCancel);
        return;
    }

    if (![url.scheme isEqualToString:@"http"] && ![url.scheme isEqualToString:@"https"] && ![url.scheme isEqualToString:@"file"]) {
        if ([[UIApplication sharedApplication]canOpenURL:url]) {
            [self stopActivityIndicator];
            [webview stopLoading];
            if (navigationAction.navigationType != UIWebViewNavigationTypeLinkClicked) {
                [self.navigationController popViewControllerAnimated:false];
            }
            [[UIApplication sharedApplication]openURL:url];

            decisionHandler(WKNavigationActionPolicyCancel);
            return;
        }
    }

    // iOS8以降から、動画再生のviewが終了しても生き残るようになったので、回避させる方法として以下の対応
    // iOS8未満も、この方法がすっきり動作で良好と思われる
    // サポートする拡張子に変動がある場合は増減すること
    // ただし、ブラウザでも対応できないavi/mpeg/mpv/amr/oggは動作しないが、VideoViewControllerで吸収させるものとする
    if (navigationAction.navigationType == UIWebViewNavigationTypeLinkClicked) {
        NSArray* supported = [NSArray arrayWithObjects:@"mp4", @"3gp", @"mov", @"avi", @"mpeg", @"mpv", @"aac", @"amr", @"mp3", @"aiff", @"caf", @"m4a", @"ogg", @"wav", nil];
        NSString* path = [url absoluteString];
        NSString* ext = [path pathExtension];

        if ([supported containsObject:ext]) {
            [self stopActivityIndicator];
            [webview stopLoading];

            dispatch_async(dispatch_get_main_queue(), ^{
                VideoViewController* video = [VideoViewController new];
                video.url = path;
                video.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
                [self presentViewController:video animated:true completion:nil];
            });
            decisionHandler(WKNavigationActionPolicyCancel);
            return;
        }
    }

    decisionHandler(WKNavigationActionPolicyAllow); //これがないとcrash
}

// Webサイトからレスポンスが帰ってきた後に判断
- (void)webView:(WKWebView*)webView decidePolicyForNavigationResponse:(WKNavigationResponse*)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    //NSLog(@"webView decidePolicyForNavigationResponse");

    decisionHandler(WKNavigationResponsePolicyAllow); //これがないとcrash
}

// 認証が必要な時
- (void)webView:(WKWebView*)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge*)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential* _Nullable))completionHandler {
    //NSLog(@"webView didReceiveAuthenticationChallenge");

    NSString* hostName = webView.URL.host;
    NSString* authenticationMethod = [[challenge protectionSpace] authenticationMethod];
    if ([authenticationMethod isEqualToString:NSURLAuthenticationMethodDefault]
        || [authenticationMethod isEqualToString:NSURLAuthenticationMethodHTTPBasic]
        || [authenticationMethod isEqualToString:NSURLAuthenticationMethodHTTPDigest]) {
        NSString* pos = UIKitLocalizedString(@"OK");
        NSString* neg = UIKitLocalizedString(@"Cancel");
        NSString* title = @"Authentication Challenge";
        NSString* message = [NSString stringWithFormat:@"%@ requires user name and password", hostName];
        UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField* textField) {
            textField.placeholder = @"User";
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField* textField) {
            textField.placeholder = @"Password";
            textField.secureTextEntry = true;
        }];
        [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
            NSString* userName = ((UITextField*)alertController.textFields[0]).text;
            NSString* password = ((UITextField*)alertController.textFields[1]).text;
            NSURLCredential* credential = [NSURLCredential credentialWithUser:userName password:password persistence:NSURLCredentialPersistenceForSession];
            completionHandler(NSURLSessionAuthChallengeUseCredential, credential);
        }]];
        [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:^(UIAlertAction* action) {
            completionHandler(NSURLSessionAuthChallengeCancelAuthenticationChallenge, nil);
        }]];
        dispatch_async(dispatch_get_main_queue(), ^{
            // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
            UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
            while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
                baseView = baseView.presentedViewController;
            }
            [baseView presentViewController:alertController animated:true completion:nil];
        });
    } else if ([authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
        completionHandler(NSURLSessionAuthChallengePerformDefaultHandling, nil);
    } else {
        completionHandler(NSURLSessionAuthChallengeCancelAuthenticationChallenge, nil);
    }
}

//ページ読み込み時にエラーが発生した時
- (void)webView:(WKWebView*)webView didFailProvisionalNavigation:(WKNavigation*)navigation withError:(NSError*)error {
    [self stopActivityIndicator];

    NSLog(@"webView didFailProvisionalNavigation:");
    NSLog(@"%@", [error description]);
    NSLog(@"code(%ld)", (long)error.code);

    // AppStoreへのリンクの場合
    if ((error.code == 102) && [error.domain isEqualToString:@"WebKitErrorDomain"]) {
        return;
    }

    if (error.code == NSURLErrorCancelled) {
        return;
    }

    @try {
        NSString* title = [error.userInfo objectForKey:@"NSErrorFailingURLStringKey"];
        NSString* message = [error.userInfo objectForKey:@"NSLocalizedDescription"];

        [self showAlert:0 title:title message:message handler:nil];
    } @catch (NSException* exception) {
        NSLog(@"Custom Alert Error : %@", exception.description);
    } @finally {
    }
}

#pragma mark -
#pragma mark View Change

- (void)showAlert:(NSInteger)type title:(NSString*)title message:(NSString*)message handler:(void (^ __nullable)(UIAlertAction *action))handler {
    NSString* pos = nil;
    NSString* neg = nil;

    if (type == 0) { // Fail Load
        pos = UIKitLocalizedString(@"OK");
        neg = nil;
    } else if (type == 1) { // Open tel:
        pos = NSLocalizedString(@"captionTelButton", @"");
        neg = UIKitLocalizedString(@"Cancel");
    } else if (type == 2) { // Open Safari
        pos = NSLocalizedString(@"captionSafariButton", @"");
        neg = UIKitLocalizedString(@"Cancel");
    } else {
        return;
    }

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:handler]];
    if (neg != nil) {
        [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:nil]];
    }

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

@end
