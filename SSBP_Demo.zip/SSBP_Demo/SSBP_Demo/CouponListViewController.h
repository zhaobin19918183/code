//
//  CouponListViewController.h
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SSBPSdkIF.h"

@interface CouponListViewController : UIViewController<SSBPSdkIFDelegate, UITableViewDelegate, UITableViewDataSource>

@end
