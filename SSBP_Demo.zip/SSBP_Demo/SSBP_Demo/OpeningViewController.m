//
//  OpeningViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#import "OpeningViewController.h"

#import "TabBarControllerEx.h"

@implementation OpeningViewController {
    BOOL isClear;
    NSDate* startTime;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    isClear = false;

    [SSBPSdkIF sharedInstance].delegateIF = self;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    startTime = [NSDate date];
    // オープニング画面の後でアンケート処理を行う場合、applicationNewActive完了まで待つ必要があります。
    // ssbpScannerDidFinishCheckMasterを受け取ってから遷移するようにしてください。
    [[SSBPSdkIF sharedInstance] applicationNewActive];

    // 待つ必要がないのであれば、一定時間後に遷移する処理で問題ありません。
    // ネットワーク接続が確立しない場合、timeoutまで待つことになります
    // setSessionParamで指定したtimeoutIntervalが長くて待てない場合はafterDelay時間を調整して下記処理を行う
    [self performSelector:@selector(startApp) withObject:nil afterDelay:5];
}

- (void)viewDidDisappear:(BOOL)animated {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(startApp) object:nil];

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark SSBPSdkIFDelegate override

- (void)ssbpSdkIFDidFailCheckMaster {
    [self proctimeCheck];
}

- (void)ssbpScannerDidFinishCheckMaster {
    [self proctimeCheck];
}

#pragma mark -
#pragma mark Delay Event

- (void)proctimeCheck {
    NSDate* now = [NSDate date];
    float sec = [now timeIntervalSinceDate:startTime];

    if (sec < 2) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self performSelector:@selector(startApp) withObject:nil afterDelay:2];
        });
    } else {
        [self startApp];
    }
}

- (void)startApp {
    [SSBPSdkIF sharedInstance].delegateIF = nil;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(startApp) object:nil];

    dispatch_async(dispatch_get_main_queue(), ^{
        TabBarControllerEx* tabView = [self.storyboard instantiateViewControllerWithIdentifier:@"TabViewID"];
        tabView.selectedIndex = self.nextPage;
        [self presentViewController:tabView animated:true completion:nil];
    });
}

@end
