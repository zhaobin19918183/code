//
//  SettingViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#import "SettingViewController.h"

#import "SettingPickerButton.h"

@implementation SettingViewController {
    __weak IBOutlet UIButton* btnBack;

    __weak IBOutlet UIView* base;
    __weak IBOutlet UIScrollView* scroll;

    ActionText* actionText;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }

    actionText = [[ActionText alloc] initWithFrame:CGRectZero];
    [actionText setView:self.view.frame.size];
    [self.view addSubview:actionText];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [SSBPSdkIF sharedInstance].delegateIF = self;

    actionText.delegateAT = self;

    [[SSBPSdkIF sharedInstance] getAttributes];
}

- (void)viewDidDisappear:(BOOL)animated {
    actionText.delegateAT = nil;

    [super viewDidDisappear:animated];
}

- (void)dealloc {
    for (UIView* view in self.view.subviews) {
        [view removeFromSuperview];
    }
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Events

- (IBAction)backTap:(UIButton*)sender {
    [[SSBPSdkIF sharedInstance] updateDeviceInfo];
}

- (IBAction)tapPickerButton:(SettingPickerButton*)sender {
    NSArray* keys = [sender.dic allKeys];
    for (int i = 0; i < keys.count; i++) {
        NSString* key = keys[i];
        NSString* value = [[SSBPSdkIF sharedInstance].attrAnswers objectForKey:key];
        if ([[SSBPSdkIF sharedInstance] checkSame:value val2:@"1"]) {
            [actionText showPickerView:sender.tagString key:key dic:sender.dic];
            return;
        }
    }

    [actionText showPickerView:sender.tagString key:nil dic:sender.dic];
}

- (IBAction)tapCheckButton:(DrawButton*)sender {
    sender.selected = !sender.selected;
    
    if (sender.selected) {
        [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"1" forKey:sender.tagString];
    } else {
        [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"0" forKey:sender.tagString];
    }
}

#pragma mark -
#pragma mark Set View

- (void)createView {
    @autoreleasepool {
        for (UIView* subView in [scroll subviews]) {
            [subView removeFromSuperview];
        }

        CGRect base_rect = [base bounds];

        // サイズ関連
        CGFloat baseMargin = 10;
        CGFloat lblWidth = base_rect.size.width * 0.9;
        CGFloat lblHeight = lblWidth * 0.08;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            lblHeight = lblWidth * 0.05;
        }
        CGFloat lblFontSize = (int)(lblHeight / 1.6);

        CGFloat btnWidth = base_rect.size.width * 0.8;
        CGFloat btnHeight = btnWidth * 0.3;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            btnHeight = btnWidth * 0.18;
        }

        CGFloat chkWidth = base_rect.size.width * 0.8;
        CGFloat chkHeight = chkWidth * 0.2;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            chkHeight = chkWidth * 0.1;
        }

        CGFloat labelX = (base_rect.size.width - lblWidth) / 2;
        CGFloat btnX = (base_rect.size.width - btnWidth) / 2;
        CGFloat itemY = baseMargin;

        // タイトルとボタンを貼り付ける
        NSInteger qNum = [SSBPSdkIF sharedInstance].attrQuestions.count;
        NSInteger btnNum = 0;
        NSInteger chkNum = 0;

        for (int index = 0; index < qNum; index++) {
            SSBPQuestion* question = [[SSBPSdkIF sharedInstance].attrQuestions objectAtIndex:index];

            CGRect label_rect = CGRectMake(labelX, itemY + (lblHeight * index) + (btnHeight * btnNum) + (chkHeight * chkNum), lblWidth, lblHeight);
            UILabel* label = [[UILabel alloc] initWithFrame:label_rect];
            label.backgroundColor = [UIColor clearColor];
            label.font = [UIFont systemFontOfSize:lblFontSize];
            label.textAlignment = NSTextAlignmentLeft;
            label.textColor = [UIColor blackColor];
            label.numberOfLines = 1;
            label.lineBreakMode = NSLineBreakByTruncatingTail;
            label.text = question.attrDescription;
            [scroll addSubview:label];

            if (question.multipleAllowed != 1) {
                btnNum++;
                [self addPickerButton:question btnX:btnX itemY:itemY + label_rect.origin.y + label_rect.size.height btnAreaWidth:btnWidth btnAreaHeight:btnHeight];
            } else {
                chkNum += question.answers.count;
                [self addCheckButton:question btnX:btnX itemY:itemY + label_rect.origin.y + label_rect.size.height btnAreaWidth:chkWidth btnAreaHeight:chkHeight];
            }
        }

        // サイズ判定
        CGFloat sumHeight = itemY * 2 + (lblHeight * qNum) + (btnHeight * btnNum) + (chkHeight * chkNum);
        BOOL isOver = (sumHeight > base_rect.size.height);

        if (!isOver) {
            [scroll setContentSize:base_rect.size];
        } else {
            [scroll setContentSize:CGSizeMake(base_rect.size.width, sumHeight)];
        }

        scroll.bounces = false;
    }
}

- (void)addPickerButton:(SSBPQuestion*)question btnX:(CGFloat)btnX itemY:(CGFloat)itemY btnAreaWidth:(CGFloat)btnAreaWidth btnAreaHeight:(CGFloat)btnAreaHeight {
    CGFloat btnMargin = btnAreaHeight * 0.2;
    CGFloat btnHeight = btnAreaHeight - (btnMargin * 2);
    CGFloat btnFontSize = (int)(btnHeight / 2.5);

    NSMutableDictionary* dic = [NSMutableDictionary dictionary];
    for (int i = 0; i < question.answers.count; i++) {
        SSBPAnswer* answer = [question.answers objectAtIndex:i];
        [dic setObject:answer.answerBody forKey:answer.answerId];
    }

    SettingPickerButton* btn = [SettingPickerButton buttonWithType:UIButtonTypeCustom];
    btn.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [btn setTitleColor:RGBA(0, 0, 0, 1.0) forState:UIControlStateNormal];
    [btn setTitleColor:RGBA(0, 0, 0, 0.6) forState:UIControlStateHighlighted];
    [btn.titleLabel setTextAlignment:NSTextAlignmentCenter];
    btn.titleLabel.numberOfLines = 1;

    btn.dic = dic;
    btn.tagString = question.attrId;
    [btn setTitle:NSLocalizedString(@"captionPickerDefault", @"") forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:btnFontSize]; // iPhone=16.0
    btn.titleLabel.adjustsFontSizeToFitWidth = true;

    btn.frame = CGRectMake(btnX, itemY, btnAreaWidth, btnHeight);
    btn.topColor = RGBA(252, 202, 63, 1);
    btn.bottomColor = RGBA(252, 202, 63, 1);
    btn.borderColor = RGBA(160, 160, 160, 0.8);
    btn.borderWidth = 1.0;
    btn.cornerRadius = 6.0;

    [btn addTarget:self action:@selector(tapPickerButton:) forControlEvents:UIControlEventTouchUpInside];
    [scroll addSubview:btn];
}

- (void)addCheckButton:(SSBPQuestion*)question btnX:(CGFloat)btnX itemY:(CGFloat)itemY btnAreaWidth:(CGFloat)btnAreaWidth btnAreaHeight:(CGFloat)btnAreaHeight {
    CGFloat btnMargin = btnAreaHeight * 0.2;
    CGFloat btnHeight = btnAreaHeight - (btnMargin * 2);
    CGFloat btnFontSize = (int)(btnHeight / 2);

    for (int i = 0; i < question.answers.count; i++) {
        SSBPAnswer* answer = [question.answers objectAtIndex:i];
        DrawButton* btn = [DrawButton buttonWithType:UIButtonTypeCustom];
        btn.imageView.contentMode = UIViewContentModeScaleAspectFit;

        [btn setImage:[self pathForResource:@"unchecked"] forState:UIControlStateNormal];
        [btn setImage:[self pathForResource:@"checked"] forState:UIControlStateSelected];
        [btn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
        [btn setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];

        [btn setTitleColor:RGBA(0, 0, 0, 1.0) forState:UIControlStateNormal];
        [btn setTitleColor:RGBA(0, 0, 0, 0.6) forState:UIControlStateHighlighted];
        [btn.titleLabel setTextAlignment:NSTextAlignmentLeft];
        btn.titleLabel.numberOfLines = 1;

        btn.tagString = answer.answerId;
        [btn setTitle:answer.answerBody forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:btnFontSize];
        btn.titleLabel.adjustsFontSizeToFitWidth = true;

        btn.frame = CGRectMake(btnX, itemY + (btnAreaHeight * i), btnAreaWidth, btnHeight);

        [btn addTarget:self action:@selector(tapCheckButton:) forControlEvents:UIControlEventTouchUpInside];
        [scroll addSubview:btn];
    }
}

- (void)updateView {
    for (id subview in scroll.subviews) {
        if ([[subview class] isSubclassOfClass:[SettingPickerButton class]]) {
            SettingPickerButton* btn = (SettingPickerButton*)subview;
            NSString* title = @"";
            for (SSBPQuestion* question in [SSBPSdkIF sharedInstance].attrQuestions) {
                if ([[SSBPSdkIF sharedInstance] checkSame:btn.tagString val2:question.attrId]) {
                    for (int i = 0; i < question.answers.count; i++) {
                        SSBPAnswer* answer = [question.answers objectAtIndex:i];
                        NSString* value = [[SSBPSdkIF sharedInstance].attrAnswers objectForKey:answer.answerId];
                        if ([[SSBPSdkIF sharedInstance] checkSame:value val2:@"1"]) {
                            title = answer.answerBody;
                        }
                    }
                }
            }
            if (title.length > 0) {
                [btn setTitle:title forState:UIControlStateNormal];
            } else {
                [btn setTitle:NSLocalizedString(@"captionPickerDefault", @"") forState:UIControlStateNormal];
            }
        } else if ([[subview class] isSubclassOfClass:[DrawButton class]]) {
            DrawButton* btn = (DrawButton*)subview;
            NSString* value = [[SSBPSdkIF sharedInstance].attrAnswers objectForKey:btn.tagString];
            if ([[SSBPSdkIF sharedInstance] checkSame:value val2:@"1"]) {
                btn.selected = true;
            } else {
                btn.selected = false;
            }
        }
    }
}

#pragma mark -
#pragma mark SSBPSdkIFDelegate override

- (void)ssbpSdkIFDidFinishGetAttributes {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self createView];
        [[SSBPSdkIF sharedInstance] getDeviceInfo];
    });
}

- (void)ssbpSdkIFDidFinishGetDeviceInfo {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self updateView];
    });
}

- (void)ssbpSdkIFDidFinishUpdateDeviceInfo {
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

#pragma mark -
#pragma mark ActionTextDelegate override

- (void)actionTextDidSelect:(NSString*)type selected:(NSString*)selected {
    for (id subview in scroll.subviews) {
        if ([[subview class] isSubclassOfClass:[SettingPickerButton class]]) {
            SettingPickerButton* btn = (SettingPickerButton*)subview;
            if ([[SSBPSdkIF sharedInstance] checkSame:btn.tagString val2:type]) {
                NSArray* keys = [btn.dic allKeys];
                for (NSString* key in keys) {
                    [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"0" forKey:key];
                }
                [[SSBPSdkIF sharedInstance].attrAnswers setObject:@"1" forKey:selected];
                [btn setTitle:[btn.dic objectForKey:selected] forState:UIControlStateNormal];
            }
        }
    }
}

#pragma mark -
#pragma mark Etc

- (UIImage*)pathForResource:(NSString*)fname {
    @autoreleasepool {
        if (fname.length > 0) {
            UIImage* image = [UIImage imageNamed:fname];
            return image;
        } else return nil;
    }
}

@end
