//
//  InfoViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define UIKitLocalizedString(key) [[NSBundle bundleWithIdentifier:@"com.apple.UIKit"] localizedStringForKey:key value:@"" table:nil]

#import "InfoViewController.h"

#import "VideoViewController.h"
#import "BrowserViewController.h"
#import "WKBrowserViewController.h"

@implementation InfoViewController {
    __weak IBOutlet UIButton* btnBack;
    __weak IBOutlet UILabel* lblTitle;

    __weak IBOutlet UIImageView* imageInfo;
    __weak IBOutlet UITextView* textInfo;

    __weak IBOutlet UIButton* btnUrl;

    __weak IBOutlet NSLayoutConstraint* imageRatio;

    NSInteger status;

    SSBPHttpRequester* requester;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnUrl != nil) {
        btnUrl.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [SSBPSdkIF sharedInstance].delegateIF = nil;

    [self getInfo];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Event

- (IBAction)backTap:(UIButton*)sender {
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

- (IBAction)urlTap:(UIButton*)sender {
    @autoreleasepool {
        if (status == 3) {
            [self showAlert];
        } else {
            [self useDB];

            TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:self.contentId];
            if (content != nil) {
                [self openContent:content.contentURL];
            }
        }
    }
}

#pragma mark -
#pragma mark DB's

- (void)useDB {
    @autoreleasepool {
        [[SSBPSdkIF sharedInstance] useContent:self.contentId];
    }
}

#pragma mark -
#pragma mark Info View

- (void)getInfo {
    if (self.contentId.length == 0) return;

    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
            __block TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:self.contentId];
            if (content == nil) return;

            if (content.contentMainImage != nil) {
                imageInfo.image = [[UIImage alloc] initWithData:content.contentMainImage];
                [self setImageViewAspect];
            } else {
                // 非同期で処理
                if ([content.contentMainImageURL hasPrefix:@"http"]) {
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                        if (requester == nil) requester = [SSBPHttpRequester new];
                        [requester httpRequestGet:content.contentMainImageURL withParam:nil completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
                            if ((error != nil) || (data == nil)) return;
                            dispatch_async(dispatch_get_main_queue(), ^{
                                content.contentMainImage = data;
                                [[SSBPContentIF sharedInstance] addContent:content];
                                imageInfo.image = [[UIImage alloc] initWithData:data];
                                [self setImageViewAspect];
                            });
                        }];
                    });
                }
            }

            [lblTitle setText:content.contentName];
            [textInfo setText:content.contentMainDescription];
            status = content.status;
        }
    });
}

- (void)setImageViewAspect {
    [imageInfo removeConstraint:imageRatio];
    CGFloat ratio = imageInfo.image.size.height / imageInfo.image.size.width;
    if (ratio > 1) ratio = 1;

    imageRatio = [NSLayoutConstraint constraintWithItem:imageInfo attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:imageInfo attribute:NSLayoutAttributeWidth multiplier:ratio constant:0];
    [imageInfo addConstraint:imageRatio];
    [imageInfo updateConstraints];
}

#pragma mark -
#pragma mark View Change

- (void)showAlert {
    NSString* pos = UIKitLocalizedString(@"OK");
    NSString* neg = UIKitLocalizedString(@"Cancel");

    NSString* message = NSLocalizedString(@"captionInfoExpiredMessage", @"");

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
        [[SSBPSdkIF sharedInstance] removeContent:self.contentId];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self backTap:nil];
        });
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:nil]];

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

// 拡張子判定による、WebBrowser/MediaPlayerの呼び出し
- (void)openContent:(NSString*)strUrl {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSArray* supported = [NSArray arrayWithObjects:@"mp4", @"3gp", @"mov", @"avi", @"mpeg", @"mpv", @"aac", @"amr", @"mp3", @"aiff", @"caf", @"m4a", @"ogg", @"wav", nil];
        NSString* ext = [strUrl pathExtension];

        if ([supported containsObject:ext]) {
            VideoViewController* video = [VideoViewController new];
            video.url = strUrl;
            video.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
            [self presentViewController:video animated:true completion:NULL];
        } else {
            BrowserViewController* browserView = [self.storyboard instantiateViewControllerWithIdentifier:@"BrowserViewID"];
            //WKBrowserViewController* browserView = [self.storyboard instantiateViewControllerWithIdentifier:@"WKBrowserViewID"];
            browserView.url = strUrl;
            [self presentViewController:browserView animated:true completion:nil];
        }
    });
}

#pragma mark -
#pragma mark Etc

- (UIImage*)pathForResource:(NSString*)fname {
    @autoreleasepool {
        if (fname.length > 0) {
            UIImage* image = [UIImage imageNamed:fname];
            return image;
        } else return nil;
    }
}

@end
