//
//  FacilityMaskViewController.h
//
//  Created by Ayumi Togashi on 2017/04/06.
//  Copyright © 2017年 Switch Smile co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SSBPSdkIF.h"

@interface FacilityMaskViewController : UIViewController

@end
