//
//  CouponListViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define UIKitLocalizedString(key) [[NSBundle bundleWithIdentifier:@"com.apple.UIKit"] localizedStringForKey:key value:@"" table:nil]

#import "CouponListViewController.h"

#import "CouponCell.h"

#import "CouponViewController.h"

@implementation CouponListViewController {
    __weak IBOutlet UIButton* btnBack;
    __weak IBOutlet UIButton* btnClear;

    __weak IBOutlet UITableView* tblView;

    NSArray* Coupons;

    SSBPHttpRequester* requester;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (btnBack != nil) {
        btnBack.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    if (btnClear != nil) {
        btnClear.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [SSBPSdkIF sharedInstance].delegateIF = self;

    tblView.dataSource = self;
    tblView.delegate = self;
    
    [self loadDB];
}

- (void)viewDidDisappear:(BOOL)animated {
    tblView.dataSource = nil;
    tblView.delegate = nil;

    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Event

- (IBAction)backTap:(UIButton*)sender {
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:true completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

- (IBAction)clearTap:(UIButton*)sender {
    [self showAlert];
}

#pragma mark -
#pragma mark SSBPSdkIFDelegate override

- (void)ssbpSdkIFAddContent:(NSString*)contentId {
    TSsbpContent* content = [[SSBPContentIF sharedInstance] getInnerContent:contentId];
    if ([[SSBPSdkIF sharedInstance] checkSame:content.contentAction val2:@"coupon"]) {
        [self loadDB];
    }
}

#pragma mark -
#pragma mark DB's

- (void)loadDB {
    @autoreleasepool {
        Coupons = nil;
        Coupons = [[SSBPContentIF sharedInstance] getInnerContents:@"coupon"];
        [tblView reloadData];
    }
}

- (void)deleteDB:(NSInteger)index {
    if (index < 0) return;
    if (Coupons == nil) return;
    if (Coupons.count <= index) return;

    @autoreleasepool {
        TSsbpContent* ssbpContent = [Coupons objectAtIndex:index];
        [[SSBPSdkIF sharedInstance] removeContent:ssbpContent.contentId];
        [self loadDB];
    }
}

#pragma mark -
#pragma mark DataSource's

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
    if (Coupons == nil) {
        return 0;
    } else {
        return Coupons.count;
    }
}

#pragma mark -
#pragma mark TableView's

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    UITableViewCell* cell = [self getCell:indexPath];
    return cell;
}

- (UITableViewCell*)getCell:(NSIndexPath*)indexPath {
    CouponCell* couponCell = [tblView dequeueReusableCellWithIdentifier:@"CouponCell" forIndexPath:indexPath];
    if (couponCell == nil) couponCell = [tblView dequeueReusableCellWithIdentifier:@"CouponCell"];
    if ((Coupons != nil) && (Coupons.count > indexPath.row)) {
        [self setCouponCell:couponCell indexPath:indexPath];
    }
    return couponCell;
}

- (void)setCouponCell:(UITableViewCell*)cell indexPath:(NSIndexPath*)indexPath {
    @autoreleasepool {
        __block TSsbpContent* content = [Coupons objectAtIndex:indexPath.row];
        NSDate* startAt = [[SSBPSdkIF sharedInstance] makeUTCDateTimeFromString:content.contentStartAt];
        NSDate* endAt = [[SSBPSdkIF sharedInstance] makeUTCDateTimeFromString:content.contentEndAt];

        __block CouponCell* couponCell = (CouponCell*)cell;

        couponCell.logo.image = [self pathForResource:@"dummy_logo"];
        if (content.contentSubImage != nil) {
            couponCell.logo.image = [[UIImage alloc] initWithData:content.contentSubImage];
        } else {
            // 非同期で処理
            if ([content.contentSubImageURL hasPrefix:@"http"]) {
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    if (requester == nil) requester = [SSBPHttpRequester new];
                    [requester httpRequestGet:content.contentSubImageURL withParam:nil completionHandler:^(NSData* data, NSURLResponse* response, NSError* error) {
                        if ((error != nil) || (data == nil)) return;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            content.contentSubImage = data;
                            [[SSBPContentIF sharedInstance] addContent:content];
                            couponCell.logo.image = [[UIImage alloc] initWithData:content.contentSubImage];
                        });
                    }];
                });
            }
        }

        couponCell.title.text = content.contentName;
        couponCell.expireDate.text= [NSString stringWithFormat:@"%@ : %@ - %@", NSLocalizedString(@"captionCouponValidityPeriod", @""), [[SSBPSdkIF sharedInstance] makeLocaleDateToString:startAt], [[SSBPSdkIF sharedInstance] makeLocaleDateToString:endAt]];
        [couponCell setStatus:content.status];
    }
}

- (void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:true];

    @autoreleasepool {
        if (Coupons.count > indexPath.row) {
            TSsbpContent* ssbpContent = [Coupons objectAtIndex:indexPath.row];
            if (ssbpContent.status != 1) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    CouponViewController* couponView = [self.storyboard instantiateViewControllerWithIdentifier:@"CouponViewID"];
                    couponView.contentId = ssbpContent.contentId;
                    [self presentViewController:couponView animated:true completion:nil];
                });
            } else {
                [self showAlert:1 index:indexPath.row mes:NSLocalizedString(@"captionCouponDeleteMessage", @"")];
            }
        }
    }
}

- (void)tableView:(UITableView*)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath*)indexPath {
    @autoreleasepool {
        if (editingStyle == UITableViewCellEditingStyleDelete) {
            [self deleteDB:indexPath.row];
        } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        }
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer*)gestureRecognizer shouldReceiveTouch:(UITouch*)touch {
    // おまじない
    // 子viewのtapを期待通りに動作させるための対策
    if ((touch.view != gestureRecognizer.view) && [touch.view isKindOfClass:[UIControl class]]) {
        return false;
    }
    return true;
}

#pragma mark -
#pragma mark View Change

- (void)showAlert:(NSInteger)type index:(NSInteger)index mes:(NSString*)mes{
    NSString* pos = UIKitLocalizedString(@"OK");
    NSString* neg = UIKitLocalizedString(@"Cancel");

    if (type == 0) {
        neg = nil;
    } else if (type == 1) {
        pos = NSLocalizedString(@"captionDeleteButton", @"");
    }

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:@"" message:mes preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
        if (type == 1) {
            [self deleteDB:index];
        }
    }]];
    if (neg != nil) {
        [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:nil]];
    }

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

- (void)showAlert {
    NSString* pos = UIKitLocalizedString(@"OK");
    NSString* neg = UIKitLocalizedString(@"Cancel");

    NSString* title = NSLocalizedString(@"captionCouponClearTitle", @"");
    NSString* message = NSLocalizedString(@"captionCouponClearMessage", @"");

    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:pos style:UIAlertActionStyleDefault handler:^(UIAlertAction* action) {
        [[SSBPSdkIF sharedInstance] clearActionContent:@"coupon"];
        [self loadDB];
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:neg style:UIAlertActionStyleCancel handler:nil]];

    // 複数だったり見失ったりの回避のために、現在のViewControllerを探す処理を行う
    UIViewController* baseView = [UIApplication sharedApplication].keyWindow.rootViewController;
    while ((baseView.presentedViewController != nil) && !baseView.presentedViewController.isBeingDismissed) {
        baseView = baseView.presentedViewController;
    }
    [baseView presentViewController:alertController animated:true completion:nil];
}

#pragma mark -
#pragma mark Etc

- (UIImage*)pathForResource:(NSString*)fname {
    @autoreleasepool {
        if (fname.length > 0) {
            UIImage* image = [UIImage imageNamed:fname];
            return image;
        } else return nil;
    }
}

@end
