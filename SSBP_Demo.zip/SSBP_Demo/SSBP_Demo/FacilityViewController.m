//
//  FacilityViewController.m
//
//  Created by Ayumi Togashi on 2016/04/22.
//  Copyright © 2016年 Switch Smile co.,ltd. All rights reserved.
//

#define RGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#define SHOW_GOAL_BUTTON 0

#import "FacilityViewController.h"

#import "GoalListViewController.h"
#import "NavigationViewController.h"

@implementation FacilityViewController {
    __weak IBOutlet UIView* base;
    __weak IBOutlet UIScrollView* scroll;

    NSArray* Facilities;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [SSBPSdkIF sharedInstance].delegateIF = nil;

    [self loadDB];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

#pragma mark -
#pragma mark Rotate Event

-(BOOL)shouldAutorotate {
    return false;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED < 90000
- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#else
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}
#endif

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#pragma mark -
#pragma mark IBOutlet Events

- (void)facilityButtonDidPush:(UIButton*)button {
    @autoreleasepool {
        NSInteger tag = button.tag;
        if (tag < 0) {
            NavigationViewController* navigationView = [self.storyboard instantiateViewControllerWithIdentifier:@"NavigationViewID"];
            navigationView.goalNodeId = @"";
            [self presentViewController:navigationView animated:true completion:nil];
        } else {
            if (Facilities.count > tag) {
                TSsbpFacility* facility = [Facilities objectAtIndex:tag];
                GoalListViewController* goalListView = [self.storyboard instantiateViewControllerWithIdentifier:@"GoalListViewID"];
                goalListView.facilityId = facility.facilityId;
                [self presentViewController:goalListView animated:true completion:nil];
            }
        }
    }
}

#pragma mark -
#pragma mark DB's

- (void)loadDB {
    @autoreleasepool {
        Facilities = nil;

        if (SHOW_GOAL_BUTTON) {
            Facilities = [[SSBPScannerManager sharedManager] getInnerFacilities];
        }

        [self createView];
    }
}

#pragma mark -
#pragma mark Set View

- (void)createView {
    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
            for (UIView* subView in [scroll subviews]) {
                [subView removeFromSuperview];
            }

            CGRect base_rect = [base bounds];

            // サイズ関連
            CGFloat baseMargin = 10;
            CGFloat btnMargin = 8;
            CGFloat btnWidth = base_rect.size.width * 0.9;
            if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) btnWidth = btnWidth / 2;
            CGFloat btnHeight = btnWidth * 0.22;
            CGFloat fontSize = (int)(btnHeight / 3.5);

            // サイズ判定
            CGFloat sumHeight = baseMargin * 2;
            NSInteger btnNum = 1;
            if (SHOW_GOAL_BUTTON) btnNum += Facilities.count;

            if (btnNum > 0) {
                sumHeight += btnNum * btnHeight;
            }

            BOOL isOver = false;
            if (sumHeight > base_rect.size.height) isOver = true;

            CGFloat btnX = (base_rect.size.width - btnWidth) / 2;
            CGFloat btnY = baseMargin;
            [scroll setContentSize:CGSizeMake(base_rect.size.width, sumHeight)];

            if (!isOver) {
                btnY = (base_rect.size.height - btnNum * btnHeight) / 2;
                [scroll setContentSize:base_rect.size];
            }

            // 現在地ナビボタン--
            TSsbpFacility* facility = [TSsbpFacility new];
            facility.facilityName = NSLocalizedString(@"captionNowButton", @"");
            UIButton* btn = [self setButton:facility btnType:-1];
            CGRect btn_rect = CGRectMake(btnX, btnY, btnWidth, btnHeight);
            btn.frame = CGRectInset(btn_rect, btnMargin, btnMargin);
            btn.tag = -1;
            btn.titleLabel.font = [UIFont systemFontOfSize:fontSize]; // iPhone=16.0
            btn.titleLabel.adjustsFontSizeToFitWidth = true;
            [btn addTarget:self action:@selector(facilityButtonDidPush:) forControlEvents:UIControlEventTouchUpInside];
            [scroll addSubview:btn];
            // --現在地ナビボタン

            // 施設ボタン--
            if (SHOW_GOAL_BUTTON) {
                for (int index = 0; index < Facilities.count; index++) {
                    TSsbpFacility* facility = [Facilities objectAtIndex:index];
                    UIButton* btn = [self setButton:facility btnType:0];
                    CGRect btn_rect = CGRectMake(btnX, btnY + (btnHeight * (index + 1)), btnWidth, btnHeight);
                    btn.frame = CGRectInset(btn_rect, btnMargin, btnMargin);
                    btn.tag = index;
                    btn.titleLabel.font = [UIFont systemFontOfSize:fontSize]; // iPhone=16.0
                    btn.titleLabel.adjustsFontSizeToFitWidth = true;
                    [btn addTarget:self action:@selector(facilityButtonDidPush:) forControlEvents:UIControlEventTouchUpInside];
                    [scroll addSubview:btn];
                }
            }
            // --施設ボタン

            scroll.bounces = false;
        }
    });
}

- (UIButton*)setButton:(TSsbpFacility*)facility btnType:(NSInteger)btnType {
    @autoreleasepool {
        UIButton* btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        if (btnType == 0) {
            [btn setBackgroundColor:RGBA(103, 192, 254, 1)];
        } else {
            [btn setBackgroundColor:RGBA(252, 202, 63, 1)];
        }
        btn.layer.borderWidth = 0.75;
        btn.layer.borderColor = RGBA(160, 160, 160, 0.8).CGColor;
        btn.layer.cornerRadius = 4;

        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn setTitleColor:RGBA(255, 255, 255, 0.6) forState:UIControlStateHighlighted];
        [btn setTitle:facility.facilityName forState:UIControlStateNormal];
        [btn.titleLabel setTextAlignment:NSTextAlignmentCenter];
        btn.titleLabel.numberOfLines = 1;
        btn.titleLabel.preferredMaxLayoutWidth = btn.bounds.size.width - 10;
        return btn;
    }
}

@end
