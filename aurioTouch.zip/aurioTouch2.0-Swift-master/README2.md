# aurioTouch

Translated by OOPer in cooperation with shlab.jp, on 2015/2/1.

Based on
<https://developer.apple.com/library/ios/samplecode/aurioTouch/Introduction/Intro.html#//apple_ref/doc/uid/DTS40007770>
2014-04-09.

As this is a line-by-line translation from the original sample code, "redistribute the Apple Software in its entirety and without modifications" would apply. See license terms in each file.
Some faults caused by my translation may exist. Not all features tested.
You should not contact to Apple or SHLab(jp) about any faults caused by my translation.

===========================================================================
BUILD REQUIREMENTS:

Xcode 8 beta 5

===========================================================================
Files under PublicUtility are not fully translated. Their license terms are kept there just to indicate the original files.
Some utility files are used to make line-by-line translation easier. They have another license terms.
See license terms in each file.
